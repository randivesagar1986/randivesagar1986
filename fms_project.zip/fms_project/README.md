# FMS7

This starter pack will provide feature driven solution structure for a react application.

## Prerequisites

- Node
- npm
- yarn

## Features
- Feature driven folder structure
- Redux state handling
- Customizable configurations
- ui-kit is pre-installed
- Examples for ui-kit usage is available
- CI pipeline script is available
- Deployment script is available
- githooks are added
- Linting is configured
- Unit test is configured

## Commands

### Set up

Clone this repository

```bash

git clone https://essnextgen@dev.azure.com/essnextgen/Platform/_git/ui-react-starter

cd ui-react-starter
```

Please run the below command for installing the dependencies.

```bash

npm install

```

### Build
Please run the below command for building the application

```bash

npm run build

```

> Please check the `dist` folder for the output


### Run
Please run the below command for running the application

```bash

npm start

```

### Test

Please run the below command for running unit test cases for this library

```bash

npm run test

```

> Please check the coverage folder for the reports


## Usage

Once you cloned the repo in your local, pls copy the entire files/folder from ui-react-starter into your target folder.

- Update name, description and repository details in package.json file
- Update the image name in pipeline yaml file

## Fix for two copies of React issue

If two copies of React are reported by your console,
Add following to `baseConfig.resolve` in `webpack.base.js` of your application , so that webpack resolves the import to the application's React copy.

Make sure the pathname inside `path.resolve` method is correctly pointing to the `react` of your application's `node_modules`.

```
 alias: {
      react: path.resolve(__dirname, "../../node_modules/react"),
 }
```

For more information and troubleshooting steps, check the below links
- https://github.com/facebook/react/issues/13991
- https://legacy.reactjs.org/warnings/invalid-hook-call-warning.html
