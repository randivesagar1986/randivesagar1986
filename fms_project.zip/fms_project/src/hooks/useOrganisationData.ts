import { getOrganisationList, orgListActions, TOrgData } from "@/store/state/organisationList.slice";
import { useAppSelector } from "@/store/store";
import { ISelectedItem } from "@essnextgen/ui-kit";
import { useEffect } from "react";
import { useDispatch } from "react-redux";

const useOrganisationData = () => {
  const { organisationList, callOrgListApi, selectedOrgData } = useAppSelector((state) => state.organisationList);
  const { setSelectedOrgData } = orgListActions;
  const dispatch = useDispatch();

  // To get the current organisation id from local storage
  const getCurrentOrgId = () => {
    // we are initially setting org id in local storage once logged in
    const orgId = localStorage.getItem("organisationId");
    return orgId;
  };

  // To get the single organisation data based on the organisation id
  const getSingleOrgData = (orgId: string) => {
    if (organisationList?.length > 0 && orgId !== null) {
      const orgData = organisationList.find((data: TOrgData) => data.organisationId === orgId);

      if (orgData) {
        return orgData;
      }
    }
    return null;
  };

  // To select the organisation based on this showing school name in header
  const selectOrg = (data: ISelectedItem) => {
    dispatch(setSelectedOrgData(data));
  };

  // To call the organisation list api
  useEffect(() => {
    if (callOrgListApi) {
      dispatch(getOrganisationList());
    }
  }, [callOrgListApi]);

  // To select the organisation based on the organisation id once api is called
  useEffect(() => {
    const orgId = getCurrentOrgId();
    if (organisationList?.length > 0 && orgId !== null) {
      const orgData = getSingleOrgData(orgId);
      const name = `${orgData?.name} (${orgData?.dfeCode})`;

      if (orgData) {
        const orgObj = {
          text: name,
          value: orgData?.organisationId
        };

        selectOrg(orgObj);
      }
    }
  }, [organisationList]);

  return {
    getCurrentOrgId,
    getSingleOrgData,
    selectOrg,
    selectedOrgData,
    organisationList,
    callOrgListApi
  };
};

export default useOrganisationData;
