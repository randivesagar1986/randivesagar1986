import { useAppSelector } from "@/store/store";
import React from "react";

const useUserAccess = () => {
  const { userMappedData } = useAppSelector((state) => state.userAccessRights);
  const saRights = userMappedData?.sa_rights;
  const mappedUser = userMappedData?.mapped_users;
  const currUserMapped = userMappedData?.curr_user_mapped;

  const checkUserAccess = () => {
    if (saRights === "F") {
      return mappedUser === "F" || currUserMapped === "F";
    }
    return currUserMapped === "F" && mappedUser !== "F";
  };

  const userDontHaveAccess = checkUserAccess();

  return {
    userDontHaveAccess
  };
};

export default useUserAccess;
