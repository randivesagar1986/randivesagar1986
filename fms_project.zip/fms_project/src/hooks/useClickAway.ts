import { RefObject, SyntheticEvent, useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useHistory, useLocation } from "react-router-dom";
import { useAppSelector } from "@/store/store";
import { getSessionItem, setToSession } from "@/utils/getDataSource";
import { actions as sidebarMenuActions } from "@/components/SidebarMenu/state/SidebarMenu.slice";

type TClickAway = {
  isDirty: boolean;
  popupTitle?: string;
  popupMessage?: string;
  popupType?: string | MODAL_TYPE;
  yesCallback: (target: HTMLElement) => void;
  noCallback: (target: HTMLElement) => void;
  cancelCallback: Function;
  unblockCondition?: boolean;
  excludePath?: string[];
  isNonReturnYesCallback?: boolean;
};

/* eslint-disable import/prefer-default-export */
export const useClickAway = ({
  isDirty,
  yesCallback,
  noCallback,
  popupTitle,
  popupMessage,
  cancelCallback,
  unblockCondition = true,
  excludePath = [],
  isNonReturnYesCallback = false
}: TClickAway) => {
  const dispatch = useDispatch();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const globalLocation = useLocation();
  const [historyRedirect, setHistoryRedirect] = useState(true);
  const { confirm } = useAppSelector((state) => state.ui);
  const targetRef = useRef<HTMLElement | null>(null);
  const homeRef = useRef<HTMLElement | null>(null);
  const menuRef = useRef<HTMLElement | null>(null);
  const title = popupTitle || t("common.simsFMSModule");
  const message = popupMessage || t("alertMessage.keepChangesMsg");
  const { setIsSidebarOpen, setShowProfileMenu } = sidebarMenuActions;

  useEffect(() => {
    const handleClick = (event: any) => {
      const anchorTag = event.target.closest("a"); // Find closest Anchor (or self)
      if (!anchorTag) {
        //    return false;
      }
      const target = event.target as HTMLButtonElement;
      let parentNode = target.parentNode as HTMLElement;
      const isRelevantLink = ["link-normal", "home-link"].some((cls) => target.classList.contains(cls));
      const isHomeLink = ["home-link"].some((cls) => target.classList.contains(cls));
      if ((event.key === "Enter" || event.key === " ") && target.dataset.testid === "header-menu-icon-btn") {
        parentNode = target as HTMLElement;
      }
      const isRelevantParent = target.closest(".switch-menu") || target.closest(".click-away-add");
      const isIconParent =
        parentNode?.classList?.contains("essui-icon") &&
        parentNode.classList.contains("essui-icon--24") &&
        parentNode.classList.contains("essui-icon--neutral-900");
      const isMenuParentClass =
        parentNode?.classList?.contains("essui-header-button") || target?.classList?.contains("essui-header-button");
      // eslint-disable-next-line no-nested-ternary
      const isMenuLable = parentNode?.classList?.contains("essui-header-button")
        ? parentNode?.getAttribute("aria-label") === "menu button"
        : target?.classList?.contains("essui-header-button")
        ? target?.getAttribute("aria-label") === "menu button"
        : false;
      const helpButtonIconClick = target.closest(".essui-header__notification-help");
      const isProfileMenu = target.closest(".essui-avatar");

      if (
        !confirm?.enable &&
        isDirty &&
        (isRelevantLink || isRelevantParent || isIconParent || isProfileMenu || isMenuLable) &&
        !helpButtonIconClick
      ) {
        event.preventDefault();
        event.stopPropagation();
        if (isHomeLink) {
          homeRef.current = target;
        }
        if (isIconParent || isMenuLable) {
          menuRef.current = target;
        }
        targetRef.current = target;

        if (isProfileMenu) {
          setToSession("clickAwayMenu", true);
        } else {
          setToSession("clickAwayMenu", false);
        }
        showConfirmPopup(title || "", message || "", yesCallback, noCallback, cancelCallback);
      } else {
        // If the user clicks on yes or no, the isOutsideClicked function in header.logic is triggered.
        // Using Redux, we are making the menu open, but when clicking outside, the menu was not closing after the click-away popup.
        // To address this, we use session storage and conditions to close the menu.
        if (getSessionItem("clickAwayMenu") !== true && !isProfileMenu) {
          dispatch(setShowProfileMenu(false));
        }
        setToSession("clickAwayMenu", false);
      }

      return true;
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " ") {
        handleClick(e as any); // Type assertion since `handleClick` expects MouseEvent
      }
    };

    document.addEventListener("click", handleClick);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("click", handleClick);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isDirty, yesCallback, noCallback, popupTitle, popupMessage, dispatch]);

  useEffect(() => {
    // eslint-disable-next-line consistent-return
    const unblock = history.block((location, action) => {
      const { pathname } = history.location;
      if (
        (location.state as { redirect?: boolean })?.redirect !== true &&
        isDirty &&
        historyRedirect &&
        pathname !== location.pathname &&
        !location.pathname.includes("general-ledger-setup") &&
        unblockCondition &&
        !checkInBlockHistory(location.pathname, [...excludePath]) // For GL path
      ) {
        setHistoryRedirect(false);
        setToSession("redirectPath", location.pathname);
        return false;
      }
    });

    return () => {
      unblock();
    };
  }, [history, isDirty, historyRedirect]);

  useEffect(() => {
    setToSession("clickAwayMenu", false);
  }, []);

  const reDispatchEvent = (target: any) => {
    if (!target.hasAttribute("href")) {
      if (target.closest(".essui-header__menu")) {
        dispatch(setIsSidebarOpen(true));
        return;
      }

      if (target.closest(".essui-avatar")) {
        setTimeout(() => {
          dispatch(setShowProfileMenu(true));
          setToSession("clickAwayMenu", false);
        }, 500);
        return;
      }

      history.push(getSessionItem("redirectPath"));
      setHistoryRedirect(true);
      setToSession("redirectPath", "");
      return;
    }
    try {
      const evt = document.createEvent("MouseEvents");
      evt.initEvent("click", true, false);
      target.dispatchEvent(evt);
    } catch (e) {
      console.error("Error dispatching event:", e);
    }
  };

  const checkInBlockHistory = (currentPath: string, conditionPath: string[]) => {
    if (!conditionPath || conditionPath.length === 0) {
      return false;
    }
    return conditionPath.some((path) => currentPath.includes(path));
  };

  const showConfirmPopup = (
    title: string,
    message: string,
    yesCallback: Function,
    noCallback: Function,
    cancelCallback: Function
  ) => {
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        message,
        title,
        type: MODAL_TYPE.CONFIRMV2,
        className: "click-away-confirm-popup",
        yesCallback: async () => {
          if (isNonReturnYesCallback) {
            yesCallback(targetRef.current);
          } else {
            const isValid = await yesCallback(targetRef.current);
            if (isValid) {
              reDispatchEvent(targetRef.current);
            } else {
              dispatch(setIsSidebarOpen(false));
              dispatch(setShowProfileMenu(false));
              setToSession("clickAwayMenu", false);
            }
            setHistoryRedirect(true);
          }
        },
        noCallback: () => {
          noCallback(targetRef.current);
          reDispatchEvent(targetRef.current);
        },
        isCancelBtnEnable: true,
        cancelCallback: () => {
          cancelCallback(targetRef.current);
          setHistoryRedirect(true);
          setToSession("redirectPath", "");
          dispatch(setIsSidebarOpen(false));
          dispatch(setShowProfileMenu(false));
        }
      })
    );
  };

  return {
    homeRef,
    targetRef,
    menuRef,
    historyRedirect,
    setHistoryRedirect,
    showConfirmPopup,
    reDispatchEvent,
    setIsSidebarOpen,
    setShowProfileMenu
  };
};
