import { useState } from "react";

export default () => {
  const [resolver, setResolver] = useState<(value: unknown) => void>();

  const setPromise = (callback: (resolve?: any) => void) =>
    new Promise<boolean>((resolve, rejects) => {
      callback(resolve);
      setResolver((prev: any) => resolve);
    });

  const result = {
    setPromise,
    resolve: resolver
  };
  return result;
};
