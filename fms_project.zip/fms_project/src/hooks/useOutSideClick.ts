import { MutableRefObject, useEffect, useRef, useState } from "react";

export type UseOutsideClickReturnType = {
  isOutsideClicked: boolean;
  previouslyFocusedElement: MutableRefObject<HTMLElement>;
};

export const useCustomOutsideClick: (ref: any) => UseOutsideClickReturnType = (ref: any): UseOutsideClickReturnType => {
  const [isOutside, setIsOutside]: any = useState(null);
  const previouslyFocusedElement: MutableRefObject<HTMLElement> = useRef<any>(null);

  useEffect(() => {
    const handleClickOutside: (event: any) => void = (event: any) => {
      previouslyFocusedElement.current = document.activeElement as HTMLElement;

      if (ref.current && !ref.current.contains(event.target)) {
        setIsOutside(true);
      } else {
        setIsOutside(false);
      }
    };
    // Bind the event listener
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleClickOutside);
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleClickOutside);
    };
  }, [ref]);

  return { isOutsideClicked: isOutside, previouslyFocusedElement };
};
