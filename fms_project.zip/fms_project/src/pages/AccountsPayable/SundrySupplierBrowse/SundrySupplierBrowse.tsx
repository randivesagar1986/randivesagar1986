import { Button, ButtonColor, ButtonSize, Grid, GridItem } from "@essnextgen/ui-kit";
import Layout from "@/components/Layout/Layout";
import HelpButton from "@/components/OpenLinkButton/HelpButton";

const SundrySupplierBrowse = () => (
  <>
    <Layout
      pageTitle="Sundry Supplier Browse"
      className=""
    >
      <Grid
        justify="space-between"
        className=""
      >
        <GridItem
          sm={4}
          md={4}
          lg={6}
          xl={6}
        >
          <HelpButton
            identifier="testIdentifier"
            labelName="Help"
          />
        </GridItem>
        <GridItem
          sm={4}
          md={4}
          lg={6}
          xl={6}
        >
          <div className="d-flex justify-end flex-wrap justify-start-resposnive gap-8">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
            >
              Cancel
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
            >
              Add
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
            >
              Select
            </Button>
          </div>
        </GridItem>
      </Grid>
    </Layout>
  </>
);
export default SundrySupplierBrowse;
