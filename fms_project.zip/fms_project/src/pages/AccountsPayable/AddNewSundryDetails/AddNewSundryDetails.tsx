import { Button, ButtonColor, ButtonSize, FormLabel, Grid, GridItem } from "@essnextgen/ui-kit";
import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import HelpButton from "@/components/OpenLinkButton/HelpButton";

const AddNewSundrySupplier = () => (
  <>
    <Layout
      pageTitle="Add New Sundry Supplier"
      className=""
    >
      <Grid className="mb-8">
        <GridItem
          sm={4}
          md={8}
          lg={5}
          xl={5}
          xxl={5}
        >
          <div>
            <FormLabel forId="txtName">Name</FormLabel>
            <Input
              searchable
              value="Sundary Supplier 10 lorem ipsum dummy text toshow MaxCharacters"
              id="txtName"
            />
          </div>
        </GridItem>
      </Grid>
      <Grid className="mb-8">
        <GridItem
          sm={4}
          md={8}
          lg={3}
          xl={3}
          xxl={3}
        >
          <div>
            <FormLabel
              forId="txtAddressLine1"
              className=""
            >
              Address Line 1
            </FormLabel>
            <Input
              searchable
              value="Address line one text here max"
              id="txtAddressLine1"
            />
          </div>
        </GridItem>
      </Grid>
      <Grid className="mb-8">
        <GridItem
          sm={4}
          md={8}
          lg={3}
          xl={3}
          xxl={3}
        >
          <div>
            <FormLabel
              forId="txtAddressLine2"
              className=""
            >
              Address Line 2
            </FormLabel>
            <Input
              searchable
              value="Address line two text here max"
              id="txtAddressLine2"
            />
          </div>
        </GridItem>
      </Grid>
      <Grid>
        <GridItem
          sm={4}
          md={8}
          lg={3}
          xl={3}
          xxl={3}
        >
          <div>
            <FormLabel
              forId="txtAddressLine3"
              className=""
            >
              Address Line 3
            </FormLabel>
            <Input
              searchable
              value="Address line three text here max"
              id="txtAddressLine3"
            />
          </div>
        </GridItem>
      </Grid>
      <Grid>
        <GridItem
          sm={4}
          md={8}
          lg={3}
          xl={3}
          xxl={3}
        >
          <div>
            <FormLabel
              forId="txtAddressLine4"
              className=""
            >
              Address Line 4
            </FormLabel>
            <Input
              searchable
              value="Address line four text here max"
              id="txtAddressLine4"
            />
          </div>
        </GridItem>
      </Grid>
      <Grid>
        <GridItem
          sm={4}
          md={8}
          lg={3}
          xl={3}
          xxl={3}
        >
          <div>
            <FormLabel
              forId="txtAddressLine5"
              className=""
            >
              Address Line 5
            </FormLabel>
            <Input
              searchable
              value="Address line five text here max"
              id="txtAddressLine5"
            />
          </div>
        </GridItem>
      </Grid>
      <Grid>
        <GridItem
          sm={4}
          md={8}
          lg={3}
          xl={3}
          xxl={3}
        >
          <div>
            <FormLabel
              forId="txtPostcode"
              className=""
            >
              Postcode
            </FormLabel>
            <Input
              searchable
              value="12345678"
              id="txtPostcode"
            />
          </div>
        </GridItem>
      </Grid>

      <Grid
        justify="space-between"
        className="mt-8"
      >
        <GridItem
          sm={1}
          md={4}
          lg={3}
          xl={3}
        >
          <HelpButton
            identifier="testIdentifier"
            labelName="Help"
          />
        </GridItem>
        <GridItem
          sm={3}
          md={4}
          lg={9}
          xl={9}
        >
          <div className="d-flex justify-end flex-wrap gap-8">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
            >
              Cancel
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
            >
              Save
            </Button>
          </div>
        </GridItem>
      </Grid>
    </Layout>
  </>
);
export default AddNewSundrySupplier;
