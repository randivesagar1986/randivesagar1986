import Input from "@/components/Input/Input";
// import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  DateInput,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  TextInput
} from "@essnextgen/ui-kit";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { Calendar } from "@carbon/icons-react";

const EditDeliveryLineDetails = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  return (
    <>
      <Layout
        className=""
        pageTitle="Edit Delivery Line Details"
      >
        <Grid className="row-gap-16">
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div className="essui-form-label mb-5">Part Number</div>
            <div>001</div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={9}
            xl={9}
          >
            <div className="essui-form-label mb-5">Item Description</div>
            <div>Test Description</div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div className="essui-form-label mb-5">Quantity Ordered</div>
            <div>250</div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={9}
            xl={9}
          >
            <div className="essui-form-label mb-5">Quantity Outstanding</div>
            <div>50</div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <FormLabel forId="txtQuantityDelivered">Quantity Delivered</FormLabel>
            <TextInput
              id="txtQuantityDelivered"
              className="width100"
              value="200"
            />
          </GridItem>
        </Grid>
      </Layout>
      <Layout isBreadcrumbRequired={false}>
        <Grid>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <HelpButton
              identifier="testIdentifier"
              labelName="Help"
            />
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="d-flex justify-end flex-wrap justify-start-resposnive gap-8">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
              >
                Cancel
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
              >
                Save
              </Button>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};
export default EditDeliveryLineDetails;
