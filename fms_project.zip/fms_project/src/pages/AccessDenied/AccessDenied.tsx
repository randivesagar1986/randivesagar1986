import Layout from "@/components/Layout/Layout";
import { Error } from "@carbon/icons-react";
import { ServiceUnavailable as ServiceUnavailablePage } from "@essnextgen/ui-error-pages-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Button, Grid, GridItem } from "@essnextgen/ui-kit";
import "./Style.scss";

type AccessDeniedProps = {
  submitCta?: () => void;
};

const AccessDenied = ({ submitCta }: AccessDeniedProps) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <>
      <div className="d-flex justify-center align-center access-denied wrapper__radius--0 ">
        <div className="w-500">
          <Grid container>
            <GridItem
              sm={4}
              md={8}
              lg={12}
              xl={12}
              className="d-flex align-center justify-center denied-icon"
            >
              <Error size={80} />
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={12}
              xl={12}
              className="essui-global-typography-default-h1"
            >
              {t("common.accessDenied")}
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={12}
              xl={12}
              className="mt-10 essui-global-typography-default-body newline"
            >
              {t("common.NoPermission")}
            </GridItem>
            {typeof submitCta === "function" && (
              <GridItem
                sm={4}
                md={8}
                lg={12}
                xl={12}
                className="mt-10 essui-global-typography-default-body newline btn-container"
              >
                <Button
                  onClick={submitCta}
                  className="logout-cta"
                >
                  {t("common.ok")}
                </Button>
              </GridItem>
            )}
          </Grid>
        </div>
      </div>
    </>
  );
};

AccessDenied.defaultProps = {
  submitCta: undefined
};
export default AccessDenied;
