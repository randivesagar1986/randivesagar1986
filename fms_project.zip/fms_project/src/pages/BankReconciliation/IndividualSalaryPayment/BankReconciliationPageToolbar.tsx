import { MailAll, CopyFile, TaskRemove } from "@carbon/icons-react";
import { Button, ButtonColor, ButtonSize, Grid, GridItem, NotificationStatus } from "@essnextgen/ui-kit";
import { RouteComponentProps, useHistory, withRouter } from "react-router-dom";

const BankReconciliationPageToolbar = () => {
  const history = useHistory();
  // To be delete this toolbar while implementing the actual functionality
  return (
    <>
      <Grid
        justify="flex-end"
        className="tools"
      >
        <GridItem>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            disabled
            onClick={async (e) => {}}
          >
            <MailAll size={22} />
          </Button>
        </GridItem>
      </Grid>
    </>
  );
};

export default withRouter(BankReconciliationPageToolbar);
