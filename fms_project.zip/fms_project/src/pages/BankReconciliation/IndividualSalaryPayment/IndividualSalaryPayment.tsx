import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  Grid,
  GridItem,
  TableUtility,
  TableWrapper,
  Tag,
  TagColor,
  TagSize,
  useTranslation
} from "@essnextgen/ui-kit";
import { UseTranslationResponse } from "react-i18next";
import Layout from "@/components/Layout/Layout";
import GridTableNew, { RowType } from "@/components/GridTableNew/GridTableNew";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { getCurrentFinancialYear, STATUS } from "@/types/UseStateType";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import CustomCell from "../BankReconciliationStatement/Grid/CustomCell";
import BankReconciliationToolbar from "./BankReconciliationToolbar";
import BankReconciliationPageToolbar from "./BankReconciliationPageToolbar";
import { getSIIndidualSalary, getSIPaymentDetailsIndividualSalary } from "../state/BankReconciliationStatement.slice";
import { contractDetailsColumnDef, paymentDetailsColumnDef } from "../BankReconciliationStatement/Grid/columnDef";
import "./Style.scss";

const IndividualSalaryPayment = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const [isAutoFocusInitially, setIsAutoFocusInitially] = useState(false);
  const historyState = history.location.state as any;
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    siStatus,
    siPaymentDetails,
    siIndividualSalaryList,
    selectedContractDetailsRow,
    siPaymentDetailsStatus,
    siIndividualSalaryContractHeader
  } = useAppSelector((state) => state.bankReconciliationStatement);

  const siView = historyState?.siView;
  const refNumber = historyState?.refNumber;
  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;

  useEffect(() => {
    dispatch(
      getSIIndidualSalary({
        Salarypaymentbatchid: siView,
        Yearid: getCurrentFinancialYear()
      })
    );
  }, [siView]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAutoFocusInitially(true); // Autofocus enabled after 3 seconds
    }, 3000);
  }, []);

  useEffect(() => {
    let timeoutId: any;
    if (siIndividualSalaryList) {
      timeoutId = setTimeout(() => {
        const element = document.getElementById(`rowIndex-contractDetailsGrid-0`);
        element?.focus();
      }, 100);
    }
    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    };
  }, [siIndividualSalaryList]);

  const onRowSelect: (row?: RowType | undefined) => void = (row) => {
    dispatch(
      getSIPaymentDetailsIndividualSalary({
        Salarypaymentid: row?.salary_payment_id
      })
    );
  };

  const getTagElement = () => (
    <div className="heading-tag">
      {refNumber && (
        <Tag
          text={String(refNumber).padStart(8, "0")}
          size={TagSize.Large}
          color={TagColor.Highlight}
        />
      )}
    </div>
  );

  const getPeriodMonth = () => {
    if (siIndividualSalaryContractHeader && siIndividualSalaryContractHeader.period_no) {
      return `${siIndividualSalaryContractHeader.period_no} ${siIndividualSalaryContractHeader.description}`;
    }
    return "-";
  };
  const numberFormatter: any = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const loaderConfig: loadingConfig = {};

  return (
    <>
      {siStatus === STATUS.LOADING ? (
        <Loader loadingConfig={loaderConfig} />
      ) : (
        <Layout
          pageTitle={t("bankReconciliation.individualSalaryPayment")}
          className="individual-salary-payment"
          isSubTitle={getTagElement()}
          rightContent={<BankReconciliationToolbar />}
          toolbar={<BankReconciliationPageToolbar />}
        >
          <Grid className="row-gap-16">
            <GridItem
              sm={4}
              md={4}
              lg={4}
              xl={4}
              xxl={4}
            >
              <div>
                <div className="essui-form-label mb-5">{t("common.date")}</div>
                <div>
                  {siIndividualSalaryContractHeader && siIndividualSalaryContractHeader.posting_date
                    ? new Date(siIndividualSalaryContractHeader.posting_date)
                        .toLocaleDateString("en-GB", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric"
                        })
                        .replace("Sept", "Sep")
                    : "-"}
                </div>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={4}
              xl={4}
              xxl={4}
            >
              <div>
                <div className="essui-form-label mb-5">{t("common.period")}</div>
                <div>{getPeriodMonth()}</div>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={4}
              xl={4}
              xxl={4}
            >
              <div>
                <div className="essui-form-label mb-5">{t("common.weekNumber")}</div>
                <div>
                  {siIndividualSalaryContractHeader && siIndividualSalaryContractHeader.week_no
                    ? siIndividualSalaryContractHeader.week_no
                    : "-"}
                </div>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={4}
              xl={4}
              xxl={4}
            >
              <div>
                <div className="essui-form-label mb-5">{t("common.paidFrom")}</div>
                <div>
                  {siIndividualSalaryContractHeader && siIndividualSalaryContractHeader.paid_from
                    ? siIndividualSalaryContractHeader.paid_from
                    : "-"}
                </div>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={4}
              xl={4}
              xxl={4}
            >
              <div className="essui-form-label mb-5 d-none-sm">&nbsp;</div>
              <div className="d-flex">
                <CheckBox
                  label={t("bankReconciliation.posted")}
                  disabled
                  isSelected={
                    siIndividualSalaryContractHeader ? siIndividualSalaryContractHeader.posted === "T" : false
                  }
                  id="txtCheckbox"
                />
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={4}
              xl={4}
              xxl={4}
            >
              <div>
                <div className="essui-form-label mb-5">{t("common.total")}</div>
                <div>
                  {siIndividualSalaryContractHeader && siIndividualSalaryContractHeader.total
                    ? numberFormatter.format(siIndividualSalaryContractHeader.total)
                    : "-"}
                </div>
              </div>
            </GridItem>
          </Grid>

          <div style={{ marginTop: "20px" }}>
            <TableWrapper>
              <TableUtility className="contract-details">
                {" "}
                {t("bankReconciliation.contractDetails")}
                <Button
                  className="button-sec"
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={() => console.log("Copy All Commitments clicked")}
                >
                  {t("bankReconciliation.copyAllCommitments")}
                </Button>
              </TableUtility>
              <GridTableNew
                id="contractDetailsGrid"
                dataTestId="contractDetailsGrid"
                customCell={CustomCell}
                columnDef={contractDetailsColumnDef}
                dataSource={siIndividualSalaryList}
                isLoading={false}
                isScrollable
                selectedRow={selectedContractDetailsRow}
                selectedRowHandler={onRowSelect}
              />
            </TableWrapper>
          </div>
          <div style={{ marginTop: "20px" }}>
            <TableWrapper>
              <TableUtility className="payment-details">
                {" "}
                {t("bankReconciliation.paymentdetails")}
                <Button
                  className="button-sec"
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={() => console.log("Copy All Commitments clicked")}
                >
                  {t("bankReconciliation.copyCommitments")}
                </Button>
              </TableUtility>
              <GridTableNew
                id="paymentDetailsGrid"
                dataTestId="paymentDetailsGrid"
                customCell={CustomCell}
                columnDef={paymentDetailsColumnDef}
                dataSource={siPaymentDetails}
                isLoading={siPaymentDetailsStatus !== STATUS.SUCCESS}
                isScrollable
                isAutoFocusInitially={isAutoFocusInitially}
              />
            </TableWrapper>
          </div>
        </Layout>
      )}
    </>
  );
};

export default IndividualSalaryPayment;
