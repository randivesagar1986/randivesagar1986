import {
  AddLarge,
  ArrowDown,
  ArrowUp,
  Printer,
  Save,
  /* eslint-disable camelcase */
  Thumbnail_2,
  Subtract,
  Undo,
  ScalesTipped
} from "@carbon/icons-react";
import { ButtonSize } from "@essnextgen/ui-kit";
import { RouteComponentProps, useHistory, useParams, withRouter } from "react-router-dom";
import Toolbar, { ToolbarType } from "@/components/Toolbar/Toolbar";

const BankReconciliationToolbar = () => {
  // To be delete this toolbar while implementing the actual functionality
  const buttons: ToolbarType[] = [
    {
      title: "Focus Mode",
      /* eslint-disable react/jsx-pascal-case */
      element: <Thumbnail_2 size={18} />,
      size: ButtonSize.Small,
      disabled: true,
      onClick: async () => {}
    },
    {
      title: "Previous Record",
      element: <ArrowUp size={18} />,
      size: ButtonSize.Small,
      disabled: true,
      onClick: async () => {}
    },
    {
      title: "Next Record",
      element: <ArrowDown size={18} />,
      size: ButtonSize.Small,
      id: "btnNextRec",
      disabled: true,
      onClick: async () => {}
    },
    {
      title: "Add Record",
      element: <AddLarge size={18} />,
      onClick: async () => {},
      disabled: true,
      size: ButtonSize.Small
    },
    {
      title: "Delete Record",
      element: <Subtract size={18} />,
      size: ButtonSize.Small,
      disabled: true,
      onClick: async () => {}
    },
    {
      title: "Save Record Changes",
      element: <Save size={18} />,
      onClick: async () => {},
      disabled: true,
      size: ButtonSize.Small
    },
    {
      title: "Undo Record Changes",
      element: <Undo size={18} />,
      size: ButtonSize.Small,
      disabled: true,
      onClick: async () => {}
    },
    {
      title: "Print Record",
      element: <Printer size={18} />,
      size: ButtonSize.Small,
      disabled: true,
      onClick: async () => {}
    },
    {
      title: "Verify Balances",
      element: <ScalesTipped size={18} />,
      size: ButtonSize.Small,
      disabled: true,
      onClick: async () => {}
    }
  ];

  return (
    <div className="bank-reconciliation-toolbar">
      <Toolbar buttons={buttons} />
    </div>
  );
};

export default withRouter(BankReconciliationToolbar);
