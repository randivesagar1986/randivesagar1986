import Layout from "@/components/Layout/Layout";
import { Button, ButtonColor, ButtonSize, Grid, GridItem, useTranslation } from "@essnextgen/ui-kit";
import { UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import "./Style.scss";

const BankReconciliationBacsView = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  return (
    <>
      <Layout pageTitle="BACS View">
        <Grid>
          <GridItem
            sm={12}
            md={8}
            lg={8}
            xl={8}
          >
            <p className="bacs__tag">{t("bankReconciliation.transferredLastYear")}</p>
          </GridItem>
          <GridItem
            sm={12}
            md={4}
            lg={4}
            xl={4}
            className="grid-items"
          >
            <Grid className="justify__content--between">
              <GridItem
                sm={4}
                md={4}
                lg={8}
                xl={8}
              >
                <div className="essui-form-label">{t("bankReconciliation.printedOn")}</div>
                <div className="mt-12">10 Feb 2023</div>
              </GridItem>

              <GridItem>
                <div className="essui-form-label">{t("bankReconciliation.cancelledOn")}</div>
                <div className="mt-12">-</div>
              </GridItem>
            </Grid>
          </GridItem>
        </Grid>
      </Layout>
      <Layout isBreadcrumbRequired={false}>
        <Grid>
          <GridItem
            sm={3}
            md={4}
            lg={6}
            xl={6}
          >
            <div>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Tertiary}
              >
                Help
              </Button>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};
export default BankReconciliationBacsView;
