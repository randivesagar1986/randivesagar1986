import Layout from "@/components/Layout/Layout";
import { UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Button, ButtonColor, ButtonSize, Grid, GridItem, useTranslation } from "@essnextgen/ui-kit";

const DebitCardPaymentView = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <Layout pageTitle="Debit Card Payment View">
      <Grid>
        <GridItem
          sm={3}
          md={4}
          lg={6}
          xl={6}
        >
          <div>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Tertiary}
            >
              {t("common.help")}
            </Button>
          </div>
        </GridItem>
      </Grid>
    </Layout>
  );
};
export default DebitCardPaymentView;
