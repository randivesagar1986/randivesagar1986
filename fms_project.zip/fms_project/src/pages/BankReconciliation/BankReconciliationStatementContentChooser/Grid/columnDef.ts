import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const statementContentChooserDef: TColumnDef = [
  {
    headerName: "Date",
    field: "item_date",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "Reference",
    field: "ref",
    sequence: true
  },
  {
    headerName: "Description",
    field: "description"
  },
  {
    headerName: "Type",
    field: "itemType"
  },
  {
    headerName: "Payments",
    field: "payamount",
    align: "right",
    sequence: true,
    cellRenderer: "GridCellLink",
    columnWidth: 10
  },
  {
    headerName: "Receipts",
    field: "rcvamount",
    sequence: true,
    cellRenderer: "GridCellLink",
    align: "right",
    columnWidth: 10
  }
];

export default statementContentChooserDef;
