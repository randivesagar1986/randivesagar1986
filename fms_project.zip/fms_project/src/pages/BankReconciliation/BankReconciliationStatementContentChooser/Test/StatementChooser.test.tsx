import { Provider } from "react-redux";
import { screen, render, waitFor, act, fireEvent } from "@testing-library/react";
import { Router } from "react-router-dom";
import { createMemoryHistory } from "history";
import configureStore from "redux-mock-store";
import userEvent from "@testing-library/user-event";
import { STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import React from "react";
import StatementChooser from "../statementChooser";

const { t } = useTranslation();

const history = createMemoryHistory();
history.push(
  "/UI/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/49/bankStatementId/1339/statement-content-chooser"
);
history.entries = history.entries.map((item, index) => {
  if (index === 0) {
    return {
      pathname:
        "/UI/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/49/bankStatementId/1339",
      search: "",
      hash: "",
      state: undefined,
      key: "brtcru"
    };
  }
  return item;
});

jest.mock("../../../../components/Breadcrumbs/Breadcrumbs", () => () => <div>breadcrumbs</div>);

jest.mock("../../../../components/GridTableNew/GridTableNew", () => ({
  __esModule: true,
  default: jest.fn((props) => (
    <div
      data-testid="unreconciledDetailsGrid"
      {...props}
    />
  ))
}));

jest.mock("../Grid/customCell", () => () => <div>customCell</div>);

jest.mock("../Grid/columnDef", () => [
  {
    headerName: "Date",
    field: "item_date",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "Reference",
    field: "ref",
    sequence: true
  }
]);

const mockOnCancelHandler = jest.fn();
const mockOnSaveHandler = jest.fn();
const mockOnFocusUnreconciled = jest.fn();
const mockHandleSequenceChange = jest.fn();
const mockMoveToReconcile = jest.fn();
const mockMoveAllRecordsToReconcile = jest.fn();
const mockRemoveRecordFromReconcile = jest.fn();
const mockRemoveAllRecordsFromReconcile = jest.fn();

let isShowArrowDown: boolean = false;
jest.mock("../useStatementContentChooser", () => () => {
  const actual = jest.requireActual("../useStatementContentChooser");
  const defaultCommon = {
    ...actual,
    t,
    handleSequenceChange: mockHandleSequenceChange,
    sccColumnDef: [
      {
        headerName: "Date",
        field: "item_date",
        cellRenderer: "GridCellLink",
        sequence: true
      },
      {
        headerName: "Reference",
        field: "ref",
        sequence: true
      }
    ],
    sequenceValue: "",
    bankReconStatus: "",
    selectedBankReconiledRow: null,
    selectedBankUnreconciledRow: null,
    onReconiledRowSelect: jest.fn(),
    onUnReconiledRowSelect: jest.fn(),
    unreconciledTotalReceipts: 0,
    reconciledTotalReceipts: 0,
    unreconciledTotalPayments: 0,
    reconciledTotalPayments: 0,
    unreconciledNetAmount: 0,
    reconciledNetAmount: 0,
    moveRecordToReconcile: mockMoveToReconcile,
    moveAllRecordsToReconcile: mockMoveAllRecordsToReconcile,
    removeRecordFromReconcile: mockRemoveRecordFromReconcile,
    removeAllRecordsFromReconcile: mockRemoveAllRecordsFromReconcile,
    reconciledDetails: [],
    unreconciledDetails: [],
    isShowArrowDown,
    setIsShowArrowDown: jest.fn(),
    lookingFor: "",
    lookingForCallback: jest.fn(),
    onFocusReconciled: mockOnFocusUnreconciled,
    onFocusUnreconciled: jest.fn(),
    onSaveHandler: mockOnSaveHandler,
    onCancelHandler: mockOnCancelHandler,
    historyState: {},
    numberFormatter: {
      format: jest.fn((num: number) => `${num}`)
    },
    closingBalance: 0,
    handleKeyDowInputn: jest.fn()
  };

  return defaultCommon;
});

const initialState = {};
const mockStore = configureStore();

const renderWithProviders = (ui: React.ReactElement, { store = mockStore(initialState) } = {}) => {
  const Wrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <Provider store={store}>
      <Router history={history}>{children}</Router>
    </Provider>
  );
  return render(ui, { wrapper: Wrapper });
};

describe("testing Statement Chooser component", () => {
  let store: any;
  beforeEach(() => {
    store = mockStore(initialState);
    jest.resetModules();
    isShowArrowDown = false;
  });

  describe("lebels sanity tests", () => {
    it("should render looking for label", () => {
      renderWithProviders(<StatementChooser />);
      const lookingForLable = screen.getByText(/common.lookingFor/i);
      expect(lookingForLable).toBeInTheDocument();
    });
    it("should render sequence label", () => {
      renderWithProviders(<StatementChooser />);
      const sequenceLabel = screen.getByText(/common.sequenceOrder/i);
      expect(sequenceLabel).toBeInTheDocument();
    });

    it("should render opening balance label", () => {
      renderWithProviders(<StatementChooser />);
      const openingBalLable = screen.getByText(/bankReconciliation.openingBalance/i);
      expect(openingBalLable).toBeInTheDocument();
    });
    it("should render closing balance label", () => {
      renderWithProviders(<StatementChooser />);
      const openingBalLable = screen.getByText(/bankReconciliation.openingBalance/i);
      expect(openingBalLable).toBeInTheDocument();
    });
    it("should render for label", () => {
      renderWithProviders(<StatementChooser />);
      const lookingForLable = screen.getByText(/common.lookingFor/i);
      expect(lookingForLable).toBeInTheDocument();
    });
  });

  describe("buttons sanity checks", () => {
    it("should render choose button", () => {
      renderWithProviders(<StatementChooser />);
      const chooseBtn = screen.getByRole("button", { name: "Choose" });
      expect(chooseBtn).toBeInTheDocument();
    });
    it("choose button should be enabled", () => {
      renderWithProviders(<StatementChooser />);
      const chooseBtn = screen.getByRole("button", { name: "Choose" });
      expect(chooseBtn).toBeEnabled();
    });
    it("should render choose all button", () => {
      renderWithProviders(<StatementChooser />);
      const chooseAllBtn = screen.getByRole("button", { name: "Choose all items" });
      expect(chooseAllBtn).toBeInTheDocument();
    });
    it("choose all button should be enabled ", () => {
      renderWithProviders(<StatementChooser />);
      const chooseAllBtn = screen.getByRole("button", { name: "Choose all items" });
      expect(chooseAllBtn).toBeEnabled();
    });
    it("should render remove button", () => {
      renderWithProviders(<StatementChooser />);
      const removeBtn = screen.getByRole("button", { name: "remove" });
      expect(removeBtn).toBeInTheDocument();
    });
    it("remove button should be enabled ", () => {
      renderWithProviders(<StatementChooser />);
      const removeBtn = screen.getByRole("button", { name: "remove" });
      expect(removeBtn).toBeEnabled();
    });
    it("should render remove all button", () => {
      renderWithProviders(<StatementChooser />);
      const removeAllBtn = screen.getByRole("button", { name: "Remove all items" });
      expect(removeAllBtn).toBeInTheDocument();
    });
    it("remove all button should be enabled", () => {
      renderWithProviders(<StatementChooser />);
      const removeAllBtn = screen.getByRole("button", { name: "Remove all items" });
      expect(removeAllBtn).toBeEnabled();
    });
  });

  describe("breadcrums", () => {
    it("should render breadcrumbs correctly", () => {
      renderWithProviders(<StatementChooser />);
      const breadcrumbs = screen.getByText(/breadcrumbs/i);
      expect(breadcrumbs).toBeInTheDocument();
    });
  });
  describe("grid tables", () => {
    it("should render grid tables correctly", () => {
      renderWithProviders(<StatementChooser />);
      const tables = screen.getAllByTestId("unreconciledDetailsGrid");
      tables.forEach((table) => {
        expect(table).toBeInTheDocument();
      });
      expect(tables).toHaveLength(2);
    });
  });

  describe("buttons functionality checks", () => {
    it("onCancelHandler function should be called if user clicks cancel button", async () => {
      renderWithProviders(<StatementChooser />);
      const cancelBtn = screen.getByRole("button", { name: /common.cancel/i });
      await userEvent.click(cancelBtn);
      expect(mockOnCancelHandler).toHaveBeenCalledTimes(1);
    });

    it("onSaveHandler function should be called if user clicks save button", async () => {
      renderWithProviders(<StatementChooser />);
      const saveBtn = screen.getByRole("button", { name: /common.save/i });
      await userEvent.click(saveBtn);
      expect(mockOnSaveHandler).toHaveBeenCalledTimes(1);
    });

    it("moveRecordToReconcile function should be called if user clicks choose button", async () => {
      renderWithProviders(<StatementChooser />);
      const chooseBtn = screen.getByRole("button", { name: "Choose" });
      await userEvent.click(chooseBtn);
      expect(mockMoveToReconcile).toHaveBeenCalledTimes(1);
    });
    it("moveAllRecordsToReconcile function should be called if user clicks choose all button", async () => {
      renderWithProviders(<StatementChooser />);
      const chooseAll = screen.getByRole("button", { name: "Choose all items" });
      await userEvent.click(chooseAll);
      expect(mockMoveAllRecordsToReconcile).toHaveBeenCalledTimes(1);
    });
    it("onSaveHandler function should be called if user clicks save button", async () => {
      renderWithProviders(<StatementChooser />);
      const remove = screen.getByRole("button", { name: "remove" });
      await userEvent.click(remove);
      expect(mockRemoveRecordFromReconcile).toHaveBeenCalledTimes(1);
    });
    it("onSaveHandler function should be called if user clicks save button", async () => {
      renderWithProviders(<StatementChooser />);
      const reomveAll = screen.getByRole("button", { name: "Remove all items" });
      await userEvent.click(reomveAll);
      expect(mockRemoveAllRecordsFromReconcile).toHaveBeenCalledTimes(1);
    });
  });

  describe("filters", () => {
    it("should show arrow down key if isArrowDown is true", () => {
      isShowArrowDown = true;
      renderWithProviders(<StatementChooser />);
      const arrowDown = screen.queryByTestId("arrow--down");
      expect(arrowDown).toBeInTheDocument();
    });

    it("sequences should be in the document", () => {
      renderWithProviders(<StatementChooser />);
      const sequences = screen.getAllByRole("radio");
      sequences.forEach((seq) => {
        expect(seq).toBeInTheDocument();
      });
      expect(sequences).toHaveLength(2);
    });

    it("if user changes the sequence then handle sequence function should be fired correctly", async () => {
      renderWithProviders(<StatementChooser />);
      const sequences = screen.getAllByRole("radio");
      await userEvent.click(sequences[1]);
      expect(mockHandleSequenceChange).toHaveBeenCalledTimes(1);
      expect(mockHandleSequenceChange).toHaveBeenCalledWith("ref", 1);
    });
  });
});
