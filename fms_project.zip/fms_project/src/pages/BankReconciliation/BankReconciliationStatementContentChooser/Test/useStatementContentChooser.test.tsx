import { renderHook, act } from "@testing-library/react-hooks";
import { useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useForm } from "react-hook-form";
import {
  getBankreconBankAccounts,
  getBankreconAccountNo,
  actions as bankReconActions
} from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { format, isAfter, parse } from "date-fns";
import { formatDateInYYYYMMDD } from "@/shared/components/InputDate/formatDate";
import { KEYBOARD_STRING, SCC_SEQUENCE_TYPE, specialCharacters, STATUS } from "@/types/UseStateType";
import { useAppSelector } from "@/store/store";
import { uiActions } from "@/store/state/ui.slice";
import React from "react";
import useDebounce from "@/hooks/useDebounce";
import useStatementContentChooser from "../useStatementContentChooser";
import { addBankreconStatement, bankreconValidateStatement } from "../../state/BankReconciliation.slice";
import { actions as sccActions } from "../../state/BankReconciliationStatement.slice";

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn(),
  useParams: jest.fn(() => ({ bankid: "123", bankStatementId: "451" }))
}));

jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("react-hook-form", () => ({
  useForm: jest.fn()
}));

jest.mock("../../state/BankReconciliation.slice", () => ({
  addBankreconStatement: jest.fn(),
  bankreconValidateStatement: jest.fn()
}));

jest.mock("@/store/state/ui.slice", () => ({
  uiActions: {
    alertPopup: jest.fn(),
    confirmPopup: jest.fn()
  },
  MODAL_TYPE: {
    ALERT: "genericAlert",
    CONFIRMV2: "genericConfirmv2",
    YEAR_DISABLED_MODAL: "yearDisableModal"
  }
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    init: jest.fn()
  }
}));

// Mock MODAL_TYPE
const MODAL_TYPE = {
  ALERT: "genericAlert",
  CONFIRMV2: "genericConfirmv2",
  YEAR_DISABLED_MODAL: "yearDisableModal"
};

// Mock ISelectedItem and NotificationStatus
jest.mock("@essnextgen/ui-kit", () => ({
  ISelectedItem: jest.fn(),
  NotificationStatus: {
    ERROR: "ERROR",
    HIGHLIGHT: "HIGHLIGHT"
  }
}));
jest.mock("@/hooks/useDebounce", () => jest.fn(() => "testing"));

const scrollToFirstElement = jest.fn();
const unreconciledList = ["item1", "item2"];
const reconciledList = ["item3", "item4"];

const calculateTotal = jest.fn();
const usNumberFormat = jest.fn();

describe("useAddStatement", () => {
  const mockDispatch = jest.fn();
  const mockSetIsBankAccountModalOpen = jest.fn();
  const mockRegister = jest.fn().mockReturnValue({
    onChange: jest.fn()
  });
  const mockSetValue = jest.fn();

  const mockHistoryPush = jest.fn();
  const mockUseForm = {
    register: mockRegister,
    setValue: mockSetValue,
    trigger: jest.fn(),
    handleSubmit: jest.fn(),
    setFocus: jest.fn(),
    setError: jest.fn(),
    reset: jest.fn(),
    watch: jest.fn(),
    formState: { errors: {}, isDirty: false },
    getValues: jest.fn()
  };

  const mockBankReconciliationStatementInitialState = {
    bankReconciliationStatement: {
      reconciledDetails: {
        bankLedger: "",
        bankReconciledTransactions: [{ testReconciledTrans: "testing transaction" }],
        uniqueIdentifier: null
      },
      unreconciledDetails: {
        bankLedger: "",
        bankReconciledTransactions: [{ testUnReconciledTrans: "testing transaction" }],
        uniqueIdentifier: null
      }
    },
    bankReconStatus: STATUS.SUCCESS,
    unreconciledDetails: [
      {
        ref: "PIB000774",
        unique_id: "PA0000001773",
        rcvamount: 750,
        payamount: 0,
        item_date: "2024-03-27T00:00:00",
        description: "Slip: PIB000774",
        user_id: "21",
        itemType: "AR",
        source: "AR Slip",
        account_id: 0,
        ledger_code: "BK01",
        posting_year: 26,
        posting_period: 12,
        statement_year: null,
        statement_period: null,
        statement_dt: null,
        statement_no: null
      }
    ],
    reconciledDetails: [
      {
        ref: "BACS382",
        unique_id: "BA0000001383",
        rcvamount: 0,
        payamount: 23909.4,
        item_date: "2024-03-22T00:00:00",
        description: "BACS Run 382",
        user_id: "21",
        itemType: "AP",
        source: "BACS",
        account_id: 0,
        ledger_code: "BK01",
        posting_year: 26,
        posting_period: 12,
        statement_year: 26,
        statement_period: 12,
        statement_dt: "2024-03-22T00:00:00",
        statement_no: 1306
      }
    ],
    storeReconciledList: [],
    sccFilterState: {
      lookingFor: "",
      sequence: 0,
      sequenceValue: "item_date"
    },
    sccColumnDef: [
      {
        headerName: "Date",
        field: "item_date",
        cellRenderer: "GridCellLink",
        sequence: true
      },
      {
        headerName: "Reference",
        field: "ref",
        sequence: true
      },
      {
        headerName: "Description",
        field: "description"
      },
      {
        headerName: "Type",
        field: "itemType"
      },
      {
        headerName: "Payments",
        field: "payamount",
        align: "right",
        sequence: true,
        cellRenderer: "GridCellLink",
        columnWidth: 10
      },
      {
        headerName: "Receipts",
        field: "rcvamount",
        sequence: true,
        cellRenderer: "GridCellLink",
        align: "right",
        columnWidth: 10
      }
    ],
    selectedBankReconiledRow: undefined,
    selectedBankUnreconciledRow: undefined,
    newReconciledDetails: [
      {
        ref: "BACS382",
        unique_id: "BA0000001383",
        rcvamount: 0,
        payamount: 23909.4,
        item_date: "2024-03-22T00:00:00",
        description: "BACS Run 382",
        user_id: "21",
        itemType: "AP",
        source: "BACS",
        account_id: 0,
        ledger_code: "BK01",
        posting_year: 26,
        posting_period: 12,
        statement_year: 26,
        statement_period: 12,
        statement_dt: "2024-03-22T00:00:00",
        statement_no: 1306
      }
    ],
    newUnReconciledDetails: [
      {
        ref: "BACS383",
        unique_id: "BA0000001384",
        rcvamount: 1,
        payamount: 23909.4,
        item_date: "2024-03-22T00:00:00",
        description: "BACS Run 382",
        user_id: "21",
        itemType: "AP",
        source: "BACS",
        account_id: 0,
        ledger_code: "BK01",
        posting_year: 26,
        posting_period: 12,
        statement_year: 26,
        statement_period: 12,
        statement_dt: "2024-03-22T00:00:00",
        statement_no: 1306
      }
    ]
  };

  const mockHistoryReplace = jest.fn();

  beforeEach(() => {
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue({
      push: mockHistoryPush,
      replace: mockHistoryReplace,
      location: { state: {} }
    });
    (useTranslation as jest.Mock).mockReturnValue({ t: (key: any) => key });
    (useForm as jest.Mock).mockReturnValue(mockUseForm);

    (useAppSelector as jest.Mock).mockImplementation((selector: any) => mockBankReconciliationStatementInitialState);

    jest.clearAllMocks();
  });

  describe("handleSequenceChange", () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should handle "item_date" case', () => {
      const { result } = renderHook(() => useStatementContentChooser());

      act(() => {
        result.current.handleSequenceChange("item_date", 0);
      });

      expect(mockDispatch).toHaveBeenCalledWith(
        sccActions.setSccColumnDef(
          expect.arrayContaining([
            expect.objectContaining({
              field: "item_date"
            }),
            expect.objectContaining({
              field: "ref"
            })
          ])
        )
      );
    });

    it('should handle "ref" case', () => {
      const { result } = renderHook(() => useStatementContentChooser());

      act(() => {
        result.current.handleSequenceChange("ref", 1);
      });

      expect(mockDispatch).toHaveBeenCalledWith(
        sccActions.setSccColumnDef(
          expect.arrayContaining([
            expect.objectContaining({
              field: "ref"
            }),
            expect.objectContaining({
              field: "item_date"
            })
          ])
        )
      );
    });

    it('should handle "payamount" case', () => {
      const { result } = renderHook(() => useStatementContentChooser());

      act(() => {
        result.current.handleSequenceChange("payamount", 2);
      });

      expect(mockDispatch).toHaveBeenCalledWith(
        sccActions.setSccColumnDef(
          expect.arrayContaining([
            expect.objectContaining({
              field: "payamount"
            }),
            expect.objectContaining({
              field: "item_date"
            })
          ])
        )
      );
    });

    it('should handle "rcvamount" case', () => {
      const { result } = renderHook(() => useStatementContentChooser());

      act(() => {
        result.current.handleSequenceChange("rcvamount", 2);
      });

      expect(mockDispatch).toHaveBeenCalledWith(
        sccActions.setSccColumnDef(
          expect.arrayContaining([
            expect.objectContaining({
              field: "rcvamount"
            }),
            expect.objectContaining({
              field: "item_date"
            })
          ])
        )
      );
    });

    it('should handle "default" case', () => {
      const { result } = renderHook(() => useStatementContentChooser());

      act(() => {
        result.current.handleSequenceChange("default", 2);
      });

      expect(mockDispatch).toHaveBeenCalledWith(
        sccActions.setSccColumnDef(
          expect.arrayContaining([
            expect.objectContaining({
              field: "item_date"
            }),
            expect.objectContaining({
              field: "ref"
            })
          ])
        )
      );
    });
  });

  describe("onReconiledRowSelect", () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it("should return earlier without doing anything if row argument is undefined", () => {
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.onReconiledRowSelect(undefined);
      });
      expect(mockDispatch).not.toHaveBeenCalledWith(sccActions.setSelectedBankReconiledRow(expect.any(Object)));
    });

    it("should return earlier without doing anything if row argument is empty array", () => {
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.onReconiledRowSelect([]);
      });
      expect(mockDispatch).not.toHaveBeenCalledWith(sccActions.setSelectedBankReconiledRow(expect.any(Object)));
    });

    it("should dispatch setSelectedBankReconiledRow action with correct argument", () => {
      (useAppSelector as jest.Mock).mockReturnValueOnce({
        ...mockBankReconciliationStatementInitialState,
        selectedBankReconiledRow: { feild: "test field 01" },
        selectedBankUnreconciledRow: undefined
      });

      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.onReconiledRowSelect({ feild: "test field 01" });
      });
      expect(mockDispatch).toHaveBeenCalledWith(sccActions.setSelectedBankReconiledRow({ feild: "test field 01" }));
    });

    it("should dispatch setSelectedBankUnReconiledRow action with correct argument", () => {
      (useAppSelector as jest.Mock).mockReturnValueOnce({
        ...mockBankReconciliationStatementInitialState,
        selectedBankReconiledRow: { feild: "test field 02" },
        selectedBankUnreconciledRow: undefined
      });

      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.onReconiledRowSelect({ feild: "test field 02" });
      });
      expect(mockDispatch).toHaveBeenCalledWith(sccActions.setSelectedBankReconiledRow({ feild: "test field 02" }));
    });
  });

  describe("onUnReconiledRowSelect", () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it("should return earlier without doing anything if row argument is undefined", () => {
      const { result } = renderHook(() => useStatementContentChooser());
      const row = undefined;
      act(() => {
        result.current.onUnReconiledRowSelect(row);
      });
      expect(mockDispatch).not.toHaveBeenCalledWith(sccActions.setSelectedBankUnReconiledRow(row));
    });

    it("should return earlier without doing anything if row argument is empty array", () => {
      const { result } = renderHook(() => useStatementContentChooser());
      const row: any = [];
      act(() => {
        result.current.onUnReconiledRowSelect(row);
      });
      expect(mockDispatch).not.toHaveBeenCalledWith(sccActions.setSelectedBankUnReconiledRow(row));
    });

    it("should dispatch setSelectedBankUnReconiledRow action with correct argument", () => {
      (useAppSelector as jest.Mock).mockReturnValueOnce({
        ...mockBankReconciliationStatementInitialState,
        selectedBankReconiledRow: undefined,
        selectedBankUnreconciledRow: { feild: "test field 01" }
      });
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.onUnReconiledRowSelect({ feild: "test field 01" });
      });
      expect(mockDispatch).toHaveBeenCalledWith(sccActions.setSelectedBankUnReconiledRow({ feild: "test field 01" }));
    });

    it("should dispatch setSelectedBankUnReconiledRow action with correct argument", () => {
      (useAppSelector as jest.Mock).mockReturnValueOnce({
        ...mockBankReconciliationStatementInitialState,
        selectedBankReconiledRow: undefined,
        selectedBankUnreconciledRow: { feild: "test field 02" }
      });
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.onUnReconiledRowSelect({ feild: "test field 02" });
      });
      expect(mockDispatch).toHaveBeenCalledWith(sccActions.setSelectedBankUnReconiledRow({ feild: "test field 02" }));
    });
  });

  describe("moveRecordToReconcile", () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it("should not dispatch any action should just do history.replace with required arguements if unreconciledList is empty array", () => {
      (useAppSelector as jest.Mock).mockReturnValueOnce({
        ...mockBankReconciliationStatementInitialState,
        unreconciledDetails: []
      });
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.moveRecordToReconcile(); // it sets isShowArrowDown to be true as well
      });
      result.current.handleSequenceChange("exception", 100);
      expect(mockDispatch).not.toHaveBeenCalledWith(sccActions.choose(expect.any(Object)));
      expect(mockHistoryReplace).toHaveBeenCalled();
    });

    it("should dispatch choose action with correct payload", () => {
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.moveRecordToReconcile();
      });
      expect(mockDispatch).toHaveBeenCalledWith(sccActions.choose(expect.any(Object)));
      expect(mockHistoryReplace).toHaveBeenCalled();
    });
  });

  describe("onCancelHandler", () => {
    it("should dispatch updateSccRow action and redirect user to previous route", () => {
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.onCancelHandler();
      });

      expect(mockDispatch).toHaveBeenCalledWith(sccActions.updateSccRow());
      expect(mockHistoryPush).toHaveBeenCalledWith(
        "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/123/bankStatementId/451",
        expect.any(Object)
      );
    });
  });

  describe("onSaveHandler", () => {
    it("should dispatch resetNewReconciledDetails action and redirect user to previous route", () => {
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.onSaveHandler();
      });

      expect(mockDispatch).toHaveBeenCalledWith(sccActions.resetNewReconciledDetails());
      expect(mockHistoryPush).toHaveBeenCalledWith(
        "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/123/bankStatementId/451",
        expect.any(Object)
      );
    });
  });

  describe("handleKeyDowInputn", () => {
    it("should return early if Tab key is passed down as arguemnt without called preventDefault", () => {
      const mockPreventDefault = jest.fn();
      const mockEvent = {
        target: {
          value: "abc"
        },
        key: "Tab",
        preventDefault: mockPreventDefault
      };
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.handleKeyDowInputn(mockEvent);
      });

      expect(mockPreventDefault).toHaveBeenCalledTimes(0);
    });

    it("should call preventDefault if key code is ArrowDown and sequence value is 'ref' ", () => {
      (useAppSelector as jest.Mock).mockReturnValueOnce({
        ...mockBankReconciliationStatementInitialState,
        sccFilterState: {
          lookingFor: "",
          sequence: 1,
          sequenceValue: "ref"
        }
      });
      const mockPreventDefault = jest.fn();
      const mockEvent = {
        target: {
          value: "abc"
        },
        key: "ArrowDown",
        preventDefault: mockPreventDefault
      };
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.handleKeyDowInputn(mockEvent);
      });

      expect(mockPreventDefault).toHaveBeenCalledTimes(1);
    });

    it("should call preventDefault if key code is ArrowDown and sequence value is not 'ref' ", () => {
      const mockPreventDefault = jest.fn();
      const mockEvent = {
        target: {
          value: "abc"
        },
        key: "ArrowDown",
        preventDefault: mockPreventDefault
      };
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.handleKeyDowInputn(mockEvent);
      });

      expect(mockPreventDefault).toHaveBeenCalledTimes(1);
    });
  });

  describe("moveAllRecordsToReconcile", () => {
    it("looking for should get cleared and down arrow should be shown if unreconciledList is empty", () => {
      (useAppSelector as jest.Mock).mockReturnValueOnce({
        ...mockBankReconciliationStatementInitialState,
        unreconciledDetails: []
      });
      const { result } = renderHook(() => useStatementContentChooser());

      act(() => {
        result.current.moveAllRecordsToReconcile();
      });

      expect(result.current.lookingFor).toBe("");
      expect(result.current.isShowArrowDown).toBe(true);
      expect(mockDispatch).not.toHaveBeenCalledWith(sccActions.chooseAll());
    });

    it("looking for should get cleared and down arrow should be shown and chooseAll action should be dispatched and if unreconciledList is not empty", () => {
      const { result } = renderHook(() => useStatementContentChooser());
      act(() => {
        result.current.moveAllRecordsToReconcile();
      });

      expect(result.current.lookingFor).toBe("");
      expect(mockDispatch).toHaveBeenCalledWith(sccActions.chooseAll());
      expect(result.current.isShowArrowDown).toBe(true);
      expect(mockHistoryReplace).toHaveBeenCalledWith(expect.any(Object));
    });
  });

  describe("removeRecordFromReconcile", () => {
    it("looking for should get cleared and up arrow should be shown and location should get replaced if reconciledDetails is empty", () => {
      (useAppSelector as jest.Mock).mockReturnValueOnce({
        ...mockBankReconciliationStatementInitialState,
        reconciledDetails: []
      });
      const { result } = renderHook(() => useStatementContentChooser());

      act(() => {
        result.current.removeRecordFromReconcile();
      });

      expect(result.current.lookingFor).toBe("");
      expect(mockDispatch).not.toHaveBeenCalledWith(sccActions.remove(expect.any(Object)));
      expect(result.current.isShowArrowDown).toBe(false);
      expect(mockHistoryReplace).toHaveBeenCalledWith(expect.any(Object));
    });
  });
});
