import { Provider } from "react-redux";
import { screen, render, waitFor, act, fireEvent } from "@testing-library/react";
import { Router } from "react-router-dom";
import { createMemoryHistory } from "history";
import configureStore from "redux-mock-store";
import userEvent from "@testing-library/user-event";
import { STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import React from "react";
import StatementChooser from "../statementChooser";
import CustomCell from "../Grid/customCell";

const history = createMemoryHistory();
history.push(
  "/UI/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/49/bankStatementId/1339/statement-content-chooser"
);

const initialState = {};
const mockStore = configureStore();

const renderWithProviders = (ui: React.ReactElement, { store = mockStore(initialState) } = {}) => {
  const Wrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <Provider store={store}>
      <Router history={history}>{children}</Router>
    </Provider>
  );
  return render(ui, { wrapper: Wrapper });
};

describe("testing custom cell component", () => {
  let store: any;
  beforeEach(() => {
    store = mockStore(initialState);
    jest.resetModules();
  });

  it("should render date if item_date is passed as field", () => {
    const row = { item_date: "2024-03-27T00:00:00" };
    renderWithProviders(
      <CustomCell
        field="item_date"
        row={row}
      />
    );
    screen.debug();
    const date = screen.getByText("27 Mar 2024");
    expect(date).toBeInTheDocument();
  });

  it("should render date if rcvamount is passed as field", () => {
    const row = { rcvamount: 0 };
    renderWithProviders(
      <CustomCell
        field="rcvamount"
        row={row}
      />
    );
    screen.debug();
    const rcvamount = screen.getByText(/0/i);
    expect(rcvamount).toBeInTheDocument();
  });

  it("should render date if payamount is passed as field", () => {
    const row = { payamount: 1 };
    renderWithProviders(
      <CustomCell
        field="payamount"
        row={row}
      />
    );
    screen.debug();
    const payamount = screen.getByText(/1/i);
    expect(payamount).toBeInTheDocument();
  });

  it("should render date if default is passed as field", () => {
    const row = { default: "2024-03-27T00:00:00" };
    renderWithProviders(
      <CustomCell
        field="default"
        row={row}
      />
    );
    screen.debug();
    const date = screen.queryByText("27 Mar 2024");
    const rcvamount = screen.queryByText(/1/i);
    const payamount = screen.queryByText(/0/i);
    expect(date).not.toBeInTheDocument();
    expect(rcvamount).not.toBeInTheDocument();
    expect(payamount).not.toBeInTheDocument();
  });
});
