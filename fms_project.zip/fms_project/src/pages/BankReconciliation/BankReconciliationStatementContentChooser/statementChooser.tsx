import { useState, useEffect } from "react";
import Layout from "@/components/Layout/Layout";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconSize,
  RadioButton,
  RadioLabelPosition
} from "@essnextgen/ui-kit";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import "./Style.scss";
import { LookingFor } from "@/shared/components/LookingFor/LookingFor";
import { STATUS } from "@/types/UseStateType";
import { useAppSelector } from "@/store/store";
import { usNumberFormat } from "@/utils/getDataSource";
import CustomCell from "./Grid/customCell";
import useStatementContentsChooser from "./useStatementContentChooser";
import ColumnDef from "./Grid/columnDef";

const StatementChooser = () => {
  const {
    t,
    handleSequenceChange,
    sccColumnDef,
    bankReconStatus,
    selectedBankReconiledRow,
    selectedBankUnreconciledRow,
    sequenceValue,
    onReconiledRowSelect,
    onUnReconiledRowSelect,
    unreconciledTotalReceipts,
    reconciledTotalReceipts,
    unreconciledTotalPayments,
    reconciledTotalPayments,
    unreconciledNetAmount,
    reconciledNetAmount,
    moveRecordToReconcile,
    moveAllRecordsToReconcile,
    removeRecordFromReconcile,
    removeAllRecordsFromReconcile,
    reconciledDetails,
    unreconciledDetails,
    isShowArrowDown,
    lookingFor,
    lookingForCallback,
    onFocusReconciled,
    onFocusUnreconciled,
    onSaveHandler,
    onCancelHandler,
    historyState,
    closingBalance,
    numberFormatter,
    handleKeyDowInputn
  } = useStatementContentsChooser();

  return (
    <>
      <Layout
        className="statement-contents-chooser table__hegiht--345"
        pageTitle="Statement Contents Chooser"
        type="transparent"
      >
        <GridTableNew
          dataTestId="unreconciledDetailsGrid"
          id="unreconciledDetailsGrid"
          onFocus={onFocusUnreconciled}
          filters={
            <>
              <Grid>
                <GridItem
                  lg={6}
                  className="upper-grid-wrapper"
                >
                  <div className="essui-global-typography-default-subtitle">{t("bankReconciliation.unreconciled")}</div>
                </GridItem>
                <GridItem lg={6}>
                  <div className="d-flex justify-end align-center gap-10">
                    <div className="read-only-field essui-textinput--medium text-right net-amount">
                      {unreconciledNetAmount}
                    </div>
                    <div className="read-only-field essui-textinput--medium text-right total-payments">
                      {unreconciledTotalPayments}
                    </div>
                    <div className="read-only-field essui-textinput--medium text-right total-receipts">
                      {unreconciledTotalReceipts}
                    </div>
                  </div>
                </GridItem>
              </Grid>
            </>
          }
          columnDef={sccColumnDef}
          customCell={CustomCell}
          isLoading={bankReconStatus === STATUS.LOADING}
          isScrollable
          stickyHeader
          dataSource={unreconciledDetails ?? []}
          selectedRow={selectedBankUnreconciledRow}
          selectedRowHandler={onUnReconiledRowSelect}
        />
      </Layout>
      <Layout isBreadcrumbRequired={false}>
        <div className="statement__content--chooser-filters">
          <LookingFor
            initialValue={lookingFor}
            callback={lookingForCallback}
            changeHandler={() => {}}
            hasDatePicker
            isBankReconciliation
            restrictInput={handleKeyDowInputn}
            nextYearStartDate={historyState?.nextYearStartDate}
            disableDatePicker={sequenceValue !== "item_date"}
            isInputReadOnly={bankReconStatus === STATUS.LOADING}
            className="essui-global-typography-default-h2 looking-for-container"
          />
          {isShowArrowDown ? (
            <Icon
              className="essui-button--tertiary essui-button-icon-only--small arrow--filter disable-pointer"
              size={IconSize.Medium}
              dataTestId="arrow--down"
              name="arrow--down"
            />
          ) : (
            <Icon
              className="essui-button--tertiary essui-button-icon-only--small arrow--filter disable-pointer"
              size={IconSize.Medium}
              name="arrow--up"
            />
          )}
          <div className="essui-global-typography-default-h2 sequence-container">
            <FormLabel>{t("common.sequenceOrder")}</FormLabel>
            <div className="sequence">
              <div className="essui-textinput sequence-fields">
                {(ColumnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
                  const sequenceId = `sequence=${index + 1}`;
                  return (
                    <RadioButton
                      label={column.sequenceName ? column.sequenceName : column.headerName}
                      labelPosition={RadioLabelPosition.Right}
                      value={column.field}
                      onChange={() => {
                        handleSequenceChange(column.field, index);
                      }}
                      isSelected={sequenceValue === column.field}
                      key={sequenceId}
                      name="sequenceColumn"
                    />
                  );
                })}
              </div>
            </div>
          </div>
          <div className="d-flex justify-end align-center mt-16 gap-8 ml-50 action-btn">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
              iconName="arrow--down"
              iconPosition={ButtonIconPosition.Left}
              aria-label="Choose"
              onClick={moveRecordToReconcile}
            >
              {t("bankReconciliation.choose")}
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
              iconName="arrow--down"
              iconPosition={ButtonIconPosition.Left}
              aria-label="Choose all items"
              onClick={moveAllRecordsToReconcile}
            >
              {t("bankReconciliation.chooseAll")}
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
              iconName="arrow--up"
              iconPosition={ButtonIconPosition.Left}
              aria-label="remove"
              onClick={removeRecordFromReconcile}
            >
              {t("bankReconciliation.remove")}
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
              iconName="arrow--up"
              iconPosition={ButtonIconPosition.Left}
              aria-label="Remove all items"
              onClick={removeAllRecordsFromReconcile}
            >
              {t("bankReconciliation.removeAll")}
            </Button>
          </div>
        </div>
      </Layout>
      <Layout
        isBreadcrumbRequired={false}
        type="transparent"
      >
        <div className="statement-contents-chooser">
          <div>
            <GridTableNew
              dataTestId="reconciledDetailsGrid"
              id="reconciledDetailsGrid"
              onFocus={onFocusReconciled}
              filters={
                <>
                  <Grid>
                    <GridItem
                      lg={6}
                      className="upper-grid-wrapper"
                    >
                      <div className="essui-global-typography-default-subtitle">
                        {t("bankReconciliation.reconciled")}
                      </div>
                    </GridItem>
                    <GridItem lg={6}>
                      <div className="d-flex justify-end align-center gap-10">
                        <div className="read-only-field essui-textinput--medium text-right net-amount">
                          {reconciledNetAmount}
                        </div>
                        <div className="read-only-field essui-textinput--medium text-right total-payments">
                          {reconciledTotalPayments}
                        </div>
                        <div className="read-only-field essui-textinput--medium text-right total-receipts">
                          {reconciledTotalReceipts}
                        </div>
                      </div>
                    </GridItem>
                  </Grid>
                </>
              }
              columnDef={sccColumnDef}
              customCell={CustomCell}
              isLoading={bankReconStatus === STATUS.LOADING}
              isScrollable
              stickyHeader
              dataSource={reconciledDetails ?? []}
              selectedRow={selectedBankReconiledRow}
              selectedRowHandler={onReconiledRowSelect}
            />
          </div>
        </div>
      </Layout>
      <Layout isBreadcrumbRequired={false}>
        <Grid className="lower-grid-footer">
          <GridItem
            lg={5}
            xl={5}
            sm={4}
          >
            <Grid>
              <GridItem
                lg={6}
                xl={6}
                sm={3}
              >
                <div className="ml-10">
                  <div className="essui-form-label">{t("bankReconciliation.openingBalance")}</div>
                  <div className="mt-8">{numberFormatter.format(historyState?.selectedBankReconRow?.opening_bal)}</div>
                </div>
              </GridItem>
              <GridItem
                lg={6}
                xl={6}
                sm={3}
              >
                <div className="essui-form-label">{t("bankReconciliation.closingBalance")}</div>
                <div className="mt-8">{numberFormatter.format(closingBalance)}</div>
              </GridItem>
            </Grid>
          </GridItem>
        </Grid>

        <Grid className="mt-8">
          <GridItem
            sm={4}
            md={8}
            lg={12}
            xl={12}
          >
            <div className="d-flex justify__content--between flex-rev">
              <div className="dialog-right-button flex-rev m-0">
                <Button
                  id="statementchooser-save-btn"
                  size={ButtonSize.Small}
                  onClick={onSaveHandler}
                >
                  {t("common.save")}
                </Button>

                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                >
                  {t("bankReconciliation.addJournal")}
                </Button>

                <Button
                  id="statementchooser-addjournal-btn"
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={onCancelHandler}
                >
                  {t("common.cancel")}
                </Button>
              </div>
              <div>
                <Grid>
                  <HelpButton
                    identifier="testIdentifier"
                    labelName={t("common.help")}
                  />
                </Grid>
              </div>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};

export default StatementChooser;
