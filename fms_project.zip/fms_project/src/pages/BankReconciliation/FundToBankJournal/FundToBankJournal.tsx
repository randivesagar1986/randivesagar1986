import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import { specialCharacters } from "@/types/UseStateType";
import { dateConvertInDDslashMMslashYYYY } from "@/utils/getDataSource";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  Divider,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";
import BodyUtil from "@/shared/utils/NoScroll";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import Modal from "@/components/Modal/Modal";
import { useFundToBankJournal } from "./useFundToBankJournal";

type TFundtoBankJournal = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
};
const FundToBankJournal = ({ setOpen, isOpen }: TFundtoBankJournal) => {
  const { fundToBankData, numberFormatter, t } = useFundToBankJournal();
  return (
    <>
      <Modal
        isOpen={isOpen}
        primaryBtnText={t("common.close")}
        fourthiaryBtnText={t("common.help")}
        primaryBtnClick={() => {
          BodyUtil.NoScroll.remove();
          setOpen(false);
        }}
        autoFocusPrimaryBtn
        fourthiaryBtnClick={() => {
          BodyUtil.NoScroll.remove();
          setOpen(false);
        }}
        onClose={() => {
          BodyUtil.NoScroll.remove();
          setOpen(false);
        }}
        header={t("bankReconciliation.fundtoBankTitle")}
        className="dialog__divider"
      >
        <div className="overflow-hidden">
          <Grid className="marginb15">
            <GridItem
              sm={2}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label pb-8">{t("bankReconciliation.journalType")}</div>
                <div>{fundToBankData[0]?.incdec_description}</div>
              </div>
            </GridItem>
            <GridItem
              sm={2}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label pb-8">{t("bankReconciliation.dateofPosting")}</div>
                <div>
                  {fundToBankData[0]?.journal_date
                    ? dateConvertInDDslashMMslashYYYY(fundToBankData[0]?.journal_date, "false")
                    : specialCharacters.HYPHEN}
                </div>
              </div>
            </GridItem>
          </Grid>
          <div className="mb-16">
            <Divider />
          </div>
          <Grid className="marginb15 row-gap-16">
            <GridItem
              sm={2}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label pb-8">{t("bankReconciliation.period")}</div>
                <div>{fundToBankData[0]?.period_no}</div>
              </div>
            </GridItem>
            <GridItem
              sm={2}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label pb-8">{t("bankReconciliation.bankAccount")}</div>
                <div>
                  {fundToBankData[0]?.bank_account ? fundToBankData[0]?.bank_account : specialCharacters.HYPHEN}
                </div>
              </div>
            </GridItem>
            <GridItem
              sm={2}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label pb-8">{t("bankReconciliation.fund")}</div>
                <div>{fundToBankData[0]?.fund_des ? fundToBankData[0]?.fund_des : specialCharacters.HYPHEN}</div>
              </div>
            </GridItem>
            <GridItem
              sm={2}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label pb-8">{t("bankReconciliation.amount")}</div>
                <div>{fundToBankData[0]?.amount ? numberFormatter.format(fundToBankData[0]?.amount) : 0}</div>
              </div>
            </GridItem>
            <GridItem
              sm={2}
              md={4}
              lg={12}
              xl={12}
            >
              <div>
                <div className="essui-form-label pb-8">{t("bankReconciliation.narrative")}</div>
                <div>{fundToBankData[0]?.narrative ? fundToBankData[0]?.narrative : specialCharacters.HYPHEN}</div>
              </div>
            </GridItem>
          </Grid>
        </div>
      </Modal>
    </>
  );
};
export default FundToBankJournal;
