import Layout from "@/components/Layout/Layout";
import { Button, ButtonSize, FormLabel, Grid, Notification, NotificationStatus } from "@essnextgen/ui-kit";
import "./Style.scss";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { Dispatch, SetStateAction } from "react";
import PayingInProcessingModal from "../PayingInProcessingModal/PayingInProcessingModal";
import ReceiptDetailsModal from "../ReceiptDetailsModal/ReceiptDetailsModal";
import FundToBankJournal from "../FundToBankJournal/FundToBankJournal";
import PettyCashDetailsModal from "../PettyCashDetailsModal/PettyCashDetailsModal";

type TBankReconciliationModalsType = {
  row: { [key: string]: any };
  isOpenAlert: boolean;
  setIsOpenAlert: Dispatch<SetStateAction<boolean>>;
  alertMessage: string;
  isFundToBankJournalOpen: boolean;
  setIsFundToBankJournalOpen: Dispatch<SetStateAction<boolean>>;
  isPCPaymentModalOpen: boolean;
  setIsPCPaymentModalOpen: Dispatch<SetStateAction<boolean>>;
  isARPaymentModalOpen: boolean;
  setIsARPaymentModalOpen: Dispatch<SetStateAction<boolean>>;
  isNIPaymentModalOpen: boolean;
  setIsNIPaymentModalOpen: Dispatch<SetStateAction<boolean>>;
};
const BankReconciliationModals = ({
  row,
  isOpenAlert,
  setIsOpenAlert,
  alertMessage,
  isFundToBankJournalOpen,
  setIsFundToBankJournalOpen,
  isPCPaymentModalOpen,
  setIsPCPaymentModalOpen,
  isARPaymentModalOpen,
  setIsARPaymentModalOpen,
  isNIPaymentModalOpen,
  setIsNIPaymentModalOpen
}: TBankReconciliationModalsType) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <>
      <Modalv2
        isOpen={isOpenAlert}
        header={t("common.simsFMSModule")}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              setIsOpenAlert(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
        className="confirm-modal-text-bank-rec"
      >
        <Notification
          actionElement={1}
          className="confirm-modal-text"
          dataTestId="delete-new-warning-id"
          escapeExits
          id="delete-new-warning-id"
          hideCloseButton
          status={NotificationStatus.ERROR}
          title={alertMessage}
        />
      </Modalv2>
      {isARPaymentModalOpen && (
        <PayingInProcessingModal
          row={row}
          isOpen={isARPaymentModalOpen}
          setOpen={setIsARPaymentModalOpen}
        />
      )}
      {isNIPaymentModalOpen && (
        <ReceiptDetailsModal
          isOpen={isNIPaymentModalOpen}
          setOpen={setIsNIPaymentModalOpen}
          row={row}
        />
      )}
      {isFundToBankJournalOpen && (
        <FundToBankJournal
          isOpen={isFundToBankJournalOpen}
          setOpen={setIsFundToBankJournalOpen}
        />
      )}
      {isPCPaymentModalOpen && (
        <PettyCashDetailsModal
          isOpen={isPCPaymentModalOpen}
          setOpen={setIsPCPaymentModalOpen}
          row={row}
        />
      )}
    </>
  );
};

export default BankReconciliationModals;
