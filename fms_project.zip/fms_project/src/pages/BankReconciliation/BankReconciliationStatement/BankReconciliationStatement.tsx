import Layout from "@/components/Layout/Layout";
import {
  Grid,
  GridItem,
  IPaginationProps,
  Tag,
  TagColor,
  TagSize,
  Button,
  ButtonSize,
  Notification,
  NotificationStatus
} from "@essnextgen/ui-kit";
import "./Style.scss";
import { useParams, useHistory } from "react-router-dom";
import { SyntheticEvent, useEffect, useState } from "react";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { setToSession, getSessionItem as getSessionData, usNumberFormat, sortByDiffKey } from "@/utils/getDataSource";

import { STATUS, specialCharacters } from "@/types/UseStateType";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import { useClickAway } from "@/hooks/useClickAway";
import {
  getBankReconciliationStatement,
  getVerifyBalaceDetail,
  deleteBankreconStatement,
  actions as brsAction,
  saveBankreconStatement
} from "../state/BankReconciliationStatement.slice";
import CustomCell from "./Grid/CustomCell";
import BankReconciliationStatementFilters from "./Grid/BankReconciliationStatementFilter";
import BankReconciliationToolbar from "../BankReconciliationToolbar";
import { getBankReconciliations, bankRecActions } from "../state/BankReconciliation.slice";

type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];
const BankReconciliationStatement = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { bankid, bankStatementId } = useParams<{
    bankid: string;
    bankStatementId: any;
  }>();
  const {
    bankReconciliationStatement,
    filterState: brsFilterState,
    bankReconStatus,
    columnDef: bankReconciliationStatementDef,
    reconciledDetails,
    saveReconStatus,
    unreconciledDetails,
    selectedRow: bankReconciliationStatementSelectedRow
  } = useAppSelector((state) => state.bankReconciliationStatement);
  const history = useHistory();
  const historyState = { ...(history.location.state as any) };
  const [isVerifyBalancesModalOpen, setIsVerifyBalancesModalOpen] = useState<boolean>(false);
  const [isSwitchToListModalOpen, setIsSwitchToListModalOpen] = useState<boolean>(false);
  const [indexNo, setIndexNo] = useState<any>(undefined);
  const [isNextRecord, setIsNextRecord] = useState<any>(undefined);

  const { selectedRow, filterState, nextYearStartDate, validateStatement, closingBalance } = useAppSelector(
    (state) => state.bankReconciliation
  );

  const dispatch = useDispatch<AppDispatch>();

  const yesCallback = async (e: any) => {
    const isRelevantLink = ["link-normal", "home-link"].some((cls) => e?.classList.contains(cls));
    const isProfileMenu = e.closest(".essui-avatar");
    await onSubmitHandlerClickAway();
    await dispatch(bankRecActions.resetValidateStatement());
    if (!isRelevantLink && !isProfileMenu) {
      dispatch(setIsSidebarOpen(true));
    }
    return true;
  };

  const noCallback = () => {
    dispatch(bankRecActions.resetValidateStatement());
    return true;
  };

  const { setIsSidebarOpen } = useClickAway({
    isDirty: historyState?.isDirty,
    yesCallback,
    noCallback,
    cancelCallback: () => {},
    excludePath: ["/statement-content-chooser", "/general-ledger/bank-reconciliation/add"]
  });

  useEffect(() => {
    if (historyState?.selectedRowState) {
      dispatch(bankRecActions.setSelectedRow(historyState.selectedRowState));
    }
    if (historyState?.from !== "statementChooser") {
      dispatch(bankRecActions.setClosingBalance(selectedRow?.closing_bal));
    }
  }, [historyState]);

  useEffect(() => {
    if (bankReconciliationStatementSelectedRow) {
      const selectedIndex = reconciledDetails.findIndex(
        (row) => row.ref === bankReconciliationStatementSelectedRow.ref
      );

      setTimeout(() => {
        const element = document.getElementById(`rowIndex-bankStatement-${selectedIndex}`);
        element?.scrollIntoView({ behavior: "smooth", block: "center" });
        element?.focus();
      }, 200);
    }
  }, [bankReconciliationStatementSelectedRow]);

  useEffect(() => {
    if (historyState?.sccDetails === undefined && reconciledDetails?.length === 0) {
      dispatch(
        getBankReconciliationStatement({
          bankId: bankid,
          bank_statement_id: bankStatementId,
          statementChooser: false,
          sequence: brsFilterState?.sequence,
          uniqueIdentifier: getSessionData("uniqueIdentifier") ? getSessionData("uniqueIdentifier") : ""
        })
      );
    } else {
      const sortedList = sortByDiffKey(reconciledDetails, String(brsFilterState?.sequenceValue), "ref");
      dispatch(brsAction.setReconciledSortedData(sortedList));
    }
  }, [brsFilterState, bankStatementId, historyState?.isDirty, historyState?.sccDetails]);

  const selectRowHandler = (row: { [key: string]: any } | undefined, data?: any) => {
    dispatch(brsAction.resetReconciledDetails());
    const bankReconciledDetailsLink = row
      ? `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${row.bank_id}/bankStatementId/${row.bank_statement_id}`
      : "";
    history.push(bankReconciledDetailsLink, {
      ...(history.location.state as any),
      bankRreconciliationList: data || historyState.bankRreconciliationList,
      selectedRowState: row,
      isDirty: false,
      sccDetails: undefined,
      from: "viewStatement",
      needToSave: false
    });
  };

  useEffect(() => {
    if (indexNo >= 0 && isNextRecord !== undefined) {
      dispatch(
        getBankReconciliations({
          ...filterState,
          lookingFor: "",
          pageNumber: historyState?.bankRreconciliationList?.currentPage,
          pageSize: String(historyState?.bankRreconciliationList?.pageSize),
          highLightedRecordId: undefined,
          callback: (data) => {
            if (isNextRecord) {
              dispatch(bankRecActions.setSelectedRow(data.data[indexNo + 1]));
              selectRowHandler(data.data[indexNo + 1]);
            } else if (history.location.pathname === "/general-ledger/bank-reconciliation/add") {
              selectRowHandler(data.data[indexNo]);
            } else {
              dispatch(bankRecActions.setSelectedRow(data.data[indexNo - 1]));
              selectRowHandler(data.data[indexNo - 1]);
            }
          }
        })
      );
    }
  }, [indexNo, isNextRecord]);

  const onChangeHandler: onChangeType = (e, page) => {
    dispatch(
      getBankReconciliations({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(historyState?.bankRreconciliationList?.pageSize),
        highLightedRecordId: undefined,
        callback: (data, selectedRow) => {
          const index = data.data.indexOf(selectedRow);
          if (historyState?.bankRreconciliationList === undefined) {
            if (bankid) {
              historyState.bankRreconciliationList = data;
              dispatch(bankRecActions.setSelectedRow(selectedRow));
              selectRowHandler(data.data?.at(index));
            } else {
              historyState.bankRreconciliationList = data;
              dispatch(bankRecActions.setSelectedRow(data.data?.at(1)));
              selectRowHandler(data.data?.at(1));
            }
          } else {
            historyState.bankRreconciliationList = data;
            dispatch(bankRecActions.setSelectedRow(data.data?.at(0)));
            selectRowHandler(data.data?.at(0));
          }
        }
      })
    );
  };
  const selectNextRecord = (e: SyntheticEvent) => {
    if (selectedRow && historyState?.bankRreconciliationList?.data) {
      const bankRreconciliationList = historyState?.bankRreconciliationList?.data;
      const indexNo = bankRreconciliationList?.findIndex(
        (row: { [key: string]: any }) => row?.bank_statement_id === selectedRow?.bank_statement_id
      );
      if (
        indexNo < 9 &&
        (bankRreconciliationList.length - 1 !== indexNo ||
          historyState?.bankRreconciliationList?.currentPage !== historyState?.bankRreconciliationList?.totalPages)
      ) {
        setIndexNo(indexNo);
        setIsNextRecord(true);
      } else if (
        historyState?.bankRreconciliationList?.currentPage < historyState?.bankRreconciliationList?.totalPages
      ) {
        onChangeHandler(e, historyState?.bankRreconciliationList?.currentPage + 1);
      }
    } else if (historyState?.bankRreconciliationList === undefined) {
      onChangeHandler(e, 1);
    }
  };

  const onchangePrevRecord: onChangeType = (e, page) => {
    dispatch(
      getBankReconciliations({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(historyState?.bankRreconciliationList?.pageSize),
        highLightedRecordId: undefined,
        callback: (data) => {
          dispatch(
            bankRecActions.setSelectedRow(data.bankRreconciliationList?.at(data.bankRreconciliationList?.length - 1))
          );
          historyState.bankRreconciliationList = data;
          selectRowHandler(data.data?.at(data.data?.length - 1), data);
        }
      })
    );
  };

  const selectPrevRecord = (e: SyntheticEvent) => {
    if (selectedRow && historyState?.bankRreconciliationList?.data) {
      const bankRreconciliationList = historyState?.bankRreconciliationList?.data;
      const indexNo = bankRreconciliationList?.findIndex(
        (row: { [key: string]: any }) => row?.bank_statement_id === selectedRow?.bank_statement_id
      );
      if (indexNo > 0) {
        setIndexNo(indexNo);
        setIsNextRecord(false);
      } else if (historyState?.bankRreconciliationList?.currentPage > 1) {
        onchangePrevRecord(e, historyState?.bankRreconciliationList?.currentPage - 1);
      } else if (history.location.pathname === "/general-ledger/bank-reconciliation/add") {
        setIndexNo(indexNo);
        setIsNextRecord(false);
      }
    }
  };

  useEffect(() => {
    if (bankReconciliationStatement?.reconciledDetails?.uniqueIdentifier) {
      setToSession("uniqueIdentifier", bankReconciliationStatement?.reconciledDetails?.uniqueIdentifier);
    }
  }, [bankReconciliationStatement]);

  useEffect(() => {
    let timeoutId: any;
    if (reconciledDetails.length > 0) {
      timeoutId = setTimeout(() => {
        const element = document.getElementById(`rowIndex-bankStatement-0`);
        element?.focus();
      }, 10);
    }
    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    };
  }, [reconciledDetails]);

  const dateFormatter = (date: Date) =>
    new Date(date)
      .toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
      })
      .replace("Sept", "Sep");

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const getTagElement = () => (
    <div className="br-sub-title">
      {selectedRow?.statement_no && (
        <Tag
          text={selectedRow.statement_no}
          size={TagSize.Large}
          color={TagColor.Highlight}
        />
      )}

      {selectedRow?.ledger_des && (
        <Tag
          text={selectedRow?.ledger_des}
          size={TagSize.Large}
          color={TagColor.Highlight}
        />
      )}
    </div>
  );
  const handleSwitchToListClick = () => {
    setIsSwitchToListModalOpen((preVal) => !preVal);

    setTimeout(() => {
      const focusButton = document.querySelector(".verify-balances-modal-alert .essui-button--primary") as HTMLElement;
      if (focusButton) {
        focusButton.focus();
      }
    }, 10);
  };

  const calculateTotal = (transactions: any[] | undefined, key: "rcvamount" | "payamount"): number =>
    transactions?.reduce((total, item) => total + Number(item[key]), 0.0) ?? 0.0;

  const calculateStatementDetails = (transactions: any) => {
    if (!transactions) return { totalReceipts: 0.0, totalPayments: 0.0, netAmount: 0.0 };

    const receiptsValue = calculateTotal(transactions, "rcvamount");
    const totalReceipts = usNumberFormat(receiptsValue);
    const paymentsValue = calculateTotal(transactions, "payamount");
    const totalPayments = usNumberFormat(paymentsValue);
    const netAmount = usNumberFormat(receiptsValue - paymentsValue);
    const newAmountRaw = receiptsValue - paymentsValue;

    return { totalReceipts, totalPayments, netAmount, newAmountRaw };
  };

  const calculateNetAmount = () => {
    if (reconciledDetails.length > 0) {
      const reconciledList = calculateStatementDetails(reconciledDetails);
      const netAmount = reconciledList?.newAmountRaw;
      return netAmount !== undefined ? netAmount.toFixed(2) : "0.00";
    }
    return "0.00";
  };

  const openingBal = historyState?.selectedRowState?.opening_bal
    ? historyState?.selectedRowState?.opening_bal
    : selectedRow?.opening_bal ?? "0.00";

  const netAmount = parseFloat(calculateNetAmount()) || 0.0;
  const closingBal = openingBal + netAmount;
  const difference = closingBalance - closingBal;

  const addedUniqueIds = reconciledDetails?.map((addedRow) => ({
    referenceNo: addedRow?.ref,
    uniqueId: addedRow?.unique_id,
    paymentType: addedRow?.itemType,
    paymentAmount: addedRow?.payamount,
    saved: addedRow?.saved || false
  }));
  const removedUniqueIds = unreconciledDetails?.map((addedRow) => ({
    referenceNo: addedRow?.ref,
    uniqueId: addedRow?.unique_id,
    paymentType: addedRow?.itemType,
    paymentAmount: addedRow?.payamount,
    saved: addedRow?.saved || false
  }));

  const onSubmitHandler = () => {
    dispatch(
      saveBankreconStatement({
        opening_bal: historyState.selectedRowState?.opening_bal,
        closing_bal: netAmount,
        bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
        uniqueIdAdded: addedUniqueIds,
        uniqueIdRemoved: removedUniqueIds,
        bank_id: selectedRow?.bank_id,
        series_no: selectedRow?.series_no,
        statement_date: selectedRow?.statement_date,
        start_stat_no: selectedRow?.statement_no + 1,
        difference,
        ledger_description: selectedRow?.ledger_des,
        statement_no: selectedRow?.statement_no,
        callback: () => {
          dispatch(
            getBankReconciliationStatement({
              bankId: bankid,
              bank_statement_id: bankStatementId,
              statementChooser: false,
              sequence: brsFilterState?.sequence,
              uniqueIdentifier: getSessionData("uniqueIdentifier") ? getSessionData("uniqueIdentifier") : ""
            })
          );
          dispatch(bankRecActions.setClosingBalance(closingBal));
        }
      })
    );
  };
  const onSubmitHandlerClickAway = async () => {
    await dispatch(
      saveBankreconStatement({
        opening_bal: historyState.selectedRowState?.opening_bal,
        closing_bal: netAmount,
        bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
        uniqueIdAdded: addedUniqueIds,
        uniqueIdRemoved: removedUniqueIds,
        bank_id: selectedRow?.bank_id,
        series_no: selectedRow?.series_no,
        statement_date: selectedRow?.statement_date,
        start_stat_no: selectedRow?.statement_no + 1,
        difference,
        ledger_description: selectedRow?.ledger_des,
        statement_no: selectedRow?.statement_no,
        callback: () => {
          dispatch(
            getBankReconciliationStatement({
              bankId: bankid,
              bank_statement_id: bankStatementId,
              statementChooser: false,
              sequence: brsFilterState?.sequence,
              uniqueIdentifier: getSessionData("uniqueIdentifier") ? getSessionData("uniqueIdentifier") : ""
            })
          );
          dispatch(bankRecActions.setClosingBalance(closingBal));
        }
      })
    );
  };

  const loaderConfig: loadingConfig = {};

  return (
    <>
      {bankReconStatus === STATUS.LOADING || saveReconStatus === STATUS.LOADING ? (
        <Loader loadingConfig={loaderConfig} />
      ) : (
        <>
          <Layout
            pageTitle={t("bankReconciliation.bankReconciliationStatement")}
            className="invoice-credit-note"
            isBreadcrumbRequired
            isSubTitle={getTagElement()}
            rightContent={
              <BankReconciliationToolbar
                goToPrevRecord={(e) => {
                  selectPrevRecord(e);
                }}
                goToNextRecord={(e) => {
                  selectNextRecord(e);
                }}
                onSubmit={onSubmitHandler}
                nextYearStartDate={nextYearStartDate}
                handleVerifyBalance={handleSwitchToListClick}
                statementBalance={netAmount}
                closingBalance={closingBal}
              />
            }
          >
            <div className="">
              <Grid
                dataTestId="test-id"
                className="row-gap-16"
              >
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">{t("bankReconciliation.statementNo")}</div>
                    <div>{selectedRow?.statement_no}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">{t("bankReconciliation.statementDate")}</div>
                    <div>{dateFormatter(selectedRow?.statement_date)}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">{t("bankReconciliation.accountNo")}</div>
                    <div>{selectedRow?.bank_account}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">{t("bankReconciliation.accSortCode")}</div>
                    <div>{selectedRow?.bank_sort_code}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">{t("bankReconciliation.bankLedger")}</div>
                    <div>
                      {bankReconciliationStatement?.reconciledDetails?.bankLedger
                        ? numberFormatter.format(Number(bankReconciliationStatement?.reconciledDetails?.bankLedger))
                        : specialCharacters.zero}
                    </div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">{t("bankReconciliation.openingBalance")}</div>
                    <div>{numberFormatter.format(selectedRow?.opening_bal)}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">{t("bankReconciliation.closingBalance")}</div>
                    <div>{numberFormatter.format(closingBal)}</div>
                  </div>
                </GridItem>
              </Grid>
            </div>
          </Layout>
          <Layout
            isBreadcrumbRequired={false}
            className="bank-reconciliation-statement"
            type="transparent"
          >
            <GridTableNew
              dataTestId="bankStatement"
              filters={<BankReconciliationStatementFilters />}
              columnDef={bankReconciliationStatementDef}
              selectedRowHandler={(row) => dispatch(brsAction.setSelectedRow(row))}
              dataSource={reconciledDetails || []}
              isLoading={false}
              customCell={CustomCell}
              isScrollable
              selectedRow={bankReconciliationStatementSelectedRow}
            />
          </Layout>

          <Layout isBreadcrumbRequired={false}>
            <Grid>
              <GridItem lg={12}>
                <div className="statement-bal">
                  <span>
                    <span className="essui-form-label">{t("bankReconciliation.statementBalance")}</span>
                    <span className="mt-4">{numberFormatter.format(netAmount)}</span>
                  </span>
                </div>
              </GridItem>
            </Grid>
          </Layout>

          <Layout isBreadcrumbRequired={false}>
            <GridItem>
              <Grid
                className="action-buttons"
                justify="flex-end"
              >
                <Button
                  size={ButtonSize.Small}
                  onClick={async () => {
                    if (historyState?.isDirty) {
                      dispatch(
                        uiActions.confirmPopup({
                          enable: true,
                          message: t("alertMessage.keepChangesMsg"),
                          title: t("common.simsFMSModule"),
                          type: MODAL_TYPE.CONFIRMV2,
                          yesCallback: async () => {
                            if (validateStatement?.rebuild === true) {
                              setIsVerifyBalancesModalOpen(true);
                            } else {
                              await onSubmitHandler();
                              dispatch(bankRecActions.resetValidateStatement());
                              history.push({
                                pathname: "/general-ledger/bank-reconciliation",
                                state: {
                                  ...(history.location.state as any),
                                  isDirty: false
                                }
                              });
                            }
                          },
                          noCallback: () => {
                            setIsVerifyBalancesModalOpen(true);
                            dispatch(
                              deleteBankreconStatement({
                                bank_statement_id: historyState.selectedRowState.bank_statement_id
                              })
                            );
                          },
                          isCancelBtnEnable: true
                        })
                      );
                    } else if (historyState?.isDirty === false && validateStatement?.rebuild === true) {
                      setIsVerifyBalancesModalOpen(true);
                    } else {
                      history.push("/general-ledger/bank-reconciliation", {
                        ...(history.location.state as any)
                      });
                    }
                    setTimeout(() => {
                      const foucusButton = document.querySelector(
                        ".essui-overlay-container .essui-button--primary"
                      ) as HTMLElement;
                      if (foucusButton) {
                        foucusButton.focus();
                      }
                    }, 10);
                  }}
                >
                  {t("common.cancel")}
                </Button>
              </Grid>
            </GridItem>
          </Layout>

          <Modalv2
            className="delete-alert close-button-disabled"
            header={t("alertMessage.verifyBalancesAlert.title")}
            isOpen={isVerifyBalancesModalOpen}
            primaryButton={
              <Button
                size={ButtonSize.Small}
                onClick={() => {
                  dispatch(
                    getVerifyBalaceDetail({
                      uniqueIdentifier: getSessionData("uniqueIdentifier") ? getSessionData("uniqueIdentifier") : "",
                      t,
                      callBackModal: false
                    })
                  );
                  dispatch(bankRecActions.resetValidateStatement());
                  history.push({
                    pathname: "/general-ledger/bank-reconciliation",
                    state: {
                      ...(history.location.state as any),
                      isDirty: false
                    }
                  });
                }}
              >
                {t("common.ok")}
              </Button>
            }
            onClose={() => {
              setIsVerifyBalancesModalOpen(false);
            }}
          >
            <>
              <Notification
                actionElement={1}
                className="confirm-modal-text"
                dataTestId="switch-to-list-warning-id"
                escapeExits
                id="switch-to-list-warning-id"
                hideCloseButton
                status={NotificationStatus.HIGHLIGHT}
                title={t("alertMessage.verifyBalancesAlert.infillStatmentAlert")}
              />
            </>
          </Modalv2>

          <div className="verify-balances-modal-alert">
            <AlertModal
              isOpen={isSwitchToListModalOpen}
              setOpen={setIsSwitchToListModalOpen}
              title={t("alertMessage.verifyBalancesAlert.title")}
              notificationType={NotificationStatus.HIGHLIGHT}
              message={t("alertMessage.switchToListAlert.message")}
              callback={() => {
                setIsSwitchToListModalOpen(false);
              }}
            />
          </div>
        </>
      )}
    </>
  );
};

export default BankReconciliationStatement;
