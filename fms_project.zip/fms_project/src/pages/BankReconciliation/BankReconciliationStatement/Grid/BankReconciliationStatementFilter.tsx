import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { FormLabel, RadioButton, RadioLabelPosition, Button, ButtonSize, Grid, GridItem } from "@essnextgen/ui-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { ACCESS_RIGHTS_ACTION, BANKRECON_STATEMENT_SEQUENCE_TYPE, KEYBOARD_STRING } from "@/types/UseStateType";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { AppDispatch, useAppSelector } from "@/store/store";
import { canDo } from "@/store/state/userAccessRights.slice";
import { Search } from "@carbon/icons-react";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import { useHistory, useParams } from "react-router-dom";
import { actions as brsAction } from "../../state/BankReconciliationStatement.slice";

import columnDef from "./columnDef";

const BankReconciliationStatementFilters = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const dispatch = useDispatch<AppDispatch>();
  const { bankid, bankStatementId } = useParams<{
    bankid: string;
    bankStatementId: any;
  }>();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { filterState, reconciledDetails } = useAppSelector((state) => state.bankReconciliationStatement);

  const { selectedRow } = useAppSelector((state) => state.bankReconciliation);
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const canReports = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.BankReconciliation,
    action: ACCESS_RIGHTS_ACTION.Add
  });
  const handleSequenceChange = (value: React.SetStateAction<string>, sequenceNewIndex: number) => {
    const getRow = columns.find((row) => row.field === value);
    columns.splice(columns.indexOf(getRow!), 1);
    columns.splice(0, 0, getRow!);
    setColumn([...columnDef]);
    dispatch(brsAction.setColumnDef(columns));
    dispatch(
      brsAction.setFilters({
        sequence: sequenceNewIndex,
        sequenceValue: String(value)
      })
    );
  };

  const handleSequenceFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey =
      e.key === KEYBOARD_STRING.ArrowDown ||
      e.key === KEYBOARD_STRING.ArrowUp ||
      e.key === KEYBOARD_STRING.ArrowLeft ||
      e.key === KEYBOARD_STRING.ArrowRight;

    if (isArrowKey) {
      e.preventDefault();

      const nextSequenceValue =
        filterState?.sequenceValue === BANKRECON_STATEMENT_SEQUENCE_TYPE.DATE
          ? BANKRECON_STATEMENT_SEQUENCE_TYPE.REFERENCE
          : BANKRECON_STATEMENT_SEQUENCE_TYPE.DATE;
      const index = nextSequenceValue === BANKRECON_STATEMENT_SEQUENCE_TYPE.REFERENCE ? 1 : 0;

      handleSequenceChange(nextSequenceValue, index);
    }
  };
  const onSequenceChange = (column: any, index: number) => {
    handleSequenceChange(column.field, index);
  };

  const onSelectHandler = () => {
    history.push(
      `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankid}/bankStatementId/${bankStatementId}/statement-content-chooser`,
      {
        ...historyState,
        selectedBankReconRow: selectedRow,
        reconciledDetails,
        redirect: false
      }
    );
  };

  return (
    <>
      <div className="filters align-center justify__content--between">
        <div className="essui-global-typography-default-h2 sequence-container">
          <FormLabel>{t("bankReconciliation.sequence")}</FormLabel>
          <div className="sequence">
            <div
              className="essui-textinput sequence-fields sequence-order"
              onKeyDown={handleSequenceFieldKeyDown}
              data-testId="forKeyDown"
            >
              {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
                const sequenceId = `sequence=${index + 1}`;
                return (
                  <RadioButton
                    label={column.sequenceName ? column.sequenceName : column.headerName}
                    labelPosition={RadioLabelPosition.Right}
                    value={column.field}
                    onChange={() => {
                      onSequenceChange(column, index);
                    }}
                    isSelected={filterState?.sequenceValue === column.field}
                    key={sequenceId}
                    name="sequenceColumn"
                  />
                );
              })}
            </div>
          </div>
        </div>
        <Grid justify="flex-end">
          <GridItem>
            <Button
              className="essui-button essui-button--utility essui-button--small br-0"
              size={ButtonSize.Small}
              onClick={onSelectHandler}
              title="Select Statement Contents"
              disabled={!canReports}
            >
              <Search
                size="18"
                color="black"
              />
            </Button>
          </GridItem>
        </Grid>
      </div>
    </>
  );
};

export default BankReconciliationStatementFilters;
