import { TColumnDef } from "@/components/GridTable/GridTable";

export const bankReconciliationStatementDef: TColumnDef = [
  {
    headerName: "Date",
    field: "item_date",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "Reference",
    field: "ref",
    sequence: true
  },
  {
    headerName: "Description",
    field: "description"
  },
  {
    headerName: "Type",
    field: "itemType"
  },
  {
    headerName: "Payments",
    field: "payamount",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Receipts",
    field: "rcvamount",
    cellRenderer: "GridCellLink",
    align: "right"
  },

  {
    headerName: "",
    field: "actions",
    align: "right",
    cellRenderer: "GridCellLink"
  }
];
export const contractDetailsColumnDef: TColumnDef = [
  {
    field: "fullname",
    headerName: "Name"
  },
  {
    field: "service_term_code",
    headerName: "Code"
  },
  {
    field: "description",
    headerName: "Service Term"
  },
  {
    field: "payroll_number",
    headerName: "Payroll No."
  },
  {
    field: "full_time_equivalence",
    headerName: "Full Time Equivalent",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    field: "status",
    headerName: "Status"
  }
];
export const paymentDetailsColumnDef: TColumnDef = [
  {
    field: "ledger_code",
    headerName: "Ledger Code"
  },
  {
    field: "fund_code",
    headerName: "Fund"
  },
  {
    field: "ledger_des",
    headerName: "Ledger Description"
  },
  {
    field: "commitment",
    headerName: "Commitment",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    field: "actual",
    headerName: "Amount",
    cellRenderer: "GridCellLink",
    align: "right"
  }
];

export default bankReconciliationStatementDef;
