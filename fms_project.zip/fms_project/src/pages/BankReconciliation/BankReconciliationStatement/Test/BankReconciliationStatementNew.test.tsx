import { useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { render, screen } from "@testing-library/react";
import BankReconciliationStatement from "../BankReconciliationStatementNew";

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn(),
  useParams: jest.fn(() => ({ bankId: "123", bankStatementId: "" }))
}));

jest.mock("@/components/GridTableNew/GridTableNew", () => () => <div>GridTableNew</div>);

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("@/pages/BankReconciliation/BankReconciliationStatement/Grid/columnDef", () => [
  {
    headerName: "Date",
    field: "item_date",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "Reference",
    field: "ref",
    sequence: true
  },
  {
    headerName: "Description",
    field: "description"
  },
  {
    headerName: "Type",
    field: "itemType"
  },
  {
    headerName: "Payments",
    field: "payamount",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Receipts",
    field: "rcvamount",
    cellRenderer: "GridCellLink",
    align: "right"
  },

  {
    headerName: "",
    field: "actions",
    align: "right",
    cellRenderer: "GridCellLink"
  }
]);

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-hook-form", () => ({
  useForm: jest.fn()
}));

jest.mock("../../state/BankReconciliationStatement.slice", () => ({
  getBankReconciliationStatement: jest.fn()
}));

jest.mock("../../state/BankReconciliation.slice", () => ({
  getBankReconciliations: jest.fn(),
  bankRecActions: jest.fn(),
  addBankreconStatement: jest.fn()
}));

jest.mock("../Grid/CustomCell", () => () => <div>customCell</div>);
jest.mock("../../BankReconciliationToolbar", () => () => <div>toolbar</div>);
jest.mock("../../../../components/Breadcrumbs/Breadcrumbs", () => () => <div>Breadcrumbs</div>);

describe("BankReconciliationStatementNew", () => {
  const mockRegister = jest.fn();
  const mockSetValue = jest.fn();
  const mockDispatch = jest.fn();
  const mockHistoryPush = jest.fn();
  const mockHistoryReplace = jest.fn();
  const mockUseForm = {
    register: mockRegister,
    setValue: mockSetValue,
    trigger: jest.fn(),
    handleSubmit: jest.fn(),
    setFocus: jest.fn(),
    setError: jest.fn(),
    reset: jest.fn(),
    watch: jest.fn(),
    formState: { errors: {}, isDirty: false },
    getValues: jest.fn()
  };

  const initialStateBankReconciliation = {
    selectedRow: {},
    filterState: {
      pageNumber: 1,
      pageSize: "10",
      sortOrder: 1,
      sequence: 0,
      sequenceValue: "item_date",
      viewname: "All",
      applyFilter: false,
      lookingFor: "",
      highLightedRecordId: 0
    },
    validationStatus: STATUS.IDLE,
    conlumnDef: [
      {
        headerName: "Statement Date",
        field: "statement_date",
        cellRenderer: "GridCellLink",
        sequence: true,
        sequenceName: "Date"
      },
      {
        headerName: "Statement No.",
        field: "statement_no",
        sequence: true,
        sequenceName: "Statement No."
      },
      {
        headerName: "Account",
        field: "ledger_des"
      },
      {
        headerName: "Account No.",
        field: "bank_account"
      },
      {
        headerName: "Sort Code",
        field: "bank_sort_code"
      },
      {
        headerName: "",
        field: "detailLink",
        cellRenderer: "GridCellLink"
      }
    ],
    status: null,
    checkedRows: null,
    checkedOrders: null,
    getFullOrderNumberStatus: null,
    authoriseFullOrderNumber: null,
    unAuthorisedRows: null,
    bankRreconciliationList: null,
    bankReconStatementDetails: null
  };

  const initialStateBankReconciliationStatement = {
    bankReconciliationStatement: {
      reconciledDetails: {
        bankLedger: "",
        bankReconciledTransactions: [],
        uniqueIdentifier: null
      },
      unreconciledDetails: {
        bankLedger: "",
        bankReconciledTransactions: [],
        uniqueIdentifier: null
      }
    }
  };

  beforeEach(() => {
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector: any) => {
      if (selector.name === "selectBankReconciliation") {
        return initialStateBankReconciliation;
      }
      if (selector.name === "selectBankReconciliationStatement") {
        return initialStateBankReconciliationStatement;
      }
      return {};
    });
    (useHistory as jest.Mock).mockReturnValue({
      push: mockHistoryPush,
      replace: mockHistoryReplace,
      location: { state: {} }
    });
    (useForm as jest.Mock).mockReturnValue(mockUseForm);
    jest.clearAllMocks();
  });

  describe("sanity checks", () => {
    it("initially component should render correctly", () => {
      render(<BankReconciliationStatement />);
      screen.debug();
      const breadcrums = screen.getByText(/Breadcrumbs/i);
      const gridTable = screen.getByText(/GridTableNew/i);
      const toolbar = screen.getByText(/toolbar/i);
      expect(breadcrums).toBeInTheDocument();
      expect(gridTable).toBeInTheDocument();
      expect(toolbar).toBeInTheDocument();
    });
  });
});
