import React from "react";
import { render, screen, fireEvent, waitFor, act } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { createMemoryHistory } from "history";
import configureStore from "redux-mock-store";
import { Provider } from "react-redux";
import { Router } from "react-router-dom";
import userEvent from "@testing-library/user-event";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS } from "@/types/UseStateType";
import { actions } from "../../state/BankReconciliationStatement.slice";
import BankReconciliationStatement from "../BankReconciliationStatement";
import {} from "../Grid/columnDef";
import BankReconciliationStatementFilters from "../Grid/BankReconciliationStatementFilter";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn(() => ({
    bankid: "49",
    bankStatementId: "1339"
  }))
}));
jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn(() => jest.fn())
}));

jest.mock("../../../../components/Breadcrumbs/Breadcrumbs", () => () => <div>Breadcrumbs</div>);

jest.mock("../Grid/columnDef", () => [
  {
    headerName: "test header name 1",
    field: "item_date",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "test header name 2",
    field: "ref",
    sequence: true
  },
  {
    headerName: "test header name 3",
    field: "ref",
    sequence: true,
    sequenceName: "test sequence name"
  }
]);

jest.mock("../../BankReconciliationToolbar", () => () => <div>BankReconciliationToolbar</div>);

jest.mock("../../../../components/GridTableNew/GridTableNew", () => jest.fn(() => <div>Mocked GridTableNew</div>));

jest.mock("../Grid/columnDef", () => [
  {
    headerName: "Date",
    field: "item_date",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "Reference",
    field: "ref",
    sequence: true
  }
]);

jest.mock("@/shared/components/AlertModal/AlertModal", () => () => <div>AlertModal</div>);

jest.mock("../Grid/CustomCell", () => jest.fn());

jest.mock("../Grid/BankReconciliationStatementFilter", () => jest.fn());

const initialState = {
  bankReconciliationStatement: {
    bankReconStatus: STATUS.SUCCESS,
    filterState: {
      sequence: 0,
      sequenceValue: "item_date"
    },
    reconciledDetails: [],
    columnDef: [
      {
        headerName: "Date",
        field: "item_date",
        cellRenderer: "GridCellLink",
        sequence: true
      },
      {
        headerName: "Reference",
        field: "ref",
        sequence: true
      }
    ]
  },
  bankReconciliation: {
    selectedRow: {},
    filterState: {},
    nextYearStartDate: "",
    validateStatement: {},
    closingBalance: ""
  }
};

const history = createMemoryHistory();
history.push(
  "/UI/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/49/bankStatementId/1339"
);

const mockStore = configureStore();

const renderWithProviders = (ui: React.ReactElement, { store = mockStore(initialState) } = {}) => {
  const Wrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <Provider store={store}>
      <Router history={history}>{children}</Router>
    </Provider>
  );
  return render(ui, { wrapper: Wrapper });
};

describe("Listing Page", () => {
  it("should render the Grid table with correct props", () => {
    renderWithProviders(<BankReconciliationStatement />);

    expect(screen.getByText("Mocked GridTableNew")).toBeInTheDocument();

    /* eslint-disable global-require */
    const GridTableNewComponent = require("../../../../components/GridTableNew/GridTableNew");
    /* eslint-enable  global-require */
    expect(GridTableNewComponent).toHaveBeenCalledWith(
      expect.objectContaining({
        dataSource: expect.any(Array),
        isLoading: false,
        isScrollable: true
      }),
      {}
    );
  });
  it("should render the Grid table with datasource as empty array if reconciledDetails is null props", () => {
    const state = {
      ...initialState,
      bankReconciliationStatement: {
        ...initialState.bankReconciliationStatement,
        reconciledDetails: null
      }
    };
    renderWithProviders(<BankReconciliationStatement />);

    expect(screen.getByText("Mocked GridTableNew")).toBeInTheDocument();

    /* eslint-disable  global-require */
    const GridTableNewComponent = require("../../../../components/GridTableNew/GridTableNew");
    /* eslint-enable  global-require */
    expect(GridTableNewComponent).toHaveBeenCalledWith(
      expect.objectContaining({
        dataSource: [],
        isLoading: false,
        isScrollable: true
      }),
      {}
    );
  });

  describe("page globals", () => {
    it("should render the page title correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      screen.debug();
      const pageTitle = screen.getByText(/bankReconciliation.bankReconciliationStatement/i);
      expect(pageTitle).toBeInTheDocument();
    });
    it("should render the breadcrums correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const breadcrums = screen.getByText(/Breadcrumbs/i);
      expect(breadcrums).toBeInTheDocument();
    });
    it("should render the toolbar correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const toolbar = screen.getByText(/BankReconciliationToolbar/i);
      expect(toolbar).toBeInTheDocument();
    });
    it("should render the Grid table correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      screen.debug();
      const table = screen.getByText(/Mocked GridTableNew/i);
      expect(table).toBeInTheDocument();
    });

    it("should not render loader if not loading", () => {
      renderWithProviders(<BankReconciliationStatement />);

      const loader = screen.queryByText(/Loading.../i);
      expect(loader).not.toBeInTheDocument();
    });

    it("should render loader while loading", () => {
      const state = {
        ...initialState,
        bankReconciliationStatement: {
          ...initialState.bankReconciliationStatement,
          bankReconStatus: STATUS.LOADING
        }
      };
      const store = mockStore(state);
      renderWithProviders(<BankReconciliationStatement />, { store });

      const loader = screen.getByText(/common.loading/i);
      expect(loader).toBeInTheDocument();
    });

    it("should render cancel button", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const cancelBtn = screen.getByRole("button", { name: /common.cancel/i });
      expect(cancelBtn).toBeInTheDocument();
    });

    it("cancel button should be enabled", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const cancelBtn = screen.getByRole("button", { name: /common.cancel/i });
      expect(cancelBtn).toBeEnabled();
    });

    it("should redirect to the bankreconciliation statement listing page on cancel button click by default", async () => {
      renderWithProviders(<BankReconciliationStatement />);
      const cancelBtn = screen.getByRole("button", { name: /common.cancel/i });
      await userEvent.click(cancelBtn);
      await waitFor(() => {
        expect(history.location.pathname).toBe("/general-ledger/bank-reconciliation");
      });
    });
  });

  describe("meta data checks Bank Reconciliation Statement", () => {
    it("should render the statement number correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const statementNo = screen.getByText(/bankReconciliation.statementNo/i);
      expect(statementNo).toBeInTheDocument();
    });
    it("should render the statement date correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const statementDate = screen.getByText(/bankReconciliation.statementDate/i);
      expect(statementDate).toBeInTheDocument();
    });

    it("should render the account number correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const accountNo = screen.getByText(/bankReconciliation.accountNo/i);
      expect(accountNo).toBeInTheDocument();
    });
    it("should render the account sort code correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const accSortCode = screen.getByText(/bankReconciliation.accSortCode/i);
      expect(accSortCode).toBeInTheDocument();
    });
    it("should render the bank ledger correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const bankLedger = screen.getByText(/bankReconciliation.bankLedger/i);
      expect(bankLedger).toBeInTheDocument();
    });
    it("should render the opening balance correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const openingBal = screen.getByText(/bankReconciliation.openingBalance/i);
      expect(openingBal).toBeInTheDocument();
    });
    it("should render the closing balance correctly", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const closingBal = screen.getByText(/bankReconciliation.closingBalance/i);
      expect(closingBal).toBeInTheDocument();
    });
    it("should render the statement balance", () => {
      renderWithProviders(<BankReconciliationStatement />);
      const statementBal = screen.getByText(/bankReconciliation.statementBalance/i);
      expect(statementBal).toBeInTheDocument();
    });
    it("should render bank ledger instead of zero in bank ledger", () => {
      const state = {
        ...initialState,
        bankReconciliationStatement: {
          ...initialState.bankReconciliationStatement,
          bankReconciliationStatement: {
            reconciledDetails: {
              ...initialState.bankReconciliationStatement.reconciledDetails,
              bankLedger: "7"
            }
          }
        }
      };
      const store = mockStore(state);
      renderWithProviders(<BankReconciliationStatement />, { store });

      const bankLedger = screen.getByText(/7/i);
      expect(bankLedger).toBeInTheDocument();
    });
  });
});
