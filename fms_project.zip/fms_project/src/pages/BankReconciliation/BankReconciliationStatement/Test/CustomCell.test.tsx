import { Provider, useDispatch } from "react-redux";
import { screen, render, waitFor, act, fireEvent } from "@testing-library/react";
import { Router, useHistory } from "react-router-dom";
import { createMemoryHistory } from "history";
import configureStore from "redux-mock-store";
import userEvent from "@testing-library/user-event";
import { BOOLEAN_DATA, STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import React from "react";
import axios from "axios";
import thunk from "redux-thunk";
import { useAppSelector } from "@/store/store";
import { checkTransCurrentYr } from "../../state/BankReconciliationStatement.slice";
import CustomCell from "../Grid/CustomCell";

jest.mock("axios");
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock("react-redux", () => ({
  __esModule: true,
  useDispatch: jest.fn()
}));
jest.mock("../../../../routes/Routes.utils", () => ({
  useAppContext: () => ({
    redirectToBankReconciledDetails: jest.fn((row) => ({
      bankreconciledDetailsLink:
        "/UI/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/49/bankStatementId/1339"
    }))
  })
}));

jest.mock("@/store/store", () => ({
  __esModule: true,
  useAppSelector: jest.fn()
}));

jest.mock("../../state/BankReconciliationStatement.slice", () => ({
  checkTransCurrentYr: jest.fn((props: any) => {
    if (props?.callback !== undefined) {
      const data = "T";
      props?.callback(data);
    }
  }),
  getBankViewGlFundToBack: jest.fn(),
  getPaymentRunId: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  __esModule: true,
  useHistory: jest.fn(),
  useParams: jest.fn(() => ({ bankId: "123", bankStatementId: "" }))
}));

const row = {
  ref: "008809",
  unique_id: "CH0000012478",
  rcvamount: 0,
  payamount: 120,
  item_date: "2024-02-23T00:00:00",
  description: "Rank Xerox",
  user_id: "21",
  itemType: "AP",
  source: "CHEQUE",
  account_id: 0,
  ledger_code: "BK01",
  posting_year: 26,
  posting_period: 11,
  statement_year: 26,
  statement_period: 12,
  statement_dt: "2024-03-22T00:00:00",
  statement_no: 1306,
  commitment: 0,
  actual: 0,
  full_time_equivalence: 0
};

describe("testing Custom Cell component", () => {
  const mockDispatch = jest.fn();
  const mockHistoryPush = jest.fn();
  const mockHistoryReplace = jest.fn();
  const initialState = {
    bankReconciliation: {
      bankRreconciliationList: {
        data: [],
        currentPage: 1,
        totalCount: "",
        pageSize: 10,
        totalPages: 0,
        highLightedRecordId: 0
      }
    }
  };
  beforeEach(() => {
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector: any) => selector(initialState));
    (useHistory as jest.Mock).mockReturnValue({
      push: mockHistoryPush,
      replace: mockHistoryReplace,
      location: { state: {} }
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe("if field is passed as actions", () => {
    it("should render view button if ", () => {
      const field = "actions";

      render(
        <CustomCell
          field={field}
          row={row}
        />
      );
      screen.debug();
      const viewBtn = screen.getByRole("button", { name: "common.view02" });
      expect(viewBtn).toBeInTheDocument();
    });

    it("view button should be enabled", () => {
      const field = "actions";

      render(
        <CustomCell
          field={field}
          row={row}
        />
      );
      const viewBtn = screen.getByRole("button", { name: "common.view02" });
      expect(viewBtn).toBeEnabled();
    });
    it("view button click handle", async () => {
      mockedAxios.get.mockResolvedValue({
        data: "some dummy response"
      });
      const field = "actions";

      render(
        <CustomCell
          field={field}
          row={row}
        />
      );
      const viewBtn = screen.getByRole("button", { name: "common.view02" });
      fireEvent.click(viewBtn);
    });
  });

  describe("if field is passed as item_date", () => {
    it("should render date", () => {
      const field = "item_date";

      render(
        <CustomCell
          field={field}
          row={row}
        />
      );
      screen.debug();
      const date = screen.getByText(/23 Feb 2024/i);
      expect(date).toBeInTheDocument();
    });
  });

  describe("if field is passed as rcvamount", () => {
    it("should render rcvamount", () => {
      const field = "rcvamount";

      render(
        <CustomCell
          field={field}
          row={row}
        />
      );
      screen.debug();
      const rcvamount = screen.getByText(/0.00/i);
      expect(rcvamount).toBeInTheDocument();
    });
  });

  describe("if field is passed as payamount", () => {
    it("should render payamount", () => {
      const field = "payamount";

      render(
        <CustomCell
          field={field}
          row={row}
        />
      );
      screen.debug();
      const payamount = screen.getByText(/120/i);
      expect(payamount).toBeInTheDocument();
    });
  });

  describe("if field is passed as commitment", () => {
    it("should render commitment", () => {
      const field = "commitment";

      render(
        <CustomCell
          field={field}
          row={row}
        />
      );
      screen.debug();
      const commitment = screen.getByText(/0/i);
      expect(commitment).toBeInTheDocument();
    });
  });

  describe("if field is passed as actual", () => {
    it("should render actual", () => {
      const field = "actual";

      render(
        <CustomCell
          field={field}
          row={row}
        />
      );
      screen.debug();
      const actual = screen.getByText(/0/i);
      expect(actual).toBeInTheDocument();
    });
  });

  describe("if field is passed as full_time_equivalence", () => {
    it("should render full_time_equivalence", () => {
      const field = "full_time_equivalence";

      render(
        <CustomCell
          field={field}
          row={row}
        />
      );
      screen.debug();
      /* eslint-disable camelcase */

      const full_time_equivalence = screen.getByText(/0/i);
      expect(full_time_equivalence).toBeInTheDocument();
      /* eslint-enable camelcase */
    });
  });

  describe("if field is passed as exception", () => {
    it("should render exception", () => {
      const field = "exception";

      render(
        <CustomCell
          field={field}
          row={row}
        />
      );
      screen.debug();
      const exception = screen.queryByRole("button");
      expect(exception).not.toBeInTheDocument();
    });
  });
});
