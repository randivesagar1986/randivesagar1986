import React from "react";
import { render, screen, fireEvent, waitFor, act } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { createMemoryHistory } from "history";
import configureStore from "redux-mock-store";
import { Provider } from "react-redux";
import { Router } from "react-router-dom";
import userEvent from "@testing-library/user-event";
import { canDo } from "@/store/state/userAccessRights.slice";
import { actions } from "../../state/BankReconciliationStatement.slice";
import BankReconciliationStatementFilters from "../Grid/BankReconciliationStatementFilter";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn(() => ({
    bankid: "49",
    bankStatementId: "1339"
  }))
}));
jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn(() => jest.fn())
}));

jest.mock("@/store/state/userAccessRights.slice", () => ({
  __esModule: true,
  default: {
    reducers: {}
  },
  canDo: jest.fn()
}));

jest.mock("../Grid/columnDef", () => [
  {
    headerName: "test header name 1",
    field: "item_date",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "test header name 2",
    field: "ref",
    sequence: true
  },
  {
    headerName: "test header name 3",
    field: "ref",
    sequence: true,
    sequenceName: "test sequence name"
  }
]);

const initialState = {
  bankReconciliationStatement: {
    filterState: {
      sequence: 0,
      sequenceValue: "item_date"
    },
    reconciledDetails: {
      bankLedger: "",
      bankReconciledTransactions: [],
      uniqueIdentifier: null
    }
  },
  bankReconciliation: {
    bank_id: 49,
    str_bank_id: null,
    ledger_code: "BK01",
    ledger_des: "Bank Account",
    bank_account: "01177112",
    bank_sort_code: "40-32-16",
    statement_no: 1306,
    series_no: 1,
    statement_date: "2024-03-22T00:00:00",
    last_modified: "2024-03-27T00:00:00",
    statement_bal: -19015.04,
    opening_bal: 628572.64,
    closing_bal: 609557.6,
    bank_statement_id: 1339,
    user_code: "US1"
  },
  userAccessRights: {}
};

const history = createMemoryHistory();
history.push(
  "/UI/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/49/bankStatementId/1339"
);

const mockStore = configureStore();

const renderWithProviders = (ui: React.ReactElement, { store = mockStore(initialState) } = {}) => {
  const Wrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <Provider store={store}>
      <Router history={history}>{children}</Router>
    </Provider>
  );
  return render(ui, { wrapper: Wrapper });
};

describe("BankReconciliationStatementFilters", () => {
  describe("sequence", () => {
    test("shoould render sequences label", () => {
      renderWithProviders(<BankReconciliationStatementFilters />);
      const sequencesLabel = screen.getByText(/bankReconciliation.sequence/i);
      expect(sequencesLabel).toBeInTheDocument();
    });
    test("renders the sequence radios", () => {
      renderWithProviders(<BankReconciliationStatementFilters />);
      const sequenceRadios = screen.getAllByRole("radio");
      sequenceRadios.forEach((radio) => {
        expect(radio).toBeInTheDocument();
      });
    });

    test("renders the sequence radios labels", () => {
      renderWithProviders(<BankReconciliationStatementFilters />);
      const sequenceLabel1 = screen.getByText(/test header name 1/i);
      const sequenceLabel2 = screen.getByText(/test header name 2/i);
      expect(sequenceLabel1).toBeInTheDocument();
      expect(sequenceLabel2).toBeInTheDocument();
    });

    test("sequence radios should be clicable", async () => {
      renderWithProviders(<BankReconciliationStatementFilters />);
      const sequenceRadios = screen.getAllByRole("radio");
      sequenceRadios.forEach(async (radio) => {
        expect(radio).toBeEnabled();
      });
    });

    test("sequences should be rightly synched with the state", () => {
      renderWithProviders(<BankReconciliationStatementFilters />);
      const sequenceRadios: any = screen.getAllByRole("radio");
      userEvent.click(sequenceRadios[0]);
      expect(sequenceRadios[0].checked).toBeTruthy();
      expect(sequenceRadios[1].checked).toBeFalsy();
    });

    test("sequences should be rightly synched with the ", async () => {
      renderWithProviders(<BankReconciliationStatementFilters />);
      const sequence2 = screen.getByRole("radio", { name: /test header name 2/i });
      fireEvent.click(sequence2);
      const sequences: HTMLInputElement[] = screen.getAllByRole("radio");
      expect(sequences[0].checked).toBeTruthy();
      expect(sequences[1].checked).toBeFalsy();
    });

    test("if sequence name is their then sequence radio label should use sequence name instead header name", async () => {
      renderWithProviders(<BankReconciliationStatementFilters />);
      const sequenceWithHeaderName: any = screen.queryByRole("radio", { name: /test header name 3/i });
      expect(sequenceWithHeaderName).not.toBeInTheDocument();
      const sequenceWithSequenceName: any = screen.queryByRole("radio", { name: /test sequence name/i });
      expect(sequenceWithSequenceName).toBeInTheDocument();
    });

    test("should trigger handleSequenceFieldKeyDown and dispatch setFilters action on arrowDown keypress on sequence radio button", async () => {
      const setFiltersSpy = jest.spyOn(actions, "setFilters");

      renderWithProviders(<BankReconciliationStatementFilters />);

      const sequence1: HTMLInputElement = screen.getByRole("radio", { name: /test header name 1/i });
      const sequence2: HTMLInputElement = screen.getByRole("radio", { name: /test header name 2/i });

      sequence1.focus();

      fireEvent.keyDown(sequence1, { key: "ArrowDown", code: "ArrowDown" });

      await waitFor(() => {
        expect(setFiltersSpy).toHaveBeenCalledWith({ sequence: 1, sequenceValue: "ref" });
      });
    });
    test("should trigger handleSequenceFieldKeyDown and dispatch setFilters action on arrowUp keypress on sequence radio button", async () => {
      const setFiltersSpy = jest.spyOn(actions, "setFilters");

      renderWithProviders(<BankReconciliationStatementFilters />);

      const sequence1: HTMLInputElement = screen.getByRole("radio", { name: /test header name 1/i });
      const sequence2: HTMLInputElement = screen.getByRole("radio", { name: /test header name 2/i });

      sequence1.focus();

      fireEvent.keyDown(sequence1, { key: "ArrowUp", code: "ArrowUp" });

      await waitFor(() => {
        expect(setFiltersSpy).toHaveBeenCalledWith({ sequence: 1, sequenceValue: "ref" });
      });
    });
    test("should trigger handleSequenceFieldKeyDown and dispatch setFilters action on arrowRight keypress on sequence radio button", async () => {
      const setFiltersSpy = jest.spyOn(actions, "setFilters");

      renderWithProviders(<BankReconciliationStatementFilters />);

      const sequence1: HTMLInputElement = screen.getByRole("radio", { name: /test header name 1/i });
      const sequence2: HTMLInputElement = screen.getByRole("radio", { name: /test header name 2/i });

      sequence1.focus();

      fireEvent.keyDown(sequence1, { key: "ArrowRight", code: "ArrowRight" });

      await waitFor(() => {
        expect(setFiltersSpy).toHaveBeenCalledWith({ sequence: 1, sequenceValue: "ref" });
      });
    });
    test("should trigger handleSequenceFieldKeyDown and dispatch setFilters action on arrowLeft keypress on sequence radio button", async () => {
      const setFiltersSpy = jest.spyOn(actions, "setFilters");

      renderWithProviders(<BankReconciliationStatementFilters />);

      const sequence1: HTMLInputElement = screen.getByRole("radio", { name: /test header name 1/i });
      const sequence2: HTMLInputElement = screen.getByRole("radio", { name: /test header name 2/i });

      sequence1.focus();

      fireEvent.keyDown(sequence1, { key: "ArrowLeft", code: "ArrowLeft" });

      await waitFor(() => {
        expect(setFiltersSpy).toHaveBeenCalledWith({ sequence: 1, sequenceValue: "ref" });
      });
    });
  });

  describe("select statement content", () => {
    beforeEach(() => {
      (canDo as jest.Mock).mockReturnValue({
        test: "mock data for testing purposes"
      });
    });
    it("should be in the dom", () => {
      renderWithProviders(<BankReconciliationStatementFilters />);
      const selectStmBtn = screen.getByRole("button", { name: "Select Statement Contents" });
      expect(selectStmBtn).toBeInTheDocument();
    });

    it("should be enabled", () => {
      renderWithProviders(<BankReconciliationStatementFilters />);
      const selectStmBtn = screen.getByRole("button", { name: "Select Statement Contents" });
      expect(selectStmBtn).toBeEnabled();
    });

    it("should navigate to the correct route on click of select statement contents button", async () => {
      renderWithProviders(<BankReconciliationStatementFilters />);
      const selectStmBtn = screen.getByRole("button", { name: "Select Statement Contents" });
      await userEvent.click(selectStmBtn);
      expect(history.location.pathname).toBe(
        "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/49/bankStatementId/1339/statement-content-chooser"
      );
    });
  });
});
