import {
  AddLarge,
  ArrowDown,
  ArrowUp,
  Printer,
  Save,
  /* eslint-disable camelcase */
  Thumbnail_2,
  Subtract,
  Undo,
  ScalesTipped
} from "@carbon/icons-react";
import { ButtonSize } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { RouteComponentProps, useHistory, useParams, withRouter } from "react-router-dom";
import Toolbar, { ToolbarType } from "@/components/Toolbar/Toolbar";
import { BaseSyntheticEvent, SyntheticEvent, useEffect, useState } from "react";
import { useAppContext } from "@/routes/Routes.utils";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { AppDispatch, useAppSelector } from "@/store/store";
import { canDo } from "@/store/state/userAccessRights.slice";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { getSessionItem, getSessionItem as getSessionData } from "@/utils/getDataSource";
import { actions as bankAccountActions } from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import {
  actions as sccActions,
  deleteRecord,
  getBankReconciliationDocument,
  deleteBankreconStatement,
  actions as bankRecStatementActions,
  saveBankreconStatement,
  getBankReconciliationStatement
} from "@/pages/BankReconciliation/state/BankReconciliationStatement.slice";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import { bankRecActions, closeDetails, getBankReconciliations } from "./state/BankReconciliation.slice";

type BRToolbarType = {
  onSubmit?: () => void;
  goToPrevRecord?: (e: SyntheticEvent) => void;
  goToNextRecord?: (e: SyntheticEvent) => void;
  handleVerifyBalance?: () => void;
  isDirty?: boolean;
  nextYearStartDate?: any;
  removeLastElement?: boolean;
  statementBalance?: any;
  closingBalance?: any;
  dataTestId?: string;
} & RouteComponentProps;

interface MyResponseType {
  payload: string; // Adjust this type according to your actual response structure
  // Add other properties if necessary
}

const BankReconciliationToolbar = ({
  onSubmit,
  goToPrevRecord,
  goToNextRecord,
  isDirty,
  removeLastElement,
  nextYearStartDate,
  handleVerifyBalance,
  statementBalance,
  dataTestId,
  closingBalance: newClosingBalance
}: BRToolbarType) => {
  const { redirectToBankReconciledDetails, setPromise } = useAppContext();
  const history = useHistory();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { selectedRow, bankRreconciliationList, filterState, closingBalance } = useAppSelector(
    (state) => state.bankReconciliation
  );
  const historyState = { ...(history.location.state as any) };
  const { bankid, bankStatementId } = useParams<{
    bankid: string;
    bankStatementId: any;
  }>();
  const dispatch = useDispatch<AppDispatch>();
  const [isUndoModalOpen, setIsUndoModalOpen] = useState<boolean>(false);
  const { alert } = useAppSelector((state) => state.ui);
  const {
    isLoading,
    VerifyBalaceStatus,
    reconciledDetails,
    unreconciledDetails,
    filterState: brsFilterState
  } = useAppSelector((state) => state.bankReconciliationStatement);

  const addedUniqueIds = reconciledDetails?.map((addedRow) => ({
    referenceNo: addedRow?.ref,
    uniqueId: addedRow?.unique_id,
    paymentType: addedRow?.itemType,
    paymentAmount: addedRow?.payamount,
    saved: addedRow?.saved || false
  }));
  const removedUniqueIds = unreconciledDetails?.map((addedRow) => ({
    referenceNo: addedRow?.ref,
    uniqueId: addedRow?.unique_id,
    paymentType: addedRow?.itemType,
    paymentAmount: addedRow?.payamount,
    saved: addedRow?.saved || false
  }));
  const difference = closingBalance - newClosingBalance;
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const canAdd = canDo(userAccessRights, { module: "Bank Reconciliation", action: "Add" });
  const canPrint = canDo(userAccessRights, { module: "Bank Reconciliation", action: "Print" });

  const onClickDelete = () => {
    dispatch(
      deleteRecord({
        isDetails: bankid === undefined,
        bankid: selectedRow?.bank_id,
        bankStatementId: selectedRow?.bank_statement_id,
        reconciledRecords: reconciledDetails,
        t,
        callback: (data, row) => {
          dispatch(bankRecStatementActions.resetDeleteStatus());
          if (row && bankid) {
            const { bankreconciledDetailsLink } = redirectToBankReconciledDetails(row);
            history.push({
              pathname: bankreconciledDetailsLink,
              state: {
                selectedRowState: row,
                bankRreconciliationList: data
              }
            });
          }
        }
      })
    );
  };

  const printDocument = async (bankID: string, statementId: string, statementNumber: string) => {
    const res = await dispatch(getBankReconciliationDocument({ bankID, statementId, statementNumber }));
    const pdfData = (res as unknown as MyResponseType).payload;
    try {
      const byteCharacters = atob(pdfData);
      const byteNumbers = new Array(byteCharacters.length);
      let i = 0;
      while (i < byteCharacters.length) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
        i += 1; // Use compound assignment instead of increment operator
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: "application/pdf" });
      const pdfUri = URL.createObjectURL(blob);
      if (pdfUri) {
        fetch(pdfUri)
          .then((response) => response.blob())
          .then((responseBlob) => {
            // Create a link element
            const link = document.createElement("a");
            link.href = window.URL.createObjectURL(responseBlob);
            link.download = statementNumber; // Set the download attribute with file extension
            link.click();
            // Revoke the Blob URL to free up memory
            window.URL.revokeObjectURL(link.href);
          })

          .catch((error) => {
            // TODO:Add error handler and remove console
            // console.error("Error downloading file:", error);
          });
      }
      // setIsLoading(true);
    } catch (error) {
      // TODO:Add error handler and remove console
      // console.error("Error decoding base64 string:", error);
      // Handle the error gracefully, e.g., set pdfUrl to null
    }
  };

  const checkSaveChanges = (resolve?: any) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: "invalidData",
        className: "delete-alert",
        callback: () => {
          if (resolve) resolve(true);
        }
      })
    );
  };

  const handleOnKeyPress = () => {
    if (handleVerifyBalance) {
      handleVerifyBalance();
    }
  };

  // Called when the user press yes button in the undo alert
  const undoAlertHandler = async () => {
    if (historyState?.isNotSaved) {
      const index = (bankRreconciliationList?.data || [])?.findIndex(
        (e: any) => e?.bank_statement_id === selectedRow?.bank_statement_id
      );
      dispatch(
        deleteBankreconStatement({
          bank_statement_id: historyState.selectedRowState.bank_statement_id,
          callback: (data) => {
            dispatch(
              getBankReconciliations({
                ...filterState,
                lookingFor: "",
                highLightedRecordId:
                  index && bankRreconciliationList?.data?.at(index + 1)
                    ? bankRreconciliationList?.data?.at(index + 1)?.bank_statement_id
                    : undefined,
                callback: (data, selectedRow) => {
                  const index = data.data.indexOf(selectedRow);
                  if (bankid) {
                    historyState.bankRreconciliationList = data;
                    dispatch(bankRecActions.setSelectedRow(selectedRow));
                    selectRowHandler(data.data?.at(index));
                    const bankReconciledDetailsLink = selectedRow
                      ? `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${selectedRow.bank_id}/bankStatementId/${selectedRow.bank_statement_id}`
                      : "";
                    history.push(bankReconciledDetailsLink, {
                      ...(history.location.state as any),
                      bankRreconciliationList: data || historyState.bankRreconciliationList,
                      selectedRowState: selectedRow,
                      isDirty: false,
                      sccDetails: undefined,
                      needToSave: false
                    });
                  }
                }
              })
            );
          }
        })
      );
    } else {
      await dispatch(
        getBankReconciliationStatement({
          bankId: bankid,
          bank_statement_id: bankStatementId,
          statementChooser: false,
          sequence: brsFilterState?.sequence,
          uniqueIdentifier: getSessionData("uniqueIdentifier") ? getSessionData("uniqueIdentifier") : ""
        })
      );
      dispatch(sccActions.resetSccRow());

      history.replace({
        ...history.location,
        state: {
          ...(history.location.state as any),
          isDirty: false,
          sccDetails: undefined,
          needToSave: false
        }
      });
    }
  };

  const selectRowHandler = (row: { [key: string]: any } | undefined, data?: any) => {
    const bankReconciledDetailsLink = row
      ? `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${row.bank_id}/bankStatementId/${row.bank_statement_id}`
      : "";
    history.push(bankReconciledDetailsLink, {
      ...(history.location.state as any),
      bankRreconciliationList: data || historyState.bankRreconciliationList,
      selectedRowState: row,
      isDirty: false,
      sccDetails: undefined
    });
  };

  const buttons: ToolbarType[] = [
    {
      title: "Focus Mode",
      /* eslint-disable react/jsx-pascal-case */
      element: <Thumbnail_2 size={18} />,
      size: ButtonSize.Small,
      onClick: async () => {
        if (bankid) {
          dispatch(
            bankRecActions.setFilters({
              highLightedRecordId: selectedRow?.bank_statement_id
            })
          );
          if (
            history.location.pathname.includes(
              "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details"
            )
          ) {
            if (historyState?.isDirty) {
              const result: boolean | undefined = await setPromise((resolve: any) => checkSaveChanges(resolve));
              if (result !== undefined) {
                if (result === true) {
                  dispatch(
                    saveBankreconStatement({
                      opening_bal: historyState.selectedRowState?.opening_bal,
                      closing_bal: statementBalance,
                      bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
                      uniqueIdAdded: addedUniqueIds,
                      uniqueIdRemoved: removedUniqueIds,
                      bank_id: selectedRow?.bank_id,
                      series_no: selectedRow?.series_no,
                      statement_date: selectedRow?.statement_date,
                      start_stat_no: selectedRow?.statement_no + 1,
                      difference,
                      ledger_description: selectedRow?.ledger_des,
                      statement_no: selectedRow?.statement_no,
                      callback: () => {
                        dispatch(bankRecActions.setClosingBalance(newClosingBalance));
                        history.push("/general-ledger/bank-reconciliation", {
                          ...(history.location.state as any),
                          redirect: true
                        });
                      }
                    })
                  );
                } else if (result === false) {
                  history.push("/general-ledger/bank-reconciliation", {
                    ...(history.location.state as any)
                  });
                }
              }
            } else {
              history.push("/general-ledger/bank-reconciliation", {
                ...(history.location.state as any)
              });
            }
          }
        } else {
          const { bankreconciledDetailsLink } = redirectToBankReconciledDetails(selectedRow);
          history.push(bankreconciledDetailsLink, {
            ...(history.location.state as any),
            selectedRowState: selectedRow,
            bankRreconciliationList,
            isDirty: false
          });
        }
      }
    },
    {
      title: "Previous Record",
      element: <ArrowUp size={18} />,
      size: ButtonSize.Small,
      onClick: async (e) => {
        let result: boolean | undefined;
        if (
          history.location.pathname !== "/general-ledger/bank-reconciliation" &&
          historyState?.isDirty &&
          history.location.pathname.includes(
            "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details"
          )
        ) {
          result = await setPromise((resolve: any) => checkSaveChanges(resolve));
          if (result !== undefined) {
            if (result === false && historyState?.from === "add statement") {
              dispatch(
                deleteBankreconStatement({
                  bank_statement_id: historyState.selectedRowState.bank_statement_id,
                  callback: (data) => {
                    if (result === false) {
                      if (goToPrevRecord) {
                        goToPrevRecord(e);
                      }
                    }
                  }
                })
              );
            } else if (goToPrevRecord && result === false) {
              goToPrevRecord(e);
            } else if (goToPrevRecord && result === true) {
              dispatch(
                saveBankreconStatement({
                  opening_bal: historyState.selectedRowState?.opening_bal,
                  closing_bal: statementBalance,
                  bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
                  uniqueIdAdded: addedUniqueIds,
                  uniqueIdRemoved: removedUniqueIds,
                  bank_id: selectedRow?.bank_id,
                  series_no: selectedRow?.series_no,
                  statement_date: selectedRow?.statement_date,
                  start_stat_no: selectedRow?.statement_no + 1,
                  difference,
                  ledger_description: selectedRow?.ledger_des,
                  statement_no: selectedRow?.statement_no,
                  callback: () => {
                    dispatch(bankRecActions.setClosingBalance(newClosingBalance));
                    goToPrevRecord(e);
                  }
                })
              );
            }
          }
        } else if (goToPrevRecord) {
          goToPrevRecord(e);
        }
      }
    },
    {
      title: "Next Record",
      element: <ArrowDown size={18} />,
      size: ButtonSize.Small,
      id: "btnNextRec",
      onClick: async (e) => {
        let result: boolean | undefined;
        if (
          history.location.pathname !== "/general-ledger/bank-reconciliation" &&
          historyState?.isDirty &&
          history.location.pathname.includes(
            "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details"
          )
        ) {
          result = await setPromise((resolve: any) => checkSaveChanges(resolve));
          if (result !== undefined) {
            if (result === false && historyState?.from === "add statement") {
              dispatch(
                deleteBankreconStatement({
                  bank_statement_id: historyState.selectedRowState.bank_statement_id,
                  callback: (data) => {
                    if (result === false) {
                      if (goToNextRecord) {
                        goToNextRecord(e);
                      }
                    }
                  }
                })
              );
            } else if (goToNextRecord && result === false) {
              goToNextRecord(e);
            } else if (goToNextRecord && result === true) {
              dispatch(
                saveBankreconStatement({
                  opening_bal: historyState.selectedRowState?.opening_bal,
                  closing_bal: statementBalance,
                  bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
                  uniqueIdAdded: addedUniqueIds,
                  uniqueIdRemoved: removedUniqueIds,
                  bank_id: selectedRow?.bank_id,
                  series_no: selectedRow?.series_no,
                  statement_date: selectedRow?.statement_date,
                  start_stat_no: selectedRow?.statement_no + 1,
                  difference,
                  ledger_description: selectedRow?.ledger_des,
                  statement_no: selectedRow?.statement_no,
                  callback: () => {
                    dispatch(bankRecActions.setClosingBalance(newClosingBalance));
                    goToNextRecord(e);
                  }
                })
              );
            }
          }
        } else if (goToNextRecord) {
          goToNextRecord(e);
        }
      }
    },
    {
      title: "Add Record",
      element: <AddLarge size={18} />,
      onClick: async (e) => {
        let result;
        if (
          history.location.pathname !== "/general-ledger/bank-reconciliation" &&
          historyState?.isDirty &&
          history.location.pathname.includes(
            "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details"
          )
        ) {
          result = await setPromise((resolve: any) => checkSaveChanges(resolve));
          if (result !== undefined) {
            dispatch(bankAccountActions.resetSelectedRow());
            if (historyState?.from === "add statement" && result === false) {
              dispatch(
                deleteBankreconStatement({
                  bank_statement_id: historyState.selectedRowState.bank_statement_id
                })
              );
            } else if (result === true) {
              dispatch(
                saveBankreconStatement({
                  opening_bal: historyState.selectedRowState?.opening_bal,
                  closing_bal: statementBalance,
                  bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
                  uniqueIdAdded: addedUniqueIds,
                  uniqueIdRemoved: removedUniqueIds,
                  bank_id: selectedRow?.bank_id,
                  series_no: selectedRow?.series_no,
                  statement_date: selectedRow?.statement_date,
                  start_stat_no: selectedRow?.statement_no + 1,
                  difference,
                  ledger_description: selectedRow?.ledger_des,
                  statement_no: selectedRow?.statement_no,
                  callback: () => {
                    dispatch(bankRecActions.setClosingBalance(newClosingBalance));
                  }
                })
              );
            }
            dispatch(bankRecStatementActions.resetReconciledDetails());
            history.push({
              pathname: "/general-ledger/bank-reconciliation/add",
              state: {
                nextYearStartDate,
                isDirty: false
              }
            });
          }
        } else {
          dispatch(bankRecStatementActions.resetReconciledDetails());
          dispatch(bankAccountActions.resetSelectedRow());
          history.push({
            pathname: "/general-ledger/bank-reconciliation/add",
            state: {
              nextYearStartDate,
              isDirty: false
            }
          });
        }
      },
      size: ButtonSize.Small,
      disabled: !canAdd
    },
    {
      title: "Delete Record",
      element: <Subtract size={18} />,
      size: ButtonSize.Small,
      onClick: onClickDelete,
      disabled: !canAdd
    },
    {
      title: "Save Record Changes",
      element: <Save size={18} />,
      onClick: async () => {
        if (onSubmit && historyState?.needToSave) {
          onSubmit();
          dispatch(bankRecStatementActions.resetSccRow());
          history.replace({
            ...history.location,
            state: {
              ...historyState,
              isDirty: false,
              isNotSaved: false,
              reconciledDetails: undefined,
              unreconciledDetails: undefined,
              sccDetails: undefined,
              needToSave: false
            }
          });
        } else {
          history.replace({
            ...history.location,
            state: {
              ...historyState,
              isDirty: false
            }
          });
        }
      },
      size: ButtonSize.Small,
      disabled: !canAdd
    },
    {
      title: "Undo Record Changes",
      element: <Undo size={18} />,
      size: ButtonSize.Small,
      onClick: async () => {
        if (
          (history.location.pathname !== "/general-ledger/bank-reconciliation" && (isDirty || historyState?.isDirty)) ||
          history.location.pathname === "/general-ledger/bank-reconciliation/add"
        ) {
          setIsUndoModalOpen(true);
        }
      },
      disabled: !canAdd
    },
    {
      title: "Print Record",
      element: <Printer size={18} />,
      size: ButtonSize.Small,
      disabled: !canPrint,
      onClick: async (e) => {
        let result;
        if (
          history.location.pathname !== "/general-ledger/bank-reconciliation" &&
          historyState?.isDirty &&
          history.location.pathname.includes(
            "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details"
          )
        ) {
          result = await setPromise((resolve: any) => checkSaveChanges(resolve));

          if (result !== undefined) {
            if (historyState?.from === "add statement" && result === false) {
              dispatch(
                deleteBankreconStatement({
                  bank_statement_id: historyState.selectedRowState.bank_statement_id,
                  callback: (data) => {
                    dispatch(
                      getBankReconciliations({
                        ...filterState,
                        lookingFor: "",
                        viewname: "All",
                        highLightedRecordId: undefined,
                        callback: (data, selectedRow) => {
                          const index = data.data.indexOf(selectedRow);
                          if (bankid) {
                            historyState.bankRreconciliationList = data;
                            dispatch(bankRecActions.setSelectedRow(selectedRow));
                            selectRowHandler(data.data?.at(index));
                            printDocument(
                              selectedRow?.bank_id,
                              selectedRow?.bank_statement_id,
                              selectedRow?.statement_no
                            );
                          }
                        }
                      })
                    );
                  }
                })
              );
            } else if (result === false) {
              history.replace({
                ...history.location,
                state: {
                  ...historyState,
                  isDirty: false,
                  sccDetails: undefined
                }
              });
              printDocument(
                historyState?.selectedRowState?.bank_id,
                historyState?.selectedRowState?.bank_statement_id,
                historyState?.selectedRowState?.statement_no
              );
            } else if (result === true) {
              dispatch(
                saveBankreconStatement({
                  opening_bal: historyState.selectedRowState?.opening_bal,
                  closing_bal: statementBalance,
                  bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
                  uniqueIdAdded: addedUniqueIds,
                  uniqueIdRemoved: removedUniqueIds,
                  bank_id: selectedRow?.bank_id,
                  series_no: selectedRow?.series_no,
                  statement_date: selectedRow?.statement_date,
                  start_stat_no: selectedRow?.statement_no + 1,
                  difference,
                  ledger_description: selectedRow?.ledger_des,
                  statement_no: selectedRow?.statement_no,
                  callback: () => {
                    dispatch(bankRecActions.setClosingBalance(newClosingBalance));
                  }
                })
              );
              history.replace({
                ...history.location,
                state: {
                  ...(history.location.state as any),
                  ...historyState,
                  isDirty: false
                }
              });
              printDocument(
                historyState?.selectedRowState?.bank_id,
                historyState?.selectedRowState?.bank_statement_id,
                historyState?.selectedRowState?.statement_no
              );
            }
          }
        } else {
          printDocument(selectedRow?.bank_id, selectedRow?.bank_statement_id, selectedRow?.statement_no);
        }
      }
    },
    {
      title: "Verify Balances",
      element: <ScalesTipped size={18} />,
      size: ButtonSize.Small,
      onClick: async () => {
        handleOnKeyPress();
      },
      disabled: !canAdd
    }
  ];

  // This can be for future use
  // useHotKeys({
  //   keyName: "F7",
  //   handleOnKeyPress
  // });

  const handleKeyDown = (e: any) => {
    if (e.key === "Escape" && bankid) {
      e.preventDefault();
      if (
        (history.location.pathname !== "/general-ledger/bank-reconciliation" && (isDirty || historyState?.isDirty)) ||
        history.location.pathname === "/general-ledger/bank-reconciliation/add"
      ) {
        setIsUndoModalOpen(true);
      }
    }
  };

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleKeyDown]);
  const loaderConfig: loadingConfig = {
    isLoaderModal: true,
    loadingText: t("common.loading")
  };
  return (
    <div
      className="bank-reconciliation-toolbar"
      data-testId={dataTestId}
    >
      <Toolbar buttons={removeLastElement ? buttons.slice(0, -1) : buttons} />
      <div className="loader-wrapper">
        {(isLoading || VerifyBalaceStatus) && <Loader loadingConfig={loaderConfig} />}
      </div>
      <ConfirmModal
        className="delete-alert"
        isOpen={isUndoModalOpen}
        setOpen={setIsUndoModalOpen}
        title={t("alertMessage.title")}
        message={t("alertMessage.undoAlert.message")}
        confirm={undoAlertHandler}
        autoFocusPrimaryBtn
      />
    </div>
  );
};

BankReconciliationToolbar.defaultProps = {
  onSubmit: undefined,
  goToPrevRecord: undefined,
  goToNextRecord: undefined,
  isDirty: undefined,
  nextYearStartDate: undefined,
  removeLastElement: undefined,
  handleVerifyBalance: undefined,
  statementBalance: undefined,
  closingBalance: undefined,
  dataTestId: undefined
};

export default withRouter(BankReconciliationToolbar);
