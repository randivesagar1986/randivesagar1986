import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const receiptDetailsDef: TColumnDef = [
  {
    headerName: "Cost Centre Code",
    field: "cost_code"
  },
  {
    headerName: "Cost Centre Name",
    field: "cost_des",
    enableTooltip: true
  },
  {
    headerName: "Ledger Code",
    field: "ledger_code"
  },
  {
    headerName: "Ledger Code Name",
    field: "ledger_des",
    enableTooltip: true
  },
  {
    headerName: "Fund",
    field: "fund_code"
  },
  {
    headerName: "Gross Amount",
    field: "gross_amount",
    align: "right",
    cellRenderer: "GridCellLink"
  }
];

export default receiptDetailsDef;
