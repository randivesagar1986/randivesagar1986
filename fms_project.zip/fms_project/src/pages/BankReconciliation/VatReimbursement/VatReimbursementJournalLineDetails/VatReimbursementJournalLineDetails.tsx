import {
  Button,
  ButtonColor,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  RadioButton,
  RadioLabelPosition
} from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";

import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import { ArrowUp } from "@carbon/icons-react";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import "./Style.scss";

const VatReimbursementJournalLineDetails = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <>
      <Layout
        pageTitle="VAT Reimbursement Journal Line Details"
        className="reimbursement__line--details"
      >
        <Grid
          dataTestId="test-id"
          className="row-gap-16"
        >
          <GridItem
            sm={4}
            md={12}
            lg={4}
            xl={4}
            xxl={4}
          >
            <div>
              <FormLabel
                className="mb-5"
                forId="txtLedgerCode"
              >
                {t("bankReconciliation.ledgercode")}
              </FormLabel>
              <Grid className="">
                <GridItem
                  sm={1}
                  md={2}
                  lg={3}
                  xl={3}
                  xxl={3}
                  className="pr-8"
                >
                  <Input
                    value="9001"
                    searchable
                    id="txtLedgerCode"
                  />
                </GridItem>
                <GridItem
                  sm={3}
                  md={6}
                  lg={9}
                  xl={9}
                  xxl={9}
                  className="pl-0"
                >
                  <Input
                    className="read-only"
                    value="VAT Standard Rate 17.5% (17.50%)"
                    disabled
                    button={
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        aria-label="search"
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    }
                    searchable
                    readOnly
                  />
                </GridItem>
              </Grid>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={4}
            xl={4}
            xxl={4}
          >
            <div>
              <FormLabel
                forId="txtAmount"
                className="mb-5"
              >
                {t("bankReconciliation.amount")}
              </FormLabel>
              <Input
                searchable
                value="220.00"
                id="txtAmount"
              />
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
            xxl={3}
          >
            <div className="">
              <FormLabel className="mb-5">Debit/Credit</FormLabel>
              <div className="d-flex">
                <div className="essui-textinput sequence radio__btn--spacing mr-8">
                  <RadioButton
                    label={t("common.debit")}
                    labelPosition={RadioLabelPosition.Right}
                    value={0}
                    onChange={() => {}}
                    isSelected
                  />
                  <RadioButton
                    label={t("common.credit")}
                    labelPosition={RadioLabelPosition.Right}
                    value={1}
                    onChange={() => {}}
                    isSelected={false}
                  />
                </div>
                <div className="d-flex align-center">
                  <ArrowUp size={28} />
                </div>
              </div>
            </div>
          </GridItem>
        </Grid>

        <Grid className="row-gap-16 mt-10">
          <GridItem
            sm={4}
            md={8}
            lg={11}
            xl={11}
            xxl={11}
          >
            <div className="narrative__spacing mr-0-responsive">
              <FormLabel
                forId="txtNarrative"
                className="mb-5"
              >
                {t("bankReconciliation.manualJournalProcessing.narrative")}
              </FormLabel>
              <Input
                searchable
                value="test"
                id="txtNarrative"
              />
            </div>
          </GridItem>
        </Grid>

        <Grid
          justify="space-between"
          className="mt-8"
        >
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <HelpButton
              identifier="testIdentifier"
              labelName="Help"
            />
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="d-flex justify-end flex-wrap justify-start-resposnive gap-8">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
              >
                Cancel
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
              >
                Update & Next Line
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
              >
                Update & Close
              </Button>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};
export default VatReimbursementJournalLineDetails;
