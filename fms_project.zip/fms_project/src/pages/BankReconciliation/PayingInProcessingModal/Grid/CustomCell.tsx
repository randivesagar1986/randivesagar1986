import { cellRendererType } from "@/components/GridTable/GridTable";

const CustomCell = ({ field, row }: cellRendererType) => {
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const getContent = () => {
    console.log("field is ", field);
    switch (field) {
      case "receipt_date":
        return (
          <>
            {new Intl.DateTimeFormat("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })
              .format(new Date(row?.receipt_date))
              .replace("Sept", "Sep")}
          </>
        );
      case "amount":
        return <>{numberFormatter.format(row?.amount)}</>;
      default:
        return null;
    }
  };
  return getContent();
};

export default CustomCell;
