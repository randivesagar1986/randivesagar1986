import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const payInProgressColumnDef: TColumnDef = [
  {
    headerName: "Receipt No.",
    field: "receipt_no"
  },
  {
    headerName: "Date",
    cellRenderer: "GridCellLink",
    field: "receipt_date"
  },
  {
    headerName: "Source",
    enableTooltip: true,
    field: "source"
  },
  {
    headerName: "Reference",
    enableTooltip: true,
    field: "ref_text"
  },
  {
    headerName: "Method",
    field: "method"
  },
  {
    headerName: "Amount",
    cellRenderer: "GridCellLink",
    align: "right",
    field: "amount"
  },
  {
    headerName: "General Ledger Journal",
    align: "left",
    field: "det_num"
  }
];

export default payInProgressColumnDef;
