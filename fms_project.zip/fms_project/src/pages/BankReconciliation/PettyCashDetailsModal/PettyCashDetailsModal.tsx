import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  TextInput
} from "@essnextgen/ui-kit";
import Modal from "@/components/Modal/Modal";
import { useEffect, useState } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import BodyUtil from "@/shared/utils/NoScroll";
import { getBankReconViewPC, getPCPostingPeriod } from "../state/PettyCashDetails.slice";
// import "./Style.scss";

type TPettyCashDetails = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  row: { [key: string]: any };
};

const numberFormatter = new Intl.NumberFormat("en-US", {
  style: "decimal",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});

const PettyCashDetailsModal = ({ setOpen, isOpen, row }: TPettyCashDetails) => {
  const [postingPeriodMonth, setPostingPeriodMonth] = useState<string>("");
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const [pcData, setPcData] = useState<{ pettyHeader: any; pettyCashTransaction: any } | null>(null);

  const { postingPeriodDetails } = useAppSelector((state) => state.pcDetails);

  useEffect(() => {
    dispatch(getPCPostingPeriod(0));
  }, []);

  useEffect(() => {
    if (postingPeriodDetails?.length && pcData) {
      const month = postingPeriodDetails?.filter(
        (p: any) => Number(p.code) === pcData?.pettyCashTransaction?.period_posted
      )[0]?.description;
      setPostingPeriodMonth(month);
    }
  }, [postingPeriodDetails, pcData]);

  useEffect(() => {
    const pcId = row?.posting_year;
    const transId = parseInt(row?.unique_id.replace(/^\D+/g, ""), 10);
    dispatch(getBankReconViewPC({ transId, pcId })).then((action) => {
      if (getBankReconViewPC.fulfilled.match(action)) {
        const payload = action.payload as { pettyHeader: any; pettyCashTransaction: any };
        setPcData(payload);
      }
    });
  }, [dispatch, row]);

  const prependZero = (num: number) => {
    if (num >= 1 && num <= 9) {
      return `0${num}`;
    }
    return num.toString();
  };

  return (
    <>
      <Modal
        header={t("payingInProgress.payingInProgTitle")}
        isOpen={isOpen}
        primaryBtnText={t("common.close")}
        primaryBtnClick={() => {
          BodyUtil.NoScroll.remove();
          setOpen(false);
        }}
        autoFocusPrimaryBtn
        className="dialog__divider"
      >
        <div className="overflow-hidden">
          <Grid className="mt-2">
            <GridItem
              sm={4}
              md={4}
              lg={3}
              xl={3}
            >
              <div>
                <FormLabel className="mb-8">{t("bankReconciliation.pcDetails.pettyCashAccount")}</FormLabel>
                <div>{pcData?.pettyHeader ? pcData.pettyHeader.pc_acc_des : 0}</div>
              </div>
            </GridItem>

            <GridItem
              sm={4}
              md={4}
              lg={3}
              xl={3}
            >
              <div>
                <FormLabel className="mb-8">{t("bankReconciliation.pcDetails.cashInHand")}</FormLabel>
                <div>{pcData?.pettyHeader ? numberFormatter.format(pcData.pettyHeader.cash_in_hand) : "0.00"}</div>
              </div>
            </GridItem>

            <GridItem
              sm={4}
              md={4}
              lg={3}
              xl={3}
            >
              <div>
                <FormLabel className="mb-8">{t("bankReconciliation.pcDetails.unpostedExpenditure")}</FormLabel>
                <div>{pcData?.pettyHeader ? numberFormatter.format(pcData.pettyHeader.unposted_exp) : "0.00"}</div>
              </div>
            </GridItem>
          </Grid>
          <Divider />
          <Grid className="margint10">
            <GridItem
              sm={4}
              md={12}
              lg={12}
              xl={12}
            >
              <FormLabel className="mb-8">{t("bankReconciliation.pcDetails.transactionNumber")}</FormLabel>
              <div>{pcData?.pettyCashTransaction ? pcData.pettyCashTransaction.trans_no : ""}</div>
            </GridItem>
          </Grid>
          <Divider />
          <Grid className="row-gap-16 marginb15 margint10 ">
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-8">{t("bankReconciliation.pcDetails.date")}</div>
              <div>
                {pcData?.pettyCashTransaction
                  ? new Date(pcData.pettyCashTransaction.date_posted)
                      .toLocaleDateString("en-GB", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric"
                      })
                      .replace("Sept", "Sep")
                  : ""}
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-8">{t("bankReconciliation.pcDetails.generalLedgerJournal")}</div>
              <div>{pcData?.pettyCashTransaction ? pcData.pettyCashTransaction.det_num : ""}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-8"> {t("bankReconciliation.pcDetails.period")}</div>
              <div>
                {pcData?.pettyCashTransaction ? prependZero(pcData.pettyCashTransaction.period_posted) : ""}{" "}
                {postingPeriodMonth}{" "}
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-8">{t("bankReconciliation.pcDetails.amount")}</div>
              <div>
                {pcData?.pettyCashTransaction ? numberFormatter.format(pcData.pettyCashTransaction.amount) : ""}
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-8">{t("bankReconciliation.pcDetails.drawnFrom")}</div>
              <div>{pcData?.pettyHeader ? pcData.pettyHeader.source_des || "N/A" : "N/A"}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-8">{t("bankReconciliation.pcDetails.chequeBook")}</div>
              <div>
                {pcData?.pettyCashTransaction
                  ? `${pcData.pettyCashTransaction.number_range || ""} ${
                      pcData.pettyCashTransaction.next_no || ""
                    }`.trim()
                  : ""}
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <FormLabel forId="txtChequeNumber">{t("viewReimbursement.chequeNumber")}</FormLabel>
                <div className="d-flex align-center gap-8 cheque__number">
                  <TextInput
                    value={pcData?.pettyCashTransaction ? pcData.pettyCashTransaction.cheque_no : ""}
                    disabled
                    maxLength={6}
                  />
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    disabled
                  >
                    {t("viewReimbursement.printCheque")}
                  </Button>
                </div>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-8">
                {t("bankReconciliation.pcDetails.reconciledOnBankStatement")}:
              </div>
              <div>{pcData?.pettyCashTransaction ? pcData.pettyCashTransaction.bank_statement_no : ""}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={12}
              lg={12}
              xl={12}
            >
              <div className="essui-form-label mb-8">{t("bankReconciliation.pcDetails.chequePayee")}</div>
              <div className="text__wrap--balance">
                {pcData?.pettyCashTransaction ? pcData.pettyCashTransaction.payee_name : ""}
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={12}
              lg={12}
              xl={12}
            >
              <div className="essui-form-label mb-8">{t("bankReconciliation.pcDetails.narrative")}</div>
              <div className="text__wrap--balance">
                {pcData?.pettyCashTransaction ? pcData.pettyCashTransaction.narrative : ""}
              </div>
            </GridItem>
          </Grid>
          <Grid>
            <GridItem
              sm={6}
              md={{
                offset: 2,
                span: 6
              }}
              lg={{
                offset: 6,
                span: 6
              }}
              xl={{
                offset: 6,
                span: 6
              }}
            >
              <div className="d-flex gap-8 justify-end flex-wrap mb-12 mr-16">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  disabled
                >
                  {t("bankReconciliation.pcDetails.viewOriginal")}
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  disabled
                >
                  {t("bankReconciliation.pcDetails.viewAdjustment")}
                </Button>
              </div>
            </GridItem>
          </Grid>
        </div>
      </Modal>
    </>
  );
};

export default PettyCashDetailsModal;
