import { Provider } from "react-redux";
import { screen, render, waitFor, act, fireEvent } from "@testing-library/react";
import { Router } from "react-router-dom";
import { createMemoryHistory } from "history";
import configureStore from "redux-mock-store";
import userEvent from "@testing-library/user-event";
import { STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import React from "react";
import AddStatement from "../AddStatement";

jest.mock("../../../../components/Breadcrumbs/Breadcrumbs", () => () => <div>BreadCrums</div>);

jest.mock("@/shared/components/BankReconciliationBankAccount/BankAccount", () => () => <div>BankAccountModal</div>);
const history = createMemoryHistory();
let flagForLoader: any;
let flagForBankAccSelections: any;
history.push("/UI/general-ledger/bank-reconciliation/add");
history.entries = history.entries.map((item, index) => {
  if (index === 0) {
    return {
      pathname: "/UI/general-ledger/bank-reconciliation",
      search: "",
      hash: "",
      state: undefined,
      key: "brtcru"
    };
  }
  return item;
});
const mockOnSubmit = jest.fn();
const mockOnBankAccountSelection = jest.fn();
const mockBankAccountClick = jest.fn();
const mockOnBankAccountNoSelection = jest.fn();
const mockSetValue = jest.fn();
const mockSetIsStatementNoEmpty = jest.fn();
const mockRegister = jest.fn((name: string) => ({
  ref: jest.fn(),
  name,
  onBlur: jest.fn(),
  onChange: jest.fn()
}));
const mockHandleKeyDowInputn = jest.fn();
const mockSetIsValueEmpty = jest.fn();

const mockFormatDateInYYYYMMDD = jest.fn();
jest.mock("@/shared/components/InputDate/formatDate", () => () => {
  const actual = jest.requireActual("@/shared/components/InputDate/formatDate");
  return { ...actual, formatDateInYYYYMMDD: mockFormatDateInYYYYMMDD };
});

jest.mock("../useAddStatement", () => () => {
  const actual = jest.requireActual("../useAddStatement");
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const defaultCommon = {
    ...actual,
    t,
    setValue: mockSetValue,
    getValues: jest.fn(),
    register: mockRegister,
    watch: jest.fn((field) => {
      if (field === "ledger_code") return "mocked_ledger_code";
      if (field === "ledger_des") return "mocked_ledger_des";
      if (field === "bank_account") return "01177112";
      if (field === "statement_no") return "1307";
      if (field === "input_date") return "2023-10-01";
      return "";
    }),
    errors: {},
    bankreconBankAccounts: [],
    isConfirmModalOpen: false,
    setIsConfirmModalOpen: jest.fn(),
    isBankAccountModalOpenb: false,
    setIsBankAccountModalOpen: jest.fn(),
    bankAccountClick: mockBankAccountClick,
    onBankAccountSelectedRow: jest.fn(),
    onBankAccountSelection: mockOnBankAccountSelection,
    formMethods: {
      register: jest.fn(),
      setValue: jest.fn(),
      trigger: jest.fn(),
      handleSubmit: jest.fn(),
      setFocus: jest.fn(),
      setError: jest.fn(),
      reset: jest.fn(),
      watch: jest.fn(),
      formState: { errors: {}, isDirty: false },
      getValues: jest.fn()
    },
    handleKeyDowInputn: mockHandleKeyDowInputn,
    handleSubmit: jest.fn(),
    bankId: "",
    isValueEmpty: false,
    setIsValueEmpty: mockSetIsValueEmpty,
    bankStatus: STATUS.SUCCESS,
    bankAccountStatus: null,
    history,
    isStatementNoEmpty: false,
    setIsStatementNoEmpty: mockSetIsStatementNoEmpty,
    historyState: {},
    onSubmit: mockOnSubmit,
    validateStatus: null,
    addBankreconStatus: null,
    subtractDaysFromDate: jest.fn(),
    datepickerChangeHandler: jest.fn(),
    selectedDate: null,
    onBankAccountNoSelection: mockOnBankAccountNoSelection,
    onBankAccountChange: jest.fn(),
    setAlertType: jest.fn()
  };
  if (flagForLoader === "default" && flagForBankAccSelections === "default") {
    return defaultCommon;
  }
  if (flagForLoader === "loading") {
    return {
      ...defaultCommon,
      bankStatus: STATUS.LOADING,
      isBankAccountModalOpen: false
    };
  }
  if (flagForBankAccSelections === "two options") {
    return {
      ...defaultCommon,
      bankreconBankAccounts: [
        {
          ledger_code: "mocked_ledger_code",
          ledger_des: "Bank Account",
          leddef_id: 3211,
          bank_account: "01177112",
          bank_sort_code: "40-32-16",
          bank_id: 49,
          ledger_id: 3599
        }
      ]
    };
  }
  return {};
});

const initialState = {};
const mockStore = configureStore();

const renderWithProviders = (ui: React.ReactElement, { store = mockStore(initialState) } = {}) => {
  const Wrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <Provider store={store}>
      <Router history={history}>{children}</Router>
    </Provider>
  );
  return render(ui, { wrapper: Wrapper });
};

describe("testing AddStatement component", () => {
  let store: any;
  beforeEach(() => {
    store = mockStore(initialState);
    flagForLoader = "default";
    flagForBankAccSelections = "default";
    jest.resetModules();
  });

  describe("sanity tests", () => {
    it("should render breadcrumbs correctly", () => {
      renderWithProviders(<AddStatement />);
      const breadcrumbs = screen.getByText(/BreadCrums/i);
      screen.debug();
      expect(breadcrumbs).toBeInTheDocument();
    });

    it("should render page title correctly", () => {
      renderWithProviders(<AddStatement />);
      const pageTitle = screen.getByText(/bankReconciliation.addAStatement/i);
      expect(pageTitle).toBeInTheDocument();
    });

    it("should render page sub titles correctly", () => {
      renderWithProviders(<AddStatement />);
      const pageSubTitles = screen.getAllByTestId("bankReconciliation-sub-title");
      pageSubTitles.forEach((subTitle) => {
        expect(subTitle).toBeInTheDocument();
      });
      expect(pageSubTitles).toHaveLength(2);
    });

    it("should render help button correctly", () => {
      renderWithProviders(<AddStatement />);
      const helpBtn = screen.getByRole("button", { name: /common.help/i });
      expect(helpBtn).toBeInTheDocument();
    });

    it("help button should be enabled correctly", () => {
      renderWithProviders(<AddStatement />);
      const helpBtn = screen.getByRole("button", { name: /common.help/i });
      expect(helpBtn).toBeEnabled();
    });

    it("should render cancel button correctly", () => {
      renderWithProviders(<AddStatement />);
      const cancelBtn = screen.getByRole("button", { name: /common.cancel/i });
      expect(cancelBtn).toBeInTheDocument();
    });

    it("cancel button should be enabled correctly", () => {
      renderWithProviders(<AddStatement />);
      const helpBtn = screen.getByRole("button", { name: /common.help/i });
      expect(helpBtn).toBeEnabled();
    });

    it("should render save button correctly", () => {
      renderWithProviders(<AddStatement />);
      const saveBtn = screen.getByRole("button", { name: /common.save/i });
      expect(saveBtn).toBeInTheDocument();
    });

    it("save button should be enabled correctly", () => {
      renderWithProviders(<AddStatement />);
      const helpBtn = screen.getByRole("button", { name: /common.help/i });
      expect(helpBtn).toBeEnabled();
    });
    it("bank account modal should be defined", () => {
      renderWithProviders(<AddStatement />);
      const bankAccModal = screen.getByText(/BankAccountModal/i);
      expect(bankAccModal).toBeDefined();
    });
  });

  describe("button tests", () => {
    it("should navigate to the correct route when user clicks cancel button", async () => {
      renderWithProviders(<AddStatement />);

      const cancelBtn = screen.getByRole("button", { name: /common.cancel/i });
      await userEvent.click(cancelBtn);

      expect(history.location.pathname).toBe("/UI/general-ledger/bank-reconciliation");
    });
    it("should call onSubmit when user click save button", async () => {
      renderWithProviders(<AddStatement />);

      const saveBtn = screen.getByRole("button", { name: /common.save/i });
      await userEvent.click(saveBtn);

      expect(mockOnSubmit).toHaveBeenCalledTimes(1);
    });
  });

  describe("loading", () => {
    it("should render loader while fetching data", () => {
      flagForLoader = "loading";
      renderWithProviders(<AddStatement />);
      const loader = screen.queryByText(/common.loading/i);
      const addStatementSection = screen.queryByTestId(/add-statement-section/i);
      expect(addStatementSection).not.toBeInTheDocument();
      expect(loader).toBeInTheDocument();
    });
    it("should not render loader while after data has been fetched", () => {
      renderWithProviders(<AddStatement />);

      const loader = screen.queryByText("Loading...");
      const addStatementSection = screen.queryByTestId(/add-statement-section/i);
      expect(addStatementSection).toBeInTheDocument();
      expect(loader).not.toBeInTheDocument();
    });
  });

  describe("bankreconAccount", () => {
    describe("bankreconBankAccounts input feild", () => {
      it("should render the Input component correctly", async () => {
        flagForBankAccSelections = "two options";
        renderWithProviders(<AddStatement />);

        const inputElement = screen.getByTestId("BankReconAccount-input");
        await waitFor(() => {
          expect(inputElement).toBeInTheDocument();
          expect(inputElement).toHaveValue("mocked_ledger_code");
        });
      });
      it("user should be able to type into it correctly", async () => {
        flagForBankAccSelections = "two options";
        renderWithProviders(<AddStatement />);

        const inputElement = screen.getByTestId("BankReconAccount-input");
        fireEvent.change(inputElement, { target: { value: "mock input" } });
        await waitFor(() => {
          expect(inputElement).toBeInTheDocument();
          expect(inputElement).toHaveValue("mock input");
        });
      });

      it("should call onBankAccountNoSelection when no item is selected", () => {
        renderWithProviders(<AddStatement />);

        const inputElement = screen.getByTestId("BankReconAccount-input");
        fireEvent.change(inputElement, { target: { value: "" } });
        fireEvent.blur(inputElement);

        expect(mockOnBankAccountNoSelection).toHaveBeenCalled();
      });

      it("should call onBankAccountChange when the input value changes", () => {
        renderWithProviders(<AddStatement />);

        const inputElement = screen.getByTestId("BankReconAccount-input");
        fireEvent.change(inputElement, { target: { value: "new_value" } });

        expect(mockOnBankAccountNoSelection).toHaveBeenCalled();
      });
    });

    describe("bankreconBankAccounts description", () => {
      it("should render bankreconBankAccounts description correctly", () => {
        flagForBankAccSelections = "two options";
        renderWithProviders(<AddStatement />);
        const descriptionBlock = screen.getByText("mocked_ledger_des");
        expect(descriptionBlock).toBeInTheDocument();
      });
    });

    describe("bankreconBankAccounts search button", () => {
      it("should render search button", () => {
        renderWithProviders(<AddStatement />);
        const searchBtn = screen.getByTestId("BankReconAccount-search");
        expect(searchBtn).toBeInTheDocument();
      });
      it("search button should be enabled", () => {
        renderWithProviders(<AddStatement />);
        const searchBtn = screen.getByTestId("BankReconAccount-search");
        expect(searchBtn).toBeEnabled();
      });
      it("if user clicks search button BankAccountClick function should be called", () => {
        renderWithProviders(<AddStatement />);
        const searchBtn = screen.getByTestId("BankReconAccount-search");
        fireEvent.click(searchBtn);
        expect(searchBtn).toBeEnabled();
        expect(mockBankAccountClick).toHaveBeenCalledTimes(1);
      });
    });

    describe("bankrecon number", () => {
      it("should render bankrecon number section correctly", () => {
        flagForBankAccSelections = "two options";
        renderWithProviders(<AddStatement />);
        const numberBlock = screen.getByText("01177112");
        expect(numberBlock).toBeInTheDocument();
      });
    });

    describe("AddStatement Component", () => {
      it("should render the TextInput component correctly", () => {
        renderWithProviders(<AddStatement />);

        const textInputElement = screen.getByTestId("bankReconciliation-txtNumber");
        expect(textInputElement).toBeInTheDocument();
        expect(textInputElement).toHaveValue("1307");
        expect(textInputElement).toHaveClass("text-width w-100");
      });
      it("should call setValue and setIsStatementNoEmpty on change", () => {
        renderWithProviders(<AddStatement />);

        const textInputElement = screen.getByTestId("bankReconciliation-txtNumber");
        fireEvent.change(textInputElement, { target: { value: "0056" } });

        expect(mockSetValue).toHaveBeenCalledWith("statement_no", "56");
        expect(mockSetIsStatementNoEmpty).toHaveBeenCalledWith(false);
      });
      it("should call handleKeyDowInputn on key down", () => {
        renderWithProviders(<AddStatement />);

        const textInputElement = screen.getByTestId("bankReconciliation-txtNumber");
        fireEvent.keyDown(textInputElement, { key: "Enter" });

        expect(mockHandleKeyDowInputn).toHaveBeenCalled();
      });
      it("should set isStatementNoEmpty to true if value is empty", () => {
        renderWithProviders(<AddStatement />);

        const textInputElement = screen.getByTestId("bankReconciliation-txtNumber");
        fireEvent.change(textInputElement, { target: { value: "" } });

        expect(mockSetIsStatementNoEmpty).toHaveBeenCalledWith(true);
      });
    });

    describe("AddStatement Component", () => {
      it("should render the InputDate component correctly", () => {
        renderWithProviders(<AddStatement />);

        const inputDateElement = screen.getByTestId("add-statement-date");
        expect(inputDateElement).toBeInTheDocument();
        expect(inputDateElement).toHaveValue("2023-10-01");
      });
    });
  });
});
