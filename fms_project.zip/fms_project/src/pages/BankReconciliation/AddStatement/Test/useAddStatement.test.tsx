import { renderHook, act } from "@testing-library/react-hooks";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useForm } from "react-hook-form";
import {
  getBankreconBankAccounts,
  getBankreconAccountNo,
  actions as bankReconActions
} from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { format, isAfter, parse } from "date-fns";
import { formatDateInYYYYMMDD } from "@/shared/components/InputDate/formatDate";
import { KEYBOARD_STRING, specialCharacters, STATUS } from "@/types/UseStateType";
import { useAppSelector } from "@/store/store";
import { uiActions } from "@/store/state/ui.slice";
import React from "react";
import { waitFor } from "@testing-library/react";
import useAddStatement from "../useAddStatement";
import { addBankreconStatement, bankreconValidateStatement } from "../../state/BankReconciliation.slice";

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("react-hook-form", () => ({
  useForm: jest.fn()
}));

jest.mock("@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice", () => ({
  getBankreconBankAccounts: jest.fn(async (args: any) => {
    const data = [
      {
        bank_id: "1234"
      }
    ];
    await args?.callback(data);
  }),
  getBankreconAccountNo: jest.fn((args: any) => {
    if (args?.callback !== undefined) {
      const data = { statementNo: 1 };
      args?.callback(data);
    }
    return { payload: { statementNo: 5678 } };
  }),
  actions: {
    setFilters: jest.fn(),
    selectBankAccountRow: jest.fn(),
    resetSelectedRow: jest.fn()
  }
}));

jest.mock("../../state/BankReconciliation.slice", () => ({
  addBankreconStatement: jest.fn(),
  bankreconValidateStatement: jest.fn((props: any) => {
    if (props?.sample === undefined) {
      props?.callback({ isValid: true });
    }
  })
}));
jest.mock("@/store/state/ui.slice", () => ({
  uiActions: {
    alertPopup: jest.fn((args: any) => {
      if (args?.callback) {
        args?.callback();
      }
    }),
    confirmPopup: jest.fn((args: any) => {
      if (args?.yesCallback) {
        args?.yesCallback();
      }
    })
  }
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    init: jest.fn()
  }
}));

// Mock MODAL_TYPE
const MODAL_TYPE = {
  ALERT: "genericAlert",
  CONFIRMV2: "genericConfirmv2",
  YEAR_DISABLED_MODAL: "yearDisableModal"
};

// Mock ISelectedItem and NotificationStatus
jest.mock("@essnextgen/ui-kit", () => ({
  ISelectedItem: jest.fn(),
  NotificationStatus: {
    ERROR: "ERROR",
    HIGHLIGHT: "HIGHLIGHT"
  }
}));

describe("useAddStatement", () => {
  let submitData: any = { statement_no: 1309, input_date: "2024-10-01" };
  const mockDispatch = jest.fn();
  const mockSetIsBankAccountModalOpen = jest.fn();
  const mockHandleSubmit = jest.fn((handler: any) =>
    jest.fn(() => {
      handler(submitData);
      return Promise.resolve("resolved");
    })
  );
  const mockRegister = jest.fn().mockReturnValue({
    onChange: jest.fn()
  });
  const mockSetValue = jest.fn();

  const mockHistoryPush = jest.fn();
  const mockUseForm = {
    register: mockRegister,
    setValue: mockSetValue,
    trigger: jest.fn(),
    handleSubmit: mockHandleSubmit,
    setFocus: jest.fn(),
    setError: jest.fn(),
    reset: jest.fn(),
    watch: jest.fn(),
    formState: { errors: {}, isDirty: false },
    getValues: jest.fn()
  };

  beforeEach(() => {
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue({ push: mockHistoryPush, location: { state: {} } });
    (useTranslation as jest.Mock).mockReturnValue({ t: (key: any) => key });
    (useForm as jest.Mock).mockReturnValue(mockUseForm);
    (useAppSelector as jest.Mock).mockImplementation((selector: any) => {
      if (selector.name === "bankReconciliation") {
        return {
          addBankreconStatus: "addBankreconStatus",
          validateStatus: ""
        };
      }
      if (selector.name === "bankreconBankAccounts") {
        return {
          bankreconBankAccounts: [
            { ledger_code: "123", bank_id: 1, ledger_des: "Description 1" },
            { ledger_code: "456", bank_id: 2, ledger_des: "Description 2" }
          ],
          bankStatus: "",
          bankAccountStatus: ""
        };
      }
      return {};
    });
    jest.clearAllMocks();
  });

  afterEach(() => {});

  it("should initialize correctly", () => {
    const { result } = renderHook(() => useAddStatement());
    expect(result.current.t).toBeDefined();
    expect(result.current.setValue).toBeDefined();
    expect(result.current.getValues).toBeDefined();
    expect(result.current.register).toBeDefined();
    expect(result.current.watch).toBeDefined();
    expect(result.current.errors).toBeDefined();
    expect(result.current.isConfirmModalOpen).toBe(false);
    expect(result.current.isBankAccountModalOpen).toBe(false);
  });

  it("should handle bankAccountClick correctly", () => {
    const { result } = renderHook(() => useAddStatement());
    act(() => {
      result.current.bankAccountClick();
    });
    expect(mockDispatch).toHaveBeenCalledWith(bankReconActions.setFilters({ lookingFor: "" }));
    expect(result.current.isBankAccountModalOpen).toBe(true);
  });

  it("should handle datepickerChangeHandler correctly", async () => {
    const newDate: any = new Date();
    const formattedDate = formatDateInYYYYMMDD(newDate);

    const { result } = renderHook(() => useAddStatement());
    act(() => {
      result.current.datepickerChangeHandler(newDate);
    });

    expect(result.current.selectedDate).toBe(newDate);
    expect(result.current.isValueEmpty).toBe(false);
    expect(result.current.setValue).toHaveBeenCalledWith("input_date", formattedDate);

    waitFor(async () => {
      await result.current.onSubmit();
    });
  });

  it("should handle onBankAccountChange correctly", () => {
    const event = { target: { value: "value" } };
    const { result } = renderHook(() => useAddStatement());

    act(() => {
      result.current.onBankAccountChange(event as React.ChangeEvent<HTMLInputElement>);
    });

    expect(mockDispatch).toHaveBeenCalledWith(bankReconActions.setFilters({ lookingFor: "value" }));
  });

  it("should show validation alert if mandatory fields are missing", () => {
    const { result } = renderHook(() => useAddStatement());
    const data: any = { input_date: "", statement_no: "" };

    act(() => {
      result.current.handleSubmit(data);
    });
  });

  it("should handle validationAlertPopup correctly", () => {
    const message = "message";
    const { result } = renderHook(() => useAddStatement());

    act(() => {
      result.current.validationAlertPopup(message, NotificationStatus.ERROR);
    });

    expect(mockDispatch).toHaveBeenCalledWith(uiActions.alertPopup(expect.any(Object)));
  });

  it("should handle bankreconWarningPopup correctly", () => {
    const message = "Test warning message";
    const { result } = renderHook(() => useAddStatement());

    act(() => {
      result.current.bankreconWarningPopup(message);
    });

    expect(mockDispatch).toHaveBeenCalledWith(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        notificationType: NotificationStatus.ERROR,
        title: "common.simsFMSModule",
        message,
        className: "primary-focus"
      })
    );
  });

  it("should handle bankReconLastStatementPopup correctly for isFutureDate false", () => {
    const message = "message";
    const isFutureDate = false;
    const formattedDate = "2023-10-10";
    const { result } = renderHook(() => useAddStatement());

    act(() => {
      result.current.bankReconLastStatementPopup(message, isFutureDate, formattedDate);
    });

    expect(mockDispatch).toHaveBeenCalledWith(uiActions.confirmPopup(expect.any(Object)));
  });

  it("should handle bankReconLastStatementPopup correctly for isFutureDate true", () => {
    const message = "message";
    const isFutureDate = true;
    const formattedDate = "2023-10-10";
    const { result } = renderHook(() => useAddStatement());

    act(() => {
      result.current.bankReconLastStatementPopup(message, isFutureDate, formattedDate);
    });

    expect(mockDispatch).toHaveBeenCalledWith(uiActions.confirmPopup(expect.any(Object)));
  });

  it("should dispatch setFilters action and open bank account modal", () => {
    const { result } = renderHook(() => useAddStatement());

    act(() => {
      result.current.bankAccountClick();
    });

    expect(mockDispatch).toHaveBeenCalledWith(bankReconActions.setFilters({ lookingFor: "" }));
  });

  it("should subtract days correctly from a given date", () => {
    const { result } = renderHook(() => useAddStatement());

    const date = new Date("2023-10-10");
    const days = 5;
    const expectedDate = new Date("2023-10-05");

    const res = result.current.subtractDaysFromDate(date, days);

    expect(res).toEqual(expectedDate);
  });

  it("should handle bank account change with empty value", () => {
    const { result } = renderHook(() => useAddStatement());

    const event = {
      target: { value: " " }
    } as React.ChangeEvent<HTMLInputElement>;

    act(() => {
      result.current.onBankAccountChange(event);
    });

    expect(mockRegister).toHaveBeenCalledWith("ledger_code");
    expect(mockRegister("ledger_code").onChange).toHaveBeenCalledWith(event);
    expect(mockDispatch).toHaveBeenCalledWith(bankReconActions.selectBankAccountRow(undefined));
    expect(mockDispatch).toHaveBeenCalledWith(bankReconActions.resetSelectedRow());
    expect(mockSetValue).toHaveBeenCalledWith("ledger_code", specialCharacters.BLANKVALUE);
    expect(mockSetValue).toHaveBeenCalledWith("ledger_des", specialCharacters.BLANKVALUE);
    expect(mockSetValue).toHaveBeenCalledWith("bank_account", specialCharacters.BLANKVALUE);
    expect(mockDispatch).toHaveBeenCalledWith(bankReconActions.setFilters({ lookingFor: "" }));
  });

  it("should allow navigation and editing keys", () => {
    const { result } = renderHook(() => useAddStatement());

    const allowedKeys = ["Tab", "Backspace", "Delete", "ArrowLeft", "ArrowRight"];
    allowedKeys.forEach((key) => {
      const event = new KeyboardEvent("keydown", { key });
      const preventDefault = jest.fn();
      Object.defineProperty(event, "preventDefault", { value: preventDefault });

      result.current.handleKeyDowInputn(event);

      expect(preventDefault).not.toHaveBeenCalled();
    });
  });

  it("should handle bank account selection with undefined selectedItem", async () => {
    const { result } = renderHook(() => useAddStatement());

    await act(async () => {
      result.current.onBankAccountSelection(undefined);
    });

    expect(mockDispatch).toHaveBeenCalledWith(bankReconActions.selectBankAccountRow(undefined));
  });

  it("should open bank account modal and reset form values", () => {
    const { result } = renderHook(() => useAddStatement());

    act(() => {
      result.current.onBankAccountNoSelection();
    });

    expect(mockSetValue).toHaveBeenCalledWith("ledger_code", "");
    expect(mockSetValue).toHaveBeenCalledWith("ledger_des", "");
    expect(mockSetValue).toHaveBeenCalledWith("bank_account", "");
  });

  it("should handle bank account selected row", async () => {
    const row = { bank_id: 1, ledger_code: "123", ledger_des: "Description 1" };
    const bankReconAccountNo = {
      payload: { bank_account: "987654321", statementNo: 5 }
    };

    mockDispatch.mockImplementation((action) => {
      if (typeof action === "function") {
        return action(mockDispatch);
      }
      return Promise.resolve(bankReconAccountNo);
    });

    const { result } = renderHook(() => useAddStatement());

    await act(async () => {
      await result.current.onBankAccountSelectedRow(row);
    });

    expect(mockDispatch).toHaveBeenCalledWith(bankReconActions.selectBankAccountRow(row));
    expect(mockDispatch).toHaveBeenCalledWith(getBankreconAccountNo({ bankId: 1 }));
    expect(mockSetValue).toHaveBeenCalledWith("ledger_code", "123", { shouldValidate: true });
    expect(mockSetValue).toHaveBeenCalledWith("ledger_des", "Description 1");
    expect(mockSetValue).toHaveBeenCalledWith("bank_account", "987654321");
    expect(mockSetValue).toHaveBeenCalledWith("statement_no", 6);
  });

  it("should show alert popup when mandatory fields are missing", async () => {
    const { result } = renderHook(() => useAddStatement());

    await act(async () => {
      await result.current.onSubmit({
        target: { value: " " }
      } as React.ChangeEvent<HTMLInputElement>);
    });
  });

  it("should set value correctly when selectedItem.text is passed as empty string", () => {
    const selectedItem = { value: "123", text: "mock text" };

    const { result } = renderHook(() => useAddStatement());

    act(() => {
      result.current.onBankAccountSelection(selectedItem);
    });

    expect(mockDispatch).toHaveBeenCalledWith(getBankreconAccountNo(expect.any(Object)));
  });

  it("form submission should be handled correctly, if input date and statement no. is passed correctly", () => {
    const { result } = renderHook(() => useAddStatement());
    act(() => {
      result.current.onSubmit();
    });
    expect(mockDispatch).toHaveBeenCalledWith(
      bankreconValidateStatement(
        expect.objectContaining({
          StatementNo: submitData?.statement_no,
          statementDate: expect.any(String),
          uniqueIdentifier: expect.any(String)
        })
      )
    );
  });
  it("form submission should be handled correctly, if input date and statement no. is not passed it should not do anything", () => {
    submitData = {};
    const { result } = renderHook(() => useAddStatement());
    act(() => {
      result.current.onSubmit();
    });
    expect(mockDispatch).not.toHaveBeenLastCalledWith(bankreconValidateStatement);
  });
});
