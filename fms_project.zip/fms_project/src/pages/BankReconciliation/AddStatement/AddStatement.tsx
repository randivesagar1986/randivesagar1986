import Input from "@/components/Input/Input";
import "./style.scss";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  ISelectedItem,
  Icon,
  IconColor,
  IconSize,
  NotificationStatus,
  TextInput,
  TextInputSize,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import DatePicker from "react-datepicker";
import { dateFormat, datePicker } from "@/utils/constants";
import { MIN_DATE, STATUS } from "@/types/UseStateType";
import { forwardRef } from "react";
import InputDate from "@/shared/components/InputDate/InputDate";
import { formatDateInYYYYMMDD } from "@/shared/components/InputDate/formatDate";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import BankAccount from "@/shared/components/BankReconciliationBankAccount/BankAccount";
import { FormProvider } from "react-hook-form";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/store/store";
import { setToSession } from "@/utils/getDataSource";
import AddStatementDateButton from "./AddStatementDateButton";
import useAddStatement from "./useAddStatement";

const loaderConfig: loadingConfig = {};
const AddStatement = () => {
  const {
    t,
    setValue,
    register,
    watch,
    errors,
    bankreconBankAccounts,
    isBankAccountModalOpen,
    setIsBankAccountModalOpen,
    bankAccountClick,
    onBankAccountSelectedRow,
    onBankAccountSelection,
    handleKeyDowInputn,
    isValueEmpty,
    setIsValueEmpty,
    bankStatus,
    bankAccountStatus,
    history,
    isStatementNoEmpty,
    setIsStatementNoEmpty,
    onSubmit,
    validateStatus,
    addBankreconStatus,
    subtractDaysFromDate,
    datepickerChangeHandler,
    selectedDate,
    historyState,
    onBankAccountNoSelection,
    onBankAccountChange,
    formMethods,
    isDirty
  } = useAddStatement();
  const dispatch = useDispatch<AppDispatch>();
  return (
    <>
      {(bankStatus === STATUS.LOADING && isBankAccountModalOpen === false) ||
      bankAccountStatus === STATUS.LOADING ||
      validateStatus === STATUS.LOADING ||
      addBankreconStatus === STATUS.LOADING ? (
        <Loader loadingConfig={loaderConfig} />
      ) : null}
      <FormProvider {...formMethods}>
        {bankStatus === STATUS.SUCCESS &&
        bankAccountStatus !== STATUS.LOADING &&
        validateStatus !== STATUS.LOADING &&
        addBankreconStatus !== STATUS.LOADING ? (
          <Layout
            pageTitle={t("bankReconciliation.addAStatement")}
            className="add-statement"
            dataTestId="add-statement-section"
          >
            <Grid container>
              <GridItem
                sm={12}
                md={12}
                lg={12}
                xl={12}
                className="mb-15"
              >
                <div
                  data-testId="bankReconciliation-sub-title"
                  className="essui-global-typography-default-subtitle"
                >
                  {t("bankReconciliation.account")}
                </div>
              </GridItem>
            </Grid>
            <Grid container>
              <GridItem
                sm={4}
                md={4}
                lg={5}
                xl={5}
                className="mb-8"
              >
                <div className="essui-form-label">{t("bankReconciliation.account")}</div>
                <div className="two-inputs">
                  <div className="width-25">
                    <Input
                      id="BankReconAccount"
                      dataTestId="BankReconAccount-input"
                      searchable
                      autoFocus
                      searchItems={bankreconBankAccounts.map((b) => ({
                        text: b.ledger_code,
                        value: b.ledger_code
                      }))}
                      onSelect={(selectedItem: ISelectedItem | undefined) => onBankAccountSelection(selectedItem)}
                      onNoSelection={onBankAccountNoSelection}
                      inputWidth={108}
                      isLabel={false}
                      maxLength={100}
                      value={watch("ledger_code")}
                      inputRef={(e) => register("ledger_code")?.ref(e)}
                      name={register("ledger_code", { required: true })?.name}
                      onBlur={(e: any) => register("ledger_code")?.onBlur(e)}
                      onChange={onBankAccountChange}
                      validationTextLevel={errors.ledger_code ? ValidationTextLevel.Error : undefined}
                    />
                  </div>
                  <div className="width100 playback">
                    <div
                      data-testId="ledger-des"
                      className="read-only essui-textinput essui-textinput--medium width-88"
                    >
                      {watch("ledger_des")}
                    </div>
                    <div className="playback">
                      <Button
                        dataTestId="BankReconAccount-search"
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        aria-label="search"
                        onClick={bankAccountClick}
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </div>
                  </div>
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={3}
                xl={3}
                className="mb-8"
              >
                <FormLabel forId="txtAccountNumber">{t("bankReconciliation.number")}</FormLabel>
                <div className="w-100 read-only essui-textinput essui-textinput--medium">{watch("bank_account")}</div>
              </GridItem>
            </Grid>

            <Divider />

            <Grid container>
              <GridItem
                sm={4}
                md={4}
                lg={12}
                xl={12}
                className="mb-20 mr-t10"
              >
                <div
                  data-testId="bankReconciliation-sub-title"
                  className="essui-global-typography-default-subtitle"
                >
                  {t("bankReconciliation.statement")}
                </div>
              </GridItem>
            </Grid>
            <Grid container>
              <GridItem
                sm={4}
                md={4}
                lg={5}
                xl={5}
                className="mb-8"
              >
                <div className="input-search">
                  <FormLabel forId="txtNumber">{t("bankReconciliation.number")}</FormLabel>
                  <div>
                    <TextInput
                      dataTestId="bankReconciliation-txtNumber"
                      className={`text-width w-100 ${isStatementNoEmpty ? "value-empty" : ""}`}
                      maxLength={4}
                      value={watch("statement_no")}
                      inputRef={(e) => register("statement_no")?.ref(e)}
                      onChange={(e) => {
                        let { value } = e.target;
                        value = value.replace(/\D/g, "").replace(/^0+/, "");
                        setValue("statement_no", value);
                        register("statement_no")?.onChange(e);
                        if (value) {
                          setIsStatementNoEmpty(false);
                        } else {
                          setIsStatementNoEmpty(true);
                        }
                      }}
                      name={register("statement_no")?.name}
                      onKeyDown={handleKeyDowInputn}
                      validationTextLevel={errors.statement_no ? ValidationTextLevel.Error : undefined}
                    />
                  </div>
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={3}
                xl={3}
                className="mb-8"
              >
                <FormLabel forId="add-statement-date">{t("bankReconciliation.date")}</FormLabel>
                <div className="looking-for">
                  <InputDate
                    dataTestId="add-statement-date"
                    id="add-statement-date"
                    width="100%"
                    value={watch("input_date")}
                    onBlur={(date) => {
                      let formattedDate = "";
                      let setShouldDirty = false;
                      if (!date.toString().trim().length) {
                        setIsValueEmpty(true);
                        setShouldDirty = false;
                      } else {
                        formattedDate = formatDateInYYYYMMDD(date);
                        setIsValueEmpty(false);
                        setShouldDirty = true;
                      }
                      setValue("input_date", formattedDate, { shouldDirty: setShouldDirty });
                    }}
                    validationTextLevel={isValueEmpty ? ValidationTextLevel.Error : undefined}
                  />
                  <DatePicker
                    onChange={() => {}}
                    customInput={<AddStatementDateButton />}
                    maxDate={subtractDaysFromDate(historyState?.nextYearStartDate, 0)}
                    minDate={new Date(MIN_DATE.MINDATE)}
                    showMonthDropdown
                    showYearDropdown
                    selected={selectedDate}
                    onSelect={datepickerChangeHandler}
                    dateFormat={dateFormat.european}
                    value={selectedDate ? selectedDate!.toLocaleDateString("en-GB").toString() : ""}
                    dropdownMode="scroll"
                    scrollableYearDropdown
                    yearDropdownItemNumber={datePicker.NumberofItemsInDropdown}
                    calendarStartDay={1}
                  />
                </div>
              </GridItem>
            </Grid>
            <Grid className="flex-rev">
              <GridItem
                sm={2}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="rightbtn">
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Primary}
                    onClick={() => {
                      onSubmit();
                    }}
                  >
                    {t("common.save")}
                  </Button>
                  <Button
                    className="activate-route"
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    onClick={() => {
                      setToSession("redirectPath", "");
                      if (isDirty) {
                        dispatch(
                          uiActions.confirmPopup({
                            enable: true,
                            message: t("alertMessage.keepChangesMsg"),
                            title: t("common.simsFMSModule"),
                            type: MODAL_TYPE.CONFIRMV2,
                            yesCallback: () => {
                              onSubmit();
                            },
                            noCallback: () => {
                              history.replace({
                                ...history.location,
                                state: {
                                  ...(history.location.state as any),
                                  ...historyState,
                                  isDirty: false,
                                  redirect: true
                                }
                              });
                              history.goBack();
                            },
                            isCancelBtnEnable: true
                          })
                        );
                      } else {
                        history.replace({
                          ...history.location,
                          state: {
                            ...(history.location.state as any),
                            ...historyState,
                            isDirty: false
                          }
                        });
                        history.goBack();
                      }
                    }}
                  >
                    {t("common.cancel")}
                  </Button>
                </div>
              </GridItem>
              <GridItem
                sm={2}
                md={4}
                lg={6}
                xl={6}
              >
                <div>
                  <HelpButton
                    identifier="testIdentifier"
                    labelName={t("common.help")}
                  />
                </div>
              </GridItem>
            </Grid>
          </Layout>
        ) : null}
        <BankAccount
          isOpen={isBankAccountModalOpen}
          setOpen={setIsBankAccountModalOpen}
          onSelectedRow={onBankAccountSelectedRow}
        />
      </FormProvider>
    </>
  );
};
export default AddStatement;
