import { AppDispatch, useAppSelector } from "@/store/store";
import React, { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { ISelectedItem, NotificationStatus } from "@essnextgen/ui-kit";
import { useForm } from "react-hook-form";
import {
  getBankreconBankAccounts,
  actions as bankReconActions,
  getBankreconAccountNo
} from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import { getDateInStringFormat } from "@/utils/constants";
import { format, isAfter, parse } from "date-fns";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import { formatDateInYYYYMMDD } from "@/shared/components/InputDate/formatDate";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useClickAway } from "@/hooks/useClickAway";
import { addBankreconStatement, bankreconValidateStatement } from "../state/BankReconciliation.slice";

/* eslint-disable camelcase */
type FormData = {
  ledger_code: string;
  ledger_des: string;
  ledger_id: string;
  bank_account: string;
  statement_no: string;
  input_date: string;
};

const useAddStatement = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState<boolean>(false);
  const [isBankAccountModalOpen, setIsBankAccountModalOpen] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");
  const [alertType, setAlertType] = useState<NotificationStatus>(NotificationStatus.ERROR);
  const [bankId, setBankId] = useState<string>("");
  const [isValueEmpty, setIsValueEmpty] = useState<boolean>(false);
  const [isStatementNoEmpty, setIsStatementNoEmpty] = useState<boolean>(false);
  const [formattedDate, setFormattedDate] = useState<string>("");
  const { addBankreconStatus, validateStatus } = useAppSelector((state) => state.bankReconciliation);
  const historyState = history.location.state as any;
  const [selectedDate, setSelectedDate] = useState<any>(undefined);
  const { bankreconBankAccounts, bankStatus, bankAccountStatus } = useAppSelector(
    (state) => state.bankreconBankAccounts
  );
  const formMethods = useForm<FormData>({
    mode: "all",
    shouldFocusError: false,
    defaultValues: {
      ledger_des: ""
    }
  });
  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    setFocus,
    setError,
    reset,
    watch,
    formState: { errors, isDirty },
    getValues
  } = formMethods;
  const prevLengthRef = useRef<boolean>(false);

  const bankAccountClick = () => {
    dispatch(bankReconActions.setFilters({ lookingFor: "" }));
    setIsBankAccountModalOpen(true);
  };

  // Click Away Functionality Start Here
  const isProfileMenuRef = useRef<boolean>(false);
  const yesCallback = async (e: any) => {
    isProfileMenuRef.current = !!e.closest(".essui-avatar");

    prevLengthRef.current = false;
    await onSubmitForClickAway();
    if (prevLengthRef.current) {
      reset();
    }
    return prevLengthRef.current;
  };

  const noCallback = (e: any) => {
    reset();
    setValue("ledger_code", "", { shouldDirty: false });
    setValue("ledger_des", "", { shouldDirty: false });
    setValue("bank_account", "", { shouldDirty: false });
    setValue("input_date", "MM/DD/YYYY", { shouldDirty: false });
    setValue("statement_no", "0", { shouldDirty: false });
    const isRelevantLink = ["link-normal", "home-link"].some((cls) => e?.classList.contains(cls));
    const isProfileMenu = e.closest(".essui-avatar");
    history.push("/general-ledger/bank-reconciliation", {
      ...(history.location.state as any),
      isDirty: false,
      redirect: true
    });
    if (!isRelevantLink && !isProfileMenu) {
      setTimeout(() => {
        dispatch(setIsSidebarOpen(true));
      }, 500);
    }
    return false;
  };
  const { isSidebarOpen, showProfileMenu } = useAppSelector((state) => state.sidebarMenu);
  const { setIsSidebarOpen, setShowProfileMenu } = useClickAway({
    isDirty,
    yesCallback,
    noCallback,
    cancelCallback: () => {}
  });
  // Click Away Functionality End Here

  const onBankAccountSelectedRow = async (row: any) => {
    dispatch(bankReconActions.selectBankAccountRow(row));
    setBankId(row.bank_id);
    const bankReconAccountNo: any = await dispatch(getBankreconAccountNo({ bankId: row.bank_id }));
    if (bankReconAccountNo) {
      setValue("ledger_code", row?.ledger_code, { shouldValidate: true, shouldDirty: true });
      setValue("ledger_des", row?.ledger_des);
      setValue("bank_account", bankReconAccountNo?.payload?.bank_account);
      if (bankReconAccountNo?.payload?.statementNo >= 0) {
        setIsStatementNoEmpty(false);
        setValue("statement_no", bankReconAccountNo?.payload?.statementNo + 1);
      }
    }
  };

  const datepickerChangeHandler = (newDate: any) => {
    setSelectedDate(newDate);

    const value = formatDateInYYYYMMDD(newDate);
    setIsValueEmpty(false);
    setValue("input_date", value, { shouldDirty: true });
  };

  const subtractDaysFromDate = (date: Date, days: number) => {
    const result = new Date(date);
    result.setDate(result.getDate() - days);
    return result;
  };

  const onBankAccountNoSelection = () => {
    setIsBankAccountModalOpen(true);
    setValue("ledger_code", "");
    setValue("ledger_des", "");
    setValue("bank_account", "");
  };

  const onBankAccountSelection = (selectedItem: ISelectedItem | undefined) => {
    const bankAccount = bankreconBankAccounts?.filter((s) => s.ledger_code === selectedItem?.value)[0];
    if (selectedItem?.text) {
      setBankId(bankAccount?.bank_id);
      dispatch(
        getBankreconAccountNo({
          bankId: bankAccount?.bank_id,
          callback: (data) => {
            if (data) {
              setValue("ledger_code", bankAccount?.ledger_code, { shouldValidate: true });
              setValue("ledger_des", bankAccount?.ledger_des);
              setValue("bank_account", data?.bank_account);
              if (data?.statementNo >= 0) {
                setIsStatementNoEmpty(false);
                setValue("statement_no", data?.statementNo + 1);
              }
            }
          }
        })
      );
      dispatch(bankReconActions.selectBankAccountRow(bankAccount));
    } else {
      dispatch(bankReconActions.selectBankAccountRow(undefined));
    }
  };

  const onBankAccountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    register("ledger_code").onChange(e);
    const { value } = e.target;
    if (!value.trim()) {
      dispatch(bankReconActions.selectBankAccountRow(undefined));
      dispatch(bankReconActions.resetSelectedRow());
      setValue("ledger_code", specialCharacters.BLANKVALUE);
      setValue("ledger_des", specialCharacters.BLANKVALUE);
      setValue("bank_account", specialCharacters.BLANKVALUE);
      dispatch(bankReconActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(bankReconActions.setFilters({ lookingFor: value }));
    }
  };

  const onSubmit = handleSubmit(
    (data) => {
      if (!data.input_date || !data.statement_no) {
        const message = t("alertMessage.mandatoryFields.message");
        validationAlertPopup(message, NotificationStatus.ERROR);
        return;
      }
      const date = parse(data.input_date, "yyyy-MM-dd", new Date());
      const currentDate = new Date();

      const isFutureDate = isAfter(date, currentDate);

      const formattedDate = format(date, "yyyy-MM-dd");
      setFormattedDate(formattedDate);
      dispatch(
        bankreconValidateStatement({
          bankId: Number(bankId),
          StatementNo: Number(data.statement_no),
          statementDate: formattedDate,
          uniqueIdentifier: "ceebaf9a-5b87-47a5-bd53-8804a4ac2e97",
          callback: async (validateData) => {
            if (!validateData.isValid && isFutureDate) {
              setIsValueEmpty(true);
              const message = t("alertMessage.statementCannotBeFuture.message");
              validationAlertPopup(message, NotificationStatus.ERROR);
            } else if (validateData.isValid && !validateData.continue) {
              setIsStatementNoEmpty(true);
              const { message } = validateData;
              bankreconWarningPopup(message);
            } else if (validateData.continue) {
              const { message } = validateData;
              bankReconLastStatementPopup(message, isFutureDate, formattedDate);
            } else if (validateData.isValid && isFutureDate) {
              setIsValueEmpty(true);
              const message = t("alertMessage.statementCannotBeFuture.message");
              validationAlertPopup(message, NotificationStatus.ERROR);
            } else {
              const res: any = await dispatch(
                addBankreconStatement({
                  bankId: Number(bankId),
                  StatementNo: Number(data.statement_no),
                  statementDate: formattedDate,
                  seriesNo: validateData.series_no,
                  uniqueIdentifier: "ceebaf9a-5b87-47a5-bd53-8804a4ac2e97",
                  callback: (responseData) => {
                    const newHistoryState = {
                      formattedDate,
                      isDirty: true,
                      isNotSaved: true,
                      selectedRowState: responseData.bankReconciliationStatement
                    };
                    const nextStartDate = historyState?.nextYearStartDate;
                    history.push({
                      pathname: `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankId}/bankStatementId/${responseData.bankReconciliationStatement.bank_statement_id}`,
                      state: {
                        ...newHistoryState,
                        nextYearStartDate: nextStartDate,
                        from: "add statement",
                        redirect: true
                      }
                    });
                  }
                })
              );
            }
          }
        })
      );
    },
    (error) => {
      const message = t("alertMessage.mandatoryFields.message");
      validationAlertPopup(message, NotificationStatus.ERROR);
      const inputDate = getValues("input_date");
      const statementNo = getValues("statement_no");
      if (!inputDate) {
        setIsValueEmpty(true);
      }
      if (!statementNo || statementNo === "0") {
        setIsStatementNoEmpty(true);
      }
    }
  );

  const onSubmitForClickAway = handleSubmit(
    async (data, isRedirect) => {
      if (!data.input_date || !data.statement_no) {
        const message = t("alertMessage.mandatoryFields.message");
        validationAlertPopup(message, NotificationStatus.ERROR);
        return;
      }
      const date = parse(data.input_date, "yyyy-MM-dd", new Date());
      const currentDate = new Date();

      const isFutureDate = isAfter(date, currentDate);

      const formattedDate = format(date, "yyyy-MM-dd");
      setFormattedDate(formattedDate);
      await dispatch(
        bankreconValidateStatement({
          bankId: Number(bankId),
          StatementNo: Number(data.statement_no),
          statementDate: formattedDate,
          uniqueIdentifier: "ceebaf9a-5b87-47a5-bd53-8804a4ac2e97",
          callback: async (validateData) => {
            if (!validateData.isValid && isFutureDate) {
              setIsValueEmpty(true);
              const message = t("alertMessage.statementCannotBeFuture.message");
              validationAlertPopup(message, NotificationStatus.ERROR);
              prevLengthRef.current = false;
            } else if (validateData.isValid && !validateData.continue) {
              setIsStatementNoEmpty(true);
              const { message } = validateData;
              bankreconWarningPopup(message);
              prevLengthRef.current = false;
            } else if (validateData.continue) {
              const { message } = validateData;
              bankReconLastStatementPopup(message, isFutureDate, formattedDate);
              prevLengthRef.current = false;
            } else if (validateData.isValid && isFutureDate) {
              setIsValueEmpty(true);
              const message = t("alertMessage.statementCannotBeFuture.message");
              validationAlertPopup(message, NotificationStatus.ERROR);
              prevLengthRef.current = false;
            } else {
              prevLengthRef.current = true;

              await dispatch(
                addBankreconStatement({
                  bankId: Number(bankId),
                  StatementNo: Number(data.statement_no),
                  statementDate: formattedDate,
                  seriesNo: validateData.series_no,
                  uniqueIdentifier: "ceebaf9a-5b87-47a5-bd53-8804a4ac2e97",
                  callback: async (responseData) => {
                    prevLengthRef.current = true;
                    const newHistoryState = {
                      formattedDate,
                      isDirty: true,
                      isNotSaved: true,
                      selectedRowState: responseData.bankReconciliationStatement
                    };
                    const nextStartDate = historyState?.nextYearStartDate;
                    if (isSidebarOpen || showProfileMenu || isProfileMenuRef.current) {
                      history.push({
                        pathname: `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankId}/bankStatementId/${responseData.bankReconciliationStatement.bank_statement_id}`,
                        state: {
                          ...newHistoryState,
                          nextYearStartDate: nextStartDate,
                          from: "add statement",
                          redirect: true,
                          isDirty: false
                        }
                      });
                      if (isSidebarOpen) {
                        dispatch(setIsSidebarOpen(true));
                      } else if (showProfileMenu) {
                        dispatch(setShowProfileMenu(true));
                      }
                    }
                  }
                })
              );
            }
          }
        })
      );
    },
    (error) => {
      const message = t("alertMessage.mandatoryFields.message");
      validationAlertPopup(message, NotificationStatus.ERROR);
      const inputDate = getValues("input_date");
      const statementNo = getValues("statement_no");
      if (!inputDate) {
        setIsValueEmpty(true);
      }
      if (!statementNo || statementNo === "0") {
        setIsStatementNoEmpty(true);
      }
      prevLengthRef.current = false;
    }
  );

  useEffect(() => {
    dispatch(
      getBankreconBankAccounts({
        sequence: Number(KEYBOARD_STRING.Zero),
        callback: async (data) => {
          if (data.length === 1) {
            setBankId(data[0].bank_id);
            const bankReconAccountNo: any = await dispatch(getBankreconAccountNo({ bankId: data[0].bank_id }));
            if (bankReconAccountNo) {
              setValue("ledger_code", data[0]?.ledger_code, { shouldValidate: true });
              setValue("ledger_des", data[0]?.ledger_des);
              setValue("bank_account", bankReconAccountNo?.payload?.bank_account);
              if (bankReconAccountNo?.payload?.statementNo) {
                setValue("statement_no", bankReconAccountNo?.payload?.statementNo + 1);
              }
            }
          } else {
            setValue("statement_no", "0");
          }
        }
      })
    );
  }, []);

  const onCancelNoReset = () => {
    dispatch(
      getBankreconBankAccounts({
        sequence: Number(KEYBOARD_STRING.Zero),
        callback: async (data) => {
          if (data.length === 1) {
            setBankId(data[0].bank_id);
            const bankReconAccountNo: any = await dispatch(getBankreconAccountNo({ bankId: data[0].bank_id }));
            if (bankReconAccountNo) {
              setValue("ledger_code", data[0]?.ledger_code, { shouldValidate: true });
              setValue("ledger_des", data[0]?.ledger_des);
              setValue("bank_account", bankReconAccountNo?.payload?.bank_account);
              if (bankReconAccountNo?.payload?.statementNo) {
                setValue("statement_no", bankReconAccountNo?.payload?.statementNo + 1);
              }
              setValue("input_date", "");
            }
          } else {
            setValue("statement_no", "0");
          }
        }
      })
    );
  };
  const handleKeyDowInputn = (event: any) => {
    if (
      event.key === "Tab" ||
      event.key === "Backspace" ||
      event.key === "Delete" ||
      event.key === "ArrowLeft" ||
      event.key === "ArrowRight"
    ) {
      return;
    }
    if (!/^\d$/.test(event.key)) {
      event.preventDefault();
    }
  };

  const validationAlertPopup = (message: string, notificationType?: NotificationStatus) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE?.ALERT,
        notificationType: notificationType || NotificationStatus.HIGHLIGHT,
        title: t("common.simsFMSModule"),
        message: message ?? "",
        className: "primary-focus",
        callback: () => {
          const inputDate = getValues("input_date");
          const statementNo = getValues("statement_no");
          if (!inputDate) {
            setIsValueEmpty(true);
          }
          if (!statementNo || statementNo === "0") {
            setIsStatementNoEmpty(true);
          }
        }
      })
    );
  };

  const bankreconWarningPopup = (message: string) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE?.ALERT,
        notificationType: NotificationStatus.ERROR,
        title: t("common.simsFMSModule"),
        message: message ?? "",
        className: "primary-focus"
      })
    );
  };

  const bankReconLastStatementPopup = (message: string, isFutureDate: boolean, formattedDate?: string) => {
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        message,
        title: t("common.simsFMSModule"),
        type: MODAL_TYPE?.CONFIRMV2,
        className: "delete-alert",
        yesCallback: () => {
          if (isFutureDate) {
            setIsValueEmpty(true);
            const message = t("alertMessage.statementCannotBeFuture.message");
            validationAlertPopup(message, NotificationStatus.ERROR);
          } else {
            dispatch(
              addBankreconStatement({
                bankId: Number(bankId),
                StatementNo: Number(getValues("statement_no")),
                statementDate: formattedDate,
                seriesNo: 1,
                uniqueIdentifier: "ceebaf9a-5b87-47a5-bd53-8804a4ac2e97",
                callback: (responseData) => {
                  const newHistoryState = {
                    formattedDate,
                    isDirty: true,
                    isNotSaved: true,
                    selectedRowState: responseData.bankReconciliationStatement
                  };
                  const nextStartDate = historyState?.nextYearStartDate;
                  history.push({
                    pathname: `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankId}/bankStatementId/${responseData.bankReconciliationStatement.bank_statement_id}`,
                    state: {
                      ...newHistoryState,
                      nextYearStartDate: nextStartDate,
                      from: "add statement",
                      needToSave: true
                    }
                  });
                }
              })
            );
          }
        },
        noCallback: () => {
          setIsStatementNoEmpty(true);
        },
        isCancelBtnEnable: false
      })
    );
  };

  return {
    t,
    setValue,
    getValues,
    register,
    watch,
    errors,
    bankreconBankAccounts,
    isConfirmModalOpen,
    setIsConfirmModalOpen,
    isBankAccountModalOpen,
    setIsBankAccountModalOpen,
    bankAccountClick,
    onBankAccountSelectedRow,
    onBankAccountSelection,
    formMethods,
    handleKeyDowInputn,
    handleSubmit,
    bankId,
    isValueEmpty,
    setIsValueEmpty,
    bankStatus,
    bankAccountStatus,
    history,
    isStatementNoEmpty,
    setIsStatementNoEmpty,
    historyState,
    onSubmit,
    validateStatus,
    addBankreconStatus,
    subtractDaysFromDate,
    datepickerChangeHandler,
    selectedDate,
    onBankAccountNoSelection,
    onBankAccountChange,
    setAlertType,
    bankReconLastStatementPopup,
    bankreconWarningPopup,
    validationAlertPopup,
    isDirty,
    onCancelNoReset
  };
};

export default useAddStatement;
