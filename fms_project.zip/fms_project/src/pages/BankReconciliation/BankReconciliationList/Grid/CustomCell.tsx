import { cellRendererType } from "@/components/GridTable/GridTable";
import { RootContext, useAppContext } from "@/routes/Routes.utils";
import { RootContextType } from "@/routes/Routes.type";
import { Button, ButtonColor, ButtonSize, Icon } from "@essnextgen/ui-kit";
import { Context, useContext } from "react";
import { useHistory } from "react-router-dom";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { getBankReconciliations, bankRecActions } from "../../state/BankReconciliation.slice";

const CustomCell = ({ field, row }: cellRendererType) => {
  const { redirectToBankReconciledDetails } = useAppContext();
  const dispatch = useDispatch<AppDispatch>();
  const { bankRreconciliationList, nextYearStartDate } = useAppSelector((state) => state.bankReconciliation);
  const { bankreconciledDetailsLink } = redirectToBankReconciledDetails(row);
  const history = useHistory();

  const state = history.location.state as any;
  const getContent = () => {
    switch (field) {
      case "detailLink":
        return (
          <Button
            className="grid-actions__button m-auto"
            dataTestId="bank-reconciliation-view-details-button"
            size={ButtonSize.Small}
            color={ButtonColor.Tertiary}
            iconName="chevron--right"
            onClick={() => {
              dispatch(bankRecActions.setSelectedRow(row));
              dispatch(bankRecActions.setFilters({ highLightedRecordId: row?.bank_statement_id }));
              history.push({
                pathname: bankreconciledDetailsLink,
                state: {
                  selectedRowState: row,
                  bankRreconciliationList,
                  isDirty: undefined,
                  nextYearStartDate
                }
              });
            }}
          />
        );
      case "statement_date":
        return (
          <>
            {new Intl.DateTimeFormat("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })
              .format(new Date(row?.statement_date))
              .replace("Sept", "Sep")}
          </>
        );
      default: {
        return <div data-testid="unknown-field" />;
      }
    }
  };
  return getContent();
};

export default CustomCell;
