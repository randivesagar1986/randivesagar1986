import { Provider, useDispatch } from "react-redux";
import { screen, render, fireEvent, getAllByLabelText, getByLabelText, queryAllByTestId } from "@testing-library/react";
import { Router, useHistory } from "react-router-dom";
import { createMemoryHistory } from "history";
import configureStore from "redux-mock-store";
import userEvent from "@testing-library/user-event";
import React from "react";
import { useAppSelector } from "@/store/store";
import { bankRecActions } from "../../state/BankReconciliation.slice";
import BankReconciliationFilters from "../Grid/BankReconciliationFilters";
import { actions } from "../../state/BankReconciliationStatus.slice";

const mockLookingForChangeHandler = jest.fn();
const props = {
  lookingFor: "",
  lookingForChangehandler: mockLookingForChangeHandler
};

const initialState = {
  bankReconciliation: {
    filterState: {
      pageNumber: 1,
      pageSize: "10",
      sortOrder: 1,
      sequence: 1,
      sequenceValue: "statement_no",
      viewname: "All",
      applyFilter: false,
      lookingFor: "",
      highLightedRecordId: 0
    },
    status: "SUCCESS",
    bankRreconciliationList: {
      data: [
        {
          bank_id: 49,
          str_bank_id: null,
          ledger_code: "BK01",
          ledger_des: "Bank Account",
          bank_account: "01177112",
          bank_sort_code: "40-32-16",
          statement_no: 1306,
          series_no: 1,
          statement_date: "2024-03-22T00:00:00",
          last_modified: "2024-03-27T00:00:00",
          statement_bal: -19015.04,
          opening_bal: 628572.64,
          closing_bal: 609557.6,
          bank_statement_id: 1339,
          user_code: "US1"
        },
        {
          bank_id: 49,
          str_bank_id: null,
          ledger_code: "BK01",
          ledger_des: "Bank Account",
          bank_account: "01177112",
          bank_sort_code: "40-32-16",
          statement_no: 1305,
          series_no: 1,
          statement_date: "2024-03-15T00:00:00",
          last_modified: "2024-03-22T00:00:00",
          statement_bal: -82615.28,
          opening_bal: 711187.92,
          closing_bal: 628572.64,
          bank_statement_id: 1338,
          user_code: "US1"
        },
        {
          bank_id: 49,
          str_bank_id: null,
          ledger_code: "BK01",
          ledger_des: "Bank Account",
          bank_account: "01177112",
          bank_sort_code: "40-32-16",
          statement_no: 1304,
          series_no: 1,
          statement_date: "2024-03-08T00:00:00",
          last_modified: "2024-03-15T00:00:00",
          statement_bal: -605.44,
          opening_bal: 711793.36,
          closing_bal: 711187.92,
          bank_statement_id: 1337,
          user_code: "US1"
        }
      ],
      highLightId: 1339,
      highLightValue: null,
      currentPage: 1,
      totalPages: 131,
      pageSize: 10,
      totalCount: 1306
    }
  },
  bankReconciliationViews: {
    bankReconciliationViews: [
      {
        ledger_code: "TestALL",
        ledger_des: "TestAll Accounts",
        bank_id: 0
      },
      {
        ledger_code: "TestBK01",
        ledger_des: "TestBank Account",
        leddef_id: 3211,
        bank_account: "01177112",
        bank_sort_code: "40-32-16",
        bank_id: 49,
        ledger_id: 3599
      }
    ],
    selectedView: {
      text: "testing selected view text",
      value: "testing selected view value"
    }
  }
};

jest.mock("react-redux", () => ({
  __esModule: true,
  useDispatch: jest.fn()
}));

jest.mock("../../state/BankReconciliationStatus.slice", () => ({
  actions: {
    setBankReconciliationView: jest.fn()
  }
}));

jest.mock("../../state/BankReconciliation.slice", () => ({
  bankRecActions: {
    setFilters: jest.fn(),
    setColumnDef: jest.fn()
  }
}));

jest.mock("@/store/store", () => ({
  __esModule: true,
  useAppSelector: jest.fn()
}));

jest.mock("@/shared/components/LookingFor/LookingFor", () => ({
  __esModule: true,
  LookingFor: jest.fn((props: any) => <p>looking for</p>)
}));

jest.mock("../../../../routes/Routes", () => ({
  useAppContext: () => ({
    redirectToBankReconciledDetails: jest.fn((row) => ({
      bankreconciledDetailsLink:
        "/UI/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/49/bankStatementId/1339"
    }))
  })
}));
jest.mock("../Grid/columnDef", () => [
  {
    headerName: "Statement Date",
    field: "statement_date",
    cellRenderer: "GridCellLink",
    sequence: true,
    sequenceName: "testing seq 1"
  },
  {
    headerName: "Statement No.",
    field: "statement_no",
    sequence: true,
    sequenceName: "testing seq 2"
  },
  {
    headerName: "Statement No.",
    field: "statement_no",
    sequence: true,
    sequenceName: undefined
  }
]);

describe("testing bankrecnciliationfilters component", () => {
  const mockDispatch = jest.fn();

  beforeAll(() => {
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
  });

  beforeEach(() => {
    (useAppSelector as jest.Mock).mockImplementation((selector: any) => selector(initialState));
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe("testing sequence", () => {
    it("sequnces should be defined", () => {
      render(<BankReconciliationFilters {...props} />);
      const sequences = screen.getByRole("radio", { name: /testing seq 1/i });
      expect(sequences).toBeDefined();
    });

    it("form label for sequence should be rendered correctly", () => {
      render(<BankReconciliationFilters {...props} />);
      const formLabelSequence = screen.getByText(/bankReconciliation.sequence/i);
      expect(formLabelSequence).toBeInTheDocument();
    });

    it("Should render 2 sequences", () => {
      render(<BankReconciliationFilters {...props} />);
      const sequenceRadiosLabels: HTMLInputElement[] = screen.getAllByTestId("bank-reconciliation-sequence");
      expect(sequenceRadiosLabels.length).toBe(3);
    });

    it("should render correct labels for each sequnce radio", () => {
      render(<BankReconciliationFilters {...props} />);
      const sequenceOneRadiosLabels = screen.getByLabelText(/testing seq 1/i);
      const sequenceTwoRadiosLabels = screen.getByLabelText(/testing seq 2/i);
      expect(sequenceOneRadiosLabels).toBeInTheDocument();
      expect(sequenceTwoRadiosLabels).toBeInTheDocument();
    });

    it("should call lookingForChangehandler on sequence change", async () => {
      render(<BankReconciliationFilters {...props} />);
      const sequence = screen.getByRole("radio", { name: /testing seq 1/i });

      await userEvent.click(sequence);
      expect(mockLookingForChangeHandler).toHaveBeenCalledWith("");
    });

    it("should dispatch setfilters action on ArrowRight key down on sequence", async () => {
      render(<BankReconciliationFilters {...props} />);
      const sequence = screen.getByRole("radio", { name: /testing seq 1/i });

      fireEvent.keyDown(sequence, { key: "ArrowRight", code: "ArrowRight" });
      expect(mockDispatch).toHaveBeenCalledWith(
        bankRecActions.setFilters(
          expect.objectContaining({
            lookingFor: "",
            sequence: 1,
            sequenceValue: expect.any(String),
            highLightedRecordId: undefined
          })
        )
      );
    });

    it("should call lookingForChangeHandler on arrow key press", async () => {
      render(<BankReconciliationFilters {...props} />);
      const sequence = screen.getByRole("radio", { name: /testing seq 1/i });

      await userEvent.type(sequence, "keydown");
      expect(mockLookingForChangeHandler).toHaveBeenCalledWith("");
    });

    it("if column does not have a sequence then sequence header should be used", () => {
      render(<BankReconciliationFilters {...props} />);
      const sequenceRadiosLabels: HTMLInputElement[] = screen.getAllByTestId("bank-reconciliation-sequence");

      expect(sequenceRadiosLabels).toHaveLength(3);
    });
  });
  describe("testing order", () => {
    it("orders should be defined", () => {
      render(<BankReconciliationFilters {...props} />);
      const orders = screen.getAllByTestId("bank-reconciliation-sequence-order");
      expect(orders).toBeDefined();
    });

    it("should be 2 orders", () => {
      render(<BankReconciliationFilters {...props} />);
      const orders = screen.getAllByTestId("bank-reconciliation-sequence-order");
      expect(orders.length).toBe(2);
    });

    it("orders should be mapped with state correctly", () => {
      render(<BankReconciliationFilters {...props} />);
      const ordersLabels = screen.getAllByTestId("bank-reconciliation-sequence-order");
      const orders: any = ordersLabels.map((label) => label.querySelector("input"));
      expect(orders[0].checked).toBe(false);
      expect(orders[1].checked).toBe(true);
    });

    it("all orders radio should be clickable", () => {
      render(<BankReconciliationFilters {...props} />);
      const ordersLabels = screen.getAllByTestId("bank-reconciliation-sequence-order");
      const orders: any = ordersLabels.map((label) => label.querySelector("input"));

      orders.forEach((order: any) => {
        expect(order).toBeEnabled();
      });
    });

    it("only one order should be checked at any given time", () => {
      render(<BankReconciliationFilters {...props} />);
      const ordersLabels = screen.getAllByTestId("bank-reconciliation-sequence-order");
      const orders: any = ordersLabels.map((label) => label.querySelector("input"));

      fireEvent.change(orders[1]);

      expect(orders[1].checked).toBe(true);
      expect(orders[0].checked).toBe(false);
    });
  });

  describe("testing view", () => {
    it("User should be able to type into it correctly", () => {
      render(<BankReconciliationFilters {...props} />);
      const viewInput = screen.getByTestId("text-input-dropdown-view");
      fireEvent.change(viewInput, { target: { value: "test value" } });
      expect(viewInput).toHaveValue("test value");
    });

    it("if bankReconciliationList is empty then it should render dropdown upto 120px height", () => {
      (useAppSelector as jest.Mock).mockImplementation((selector: any) =>
        selector({
          ...initialState,
          bankReconciliation: {
            ...initialState.bankReconciliation,
            bankRreconciliationList: {
              ...initialState.bankReconciliation.bankRreconciliationList,
              data: [],
              totalCount: undefined
            }
          }
        })
      );
      render(<BankReconciliationFilters {...props} />);
      const dropdown = screen.queryByTestId("dropdown-view");
      expect(dropdown).toBeInTheDocument();
    });
    it("if bankReconciliation views are 0 then it should not render dropdown items", () => {
      (useAppSelector as jest.Mock).mockImplementation((selector: any) =>
        selector({
          ...initialState,
          bankReconciliationViews: {
            bankReconciliationViews: null,
            selectedView: {
              text: "",
              value: ""
            }
          }
        })
      );
      render(<BankReconciliationFilters {...props} />);
      const dropdowns = screen.queryAllByTestId("dropdown-option-view");
      expect(dropdowns.length).toBe(0);
    });
  });
});
