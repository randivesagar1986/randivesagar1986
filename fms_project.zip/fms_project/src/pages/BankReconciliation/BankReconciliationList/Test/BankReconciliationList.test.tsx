import { Provider, useDispatch } from "react-redux";
import { screen, render, fireEvent, getAllByLabelText, getByLabelText, queryAllByTestId } from "@testing-library/react";
import RouterProvider, { Router, useHistory } from "react-router-dom";

import { createMemoryHistory } from "history";
import configureStore from "redux-mock-store";
import userEvent from "@testing-library/user-event";
import { STATUS } from "@/types/UseStateType";
import React from "react";
import { useAppDispatch, useAppSelector } from "@/store/store";
import { bankRecActions, getBankReconciliations } from "../../state/BankReconciliation.slice";
import BankReconciliationFilters from "../Grid/BankReconciliationFilters";
import BankReconciliationList from "../BankReconciliationList";

const props = {
  lookingFor: "",
  lookingForChangehandler: jest.fn()
};

const row1 = { id: "1234", row: "row 1" };
const row2 = { id: "5678", row: "row 2" };

const initialState = {
  bankReconciliation: {
    filterState: {
      pageNumber: 1,
      pageSize: "10",
      sortOrder: 1,
      sequence: 1,
      sequenceValue: "statement_no",
      viewname: "All",
      applyFilter: false,
      lookingFor: "",
      highLightedRecordId: 0
    },
    selectedRow: row2,
    checkedRow: [],
    conlumnDef: [],
    status: "SUCCESS",
    bankRreconciliationList: {
      data: [row1, row2],
      highLightId: 1339,
      highLightValue: null,
      currentPage: 2,
      totalPages: 131,
      pageSize: 10,
      totalCount: 1306
    }
  },
  bankReconciliationStatement: {
    deleteStatus: "hii"
  },
  supplierCatalogue: {
    catalogueData: {}
  },
  bankReconciliationViews: {
    bankReconciliationViews: [
      {
        ledger_code: "TestALL",
        ledger_des: "TestAll Accounts",
        bank_id: 0
      },
      {
        ledger_code: "TestBK01",
        ledger_des: "TestBank Account",
        leddef_id: 3211,
        bank_account: "01177112",
        bank_sort_code: "40-32-16",
        bank_id: 49,
        ledger_id: 3599
      }
    ],
    selectedView: {
      text: "testing selected view text",
      value: "testing selected view value"
    }
  }
};
jest.mock("react-redux", () => ({
  __esModule: true,
  useDispatch: jest.fn()
}));

jest.mock("../../state/BankReconciliation.slice", () => ({
  bankRecActions: {
    setFilters: jest.fn(),
    setNextYearStartDate: jest.fn(),
    setSelectedRow: jest.fn()
  },
  getBankReconciliations: jest.fn((props: any) => {
    if (props?.callback !== undefined) {
      props?.callback({ data: [{ id: "1234", row: "row 1" }] });
    }
  })
}));

jest.mock("react-router-dom", () => ({
  __esModule: true,
  useHistory: jest.fn()
}));

jest.mock("@/store/store", () => ({
  __esModule: true,
  useAppSelector: jest.fn()
}));

jest.mock("../../BankReconciliationToolbar", () => ({
  __esModule: true,
  default: jest.fn((props: any) => (
    <div data-testId={props?.dataTestId}>
      <h1>toolbar</h1>
      <div>
        <button
          type="button"
          onClick={props?.goToPrevRecord}
        >
          goToPrevRecord
        </button>
        <button
          type="button"
          onClick={props?.goToNextRecord}
        >
          goToNextRecord
        </button>
        <button
          type="button"
          onClick={props?.handleVerifyBalance}
        >
          verify balance
        </button>
      </div>
    </div>
  ))
}));
const mockDataSource = [
  {
    statementDate: "22-mar-2024",
    statementNumber: "1306",
    account: "Bank Account",
    accountNumber: "01177112",
    sortCode: "40-32-16"
  }
];

jest.mock("../../../../components/Breadcrumbs/Breadcrumbs", () => () => <div>breadcrum</div>);

jest.mock("../../../../routes/Routes.utils", () => ({
  useAppContext: () => ({
    redirectToBankReconciledDetails: jest.fn((row) => ({
      bankreconciledDetailsLink:
        "/UI/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/49/bankStatementId/1339"
    }))
  })
}));

jest.mock("@/components/Loader/Loader", () => ({
  __esModule: true,
  default: jest.fn((props: any) => <p>loading</p>)
}));

jest.mock("@/components/GridTableNew/GridTableNew", () => ({
  __esModule: true,
  default: jest.fn((props: any) => (
    <>
      <table>
        {props?.dataSource?.map((row: any) => (
          <tr>{row?.id}</tr>
        ))}
      </table>
    </>
  ))
}));

jest.mock("../Grid/columnDef", () => [
  {
    headerName: "Statement Date",
    field: "statement_date",
    cellRenderer: "GridCellLink",
    sequence: true,
    sequenceName: "testing seq 1"
  },
  {
    headerName: "Statement No.",
    field: "statement_no",
    sequence: true,
    sequenceName: "testing seq 2"
  }
]);

const history = createMemoryHistory();
history.push("/UI/general-ledger/bank-reconciliation");

describe("BankReconciliationList Component", () => {
  const mockDispatch = jest.fn();
  const mockHistoryPush = jest.fn();
  const blockReturn = jest.fn();
  const mockHistoryBlock = jest.fn(() => blockReturn);

  beforeAll(() => {
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue({
      location: {
        state: {}
      },
      push: mockHistoryPush,
      block: mockHistoryBlock
    });
  });

  beforeEach(() => {
    (useAppSelector as jest.Mock).mockImplementation((selector: any) => selector(initialState));
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("testing", () => {
    render(<BankReconciliationList />);
    screen.debug();
  });

  it("while loading loader should be rendered", () => {
    (useAppSelector as jest.Mock).mockImplementation((selector: any) =>
      selector({
        ...initialState,
        bankReconciliationStatement: {
          deleteStatus: STATUS.LOADING
        }
      })
    );
    render(<BankReconciliationList />);
    const loader = screen.getByText(/loading/i);
    expect(loader).toBeInTheDocument();
  });
  it("after loading loader no longer should be in the dom", () => {
    render(<BankReconciliationList />);
    const loader = screen.queryByTestId(/loading/i);
    expect(loader).not.toBeInTheDocument();
  });

  it("should render page title currectly", () => {
    render(<BankReconciliationList />);
    const title = screen.getByText(/bankReconciliation.bankReconciliation/i);
    expect(title).toBeInTheDocument();
  });

  it("should render breadcrums", () => {
    render(<BankReconciliationList />);
    const breadCrums = screen.getByText(/breadcrum/i);
    expect(breadCrums).toBeInTheDocument();
  });

  it("should render toolbar", () => {
    render(<BankReconciliationList />);
    const toolbar = screen.getByTestId(/bankReconciliation-toolbar/i);
    expect(toolbar).toBeInTheDocument();
  });

  it("should render grid table", () => {
    render(<BankReconciliationList />);
    const table = screen.getByRole("table");
    expect(table).toBeInTheDocument();
  });

  it("should render grid table with correct number of rows mapping with dataSource", () => {
    const tableRowData = initialState.bankReconciliation.bankRreconciliationList.data;
    render(<BankReconciliationList />);
    const table = screen.getByRole("table");
    expect(table.childElementCount).toBe(tableRowData.length);
  });

  it("should not render any row inside grid table if dataSource is empty", () => {
    (useAppSelector as jest.Mock).mockImplementation((selector: any) =>
      selector({
        ...initialState,
        bankReconciliation: {
          ...initialState.bankReconciliation,
          bankRreconciliationList: {
            ...initialState.bankReconciliation.bankRreconciliationList,
            data: []
          }
        }
      })
    );

    render(<BankReconciliationList />);
    const table = screen.getByRole("table");
    expect(table.childElementCount).toBe(0);
  });

  it("should select previous record on click of go to previous record button, if current selected record is not the first record in the table", async () => {
    render(<BankReconciliationList />);
    const prevRecBtn = screen.getByRole("button", { name: /goToPrevRecord/i });
    fireEvent.click(prevRecBtn);
    expect(mockDispatch).toHaveBeenCalledWith(bankRecActions.setSelectedRow(row1));
  });

  it("should select previous record on click of go to previous record button, if current selected record is the first record in the table", async () => {
    (useAppSelector as jest.Mock).mockImplementation((selector: any) =>
      selector({
        ...initialState,
        bankReconciliation: {
          ...initialState.bankReconciliation,
          selectedRow: row1
        }
      })
    );
    render(<BankReconciliationList />);
    const prevRecBtn = screen.getByRole("button", { name: /goToPrevRecord/i });
    fireEvent.click(prevRecBtn);
    expect(mockDispatch).toHaveBeenCalledWith(
      getBankReconciliations(
        expect.objectContaining({
          pageNumber: 1,
          pageSize: "10",
          LookingFor: ""
        })
      )
    );
  });

  it("should select next record on click of go to next record button, if current selected record is not the last record in the table", async () => {
    (useAppSelector as jest.Mock).mockImplementation((selector: any) =>
      selector({
        ...initialState,
        bankReconciliation: {
          ...initialState.bankReconciliation,
          selectedRow: row1
        }
      })
    );
    render(<BankReconciliationList />);
    const nextBtn = screen.getByRole("button", { name: /goToNextRecord/i });
    fireEvent.click(nextBtn);
    expect(mockDispatch).toHaveBeenCalledWith(bankRecActions.setSelectedRow(row2));
  });

  it("should select next record on click of go to next record button, if current selected record is the last record in the table", async () => {
    render(<BankReconciliationList />);
    const nextBtn = screen.getByRole("button", { name: /goToNextRecord/i });
    fireEvent.click(nextBtn);
    expect(mockDispatch).toHaveBeenCalledWith(
      bankRecActions.setFilters(
        expect.objectContaining({
          lookingFor: "",
          pageNumber: 3,
          pageSize: "10",
          viewname: "All",
          highLightedRecordId: undefined
        })
      )
    );
  });
});
