import { render, screen, fireEvent } from "@testing-library/react";
import React from "react";
import { Provider, useDispatch } from "react-redux";
import { createMemoryHistory } from "history";
import { Router, useHistory } from "react-router-dom";
import configureStore from "redux-mock-store";
import { useAppSelector } from "@/store/store";
import CustomCell from "../Grid/CustomCell";
import { bankRecActions } from "../../state/BankReconciliation.slice";
import "@testing-library/jest-dom/extend-expect";

const mockBankreconciledDetailsLink =
  "/UI/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/49/bankStatementId/1339";
const initialState = {
  bankReconciliation: {
    bankRreconciliationList: [],
    nextYearStartDate: "2023-01-01"
  }
};

const row = {
  bank_statement_id: 1339,
  statement_date: "2023-09-01T00:00:00Z",
  user_code: "US1"
};

const props = {
  field: "detailLink",
  row
};

jest.mock("../../../../routes/Routes.utils", () => ({
  useAppContext: () => ({
    redirectToBankReconciledDetails: jest.fn((row) => ({
      bankreconciledDetailsLink: mockBankreconciledDetailsLink
    }))
  })
}));

jest.mock("react-redux", () => ({
  __esModule: true,
  useDispatch: jest.fn()
}));

jest.mock("../../state/BankReconciliation.slice", () => ({
  bankRecActions: {
    setSelectedRow: jest.fn(),
    setFilters: jest.fn()
  }
}));

jest.mock("@/store/store", () => ({
  __esModule: true,
  useAppSelector: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  __esModule: true,
  useHistory: jest.fn()
}));

describe("CustomCell component", () => {
  const mockDispatch = jest.fn();
  const mockHistoryPush = jest.fn();

  beforeAll(() => {
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue({
      location: {
        state: {}
      },
      push: mockHistoryPush
    });
  });

  beforeEach(() => {
    (useAppSelector as jest.Mock).mockImplementation((selector: any) => selector(initialState));
  });

  it("should render detailLink button correctly", () => {
    render(<CustomCell {...props} />);
    const button = screen.getByTestId("bank-reconciliation-view-details-button");
    expect(button).toBeInTheDocument();
  });

  it("should call dispatch and navigate to the correct route on detailLink button click", () => {
    const { bankRreconciliationList } = initialState.bankReconciliation;
    const { nextYearStartDate } = initialState.bankReconciliation;
    render(<CustomCell {...props} />);
    const btn = screen.getByTestId(/bank-reconciliation-view-details-button/i);
    fireEvent.click(btn);
    expect(mockDispatch).toHaveBeenCalledWith(bankRecActions.setSelectedRow(row));
    expect(mockDispatch).toHaveBeenCalledWith(
      bankRecActions.setFilters({ highLightedRecordId: row?.bank_statement_id })
    );
    expect(mockHistoryPush).toHaveBeenCalledWith({
      pathname: mockBankreconciledDetailsLink,
      state: {
        selectedRowState: row,
        bankRreconciliationList,
        isDirty: undefined,
        nextYearStartDate
      }
    });
  });

  it("should render statement_date correctly", () => {
    const diffProp = { ...props, field: "statement_date" };
    render(<CustomCell {...diffProp} />);
    screen.debug();
    const formattedDate = new Intl.DateTimeFormat("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    })
      .format(new Date(row.statement_date))
      .replace("Sept", "Sep");

    expect(screen.getByText(formattedDate)).toBeInTheDocument();
  });

  it("should return an empty div for unknown field", () => {
    const diffProp = { ...props, field: "testing" };
    render(<CustomCell {...diffProp} />);
    expect(screen.queryByTestId("unknown-field")).toBeEmptyDOMElement();
  });
});
