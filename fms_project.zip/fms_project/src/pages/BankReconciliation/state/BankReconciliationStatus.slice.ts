import { ISelectedItem } from "@essnextgen/ui-kit";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "../../../config";

type bankReconciliationStatus = {
  bankReconciliationViews: { [key: string]: any }[];
  error: string | undefined;
  status?: STATUS;
  selectedView: ISelectedItem;
};

const initialState: bankReconciliationStatus = {
  bankReconciliationViews: [],
  selectedView: {
    text: "",
    value: ""
  },
  error: ""
};

/** Thunks */
export const getBankReconciliationStatus = createAsyncThunk("bankReconciliation/Status", async () => {
  const response = await client.get(`${apiRoot}/bankrecon/bankrecon-bank-accounts`);
  return response.data;
});

/**
 * # Purchase Order Status Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** Purchase Orders List */
    builder
      .addCase(getBankReconciliationStatus.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getBankReconciliationStatus.fulfilled, (state, action: PayloadAction<any>) => {
        const AllBank = {
          ledger_code: "ALL",
          ledger_des: "All Accounts",
          bank_id: 0
        };
        const newPayload = [AllBank, ...action.payload];
        if (state.selectedView.text === "") {
          state.selectedView = {
            text: newPayload[0]?.ledger_des,
            value: newPayload[0]?.ledger_code
          };
        }
        state.bankReconciliationViews = newPayload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getBankReconciliationStatus.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  initialState,
  name: "bankReconciliationStatus",
  reducers: {
    setBankReconciliationView: (state, action: PayloadAction<any>) => {
      state.selectedView = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
