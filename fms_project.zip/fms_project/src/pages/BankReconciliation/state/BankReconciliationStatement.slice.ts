import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { STATUS } from "@/types/UseStateType";
import { getSessionItem, setToSession } from "@/utils/getDataSource";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { TFunction } from "@essnextgen/ui-intl-kit";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { RootState } from "@/store/store";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import { bankRecActions, getBankReconciliations } from "./BankReconciliation.slice";
import columnDef from "../BankReconciliationStatement/Grid/columnDef";
import sccColumnDef from "../BankReconciliationStatementContentChooser/Grid/columnDef";

export type bankReconcilicationStatement = { [key: string]: any }[];

export type FilterStateType = {
  lookingFor?: string | undefined;
  sequence?: number;
  sequenceValue?: string;
};

export type BankRecType = {
  reconciledDetails: {
    bankLedger: string;
    bankReconciledTransactions?: { [key: string]: any }[];
    uniqueIdentifier: string | null;
  };
  unreconciledDetails: {
    bankLedger: string;
    bankReconciledTransactions?: { [key: string]: any }[];
    uniqueIdentifier: string | null;
  };
};

type intialStateType = {
  siIndividualSalaryList: { [key: string]: any }[];
  siIndividualSalaryContractHeader: { [key: string]: any };
  siPaymentDetails: { [key: string]: any }[];
  siPaymentDetailsStatus?: STATUS;
  formData?: { [key: string]: any };
  bankReconciliationStatement?: BankRecType;
  bankReconStatus?: STATUS;
  saveReconStatus?: STATUS;
  bankGlFundToBankData: { [key: string]: any }[];
  reconciledDetails: { [key: string]: any }[];
  unreconciledDetails: { [key: string]: any }[];
  storeReconciledList?: { [key: string]: any }[];
  storeUnreconciledList?: { [key: string]: any }[];
  newReconciledDetails?: { [key: string]: any }[];
  newUnReconciledDetails?: { [key: string]: any }[];
  selectedContractDetailsRow?: { [key: string]: any };
  selectedRow?: { [key: string]: any };
  selectedBankReconiledRow?: { [key: string]: any };
  selectedBankUnreconciledRow?: { [key: string]: any };
  glFundStatus?: STATUS;
  siStatus?: STATUS;
  filterState?: FilterStateType;
  sccFilterState?: FilterStateType;
  deleteStatus?: STATUS;
  columnDef: TColumnDef;
  sccColumnDef: TColumnDef;
  isLoading: boolean;
  VerifyBalaceStatus?: boolean;
  contractDetailsApiStatus?: STATUS;
};

const initialState: intialStateType = {
  siIndividualSalaryList: [],
  siIndividualSalaryContractHeader: {},
  siPaymentDetails: [],
  filterState: {
    sequence: 0,
    sequenceValue: columnDef.filter((col) => !!col.sequence)[0].field
  },
  sccFilterState: {
    lookingFor: "",
    sequence: 0,
    sequenceValue: columnDef.filter((col) => !!col.sequence)[0].field
  },
  columnDef,
  sccColumnDef,
  bankGlFundToBankData: [],
  isLoading: false,
  VerifyBalaceStatus: false,
  bankReconciliationStatement: {
    reconciledDetails: {
      bankLedger: "",
      bankReconciledTransactions: [],
      uniqueIdentifier: null
    },
    unreconciledDetails: {
      bankLedger: "",
      bankReconciledTransactions: [],
      uniqueIdentifier: null
    }
  },
  reconciledDetails: [],
  unreconciledDetails: [],
  newReconciledDetails: [],
  newUnReconciledDetails: []
};
/* eslint-disable camelcase */
type bankReconcilicationStatementDetails = {
  bankId: string | null;
  bank_statement_id: string | null;
  uniqueIdentifier?: string | null;
  sequence?: number;
  statementChooser: boolean;
  callback?: (data: any) => void;
};

/** Thunks */

export const getBankReconciliationStatement = createAsyncThunk(
  "bankReconcilicationStatement/get",
  async ({
    bankId,
    bank_statement_id,
    uniqueIdentifier,
    sequence,
    statementChooser,
    callback
  }: bankReconcilicationStatementDetails) => {
    const response = await client.get(
      `${apiRoot}/bankrecon/bankrecon-details?bankId=${bankId}&bankStatementId=${bank_statement_id}&sequence=${sequence}&statementChooser=${statementChooser}&uniqueIdentifier=${uniqueIdentifier}`
    );
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

type DeleteRocordType = {
  bankid: string;
  bankStatementId: string;
  t: TFunction<"translation", {}>;
  callback?: (data?: RowType, row?: RowType) => void;
  isDetails: boolean;
  reconciledRecords: { [key: string]: any }[];
};

type BalanceVerifyType = {
  uniqueIdentifier: string | null;
  t: TFunction<"translation", {}>;
  callBackModal: boolean;
  callback?: () => void;
};

type TSaveBankStatement = {
  opening_bal: number;
  closing_bal: number;
  bank_statement_id: number;
  uniqueIdAdded: any;
  uniqueIdRemoved: any;
  bank_id: number;
  statement_date: string;
  start_stat_no: number;
  series_no: number;
  difference: any;
  ledger_description: string;
  statement_no: number;
};

export const deleteBankreconStatement = createAsyncThunk(
  "bankrecon/bankreconDeleteStatement",
  async ({ bank_statement_id, callback }: { bank_statement_id: number; callback?: (data: any) => void }) => {
    const response = await client.delete(
      `${apiRoot}/bankrecon/bankrecon-delete-statement?bankStatementId=${bank_statement_id}`
    );
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const deleteRecord = createAsyncThunk(
  "bankReconcilicationStatement/delete",
  async ({ bankid, bankStatementId, t, callback, isDetails, reconciledRecords }: DeleteRocordType, thunkAPI) => {
    const { dispatch, getState } = thunkAPI;
    const {
      bankReconciliation,
      bankReconciliationStatement: { bankReconciliationStatement }
    } = getState() as RootState;
    const { filterState } = bankReconciliation;
    const uniqueId = getSessionItem("uniqueIdentifier");
    let result;
    if (isDetails) {
      result = await dispatch(
        getBankReconciliationStatement({
          bankId: bankid,
          bank_statement_id: bankStatementId,
          statementChooser: false,
          uniqueIdentifier: uniqueId || ""
        })
      );
    }
    if (result === undefined) {
      result = {
        payload: bankReconciliationStatement
      };
    } else {
      result = {
        payload: result.payload as any
      };
    }
    if (result?.payload) {
      if (
        reconciledRecords?.length !== 0 ||
        result?.payload?.reconciledDetails?.bankReconciledTransactions?.length !== 0
      ) {
        dispatch(
          uiActions.alertPopup({
            enable: true,
            type: MODAL_TYPE?.ALERT,
            title: t("common.simsFMSModule"),
            message: t("bankReconciliation.errors.invalidDeleteStatement"),
            notificationType: NotificationStatus?.ERROR,
            className: "primary-focus",
            callback: () => {
              if (isDetails) {
                dispatch(actions.resetReconciledDetails());
              }
            }
          })
        );
      } else {
        await new Promise((resolve, rejects) => {
          dispatch(
            uiActions.confirmPopup({
              enable: true,
              type: MODAL_TYPE?.CONFIRMV2,
              title: t("common.simsFMSModule"),
              message: t("bankReconciliation.errors.deleteStatement"),
              notificationType: NotificationStatus?.WARNING,
              className: "delete-alert",
              escapeExits: false,
              yesCallback: async () => {
                try {
                  const result = await dispatch(
                    deleteBankreconStatement({
                      bank_statement_id: Number(bankStatementId)
                    })
                  );
                  if (result.type === "bankrecon/bankreconDeleteStatement/fulfilled") {
                    let index = bankReconciliation.bankRreconciliationList.data.indexOf(
                      bankReconciliation!.selectedRow!
                    );
                    const length =
                      bankReconciliation.bankRreconciliationList.currentPage ===
                      bankReconciliation.bankRreconciliationList.totalPages;
                    index = length ? index - 1 : index;
                    const result = await dispatch(
                      getBankReconciliations({
                        ...filterState,
                        index,
                        pageNumber:
                          length && bankReconciliation.bankRreconciliationList.data.length === 1
                            ? filterState?.pageNumber! - 1
                            : filterState?.pageNumber!
                      })
                    );
                    const response = result?.payload as RowType;
                    if (response) {
                      const row = index
                        ? ((response?.data as RowType[]) || []).at(index)
                        : ((response?.data as RowType[]) || [])
                            ?.filter((p) => p.bank_statement_id === response?.highLightId)
                            .at(0);
                      dispatch(bankRecActions.setSelectedRow(row));
                      if (callback) {
                        callback(response, row);
                      }
                    }
                  }
                  resolve(true);
                } catch (e) {
                  const errorDetail: any = thunkAPI.rejectWithValue({
                    error: e
                  });
                  const errorMsg =
                    errorDetail?.payload?.error?.response?.data?.detail === "LRM71"
                      ? t("purchaseOrder.errors.LRM71")
                      : t("purchaseOrder.errors.genricError");
                  dispatch(
                    uiActions.alertPopup({
                      enable: true,
                      type: MODAL_TYPE?.ALERT,
                      title: t("common.simsFMSModule"),
                      message: errorMsg,
                      notificationType: NotificationStatus?.WARNING
                    })
                  );
                  rejects(e);
                }
              },
              noCallback: () => {
                resolve(true);
              }
            })
          );
        });
      }
    }
  }
);

export const checkTransCurrentYr = createAsyncThunk(
  "bankrecon/bankreconTransCurrentYr",
  async (
    {
      uniqueId,
      currentYearId,
      callback
    }: {
      uniqueId: string;
      currentYearId: number;
      callback?: (data: any) => void;
    },
    thunkAPI
  ) => {
    try {
      const response = await client.get(`${apiRoot}/bankrecon/bankrecon-trans-current-yr`, {
        params: {
          uniqueId,
          currentYearId
        }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getPaymentRunId = createAsyncThunk(
  "bankrecon/getPaymentRunId",
  async ({ paymentId, callback }: { paymentId: number; callback?: (data: any) => void }, thunkAPI) => {
    try {
      const response = await client.get(`${apiRoot}/bankrecon/bankrecon-view-ch`, {
        params: {
          paymentId
        }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getBankViewGlFundToBack = createAsyncThunk(
  "bankrecon/bankrecon-view-gl-fund-to-bank",
  async ({ voucherLineId, callback }: { voucherLineId: number; callback?: (data: any) => void }, thunkAPI) => {
    try {
      const response = await client.get(`${apiRoot}/bankrecon/bankrecon-view-gl-fund-to-bank`, {
        params: {
          voucherLineId
        }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getSIPaymentDetailsIndividualSalary = createAsyncThunk(
  "bankrecon/bankrecon-view-GetSIpaymentdetails",
  async ({ Salarypaymentid, callback }: { Salarypaymentid: number; callback?: (data: any) => void }, thunkAPI) => {
    try {
      const response = await client.get(`${apiRoot}/bankrecon/bankrecon-view-GetSIpaymentdetails`, {
        params: {
          Salarypaymentid
        }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);
export const getSIIndidualSalary = createAsyncThunk(
  "bankrecon/bankrecon-view-GetSI",
  async (
    {
      Salarypaymentbatchid,
      Yearid,
      callback
    }: { Salarypaymentbatchid: number; Yearid: any; callback?: (data: any) => void },
    thunkAPI
  ) => {
    try {
      const { dispatch } = thunkAPI;
      const { data }: { data: { [key: string]: any } } = await client.get(`${apiRoot}/bankrecon/bankrecon-view-GetSI`, {
        params: {
          Salarypaymentbatchid,
          Yearid
        }
      });
      if (data) {
        const row = ((data?.siIndividualSalaryLinkList as { [key: string]: any }[]) || [])
          ?.filter((p) => p.Salarypaymentbatchid === data?.highLightId)
          .at(0);
        dispatch(actions.setSelectedContractDetailsRow(row));
        if (callback) {
          callback(data);
        }
      }

      return data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getPayingInProgressDetails = createAsyncThunk(
  "bankrecon/bankreconTransCurrentYr",
  async ({ paySlipId, callback }: { paySlipId: number; callback?: (data: any) => void }, thunkAPI) => {
    try {
      const response = await client.get(`${apiRoot}/bankrecon/bankrecon-ar`, {
        params: {
          paySlipId
        }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);
/** Export document */
export const getBankReconciliationDocument = createAsyncThunk(
  "bank-reconciliation/BankReconciliationDocument",
  async ({ bankID, statementId, statementNumber }: { bankID: any; statementId: any; statementNumber: any }) => {
    const response = await client.get(
      `${apiRoot}/document/bankrecon-print?bankId=${bankID}&statementId=${statementId}&statementNumber=${statementNumber}`
    );
    return response.data;
  }
);

export const getVerifyBalaceDetail = createAsyncThunk(
  "bankrecon/bankreconTransCurrentYr",
  async ({ uniqueIdentifier, t, callBackModal, callback }: BalanceVerifyType, thunkAPI) => {
    const { dispatch } = thunkAPI;
    try {
      const response = await client.get(
        `${apiRoot}/bankrecon/bankrecon-verify-balance?uniqueIdentifier=${uniqueIdentifier}`
      );

      if (response.status === 200 && callBackModal) {
        dispatch(
          uiActions.alertPopup({
            enable: true,
            type: MODAL_TYPE?.ALERT,
            title: t("alertMessage.verifyBalancesAlert.title"),
            message: t("alertMessage.verifyBalancesAlert.verifyBalancesSucessAlert"),
            notificationType: NotificationStatus?.HIGHLIGHT
          })
        );

        setTimeout(() => {
          const foucusButton = document.querySelector(".essui-overlay-container .essui-button--primary") as HTMLElement;
          if (foucusButton) {
            foucusButton.focus();
          }
        }, 10);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const saveBankreconStatement = createAsyncThunk(
  "bankrecon/saveBankreconStatement",
  async (
    {
      opening_bal,
      closing_bal,
      bank_statement_id,
      uniqueIdAdded,
      uniqueIdRemoved,
      bank_id,
      statement_date,
      start_stat_no,
      series_no,
      difference,
      ledger_description,
      statement_no,
      callback
    }: TSaveBankStatement & { callback?: (data: any) => void },
    thunkAPI
  ) => {
    try {
      const { data }: { data: { [key: string]: any } } = await client.post(
        `${apiRoot}/bankrecon/bankrecon-statement-chooser-save`,
        {
          opening_bal,
          closing_bal,
          bank_statement_id,
          uniqueIdAdded,
          uniqueIdRemoved,
          bank_id,
          statement_date,
          start_stat_no,
          series_no,
          difference,
          ledger_description,
          statement_no
        }
      );
      if (callback) {
        callback(data);
      }
      return data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

/**
 * This slice of state is responsible for storing BRC details state
 */
const slice = createSlice({
  initialState,
  name: "bankReconcilicationStatement",
  extraReducers: (builder) => {
    /** BRC details state */
    builder
      .addCase(getBankReconciliationStatement.pending, (state) => {
        state.bankReconStatus = STATUS.LOADING;
      })
      .addCase(getBankReconciliationStatement.fulfilled, (state, action: PayloadAction<any>) => {
        state.bankReconStatus = STATUS.SUCCESS;
        state.bankReconciliationStatement = action.payload;
        state.unreconciledDetails =
          state.bankReconciliationStatement?.unreconciledDetails?.bankReconciledTransactions ?? [];
        state.reconciledDetails =
          state.bankReconciliationStatement?.reconciledDetails?.bankReconciledTransactions ?? [];
      })
      .addCase(getBankReconciliationStatement.rejected, (state, action: PayloadAction<any>) => {
        state.bankReconStatus = STATUS.FAILED;
      });
    /** BRC delete state */
    builder
      .addCase(deleteBankreconStatement.pending, (state) => {
        state.deleteStatus = STATUS.LOADING;
      })
      .addCase(deleteBankreconStatement.fulfilled, (state) => {
        state.deleteStatus = STATUS.SUCCESS;
      })
      .addCase(deleteBankreconStatement.rejected, (state) => {
        state.deleteStatus = STATUS.FAILED;
      });

    builder
      .addCase(getBankViewGlFundToBack.pending, (state) => {
        state.glFundStatus = STATUS.LOADING;
      })
      .addCase(getBankViewGlFundToBack.fulfilled, (state, action: PayloadAction<any>) => {
        state.glFundStatus = STATUS.SUCCESS;
        state.bankGlFundToBankData = action.payload;
      })
      .addCase(getBankViewGlFundToBack.rejected, (state, action: PayloadAction<any>) => {
        state.glFundStatus = STATUS.FAILED;
      });
    builder
      .addCase(getBankReconciliationDocument.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getBankReconciliationDocument.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(getBankReconciliationDocument.rejected, (state) => {
        state.isLoading = false;
      });
    builder
      .addCase(getVerifyBalaceDetail.pending, (state) => {
        state.VerifyBalaceStatus = true;
      })
      .addCase(getVerifyBalaceDetail.fulfilled, (state) => {
        state.VerifyBalaceStatus = false;
      })
      .addCase(getVerifyBalaceDetail.rejected, (state) => {
        state.VerifyBalaceStatus = false;
      });
    builder
      .addCase(saveBankreconStatement.pending, (state) => {
        state.saveReconStatus = STATUS.LOADING;
      })
      .addCase(saveBankreconStatement.fulfilled, (state) => {
        state.saveReconStatus = STATUS.SUCCESS;
      })
      .addCase(saveBankreconStatement.rejected, (state) => {
        state.saveReconStatus = STATUS.FAILED;
      });

    builder
      .addCase(getSIPaymentDetailsIndividualSalary.pending, (state) => {
        state.siPaymentDetailsStatus = STATUS.LOADING;
      })
      .addCase(getSIPaymentDetailsIndividualSalary.fulfilled, (state, action: PayloadAction<any>) => {
        state.siPaymentDetails = action.payload;
        state.siPaymentDetailsStatus = STATUS.SUCCESS;
      })
      .addCase(getSIPaymentDetailsIndividualSalary.rejected, (state) => {
        state.siPaymentDetailsStatus = STATUS.FAILED;
      });

    builder
      .addCase(getSIIndidualSalary.pending, (state) => {
        state.siStatus = STATUS.LOADING;
      })
      .addCase(getSIIndidualSalary.fulfilled, (state, action: PayloadAction<any>) => {
        state.siIndividualSalaryList = action.payload.contractdetailview;
        state.siIndividualSalaryContractHeader = action.payload.contractdetailHeader;
        state.siStatus = STATUS.SUCCESS;
      })
      .addCase(getSIIndidualSalary.rejected, (state) => {
        state.siStatus = STATUS.FAILED;
      });
  },
  reducers: {
    initialState: (state) => {
      state.filterState = { ...initialState.filterState };
    },
    setFilters: (state, action: PayloadAction<FilterStateType>) => {
      state.filterState = {
        ...current(state.filterState),
        ...action.payload
      };
    },
    setSelectedContractDetailsRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedContractDetailsRow = action.payload;
    },
    setSccFilters: (state, action: PayloadAction<FilterStateType>) => {
      state.sccFilterState = {
        ...current(state.sccFilterState),
        ...action.payload
      };
    },
    resetFilter: (state) => {
      state.filterState = { ...initialState.filterState };
    },
    resetDeleteStatus: (state) => {
      state.deleteStatus = undefined;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setSccColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.sccColumnDef = [...action.payload];
    },
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedRow = action.payload;
    },
    setSelectedBankReconiledRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedBankReconiledRow = action.payload;
    },
    setSelectedBankUnReconiledRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedBankUnreconciledRow = action.payload;
    },
    setReconiledDetails: (state, action: PayloadAction<{ [key: string]: any }[]>) => {
      state.reconciledDetails = action.payload;
    },
    setUnReconiledDetails: (state, action: PayloadAction<{ [key: string]: any }[]>) => {
      state.unreconciledDetails = action.payload;
    },
    setNewReconiledDetails: (state, action: PayloadAction<{ [key: string]: any }[]>) => {
      state.newReconciledDetails = action.payload;
    },
    setNewUnReconiledDetails: (state, action: PayloadAction<{ [key: string]: any }[]>) => {
      state.newUnReconciledDetails = action.payload;
    },

    choose: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const index = current(state.unreconciledDetails).findIndex(
        (row: { [key: string]: any }) => row.unique_id === action.payload.unique_id
      );
      if (index > -1) {
        state.unreconciledDetails.splice(index, 1);
        if (index < state.unreconciledDetails.length) {
          state.selectedBankUnreconciledRow = state.unreconciledDetails[index];
        } else if (state.unreconciledDetails.length > 0) {
          state.selectedBankUnreconciledRow = state.unreconciledDetails[state.unreconciledDetails.length - 1];
        } else {
          state.selectedBankUnreconciledRow = [];
        }
      }
      state.reconciledDetails.push(action.payload);
    },
    setReconciledRecord: (state, action: PayloadAction<{ [key: string]: any }>) => {},
    chooseAll: (state) => {
      state.reconciledDetails = [...(state.reconciledDetails ?? []), ...(state.unreconciledDetails ?? [])];
      state.unreconciledDetails = [];

      const newUnReconciledIds = new Set(state.newUnReconciledDetails?.map((item) => item.unique_id));
      const newReconciledIds = new Set(state.newReconciledDetails?.map((item) => item.unique_id));

      state.reconciledDetails?.forEach((reconciledItem) => {
        if (newUnReconciledIds.has(reconciledItem.unique_id)) {
          reconciledItem.saved = true;
        } else if (newReconciledIds.has(reconciledItem.unique_id)) {
          reconciledItem.saved = false;
        }
      });
    },
    remove: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const index = current(state.reconciledDetails).findIndex(
        (row: { [key: string]: any }) => row.unique_id === action.payload.unique_id
      );
      if (index > -1) {
        state.reconciledDetails.splice(index, 1);
        if (index < state.reconciledDetails.length) {
          state.selectedBankReconiledRow = state.reconciledDetails[index];
        } else if (state.reconciledDetails.length > 0) {
          state.selectedBankReconiledRow = state.reconciledDetails[state.reconciledDetails.length - 1];
        } else {
          state.selectedBankReconiledRow = [];
        }
      }
      state.unreconciledDetails.push(action.payload);
    },
    removeAll: (state) => {
      state.unreconciledDetails = [...(state.unreconciledDetails ?? []), ...(state.reconciledDetails ?? [])];
      state.reconciledDetails = [];

      const newReconciledIds = new Set(state.newReconciledDetails?.map((item) => item.unique_id));
      const newUnReconciledIds = new Set(state.newUnReconciledDetails?.map((item) => item.unique_id));

      state.unreconciledDetails?.forEach((item) => {
        if (newReconciledIds.has(item.unique_id)) {
          item.saved = true;
        } else if (newUnReconciledIds.has(item.unique_id)) {
          item.saved = false;
        }
      });
    },
    resetReconciledDetails: (state) => {
      state.reconciledDetails = [];
    },
    setUnreconciledSortedData: (state, action: PayloadAction<any>) => {
      if (action.payload) {
        const [firstUnreconciledRow, ...rest] = action.payload;
        state.unreconciledDetails = action.payload;
        state.selectedBankUnreconciledRow = firstUnreconciledRow;
      }
    },
    setReconciledSortedData: (state, action: PayloadAction<any>) => {
      if (action.payload) {
        const [firstReconciledRow, ...rest] = action.payload;
        state.reconciledDetails = action.payload;
        state.selectedBankReconiledRow = firstReconciledRow;
      }
    },
    addSccRow: (state, action: PayloadAction<any>) => {
      state.storeReconciledList = [...action.payload];
      state.storeUnreconciledList = [...state.unreconciledDetails];
      state.reconciledDetails = [...action.payload];
    },
    updateSccRow: (state) => {
      state.reconciledDetails = [...(state.storeReconciledList ?? [])];
      state.unreconciledDetails = [...(state.storeUnreconciledList ?? [])];
    },
    resetSccRow: (state) => {
      state.storeReconciledList = [];
      state.storeUnreconciledList = [];
    },

    resetNewReconciledDetails: (state) => {
      state.newReconciledDetails = [];
      state.newUnReconciledDetails = [];
    },
    setSiIndividualSalaryContractHeader: (state, action: PayloadAction<any>) => {
      state.siIndividualSalaryContractHeader = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
