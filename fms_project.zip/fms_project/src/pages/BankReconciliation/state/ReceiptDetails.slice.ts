import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { OrderType, STATUS } from "@/types/UseStateType";

type TReceiptDetailsState = {
  error: string | undefined;
  status?: STATUS;
  selectedRow?: { [key: string]: any };
  receiptDetails: {
    bankReconciliationNiHeader: { [key: string]: any };
    bankReconciliationNiListing: { [key: string]: any }[];
  };
};

const initialState: TReceiptDetailsState = {
  error: "",
  receiptDetails: {
    bankReconciliationNiHeader: {},
    bankReconciliationNiListing: []
  }
};

/** Thunks */

export const getBankReconciliationViewNI = createAsyncThunk(
  "bankReconciliationViewNI",
  async ({ receiptId, callback }: any) => {
    const response = await client.get(`${apiRoot}/bankrecon/bankrecon-view-ni?receiptId=${receiptId}`);
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * This slice of state is responsible for storing BRC details state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** BRC details state */
    builder
      .addCase(getBankReconciliationViewNI.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getBankReconciliationViewNI.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.receiptDetails = action.payload;
      })
      .addCase(getBankReconciliationViewNI.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
      });
  },
  initialState,
  name: "receiptDetails",
  reducers: {
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedRow = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
