import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { STATUS } from "@/types/UseStateType";
import { RowType, TColumnDef } from "@/components/GridTableNew/GridTableNew";
import columnDef from "../BankReconciliationStatementContentChooser/Grid/columnDef";

export type bankReconcilicationStatement = { [key: string]: any }[];

export type FilterStateType = {
  sequence?: number;
  sequenceValue?: string;
};

export type BankRecType = {
  length?: number;
  bankLedger: string;
  bankReconciledTransactions: { [key: string]: any }[];
  uniqueIdentifier: string | null;
};

type intialStateType = {
  formData?: { [key: string]: any };
  bankReconciledStatement?: BankRecType;
  bankUnreconciledStatement?: BankRecType;
  status?: STATUS;
  bankGlFundToBankData: { [key: string]: any }[];
  filterState?: FilterStateType;
  columnDef: TColumnDef;
  isLoading: boolean;
};

const initialState: intialStateType = {
  filterState: {
    sequence: 0,
    sequenceValue: columnDef.filter((col) => !!col.sequence)[0].field
  },
  columnDef,
  bankGlFundToBankData: [],
  isLoading: false,
  bankUnreconciledStatement: {
    bankLedger: "",
    bankReconciledTransactions: [],
    uniqueIdentifier: null
  },
  bankReconciledStatement: {
    bankLedger: "",
    bankReconciledTransactions: [],
    uniqueIdentifier: null
  }
};
/* eslint-disable camelcase */
type bankReconcilicationStatementDetails = {
  bankId: string | null;
  bank_statement_id?: string | null;
  uniqueIdentifier: string | null;
  sequence?: number;
  callback?: (data: any) => void;
};

/** Thunks */

export const getBankUnconciledStatement = createAsyncThunk(
  "bankReconcilicationStatement/get",
  async ({ bankId, uniqueIdentifier, sequence, callback }: bankReconcilicationStatementDetails) => {
    const response = await client.get(
      `${apiRoot}/bankrecon/bankrecon-details?bankId=${bankId}&sequence=${sequence}&uniqueIdentifier=${uniqueIdentifier}`
    );
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getBankReconciliationStatement = createAsyncThunk(
  "bankunconciledStatement/get",
  async ({ bankId, bank_statement_id, uniqueIdentifier, sequence, callback }: bankReconcilicationStatementDetails) => {
    const response = await client.get(
      `${apiRoot}/bankrecon/bankrecon-details?bankId=${bankId}&bankStatementId=${bank_statement_id}&sequence=${sequence}&uniqueIdentifier=${uniqueIdentifier}`
    );
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * This slice of state is responsible for storing BRC details state
 */
const slice = createSlice({
  initialState,
  name: "bankReconcilicationStatement",
  extraReducers: (builder) => {
    /** BRC details state */
    builder
      .addCase(getBankReconciliationStatement.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getBankReconciliationStatement.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.bankReconciledStatement = action.payload;
      })
      .addCase(getBankReconciliationStatement.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getBankUnconciledStatement.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getBankUnconciledStatement.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.bankUnreconciledStatement = action.payload;
      })
      .addCase(getBankUnconciledStatement.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
      });
  },
  reducers: {
    initialState: (state) => {
      state.filterState = { ...initialState.filterState };
    },
    setFilters: (state, action: PayloadAction<FilterStateType>) => {
      state.filterState = {
        ...current(state.filterState),
        ...action.payload
      };
    },
    resetFilter: (state) => {
      state.filterState = { ...initialState.filterState };
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setSortedData: (state, action: PayloadAction<any>) => {
      if (action.payload) {
        state.bankReconciledStatement!.bankReconciledTransactions = action.payload;
      }
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
