import Layout from "@/components/Layout/Layout";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconSize,
  RadioButton,
  RadioLabelPosition,
  TextInput
} from "@essnextgen/ui-kit";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import "./Style.scss";
import { LookingFor } from "@/shared/components/LookingFor/LookingFor";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";

const StatementContentsChooser = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  return (
    <>
      <Layout
        className="statement-contents-chooser"
        pageTitle="Statement Contents Chooser"
        type="transparent"
      >
        <Grid>
          <GridItem
            xl={8}
            lg={8}
            md={8}
            sm={4}
            className="d-flex align-center"
          >
            <div className="essui-global-typography-default-subtitle">Unreconciled</div>
          </GridItem>
          <GridItem
            xl={4}
            lg={4}
            md={4}
            sm={4}
          >
            <div className="d-flex gap-8">
              <div className="input__widthSet">
                <TextInput
                  id="name-1"
                  name="Net-1"
                  readOnly
                  value="-929,876.87"
                  className="read-only br-0 border__none text-align-right"
                  aria-describedby="name-1__validation-text"
                />
              </div>
              <div className="input__widthSet">
                <TextInput
                  id="name-2"
                  name="Net-2"
                  readOnly
                  value="-929,876.87"
                  className="read-only br-0 border__none text-align-right"
                  aria-labelledby="label-name2"
                />
              </div>
              <div className="input__widthSet">
                <TextInput
                  id="name-3"
                  name="firstname"
                  readOnly
                  value="-929,876.87"
                  className="read-only br-0 border__none text-align-right"
                  aria-labelledby="label-name3"
                />
              </div>
            </div>
          </GridItem>
        </Grid>
      </Layout>

      <Layout isBreadcrumbRequired={false}>
        <Grid className="row-gap-16">
          <GridItem
            xl={3}
            lg={3}
            md={3}
            sm={4}
          >
            <div className="statement__content--chooser-filters">
              <LookingFor
                initialValue=""
                callback={() => {}}
                changeHandler={() => {}}
                hasDatePicker
                disableDatePicker={false}
                isInputReadOnly
                restrictInput={() => {}}
                className=""
              />
              <Button
                className="essui-button--tertiary essui-button-icon-only--small arrow--filter"
                size={ButtonSize.Small}
                aria-label="arrowUp"
              >
                <Icon
                  size={IconSize.Medium}
                  name="arrow--up"
                />
              </Button>
            </div>
          </GridItem>
          <GridItem
            xl={4}
            lg={4}
            md={4}
            sm={4}
            className="sequence__field"
          >
            <div className="essui-global-typography-default-h2 sequence-container ">
              <FormLabel>{t("common.sequenceOrder")}</FormLabel>
              <div className="statement__sequence">
                <div className="essui-textinput sequence-order">
                  <RadioButton
                    label={t("bankReconciliation.date")}
                    labelPosition={RadioLabelPosition.Right}
                    value={0}
                    onChange={() => {}}
                    isSelected
                  />
                  <RadioButton
                    label={t("bankReconciliation.reference")}
                    labelPosition={RadioLabelPosition.Right}
                    value={1}
                    onChange={() => {}}
                    isSelected={false}
                  />
                  <RadioButton
                    label={t("bankReconciliation.payments")}
                    labelPosition={RadioLabelPosition.Right}
                    value={2}
                    onChange={() => {}}
                    isSelected={false}
                  />
                  <RadioButton
                    label={t("bankReconciliation.receipts")}
                    labelPosition={RadioLabelPosition.Right}
                    value={3}
                    onChange={() => {}}
                    isSelected={false}
                  />
                </div>
              </div>
            </div>
          </GridItem>
          <GridItem
            xxl={5}
            xl={5}
            lg={5}
            md={5}
            sm={4}
            className="choose__btn_field"
          >
            <div className="d-flex row-gap-8 content__chooser--btn btn__wrap--responsive">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                iconName="arrow--down"
                iconPosition={ButtonIconPosition.Left}
                aria-label="Choose"
              >
                Choose
              </Button>
              &nbsp; &nbsp;
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                iconName="arrow--down"
                iconPosition={ButtonIconPosition.Left}
                aria-label="Choose all items"
              >
                Choose All
              </Button>
              &nbsp; &nbsp;
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                iconName="arrow--up"
                iconPosition={ButtonIconPosition.Left}
                aria-label="remove"
              >
                Remove
              </Button>
              &nbsp; &nbsp;
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                iconName="arrow--up"
                iconPosition={ButtonIconPosition.Left}
                aria-label="Remove all items"
              >
                Remove All
              </Button>
            </div>
          </GridItem>
        </Grid>
      </Layout>

      <Layout isBreadcrumbRequired={false}>
        <Grid>
          <GridItem
            xl={8}
            lg={8}
            md={8}
            sm={4}
            className="d-flex align-center"
          >
            <div className="essui-global-typography-default-subtitle">Reconciled</div>
          </GridItem>
          <GridItem
            xl={4}
            lg={4}
            md={4}
            sm={4}
          >
            <div className="d-flex gap-8">
              <div className="input__widthSet">
                <TextInput
                  id="name-1"
                  name="Net-1"
                  readOnly
                  value="121.96"
                  className="read-only br-0 border__none text-align-right"
                  aria-describedby="name-1__validation-text"
                />
              </div>
              <div className="input__widthSet">
                <TextInput
                  id="name-2"
                  name="Net-2"
                  readOnly
                  value="588.56"
                  className="read-only br-0 border__none text-align-right"
                  aria-labelledby="label-name2"
                />
              </div>
              <div className="input__widthSet">
                <TextInput
                  id="name-3"
                  name="firstname"
                  readOnly
                  value="710.52"
                  className="read-only br-0 border__none text-align-right"
                  aria-labelledby="label-name3"
                />
              </div>
            </div>
          </GridItem>
        </Grid>
      </Layout>

      <Layout isBreadcrumbRequired={false}>
        <div className="">
          <Grid>
            <GridItem
              lg={5}
              xl={5}
              sm={4}
            >
              <Grid>
                <GridItem
                  lg={6}
                  xl={6}
                  sm={3}
                >
                  <div className="">
                    <div className="essui-form-label">Opening Balance</div>
                    <div className="mt-8">620,432.87</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={6}
                  xl={6}
                  sm={3}
                >
                  <div className="">
                    <div className="essui-form-label">Closing Balance</div>
                    <div className="mt-8">612,544.00</div>
                  </div>
                </GridItem>
              </Grid>
            </GridItem>
          </Grid>

          <Grid
            className="mt-16"
            justify="space-between"
          >
            <GridItem
              sm={8}
              lg={6}
              md={4}
            >
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </GridItem>
            <GridItem
              sm={8}
              lg={6}
              md={4}
            >
              <div className="d-flex justify-end">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                >
                  Add Journal
                </Button>
                &nbsp; &nbsp;
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Primary}
                >
                  Save
                </Button>
                &nbsp; &nbsp;
                <Button size={ButtonSize.Small}>Save</Button>
              </div>
            </GridItem>
          </Grid>
        </div>
      </Layout>
    </>
  );
};

export default StatementContentsChooser;
