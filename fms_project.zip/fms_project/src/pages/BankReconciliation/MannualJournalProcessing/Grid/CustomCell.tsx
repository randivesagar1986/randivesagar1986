import { cellRendererType } from "@/components/GridTable/GridTable";

const CustomCell = ({ field, row }: cellRendererType) => {
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const getContent = () => {
    switch (field) {
      case "debit":
        return <div>{numberFormatter.format(row?.debit)}</div>;
      case "credit":
        return <div>{numberFormatter.format(row?.credit)}</div>;
      default: {
        return <div />;
      }
    }
  };
  return getContent();
};

export default CustomCell;
