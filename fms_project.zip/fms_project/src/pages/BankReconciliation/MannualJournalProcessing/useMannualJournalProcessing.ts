import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import {
  getBankReconViewGL,
  actions as brMJPAction
} from "@/pages/BankReconciliation/state/MannualJournalProcessing.slice";
import { getInvoicePostingPeriod } from "@/pages/Invoice/State/InvoicePostingPeriod.slice";
import { getInvoiceSupplierAll } from "@/pages/Invoice/State/InvoiceSupplierList.slice";

const useMannualJournalProcessing = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { status: bankReconMJPStatus, bankReconGLData } = useAppSelector((state) => state?.manualJournalProcessing);
  const { supplier } = useAppSelector((state) => state.selectedSupplier);
  const { selectedRow } = useAppSelector((state) => state.bankReconciliationStatement);
  const { postingPeriodDetails } = useAppSelector((state) => state.invoicePostingPeriod);
  const [periodMonth, setPeriodMonth] = useState<string>("");
  const [footerNarrative, setFooterNarrative] = useState<string>("");
  const [totalDebits, setTotalDebits] = useState<string>("0.00");
  const [totalCredits, setTotalCredits] = useState<string>("0.00");
  const [openSupplierBrowseModal, setOpenSupplierBrowseModal] = useState<boolean>(false);

  useEffect(() => {
    if (selectedRow?.unique_id) {
      const numberFormatter = new Intl.NumberFormat("en-US", {
        style: "decimal",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
      const uniqId = selectedRow.unique_id.slice(2);
      const trimmedStr = uniqId.replace(/^0+/, "");
      dispatch(
        getBankReconViewGL({
          voucherID: trimmedStr,
          callback: (res) => {
            const { journalDetails } = res;
            const debitSum = journalDetails.reduce(
              (total: any, journalDetail: { debit: any }) => total + journalDetail.debit,
              0
            );
            setTotalDebits(numberFormatter.format(debitSum));
            const creditSum = journalDetails.reduce(
              (total: any, journalDetail: { credit: any }) => total + journalDetail.credit,
              0
            );
            setTotalCredits(numberFormatter.format(creditSum));
          }
        })
      );
    }
  }, [selectedRow]);

  useEffect(() => {
    if (bankReconGLData?.headerDetails) {
      dispatch(getInvoicePostingPeriod(bankReconGLData.headerDetails?.period));
    }
  }, [bankReconGLData]);

  useEffect(() => {
    let timeoutId: any;
    if (bankReconGLData?.journalDetails) {
      timeoutId = setTimeout(() => {
        const element = document.getElementById(`rowIndex-manualJournalLinesGridData-0`);
        element?.focus();
      }, 10);
    }
    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    };
  }, [bankReconGLData?.journalDetails]);

  useEffect(() => {
    onPaymentPeriodSelection();
  }, [postingPeriodDetails]);

  const onPaymentPeriodSelection = () => {
    if (postingPeriodDetails.length > 0) {
      const found = postingPeriodDetails.find((s) => s.code === String(bankReconGLData.headerDetails?.period));
      if (found) setPeriodMonth(found.description);
    }
  };

  const prependZero = (num: number) => {
    if (num >= 1 && num <= 9) {
      return `0${num}`;
    }
    return num.toString();
  };

  const getSupplierDetailByClientId = (clientId: any) => {
    dispatch(getInvoiceSupplierAll({ clientId }));
    setOpenSupplierBrowseModal(true);
  };

  return {
    bankReconGLData,
    bankReconMJPStatus,
    selectedRow,
    periodMonth,
    setFooterNarrative,
    footerNarrative,
    totalDebits,
    totalCredits,
    prependZero,
    setOpenSupplierBrowseModal,
    openSupplierBrowseModal,
    getSupplierDetailByClientId,
    supplier
  };
};

export default useMannualJournalProcessing;
