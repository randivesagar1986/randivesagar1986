import React, { ReactNode } from "react";
import { render, act } from "@testing-library/react";
import configureStore from "redux-mock-store";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import { getBankReconViewGL } from "@/pages/BankReconciliation/state/MannualJournalProcessing.slice";
import { getInvoiceSupplierAll } from "@/pages/Invoice/State/InvoiceSupplierList.slice";
import { getInvoicePostingPeriod } from "@/pages/Invoice/State/InvoicePostingPeriod.slice";
import { AnyAction } from "redux";
import useMannualJournalProcessing from "../useMannualJournalProcessing";

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

const TestComponent = () => {
  useMannualJournalProcessing();
  return null;
};

describe("useMannualJournalProcessing", () => {
  let store: any;

  beforeEach(() => {
    store = mockStore({
      manualJournalProcessing: {
        status: "idle",
        bankReconGLData: null
      },
      selectedSupplier: {
        supplier: null
      },
      bankReconciliationStatement: {
        selectedRow: null
      },
      invoicePostingPeriod: {
        postingPeriodDetails: []
      }
    });
  });

  test("should initialize with default values", () => {
    render(
      <Provider store={store}>
        <TestComponent />
      </Provider>
    );

    const state = store.getState();
    expect(state.manualJournalProcessing.bankReconGLData).toBeNull();
    expect(state.manualJournalProcessing.status).toBe("idle");
    expect(state.bankReconciliationStatement.selectedRow).toBeNull();
    expect(state.invoicePostingPeriod.postingPeriodDetails).toEqual([]);
  });

  describe("Bank Recon Actions", () => {
    it("should dispatch getBankReconViewGL action when selectedRow is set", () => {
      const store = mockStore({});
      const voucherID = 123;
      const callback = jest.fn();

      // Dispatch the action, casting it to AnyAction
      store.dispatch(getBankReconViewGL({ voucherID, callback }) as unknown as AnyAction);

      // Get the actions dispatched to the store
      const actions = store.getActions();

      // Check if the correct action was dispatched
      expect(actions).toContainEqual(
        expect.objectContaining({
          type: "bankrecon/bankrecon-view-gl/pending",
          meta: expect.objectContaining({
            arg: expect.objectContaining({
              voucherID: 123
            })
          })
        })
      );

      // Optionally, you can also check if the callback was called
      expect(callback).not.toHaveBeenCalled(); // Adjust this based on when you expect the callback to be called
    });
  });

  test("should dispatch getInvoiceSupplierAll action when getSupplierDetailByClientId is called", () => {
    const clientId = "12345";
    render(
      <Provider store={store}>
        <TestComponent />
      </Provider>
    );

    act(() => {
      store.dispatch(getInvoiceSupplierAll({ clientId }));
    });

    const actions = store.getActions();
    expect(actions).toContainEqual(
      expect.objectContaining({
        type: "supplierAll/listAll/pending",
        meta: expect.objectContaining({
          arg: { clientId: "12345" }
        })
      })
    );
  });

  test("should set periodMonth when postingPeriodDetails is updated", () => {
    const bankReconGLData = { headerDetails: { period: "2023-01" } };
    const postingPeriodDetails = [{ code: "2023-01", description: "January 2023" }];
    store = mockStore({
      ...store.getState(),
      manualJournalProcessing: { bankReconGLData },
      invoicePostingPeriod: { postingPeriodDetails }
    });

    render(
      <Provider store={store}>
        <TestComponent />
      </Provider>
    );

    act(() => {
      store.dispatch({
        type: "UPDATE_POSTING_PERIOD_DETAILS",
        payload: postingPeriodDetails
      });
    });

    const state = store.getState();
    expect(state.manualJournalProcessing.bankReconGLData.headerDetails.period).toBe("2023-01");
    expect(state.invoicePostingPeriod.postingPeriodDetails).toEqual(postingPeriodDetails);
  });

  test("should dispatch getInvoicePostingPeriod action when bankReconGLData is set", () => {
    const bankReconGLData = { headerDetails: { period: "2023-01" } };
    store = mockStore({
      manualJournalProcessing: { bankReconGLData },
      selectedSupplier: { supplier: null },
      bankReconciliationStatement: { selectedRow: null },
      invoicePostingPeriod: { postingPeriodDetails: [] }
    });

    render(
      <Provider store={store}>
        <TestComponent />
      </Provider>
    );

    act(() => {
      store.dispatch({
        type: "SET_BANK_RECON_GL_DATA",
        payload: bankReconGLData
      });
    });

    const actions = store.getActions();

    expect(actions).toContainEqual(
      expect.objectContaining({
        type: "invoiceNote/paymentFromDetails/pending",
        meta: expect.objectContaining({
          arg: "2023-01"
        })
      })
    );
  });
});
