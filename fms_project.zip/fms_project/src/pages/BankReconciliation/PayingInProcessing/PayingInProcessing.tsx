import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import Modal from "@/components/Modal/Modal";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  FormLabel,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";

type TPayingInProgress = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
};
const PayingInProcessing = ({ setOpen, isOpen }: TPayingInProgress) => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();

  return (
    <>
      <Modal
        header={t("Paying in Progress")}
        isOpen={isOpen}
        primaryBtnText={t("common.close")}
        primaryBtnClick={() => {
          setOpen(false);
        }}
        className="vat-line-detail-modal"
      >
        <div className="overflow-hidden">
          <Grid className="marginb15 row-gap-16">
            <GridItem
              sm={3}
              md={4}
              lg={4}
              xl={4}
            >
              <div>
                <div className="essui-form-label pb-8">Reference</div>
                <div>230303</div>
              </div>
            </GridItem>
            <GridItem
              sm={3}
              md={4}
              lg={4}
              xl={4}
            >
              <div>
                <div className="essui-form-label pb-8">Destination</div>
                <div>Bank Account</div>
              </div>
            </GridItem>
            <GridItem
              sm={3}
              md={4}
              lg={4}
              xl={4}
            >
              <div>
                <div className="essui-form-label pb-8"> Posting Period</div>
                <div>1 Apr</div>
              </div>
            </GridItem>
            <GridItem
              sm={3}
              md={4}
              lg={4}
              xl={4}
            >
              <div>
                <div className="essui-form-label pb-8">Date</div>
                <div>23 Apr 2024</div>
              </div>
            </GridItem>
            <GridItem
              sm={3}
              md={4}
              lg={4}
              xl={4}
            >
              <div>
                <div className="essui-form-label pb-8">Status</div>
                <div>Posted</div>
              </div>
            </GridItem>
          </Grid>

          <Grid className="mt-12 justify__content--between row-gap-16 pr-32">
            <GridItem>
              <div>
                <FormLabel className="mb-5">Items</FormLabel>
                <div>1</div>
              </div>
            </GridItem>
            <GridItem>
              <div>
                <FormLabel className="mb-5">Cash</FormLabel>
                <div>122,036.00</div>
              </div>
            </GridItem>
            <GridItem className="d-flex align-end">
              <div>
                <b>+</b>
              </div>
            </GridItem>
            <GridItem>
              <div>
                <FormLabel className="mb-5">Cheque</FormLabel>
                <div>0</div>
              </div>
            </GridItem>
            <GridItem className="d-flex align-end">
              <div>
                <b>=</b>
              </div>
            </GridItem>
            <GridItem>
              <div>
                <FormLabel className="mb-5">&nbsp;</FormLabel>
                <div>122,036.00</div>
              </div>
            </GridItem>
          </Grid>
        </div>
      </Modal>
    </>
  );
};
export default PayingInProcessing;
