import { Button, ButtonColor, ButtonSize, Divider, FormLabel, Grid, GridItem } from "@essnextgen/ui-kit";

import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";

const BACSItemsForPayment = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <>
      <Layout
        pageTitle="Items for Payment"
        className=""
      >
        <Grid className="mb-8">
          <GridItem sm={4}>
            <div className="essui-global-typography-default-subtitle">Bank Balance</div>
          </GridItem>
        </Grid>
        <Grid className="row-gap-16">
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label mb-5">Current</div>
              <div>607,690.73</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label mb-5">Tagged Items</div>
              <div>0.00</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label mb-5">New</div>
              <div>0.00</div>
            </div>
          </GridItem>
        </Grid>
      </Layout>

      <Layout
        isBreadcrumbRequired={false}
        className=""
      >
        <Grid className="row-gap-16">
          <GridItem
            sm={4}
            md={4}
            lg={4}
            xl={4}
            xxl={4}
          >
            <div>
              <div className="essui-form-label mb-5">Period</div>
              <div>1</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
            xxl={6}
          >
            <div>
              <div className="essui-form-label mb-5">Order</div>
              <div>BANK012034</div>
            </div>
          </GridItem>
          <GridItem
            sm={2}
            md={4}
            lg={2}
            xl={2}
            xxl={2}
          >
            <div>
              <div className="essui-form-label mb-5">Selection</div>
              <div className="d-flex gap-8">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Utility}
                  disabled
                >
                  {t("tagUntag.unTagAll")}
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                >
                  {t("tagUntag.tag")}
                </Button>
              </div>
            </div>
          </GridItem>
        </Grid>

        <div className="mb-16 mt-16">
          <Divider />
        </div>

        <Grid
          justify="space-between"
          className="mt-8"
        >
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <HelpButton
              identifier="testIdentifier"
              labelName="Help"
            />
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="d-flex justify-end flex-wrap justify-start-resposnive gap-8">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
              >
                Cancel
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
              >
                {t("common.back")}
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
                disabled
              >
                {t("common.next")}
              </Button>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};

export default BACSItemsForPayment;
