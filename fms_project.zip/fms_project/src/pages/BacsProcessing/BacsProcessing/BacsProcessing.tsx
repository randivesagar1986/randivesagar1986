import Layout from "@/components/Layout/Layout";
import { Grid, GridItem, Tag, TagColor, TagSize } from "@essnextgen/ui-kit";

const BacsProcessing = () => {
  const getTagElement = () => (
    <div className="heading__tag">
      <Tag
        text="000622"
        size={TagSize.Large}
        color={TagColor.Highlight}
      />
    </div>
  );
  return (
    <>
      <Layout
        pageTitle="BACS Processing"
        isSubTitle={getTagElement()}
        className="page__title_tag"
        isBreadcrumbRequired
      >
        <Grid className="row-gap-16">
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div className="">
              <div className="essui-form-label">Bank</div>
              <div className="mt-8">Bank Account</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div className="">
              <div className="essui-form-label">Account Number</div>
              <div className="mt-8">01177112</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div className="">
              <div className="essui-form-label">Number of Invoices & Credit Notes</div>
              <div className="mt-8">1</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div className="">
              <div className="essui-form-label">User</div>
              <div className="mt-8">SYS</div>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};

export default BacsProcessing;
