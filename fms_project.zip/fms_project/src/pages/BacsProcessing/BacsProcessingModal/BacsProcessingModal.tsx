import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  Dialog,
  DialogContent,
  DialogFooter,
  FormLabel,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import Input from "@/components/Input/Input";

const BacsProcessingModal = () => (
  <Dialog
    dataTestId="test-id"
    escapeExits
    id="element-id"
    returnFocusOnDeactivate
    title="BACS Processing"
    className="dialog__divider modal__align--set"
  >
    <DialogContent>
      <div className="overflow-hidden">
        <Grid
          container
          className="row-gap-16"
        >
          <GridItem
            sm={4}
            md={8}
            lg={12}
            xl={12}
          >
            <div className="essui-form-label mb-5">Original BACS Processing Date</div>
            <div>09 Apr 2024</div>
          </GridItem>
          <GridItem
            sm={4}
            md={8}
            lg={12}
            xl={12}
          >
            <FormLabel forId="txtProcessingDate">New BACS Processing Date</FormLabel>
            <Input
              searchable
              value="10/04/2024"
              id="txtProcessingDate"
            />
          </GridItem>
        </Grid>
      </div>
    </DialogContent>
    <DialogFooter>
      <Grid container>
        <GridItem
          sm={4}
          md={8}
          lg={12}
          xl={12}
        >
          <div className="d-flex justify-end">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
              className="ml-4 mr-4"
            >
              Cancel
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
              className="ml-4"
            >
              OK
            </Button>
          </div>
        </GridItem>
      </Grid>
    </DialogFooter>
  </Dialog>
);

export default BacsProcessingModal;
