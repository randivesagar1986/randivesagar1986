import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  FormLabel,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import Input from "@/components/Input/Input";

const BacsAuditPrintOutModal = () => (
  <Dialog
    dataTestId="test-id"
    escapeExits
    id="element-id"
    returnFocusOnDeactivate
    title="BACS Processing"
    className="dialog__divider modal__align--set"
  >
    <DialogContent>
      <div className="overflow-hidden">
        <Grid
          container
          className="row-gap-16"
        >
          <GridItem
            sm={4}
            md={8}
            lg={12}
            xl={12}
          >
            <FormLabel forId="txtProcessingDate">
              If you require an audit printout of transactions please enter a figure between 1 and 1. If you do not
              require an audit report leave as zero
            </FormLabel>
            <Input
              searchable
              value="0"
              id="txtProcessingDate"
            />
          </GridItem>
        </Grid>
      </div>
    </DialogContent>

    <DialogFooter>
      <Grid container>
        <GridItem
          sm={2}
          md={4}
          lg={6}
          xl={6}
        >
          <div>
            <HelpButton
              identifier="testIdentifier"
              labelName=""
            />
          </div>
        </GridItem>
        <GridItem
          sm={2}
          md={4}
          lg={6}
          xl={6}
        >
          <div className="d-flex justify-end">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
              className="ml-4"
            >
              OK
            </Button>
          </div>
        </GridItem>
      </Grid>
    </DialogFooter>
  </Dialog>
);

export default BacsAuditPrintOutModal;
