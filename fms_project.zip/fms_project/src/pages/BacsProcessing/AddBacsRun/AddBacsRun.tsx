import Input from "@/components/Input/Input";
import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  DateInput,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  TextInput
} from "@essnextgen/ui-kit";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { Calendar } from "@carbon/icons-react";

const AddBacsRun = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  return (
    <>
      <Layout
        className="add-bacs-run"
        pageTitle="Add BACS Run"
      >
        <Grid className="mb-8">
          <GridItem sm={4}>
            <div className="essui-global-typography-default-subtitle">Bank Details</div>
          </GridItem>
        </Grid>
        <Grid className="row-gap-16">
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">BACS User Number</div>
              <div className="height__equal--input">838080</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <FormLabel forId="txtBank">Bank</FormLabel>
              <Input
                id="txtBank"
                button={
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    className="essui-button-icon-only--small"
                    aria-label="search"
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                }
                searchable
                value="Bank Account"
              />
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">Account Number</div>
              <div className="height__equal--input">01177332</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">Sort Code</div>
              <div className="height__equal--input">20-35-21</div>
            </div>
          </GridItem>
        </Grid>
        <Divider />
        <Grid className="mt-16">
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <FormLabel forId="txtPaymentPeriod">Payment Period</FormLabel>
              <Grid className="">
                <GridItem>
                  <Input
                    id="txtPaymentPeriod"
                    searchable={false}
                    labelText=""
                    inputWidth={45}
                    value="01"
                    button={
                      <>
                        <Input
                          readOnly
                          searchable={false}
                          inputWidth={55}
                          value="Apr"
                          className="read-only"
                        />
                        <Button
                          color={ButtonColor.Secondary}
                          onClick={() => {}}
                          className="essui-button-icon-only--small"
                          size={ButtonSize.Small}
                          aria-label="search"
                        >
                          <Icon
                            color={IconColor.Primary500}
                            size={IconSize.Medium}
                            name="search"
                          />
                        </Button>
                      </>
                    }
                  />
                </GridItem>
              </Grid>
            </div>
          </GridItem>
        </Grid>
        <Divider />
        <Grid className="mt-16">
          <GridItem
            sm={4}
            className="mb-8"
          >
            <div className="essui-global-typography-default-subtitle">BACS</div>
          </GridItem>
        </Grid>
        <Grid className="row-gap-16">
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div>
              <FormLabel forId="Processing-Date">Processing Date</FormLabel>
              <Input
                id="Processing-Date"
                value="28/03/2024"
                button={
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    className="essui-button-icon-only--small"
                    aria-label="calender"
                  >
                    <Calendar size={24} />
                  </Button>
                }
                searchable
              />
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={4}
            xl={4}
          >
            <div className="height__equal--input mt-16">
              <CheckBox label="Treat the BACS run as a test run" />
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={8}
            lg={12}
            xl={12}
          >
            <div>
              <FormLabel forId="txtRunNarrative">Run Narrative</FormLabel>
              <TextInput
                id="txtRunNarrative"
                className="width100"
                value=" "
              />
            </div>
          </GridItem>
        </Grid>
        <Grid
          justify="space-between"
          className="mt-16"
        >
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <HelpButton
              identifier="testIdentifier"
              labelName="Help"
            />
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="d-flex justify-end flex-wrap justify-start-resposnive gap-8">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
              >
                Cancel
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                disabled
              >
                {t("common.back")}
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
              >
                {t("common.next")}
              </Button>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};
export default AddBacsRun;
