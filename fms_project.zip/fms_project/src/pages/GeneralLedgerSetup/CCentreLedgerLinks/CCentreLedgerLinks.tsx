import { useEffect, useState, useRef } from "react";
import "./Style.scss";
import { Button, ButtonColor, ButtonSize, Grid, GridItem, Notification, NotificationStatus } from "@essnextgen/ui-kit";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS } from "@/types/UseStateType";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useHistory } from "react-router-dom";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import BodyUtil from "@/shared/utils/NoScroll";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import { getSessionItem, setToSession } from "@/utils/getDataSource";
import { FMSSessionStorage } from "@/utils/Storage";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import { useClickAway } from "@/hooks/useClickAway";
import {
  getLedgerCostCenterLinkList,
  centreLinksAction,
  postGlLedgerBudgetLink,
  saveCostCenterLedgerLink
} from "../State/glCentreLedgerLinks.slice";
import CostCentreLinksFilter from "./Grid/CostCentreLinksFilter";
import GenralLedgerFooter from "../GeneralLedgerFooter";
import GeneralLedgerSetup from "../GeneralLedgerSetup";
import CustomCell from "./Grid/CustomCell";
import useLedgerGrpPopup from "../hooks/useLedgerGrpPopup";

export interface LedgerBudgetLink {
  failedCnt: number;
  spid: number;
  centreLinkLedgerCostCentrePrintData: any;
}

const CCentreLedgerLinks = () => {
  const history = useHistory();
  const [ledgerBudgetLink, setLedgerBudgetLink] = useState<LedgerBudgetLink | null>(null);
  const {} = useAppSelector((state) => state.glCentreLedgerLinks);
  const [statusFilter, setStatusFilter] = useState<string>("In use");
  const [selectedRows, setSelectedRows] = useState<any[]>([]);
  const [hiddenRows, setHiddenRows] = useState<any[]>([]);
  const [isHiding, setIsHiding] = useState<boolean>(true);
  const [showDialog, setShowDialog] = useState(false);
  const [dialogMessage, setDialogMessage] = useState("");
  const dispatch = useDispatch<AppDispatch>();
  const { setTabData } = useLedgerGrpPopup();
  const yesButtonRef = useRef<HTMLButtonElement>(null);

  const {
    status,
    filters,
    columnDef,
    selectedRowGlCodes,
    costCenterLinkList,
    deletedIds,
    savedIds,
    linkHide,
    linkUnhide,
    linkHideRows,
    linkUnhideRows,
    selectedRows: checkedRows
  } = useAppSelector((state) => state.glCentreLedgerLinks);
  const { selectGlListSelectedRow, setFilters, resetFilters, setSavedIds, resetDeletedIds, resetCentreLedgerLinks } =
    centreLinksAction;
  const isWarnBud = getSessionItem("glWarnBud");

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const userAccessRights = useAppSelector((state) => state.userAccessRights); // get user access rights
  const canAddEdit = canDo(userAccessRights, {
    action: ACCESS_RIGHTS_ACTION.Define,
    module: ACCESS_RIGHTS_MODULE.GLCCLCLinks
  });
  const isBtnDisable = canAddEdit !== undefined ? !canAddEdit : false;

  useEffect(() => {
    if (!FMSSessionStorage.getItem("trackOfGLPreviewPage") && !FMSSessionStorage.getItem("trackOfCreateLinksPage")) {
      dispatch(resetFilters());
    } else {
      const itemRemove = FMSSessionStorage.getItem("trackOfGLPreviewPage")
        ? "trackOfGLPreviewPage"
        : "trackOfCreateLinksPage";
      FMSSessionStorage.removeItem(itemRemove);
    }
  }, []);

  useEffect(() => {
    setTimeout(() => {
      if (showDialog && yesButtonRef?.current) {
        yesButtonRef.current?.focus();
      }
    }, 100);
  }, [showDialog, yesButtonRef?.current]);

  const fetchLedgerCostCenterLinkList = function () {
    dispatch(
      getLedgerCostCenterLinkList({
        sequence: filters?.sequenceIndex,
        status: filters?.linkStatusIndex,
        callback: (response: any) => {
          if (response.length > 0) {
            dispatch(selectGlListSelectedRow(response?.data?.data[0]));
          }
        }
      })
    );
  };

  useEffect(() => {
    fetchLedgerCostCenterLinkList();
  }, [filters?.linkStatusIndex, filters?.sequenceIndex]);

  useEffect(() => {
    dispatch(centreLinksAction.selectCheckedRows([]));
  }, [filters?.linkStatusIndex]);

  // Display a temporary loader to prevent UI flicker during row selection
  useEffect(() => {
    const initializeData = async () => {
      dispatch(setFilters({ lookingFor: "" }));

      await new Promise((resolve) => setTimeout(resolve, 0));
      await new Promise((resolve) => setTimeout(resolve, 400));

      const element = document.getElementById(
        `rowIndex-generalLedgerGrpList-${costCenterLinkList.indexOf(selectedRowGlCodes!)}`
      );
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    };
    initializeData();
  }, [filters?.sequenceValue, costCenterLinkList]);

  const handleCancelCallBack = () => {
    cancelWarningPopup();
  };

  const getAlertMessage = (message: string) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        message: t(`generalLedgerSetup.ledgerCode.${message}`),
        title: t("common.simsFMSModule"),
        className: "primary-focus",
        notificationType: NotificationStatus.HIGHLIGHT,
        callback: () => {
          setToSession("glWarnBud", true);
          history.push("/tools/c-centre-ledger-links/add");
        }
      })
    );
  };

  const handlePreviewClick = () => {
    FMSSessionStorage.setItem("trackOfGLPreviewPage", true);
    history.push("/tools/general-ledger-setup/c-centre-ledger-links/preview", {
      ledgerBudgetLink
    });
  };

  const handleAddClick = () => {
    if (isBtnDisable) return;
    FMSSessionStorage.setItem("trackOfCreateLinksPage", true);
    if (isWarnBud === false) {
      getAlertMessage("warnBudgetAlertMsg");
    } else {
      history.push("/tools/c-centre-ledger-links/add");
    }
  };

  const onSuccessSubmit = () => {
    dispatch(resetFilters());
    dispatch(setSavedIds([]));
    fetchLedgerCostCenterLinkList();
    dispatch(resetDeletedIds());
  };

  const generateBudgetXML = (budgetIds: any) => {
    let xmlOutput = "<budget>";
    budgetIds.forEach((budgetId: any) => {
      xmlOutput += `${budgetId ? `<budget_id>${budgetId}</budget_id>` : ""}`;
    });
    xmlOutput += "</budget>";
    return xmlOutput;
  };

  const submitHandler = () => {
    if (
      (deletedIds && deletedIds.length > 0) ||
      (savedIds && savedIds.length > 0) ||
      linkHide.length > 0 ||
      linkUnhide.length > 0
    ) {
      const linkHideIds = generateBudgetXML(linkHide || []);
      const linkHidePayload = { budget_ids: linkHideIds, hideBudgetLink: "H" };

      const linkUnhideIds = generateBudgetXML(linkUnhide || []);
      const linkUnHidePayload = {
        budget_ids: linkUnhideIds,
        hideBudgetLink: "U"
      };

      dispatch(
        saveCostCenterLedgerLink({
          linkAdd: savedIds.map((savedId) => ({
            ledger_id: savedId.ledger_id,
            cost_id: savedId.cost_id
          })),
          linkDelete: deletedIds,
          linkHide: linkHidePayload,
          linkUnhide: linkUnHidePayload,
          callback: onSuccessSubmit
        })
      );
    } else {
      setTabData("/tools/general-ledger-setup/c-centre-ledger-links");
      dispatch(resetFilters());
    }
  };

  const isPayloadValidCostCentreLink = () =>
    deletedIds.length > 0 || savedIds.length > 0 || linkHide.length > 0 || linkUnhide.length > 0;

  const cancelWarningPopup = () => {
    if (isPayloadValidCostCentreLink()) {
      dispatch(
        uiActions.confirmPopup({
          className: "delete-alert",
          enable: true,
          message: t("generalLedgerSetup.cancelWarningMsg"),
          title: t("common.simsFMSModule"),
          type: MODAL_TYPE.CONFIRMV2,
          yesCallback: async () => {
            dispatch(resetFilters());
            dispatch(setSavedIds([]));
            history.push("/", { redirect: true });
          },
          noCallback: () => {
            history.push("/tools/general-ledger-setup/c-centre-ledger-links");
          }
        })
      );
    } else {
      setTabData("/");
      dispatch(resetFilters());
      dispatch(setSavedIds([]));
    }
  };

  const handleOnClickHideUnhide = (budgetIds: any, budgetIdsArr: any, addedHiddenLinks: any) => {
    let budgetIdsArrWithFilteredId = budgetIdsArr;

    if (linkHideRows.length > 0) {
      budgetIdsArrWithFilteredId = budgetIdsArr.filter(
        (id: any) => !linkHideRows.some((item: any) => item.budget_id === id)
      );
      const linkHideRowsWithFilteredId = linkHideRows.filter((item: any) => !budgetIdsArr.includes(item.budget_id));

      dispatch(centreLinksAction.setLinkHideRows(linkHideRowsWithFilteredId));

      const bugIds = new Set(linkHideRowsWithFilteredId.map((item) => item.budget_id));
      const newLinkHide = linkHide.filter((id) => bugIds.has(id));
      dispatch(centreLinksAction.setNewLinkHide(newLinkHide));
    } else if (linkUnhideRows.length > 0) {
      budgetIdsArrWithFilteredId = budgetIdsArr.filter(
        (id: any) => !linkUnhideRows.some((item: any) => item.budget_id === id)
      );

      const linkUnhideRowsWithFilteredId = linkUnhideRows.filter((item: any) => !budgetIdsArr.includes(item.budget_id));

      dispatch(centreLinksAction.setLinkUnhideRows(linkUnhideRowsWithFilteredId));

      const bugIds = new Set(linkUnhideRowsWithFilteredId.map((item) => item.budget_id));
      const newLinkUnhide = linkUnhide.filter((id) => bugIds.has(id));
      dispatch(centreLinksAction.setNewLinkUnhide(newLinkUnhide));
    }

    dispatch(
      postGlLedgerBudgetLink({
        budgetIds: generateBudgetXML(budgetIdsArrWithFilteredId),
        hideBudgetLink: filters?.linkStatusIndex === "0" || filters?.linkStatusIndex === "1" ? "H" : "U",
        addedHiddenLinks,
        callback: (data) => {
          const uniqueIds = [
            ...new Set(data?.centreLinkLedgerCostCentrePrintData?.centreLinkDetails.map((item: any) => item.budget_id))
          ];
          const uniqueIdsSet = new Set(uniqueIds);
          const filteredBudgetIdsArr = budgetIdsArrWithFilteredId.filter((id: any) => !uniqueIdsSet.has(id));

          if (filters?.linkStatusIndex === "0" || filters?.linkStatusIndex === "1") {
            dispatch(centreLinksAction.setLinkHide(filteredBudgetIdsArr));
          } else {
            dispatch(centreLinksAction.setLinkUnhide(filteredBudgetIdsArr));
          }

          setLedgerBudgetLink(data);
          setDialogMessage(
            `${(checkedRows?.length ?? 0) - (data?.failedCnt ?? 0)} of ${
              checkedRows?.length ?? 0
            } combinations are now set to ${
              filters?.linkStatusIndex === "2" ? `${t("alertMessage.inUse")}` : `${t("alertMessage.hidden")}`
            }${
              (checkedRows?.length ?? 0) - (data?.failedCnt ?? 0) !== (checkedRows?.length ?? 0)
                ? `\n${t("alertMessage.dialogMessage")}`
                : ``
            }`
          );
          setShowDialog(true);
          fetchLedgerCostCenterLinkList();
          dispatch(centreLinksAction.selectCheckedRows([]));
        }
      })
    );
  };

  // Click Away Functionality Start Here
  const yesCallback = async () => {
    submitHandler();
    fetchLedgerCostCenterLinkList();
    return true;
  };

  const noCallback = () => {
    dispatch(resetFilters());
    dispatch(resetDeletedIds());
    dispatch(resetCentreLedgerLinks());
    fetchLedgerCostCenterLinkList();
  };
  useClickAway({
    isDirty:
      (deletedIds && deletedIds.length > 0) ||
      (savedIds && savedIds.length > 0) ||
      linkHide.length > 0 ||
      linkUnhide.length > 0,
    yesCallback,
    noCallback,
    cancelCallback: () => {},
    excludePath: ["c-centre-ledger-links/add"]
  });
  // Click Away Functionality End Here

  return (
    <>
      <GeneralLedgerSetup>
        <div
          className={`general-ledger-listing-container ${
            filters?.linkStatusIndex === "0" ? "cost-ledger-link-scroll-height-all" : "cost-ledger-link-scroll-height"
          }`}
        >
          <Grid container>
            <GridItem
              sm={12}
              md={12}
              lg={12}
              xl={12}
            >
              <GridTableNew
                dataTestId="generalLedgerGrpList"
                filters={
                  <CostCentreLinksFilter
                    isDisabled={isBtnDisable}
                    handleAddClick={handleAddClick}
                    setSelectRow={selectGlListSelectedRow}
                  />
                }
                columnDef={columnDef.filter((col) => {
                  if (filters?.linkStatusIndex !== "0" && col.field === "hideCCLedLink") {
                    return false;
                  }
                  return true;
                })}
                isLoading={status === STATUS.LOADING}
                dataSource={statusFilter === "In use" ? costCenterLinkList : hiddenRows}
                isRowSelectionEnabled
                isScrollable
                customCell={CustomCell}
                selectedRow={selectedRowGlCodes}
                selectedRowHandler={(row) => {
                  const isSelected = selectedRows.includes(row);
                  setSelectedRows(isSelected ? selectedRows.filter((r) => r !== row) : [...selectedRows, row]);
                  dispatch(selectGlListSelectedRow(row));
                }}
                actions={
                  <>
                    {showDialog && (
                      <Modalv2
                        className="verify-balances-modal custom-text-white-space"
                        header={t("alertMessage.title")}
                        isOpen={showDialog}
                        primaryButton={
                          <Button
                            id="switch-to-list-warning-button"
                            size={ButtonSize.Small}
                            className="switch-to-list-warning-button"
                            ref={yesButtonRef}
                            onClick={() => {
                              BodyUtil.NoScroll.remove();
                              if (ledgerBudgetLink && ledgerBudgetLink.failedCnt > 0) {
                                handlePreviewClick();
                              } else {
                                setShowDialog(false);
                              }
                            }}
                          >
                            {t("common.ok")}
                          </Button>
                        }
                        onClose={() => {
                          BodyUtil.NoScroll.remove();
                          if (ledgerBudgetLink && ledgerBudgetLink.failedCnt > 0) {
                            handlePreviewClick();
                          } else {
                            setShowDialog(false);
                          }
                        }}
                      >
                        <>
                          <Notification
                            actionElement={1}
                            className="confirm-modal-text"
                            dataTestId="switch-to-list-warning-id"
                            escapeExits
                            id="switch-to-list-warning-id"
                            hideCloseButton
                            status={NotificationStatus.HIGHLIGHT}
                            title={dialogMessage}
                          />
                        </>
                      </Modalv2>
                    )}
                    <div className="button-right">
                      <Button
                        id="ccLedger-link-toggle-Hide-Unhide-btn"
                        size={ButtonSize.Small}
                        color={ButtonColor.Primary}
                        onClick={() => {
                          const addedHiddenLinks: any = [];
                          const budgetIdsArr = [
                            ...new Set(
                              checkedRows?.map((i) => {
                                if (i?.budget_id === undefined) {
                                  addedHiddenLinks.push({
                                    ledger_id: i?.ledger_id,
                                    cost_id: i?.cost_id
                                  });
                                }
                                return i.budget_id;
                              })
                            )
                          ];
                          const budgetIds = checkedRows?.reduce(
                            (acc, item) => `${acc}<budget_id>${item?.budget_id}</budget_id>`,
                            ""
                          );

                          handleOnClickHideUnhide(budgetIds, budgetIdsArr, addedHiddenLinks);
                        }}
                        disabled={filters?.linkStatusIndex === "0" || isBtnDisable}
                      >
                        {filters?.linkStatusIndex === "0" || filters?.linkStatusIndex === "1"
                          ? t("generalLedgerSetup.costCentre.hideTaggedLink")
                          : t("generalLedgerSetup.costCentre.unhideTaggedLink")}
                      </Button>
                    </div>
                  </>
                }
              />
            </GridItem>
          </Grid>
        </div>
        <GenralLedgerFooter
          disableSubmit={isBtnDisable}
          onSubmit={submitHandler}
          cancelCallback={handleCancelCallBack}
        />
      </GeneralLedgerSetup>
    </>
  );
};
export default CCentreLedgerLinks;
