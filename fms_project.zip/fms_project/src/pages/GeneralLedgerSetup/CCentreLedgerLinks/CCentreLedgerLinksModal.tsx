import React from "react";
import { ButtonColor } from "@essnextgen/ui-kit";
import Modal from "@/components/Modal/Modal";
import "./Style.scss";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";

type WarningModalProps = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  message: string;
  // eslint-disable-next-line
  primaryButtonHandler?: () => void;
};

const WarningModal = ({ setOpen, isOpen, message, primaryButtonHandler }: WarningModalProps) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const closeHandler = () => setOpen(false);

  return (
    <div className="ccentre-modal">
      <div className="text-area-label-color">
        <Modal
          header="SIMS FMS Module"
          isOpen={isOpen}
          primaryBtnText={t("common.ok")}
          primaryBtnClick={primaryButtonHandler}
          primaryBtnType={ButtonColor.Primary}
        >
          <div className="warning-message">{message}</div>
        </Modal>
      </div>
    </div>
  );
};

export default WarningModal;
