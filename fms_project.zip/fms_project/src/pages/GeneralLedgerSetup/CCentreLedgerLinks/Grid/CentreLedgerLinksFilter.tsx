import { Grid, GridItem, TextInput, RadioButton, RadioLabelPosition, FormLabel } from "@essnextgen/ui-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import AvailableCostCentreColumnDef from "./AvailableCostCentreColumnDef";

const CentreLedgerLinksFilter = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <Grid>
      <GridItem
        sm={5}
        md={5}
        xl={5}
      >
        <div className="essui-global-typography-default-h2  ">
          <FormLabel forId="looking-for">{t("purchaseOrder.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              onKeyDown={(event) => {
                // eslint-disable-next-line
                if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                  event.preventDefault();
                }
              }}
              id="looking-for"
              autoComplete={false}
            />
          </div>
        </div>
      </GridItem>
      <GridItem
        md={4}
        lg={4}
        xl={4}
      >
        <div className="filters align-center justify__content--between">
          <div className="essui-global-typography-default-h2 sequence-container">
            <FormLabel>{t("common.sequence02")}</FormLabel>
            <div className="sequence">
              <div className="essui-textinput sequence-fields sequence-order">
                {(AvailableCostCentreColumnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
                  const sequenceId = `sequence=${index + 1}`;
                  const sequence = column.sequenceIndex
                    ? AvailableCostCentreColumnDef.find(
                        (s) => s.sequenceIndex === index && s.sequence && s.sequenceIndex
                      )
                    : column;
                  return (
                    <RadioButton
                      id="sequence-btn"
                      label={column.sequenceName ? column.sequenceName : column.headerName}
                      labelPosition={RadioLabelPosition.Right}
                      value={column.field}
                      isSelected={column.field === "cost_code"}
                    />
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </GridItem>
    </Grid>
  );
};

export default CentreLedgerLinksFilter;
