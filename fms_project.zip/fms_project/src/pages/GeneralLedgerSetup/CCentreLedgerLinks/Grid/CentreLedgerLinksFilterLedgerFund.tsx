import { Grid, GridItem, TextInput, RadioButton, RadioLabelPosition, FormLabel } from "@essnextgen/ui-kit";
import React, { useEffect, useState } from "react";
import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import useDebounce from "@/hooks/useDebounce";
import findNearest from "@/utils/nearestSearch";
import { KEYBOARD_STRING, LEDGER_CENTER_SEQUENCE_TYPE } from "@/types/UseStateType";
import { centreLinksActionView } from "../../State/glCentreLedgerLinksView.slice";
import AvailableLedgerCodeColumnDef from "./AvailableLedgerCodeColumnDef";

const CentreLedgerLinksFilterLedgerFund = () => {
  const [columns, setColumn] = useState<TColumnDef>([...AvailableLedgerCodeColumnDef]);
  const dispatch = useDispatch<AppDispatch>();
  const {
    setLedgerCodeColumnDef,
    setLedgerCodeFilters,
    setSelectedRowLedgerFund,
    setLedgerCodeTableList,
    resetLedgerCodeFilters
  } = centreLinksActionView;
  const { ledgerCodeFilters, availableLedgerCodeList } = useAppSelector((state) => state.glCentreLedgerLinksView);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const debouncedValue = useDebounce(ledgerCodeFilters?.lookingFor!, 600);
  useEffect(() => {
    if (debouncedValue !== "" && availableLedgerCodeList && availableLedgerCodeList?.length) {
      let found;
      found = [...availableLedgerCodeList]
        .filter((element) =>
          debouncedValue
            ? (element as any)[ledgerCodeFilters?.sequenceValue!]
                ?.toString()
                ?.toUpperCase()
                ?.startsWith(debouncedValue!)
            : false
        )
        .at(0);

      if (found && found !== undefined) setSelectedRowLedgerFund(found);

      if (found === undefined) {
        found = findNearest(
          [...availableLedgerCodeList],
          [{ fieldName: ledgerCodeFilters?.sequenceValue!, searchValue: debouncedValue }],
          true
        );
        setSelectedRowLedgerFund(found);
      }
      const element = document.getElementById(
        `rowIndex-cdgentralLedgerLinksListLedgerCodes-${availableLedgerCodeList.indexOf(found!)}`
      );
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
      dispatch(setSelectedRowLedgerFund(found));
    }
  }, [debouncedValue]);

  useEffect(() => {
    setTimeout(() => {
      document.getElementById("looking-for-ledger-code")?.focus();
    }, 100);
  }, [ledgerCodeFilters?.sequenceValue]);

  useEffect(() => {
    handleSequenceChange(ledgerCodeFilters?.sequenceValue);
  }, [ledgerCodeFilters?.sequenceValue]);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    dispatch(setLedgerCodeFilters({ lookingFor: value.toUpperCase() }));
  };

  const handleSequenceChange = (value?: string) => {
    AvailableLedgerCodeColumnDef.map((col, index) => {
      if (col.field === value) {
        const temp = columns[0];
        columns[0] = columns[index];
        columns[index] = temp;
      }
      return col;
    });
    setColumn([...AvailableLedgerCodeColumnDef]);
    dispatch(setLedgerCodeColumnDef(columns));
    dispatch(setLedgerCodeTableList([...availableLedgerCodeList]));
  };

  const handleSequenceFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey = e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp;

    if (isArrowKey || e.key === KEYBOARD_STRING.ArrowRight || e.key === KEYBOARD_STRING.ArrowLeft) {
      e.preventDefault();
      let nextSequenceValue = "";
      let index = "";

      if (e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowRight) {
        switch (ledgerCodeFilters?.sequenceValue) {
          case LEDGER_CENTER_SEQUENCE_TYPE.LEDGER_CODE:
            nextSequenceValue = LEDGER_CENTER_SEQUENCE_TYPE.LEDGER_DES;
            index = "1";
            break;
          case LEDGER_CENTER_SEQUENCE_TYPE.LEDGER_DES:
            nextSequenceValue = LEDGER_CENTER_SEQUENCE_TYPE.LEDGER_CODE;
            index = "0";
            break;
          default:
            nextSequenceValue = LEDGER_CENTER_SEQUENCE_TYPE.LEDGER_CODE;
            index = "0";
            break;
        }
      } else if (e.key === KEYBOARD_STRING.ArrowUp || e.key === KEYBOARD_STRING.ArrowLeft) {
        switch (ledgerCodeFilters?.sequenceValue) {
          case LEDGER_CENTER_SEQUENCE_TYPE.LEDGER_CODE:
            nextSequenceValue = LEDGER_CENTER_SEQUENCE_TYPE.LEDGER_DES;
            index = "1";
            break;
          case LEDGER_CENTER_SEQUENCE_TYPE.LEDGER_DES:
            nextSequenceValue = LEDGER_CENTER_SEQUENCE_TYPE.LEDGER_CODE;
            index = "0";
            break;

          default:
            nextSequenceValue = LEDGER_CENTER_SEQUENCE_TYPE.LEDGER_DES;
            index = "0";
            break;
        }
      }
      dispatch(resetLedgerCodeFilters());

      dispatch(
        setLedgerCodeFilters({
          sequenceValue: nextSequenceValue,
          sequenceIndex: index
        })
      );
    }
  };

  return (
    <Grid>
      <GridItem
        sm={6}
        md={6}
        xl={6}
      >
        <div className="essui-global-typography-default-h2  ">
          <FormLabel forId="looking-for-ledger-code">{t("common.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              value={ledgerCodeFilters?.lookingFor}
              onChange={(e) => handleLookingForChange(e)}
              id="looking-for-ledger-code"
              autoComplete={false}
            />
          </div>
        </div>
      </GridItem>
      <GridItem
        md={4}
        lg={4}
        xl={4}
      >
        <div className="filters align-center justify__content--between">
          <div className="essui-global-typography-default-h2 sequence-container">
            <FormLabel forId="sequence-btn">{t("common.sequence02")}</FormLabel>
            <div className="sequence">
              <div
                className="essui-textinput sequence-fields sequence-order"
                onKeyDown={handleSequenceFieldKeyDown}
              >
                {(AvailableLedgerCodeColumnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
                  const sequenceId = `sequence=${index + 1}`;
                  const sequence = column.sequenceIndex
                    ? AvailableLedgerCodeColumnDef.find(
                        (s) => s.sequenceIndex === index && s.sequence && s.sequenceIndex
                      )
                    : column;
                  return (
                    <RadioButton
                      id="sequence-btn"
                      label={column.sequenceName ? column.sequenceName : column.headerName}
                      labelPosition={RadioLabelPosition.Right}
                      value={column.field}
                      key={sequenceId}
                      name="linkStatusColumn"
                      onChange={() => {
                        dispatch(
                          setLedgerCodeFilters({
                            sequenceValue: String(column.field),
                            sequenceIndex: String(index),
                            lookingFor: ""
                          })
                        );
                      }}
                      isSelected={ledgerCodeFilters?.sequenceValue === column.field}
                    />
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </GridItem>
    </Grid>
  );
};

export default CentreLedgerLinksFilterLedgerFund;
