import { Grid, GridItem, TextInput, RadioButton, RadioLabelPosition, FormLabel } from "@essnextgen/ui-kit";
import React, { useEffect, useState } from "react";
import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import useDebounce from "@/hooks/useDebounce";
import findNearest from "@/utils/nearestSearch";
import { KEYBOARD_STRING, COST_CENTER_SEQUENCE_TYPE, LEDGER_CENTER_SEQUENCE_TYPE } from "@/types/UseStateType";
import { centreLinksActionView } from "../../State/glCentreLedgerLinksView.slice";
import AvailableCostCentreColumnDef from "./AvailableCostCentreColumnDef";
// import { CARBON_ICON, CCENTRE_LEDGER_LINK_STATUS_TYPE, CCENTRE_LEDGER_SEQUENCE_TYPE, KEYBOARD_STRING } from "@/types/UseStateType";

const CentreLedgerLinksFilterCostCentre = () => {
  const [columns, setColumn] = useState<TColumnDef>([...AvailableCostCentreColumnDef]);
  const dispatch = useDispatch<AppDispatch>();
  const {
    setCostCentreColumnDef,
    setCostCentreFilters,
    setSelectedRowCostCentre,
    setCostCentreTableList,
    resetCostCentreFilters
  } = centreLinksActionView;
  const { costCentreFilters, availableCostCentreList } = useAppSelector((state) => state.glCentreLedgerLinksView);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const debouncedValue = useDebounce(costCentreFilters?.lookingFor!, 600);
  useEffect(() => {
    if (debouncedValue !== "" && availableCostCentreList && availableCostCentreList?.length) {
      let found;
      found = [...availableCostCentreList]
        .filter((element) =>
          debouncedValue
            ? (element as any)[costCentreFilters?.sequenceValue!]
                ?.toString()
                ?.toUpperCase()
                ?.startsWith(debouncedValue!)
            : false
        )
        .at(0);

      if (found && found !== undefined) setSelectedRowCostCentre(found);

      if (found === undefined) {
        found = findNearest(
          [...availableCostCentreList],
          [
            {
              fieldName: costCentreFilters?.sequenceValue!,
              searchValue: debouncedValue
            }
          ],
          true
        );
        setSelectedRowCostCentre(found);
      }
      const element = document.getElementById(
        `rowIndex-cdgentralLedgerLinksListCostCentres-${availableCostCentreList.indexOf(found!)}`
      );
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
      dispatch(setSelectedRowCostCentre(found));
    }
  }, [debouncedValue]);

  useEffect(() => {
    setTimeout(() => {
      document.getElementById("looking-for-cost-centre")?.focus();
    }, 111);
  }, [costCentreFilters?.sequenceValue]);

  useEffect(() => {
    handleSequenceChange(costCentreFilters?.sequenceValue);
  }, [costCentreFilters?.sequenceValue]);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    dispatch(setCostCentreFilters({ lookingFor: value.toUpperCase() }));
  };

  const handleSequenceChange = (value?: string) => {
    AvailableCostCentreColumnDef.map((col, index) => {
      if (col.field === value) {
        const temp = columns[0];
        columns[0] = columns[index];
        columns[index] = temp;
      }
      return col;
    });
    setColumn([...AvailableCostCentreColumnDef]);
    dispatch(setCostCentreColumnDef(columns));
    dispatch(setCostCentreTableList([...availableCostCentreList]));
  };

  const handleSequenceFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey = e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp;

    if (isArrowKey || e.key === KEYBOARD_STRING.ArrowRight || e.key === KEYBOARD_STRING.ArrowLeft) {
      e.preventDefault();
      let nextSequenceValue = "";
      let index = "";

      if (e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowRight) {
        switch (costCentreFilters?.sequenceValue) {
          case COST_CENTER_SEQUENCE_TYPE.COST_CODE:
            nextSequenceValue = COST_CENTER_SEQUENCE_TYPE.COST_DES;
            index = "1";
            break;
          case COST_CENTER_SEQUENCE_TYPE.COST_DES:
            nextSequenceValue = COST_CENTER_SEQUENCE_TYPE.COST_CODE;
            index = "0";
            break;
          default:
            nextSequenceValue = COST_CENTER_SEQUENCE_TYPE.COST_CODE;
            index = "0";
            break;
        }
      } else if (e.key === KEYBOARD_STRING.ArrowUp || e.key === KEYBOARD_STRING.ArrowLeft) {
        switch (costCentreFilters?.sequenceValue) {
          case COST_CENTER_SEQUENCE_TYPE.COST_CODE:
            nextSequenceValue = COST_CENTER_SEQUENCE_TYPE.COST_DES;
            index = "1";
            break;
          case COST_CENTER_SEQUENCE_TYPE.COST_DES:
            nextSequenceValue = COST_CENTER_SEQUENCE_TYPE.COST_CODE;
            index = "0";
            break;

          default:
            nextSequenceValue = COST_CENTER_SEQUENCE_TYPE.COST_DES;
            index = "0";
            break;
        }
      }

      dispatch(resetCostCentreFilters());

      dispatch(
        setCostCentreFilters({
          sequenceValue: nextSequenceValue,
          sequenceIndex: index
        })
      );
    }
  };

  return (
    <Grid>
      <GridItem
        sm={6}
        md={6}
        xl={6}
      >
        <div className="essui-global-typography-default-h2  ">
          <FormLabel forId="looking-for">{t("common.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              value={costCentreFilters?.lookingFor}
              onChange={(e) => handleLookingForChange(e)}
              id="looking-for-cost-centre"
              autoComplete={false}
            />
          </div>
        </div>
      </GridItem>
      <GridItem
        md={4}
        lg={4}
        xl={4}
      >
        <div className="filters align-center justify__content--between">
          <div className="essui-global-typography-default-h2 sequence-container">
            <FormLabel forId="sequence-btn">{t("common.sequence02")}</FormLabel>
            <div className="sequence">
              <div
                className="essui-textinput sequence-fields sequence-order"
                onKeyDown={handleSequenceFieldKeyDown}
              >
                {(AvailableCostCentreColumnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
                  const sequenceId = `sequence=${index + 1}`;
                  const sequence = column.sequenceIndex
                    ? AvailableCostCentreColumnDef.find(
                        (s) => s.sequenceIndex === index && s.sequence && s.sequenceIndex
                      )
                    : column;
                  return (
                    <RadioButton
                      id="sequence-btn"
                      label={column.sequenceName ? column.sequenceName : column.headerName}
                      labelPosition={RadioLabelPosition.Right}
                      value={column.field}
                      key={sequenceId}
                      name="StatusColumn"
                      onChange={() => {
                        dispatch(
                          setCostCentreFilters({
                            sequenceValue: String(column.field),
                            sequenceIndex: String(index),
                            lookingFor: ""
                          })
                        );
                      }}
                      isSelected={costCentreFilters?.sequenceValue === column.field}
                    />
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </GridItem>
    </Grid>
  );
};

export default CentreLedgerLinksFilterCostCentre;
