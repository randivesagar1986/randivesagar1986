import React, { useEffect, useState } from "react";
import {
  Grid,
  GridItem,
  ButtonSize,
  Button,
  FormLabel,
  TextInput,
  RadioButton,
  RadioLabelPosition
} from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { AddLarge } from "@carbon/icons-react";
import {
  CARBON_ICON,
  CCENTRE_LEDGER_LINK_STATUS_TYPE,
  CCENTRE_LEDGER_SEQUENCE_TYPE,
  KEYBOARD_STRING
} from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import useDebounce from "@/hooks/useDebounce";
import findNearest from "@/utils/nearestSearch";
import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import CostCentreLinksColumnDef from "./columnDef";
import { centreLinksAction } from "../../State/glCentreLedgerLinks.slice";

const CostCentreLinksFilter = ({ handleAddClick, setSelectRow, isDisabled = false }: any) => {
  const dispatch = useDispatch();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { setFilters, setColumnDef, selectGlListSelectedRow } = centreLinksAction;
  // eslint-disable-next-line
  const [columns, setColumn] = useState<TColumnDef>([...CostCentreLinksColumnDef]);
  const { filters, costCenterLinkList } = useAppSelector((state) => state.glCentreLedgerLinks);
  const debouncedValue = useDebounce(filters?.lookingFor!, 600);

  useEffect(() => {
    if (debouncedValue !== "" && costCenterLinkList && costCenterLinkList?.length) {
      let found;
      found = [...costCenterLinkList]
        .filter((element) =>
          debouncedValue
            ? element[filters?.sequenceValue!].toString()?.toUpperCase()?.startsWith(debouncedValue!)
            : false
        )
        .at(0);

      if (found && found !== undefined) setSelectRow(found);

      if (found === undefined) {
        found = findNearest(
          [...costCenterLinkList],
          [{ fieldName: filters?.sequenceValue!, searchValue: debouncedValue }],
          true
        );
        setSelectRow(found);
      }
      const element = document.getElementById(`rowIndex-generalLedgerGrpList-${costCenterLinkList.indexOf(found!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
      dispatch(selectGlListSelectedRow(found));
    }
  }, [debouncedValue]);

  useEffect(() => {
    setTimeout(() => {
      document.getElementById("looking-for")?.focus();
    }, 100);
  }, []);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    dispatch(setFilters({ lookingFor: value.toUpperCase() }));
  };

  const handleSequenceChange = (columnsNew: any) => {
    const isChecked = columnsNew[0].checkboxSelection === true ? 1 : 0;
    const getRow = columnsNew.find((row: any) => row.field === filters?.sequenceValue);
    columnsNew.splice(columnsNew.indexOf(getRow!), 1); // delete
    columnsNew.splice(isChecked, 0, getRow!);

    const checkboxIndex = columnsNew.findIndex((col: any) => col.field === "checkbox");

    if (checkboxIndex > 0) {
      const [checkboxColumn] = columnsNew.splice(checkboxIndex, 1);
      columnsNew.unshift(checkboxColumn);
    }

    if (filters?.sequenceValue === "ledger_des") {
      [columnsNew[1], columnsNew[2], columnsNew[3]] = [
        CostCentreLinksColumnDef[0],
        CostCentreLinksColumnDef[3],
        CostCentreLinksColumnDef[2]
      ];
    } else if (filters?.sequenceValue === "cost_code") {
      [columnsNew[1], columnsNew[2], columnsNew[3]] = [
        CostCentreLinksColumnDef[3],
        CostCentreLinksColumnDef[0],
        CostCentreLinksColumnDef[1]
      ];
    } else if (filters?.sequenceValue === "cost_des") {
      [columnsNew[1], columnsNew[2], columnsNew[3]] = [
        CostCentreLinksColumnDef[2],
        CostCentreLinksColumnDef[1],
        CostCentreLinksColumnDef[0]
      ];
    }

    setColumn([...columnsNew]);
    dispatch(setColumnDef(columnsNew));
  };

  useEffect(() => {
    handleSequenceChange(columns);
  }, [filters?.sequenceValue]);

  const handleSequenceFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey = e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp;

    if (isArrowKey || e.key === KEYBOARD_STRING.ArrowRight || e.key === KEYBOARD_STRING.ArrowLeft) {
      e.preventDefault();
      let nextSequenceValue = "";
      let index = "";

      if (e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowRight) {
        switch (filters?.sequenceValue) {
          case CCENTRE_LEDGER_SEQUENCE_TYPE.LEDGER_FUND:
            nextSequenceValue = CCENTRE_LEDGER_SEQUENCE_TYPE.LEDGER_DES;
            index = "1";
            break;
          case CCENTRE_LEDGER_SEQUENCE_TYPE.LEDGER_DES:
            nextSequenceValue = CCENTRE_LEDGER_SEQUENCE_TYPE.COST_CODE;
            index = "2";
            break;
          case CCENTRE_LEDGER_SEQUENCE_TYPE.COST_CODE:
            nextSequenceValue = CCENTRE_LEDGER_SEQUENCE_TYPE.COST_DES;
            index = "3";
            break;
          case CCENTRE_LEDGER_SEQUENCE_TYPE.COST_DES:
            nextSequenceValue = CCENTRE_LEDGER_SEQUENCE_TYPE.LEDGER_FUND;
            index = "0";
            break;
          default:
            nextSequenceValue = CCENTRE_LEDGER_SEQUENCE_TYPE.LEDGER_FUND;
            index = "0";
            break;
        }
      } else if (e.key === KEYBOARD_STRING.ArrowUp || e.key === KEYBOARD_STRING.ArrowLeft) {
        switch (filters?.sequenceValue) {
          case CCENTRE_LEDGER_SEQUENCE_TYPE.LEDGER_FUND:
            nextSequenceValue = CCENTRE_LEDGER_SEQUENCE_TYPE.COST_DES;
            index = "3";
            break;
          case CCENTRE_LEDGER_SEQUENCE_TYPE.LEDGER_DES:
            nextSequenceValue = CCENTRE_LEDGER_SEQUENCE_TYPE.LEDGER_FUND;
            index = "0";
            break;
          case CCENTRE_LEDGER_SEQUENCE_TYPE.COST_CODE:
            nextSequenceValue = CCENTRE_LEDGER_SEQUENCE_TYPE.LEDGER_DES;
            index = "1";

            break;
          // eslint-disable-next-line
          case CCENTRE_LEDGER_SEQUENCE_TYPE.COST_DES:
            nextSequenceValue = CCENTRE_LEDGER_SEQUENCE_TYPE.COST_CODE;
            index = "2";
            break;
          default:
            nextSequenceValue = CCENTRE_LEDGER_SEQUENCE_TYPE.LEDGER_FUND;
            index = "0";
            break;
        }
      }

      dispatch(
        setFilters({
          sequenceValue: nextSequenceValue,
          sequenceIndex: index
        })
      );
    }
  };

  const handleLinkStatusFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey = e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp;

    if (isArrowKey || e.key === KEYBOARD_STRING.ArrowRight || e.key === KEYBOARD_STRING.ArrowLeft) {
      e.preventDefault();
      let nextLinkStatusValue = "";
      let index = "";

      if (e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowRight) {
        switch (filters?.linkStatusValue) {
          case CCENTRE_LEDGER_LINK_STATUS_TYPE.ALL:
            nextLinkStatusValue = CCENTRE_LEDGER_LINK_STATUS_TYPE.IN_USE;
            index = "1";
            break;
          case CCENTRE_LEDGER_LINK_STATUS_TYPE.IN_USE:
            nextLinkStatusValue = CCENTRE_LEDGER_LINK_STATUS_TYPE.HIDDEN;
            index = "2";
            break;
          case CCENTRE_LEDGER_LINK_STATUS_TYPE.HIDDEN:
            nextLinkStatusValue = CCENTRE_LEDGER_LINK_STATUS_TYPE.ALL;
            index = "0";
            break;
          default:
            nextLinkStatusValue = CCENTRE_LEDGER_LINK_STATUS_TYPE.ALL;
            index = "0";
            break;
        }
      } else if (e.key === KEYBOARD_STRING.ArrowUp || e.key === KEYBOARD_STRING.ArrowLeft) {
        switch (filters?.linkStatusValue) {
          case CCENTRE_LEDGER_LINK_STATUS_TYPE.ALL:
            nextLinkStatusValue = CCENTRE_LEDGER_LINK_STATUS_TYPE.HIDDEN;
            index = "2";
            break;
          case CCENTRE_LEDGER_LINK_STATUS_TYPE.IN_USE:
            nextLinkStatusValue = CCENTRE_LEDGER_LINK_STATUS_TYPE.ALL;
            index = "0";
            break;
          case CCENTRE_LEDGER_LINK_STATUS_TYPE.HIDDEN:
            nextLinkStatusValue = CCENTRE_LEDGER_LINK_STATUS_TYPE.IN_USE;
            index = "1";
            break;
          default:
            nextLinkStatusValue = CCENTRE_LEDGER_LINK_STATUS_TYPE.ALL;
            index = "0";
            break;
        }
      }

      dispatch(
        setFilters({
          linkStatusValue: nextLinkStatusValue,
          linkStatusIndex: index
        })
      );
    }
  };

  const CostCentreLedgerLinkStatus = [
    {
      sequence: true,
      sequenceName: "All",
      field: "all"
    },
    {
      sequence: true,
      sequenceName: "In Use",
      field: "inUse"
    },
    {
      sequence: true,
      sequenceName: "Hidden",
      field: "hidden"
    }
  ];

  useEffect(() => {
    modifyArray(filters?.linkStatusIndex);
  }, [filters?.linkStatusIndex]);

  const modifyArray = (linkStatusIndex: string | undefined) => {
    const item: {
      field: string;
      key?: string;
      headerName?: string;
      primary?: boolean;
      sequenceName?: string;
      sequence?: boolean;
      sequenceIndex?: number;
      checkboxSelection?: boolean;
      headerCheckboxSelection?: boolean;
      align?: "left" | "right" | "center";
      cellRenderer?: "GridCellLink";
      className?: string;
      val?: number;
      enableTooltip?: boolean;
      columnWidth?: 5 | 10 | 15 | 20 | 25 | 30 | 50 | 70 | 80 | 90;
    } = {
      align: "center",
      field: "checkbox",
      cellRenderer: "GridCellLink",
      columnWidth: 5
    };

    if (linkStatusIndex === "1" || linkStatusIndex === "2") {
      // Check if item already exists
      const exists = columns.some((el) => el.field === item.field);
      if (!exists) {
        const newColumn = [item, ...columns];
        const removeHidden = newColumn.filter((el) => el.field !== "hideCCLedLink");
        setColumn([...removeHidden]);
        dispatch(setColumnDef(removeHidden));
      }
    } else if (linkStatusIndex === "0") {
      const newColumn = columns.filter((el) => el.field !== item.field);
      setColumn([...newColumn]);
      dispatch(setColumnDef(newColumn));
    }
  };

  return (
    <Grid>
      <GridItem
        sm={2}
        md={2}
        xl={2}
      >
        <div className="essui-global-typography-default-h2  ">
          <FormLabel forId="looking-for">{t("purchaseOrder.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              autoFocus
              value={filters?.lookingFor}
              // onKeyDown={}  // Attach the keydown handler here
              onChange={(e) => handleLookingForChange(e)}
              id="looking-for"
              autoComplete={false}
            />
          </div>
        </div>
      </GridItem>
      <GridItem
        md={9}
        lg={9}
        xl={9}
      >
        <div className="filters align-center">
          <div className="essui-global-typography-default-h2 sequence-container">
            <FormLabel>{t("generalLedgerSetup.CostCenterLedgerLinks.CostCenterLedgerLinksStatus")}</FormLabel>
            <div className="sequence">
              <div
                className="essui-textinput sequence-fields sequence-order"
                onKeyDown={handleLinkStatusFieldKeyDown}
              >
                {(CostCentreLedgerLinkStatus.filter((col) => !!col.sequence) || []).map((column, index) => {
                  const sequenceId = `sequence=${index + 1}`;
                  return (
                    <RadioButton
                      label={column.sequenceName ? column.sequenceName : ""}
                      labelPosition={RadioLabelPosition.Right}
                      value={column.field}
                      key={sequenceId}
                      name="linkStatusColumn"
                      onChange={() => {
                        dispatch(
                          setFilters({
                            linkStatusValue: String(column.field),
                            linkStatusIndex: String(index),
                            lookingFor: ""
                          })
                        );
                      }}
                      isSelected={filters?.linkStatusValue === column.field}
                    />
                  );
                })}
              </div>
            </div>
          </div>
          <div className="essui-global-typography-default-h2 sequence-container">
            <FormLabel>{t("common.sequence02")}</FormLabel>
            <div className="sequence">
              <div
                className="essui-textinput sequence-fields sequence-order"
                onKeyDown={handleSequenceFieldKeyDown}
              >
                {(CostCentreLinksColumnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
                  const sequenceId = `sequence=${index + 1}`;

                  return (
                    <RadioButton
                      label={column.sequenceName ? column.sequenceName : column.headerName}
                      labelPosition={RadioLabelPosition.Right}
                      value={column.field}
                      key={sequenceId}
                      name="sequenceColumn"
                      onChange={() => {
                        dispatch(
                          setFilters({
                            sequenceValue: String(column.field),
                            sequenceIndex: String(index),
                            lookingFor: ""
                          })
                        );
                      }}
                      isSelected={filters?.sequenceValue === column.field}
                    />
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </GridItem>
      <GridItem
        md={1}
        lg={1}
        xl={1}
        className="btn-container"
      >
        <Button
          size={ButtonSize.Small}
          onClick={() => handleAddClick()}
          title={t("generalLedgerSetup.CostCenterLedgerLinks.addLinks")}
          id="gllg-add-btn"
          className={`essui-button essui-button--utility essui-button--small br-0 focus-active add-button btn-align ${
            !isDisabled ? "" : "disable-cta"
          }`}
        >
          <AddLarge
            className={!isDisabled ? "" : "button-disabled-icon "}
            size={CARBON_ICON.SIZE}
            color={CARBON_ICON.COLOR_BLACK}
          />
        </Button>
      </GridItem>
    </Grid>
  );
};

export default CostCentreLinksFilter;
