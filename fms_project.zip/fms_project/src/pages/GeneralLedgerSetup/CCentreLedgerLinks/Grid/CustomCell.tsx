import { cellRendererType } from "@/components/GridTable/GridTable";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { Button, ButtonColor, CheckBox, Icon, IconSize, NotificationStatus } from "@essnextgen/ui-kit";
import { ReactNode, useState } from "react";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import { centreLinksAction, getCostCentreLinkValidate } from "../../State/glCentreLedgerLinks.slice";

const CustomCell = ({ field, row }: cellRendererType) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch();
  const { selectedRows = [], costCenterLinkList, savedIds } = useAppSelector((state) => state.glCentreLedgerLinks);
  const { selectGlListSelectedRow } = centreLinksAction;
  const [isLoading, setIsLoading] = useState(false);
  const userAccessRights = useAppSelector((state) => state.userAccessRights); // get user access rights
  const canAddEdit = canDo(userAccessRights, {
    action: ACCESS_RIGHTS_ACTION.Define,
    module: ACCESS_RIGHTS_MODULE.GLCCLCLinks
  });
  const isBtnDisable = canAddEdit !== undefined ? !canAddEdit : false;

  const handleDelete = async () => {
    const itemIndex = costCenterLinkList.indexOf(row);
    const ele = document.getElementById(`rowIndex-generalLedgerGrpList-${itemIndex}`);
    // Delete conditions will be there..
    setIsLoading(true);
    const result: any = await dispatch(
      getCostCentreLinkValidate({
        ledgerId: row?.ledger_id,
        costId: row?.cost_id
      })
    );
    setIsLoading(false);
    if (result?.payload) {
      if (result?.payload?.budgetValidate > 0) {
        ele?.focus();
        dispatch(
          uiActions.alertPopup({
            enable: true,
            type: MODAL_TYPE.ALERT,
            notificationType: NotificationStatus.ERROR,
            title: t("common.simsFMSModule"),
            message: t("generalLedgerSetup.costCentre.costCentreLinkBecauseBudgetHasAlreadyBeenSet")
          })
        );
        setTimeout(() => {
          const focusButton = document.querySelector(
            ".essui-dialog__footer button.essui-button.essui-button--primary.essui-button--small"
          ) as HTMLElement;
          if (focusButton) {
            focusButton.focus();
          }
        }, 10);
      } else if (result?.payload?.trasactionValidate === "T") {
        ele?.focus();
        dispatch(
          uiActions.alertPopup({
            enable: true,
            type: MODAL_TYPE.ALERT,
            notificationType: NotificationStatus.ERROR,
            title: t("common.simsFMSModule"),
            message: t("generalLedgerSetup.costCentre.costCentreLinkCannotBeDeleted")
          })
        );
        setTimeout(() => {
          const focusButton = document.querySelector(
            ".essui-dialog__footer button.essui-button.essui-button--primary.essui-button--small"
          ) as HTMLElement;
          if (focusButton) {
            focusButton.focus();
          }
        }, 10);
      } else {
        if (savedIds.some((item) => item?.ledger_id === row?.ledger_id && item?.cost_id === row?.cost_id)) {
          dispatch(
            centreLinksAction.setSavedIds(
              savedIds.filter((item) => item?.ledger_id !== row?.ledger_id && item?.cost_id !== row?.cost_id)
            )
          );
        }

        dispatch(
          centreLinksAction.setDeletedIds({
            ledgerId: row?.ledger_id,
            costId: row?.cost_id
          })
        );

        const itemIndex = costCenterLinkList.indexOf(row);
        const arrLength = costCenterLinkList.length;
        const ele = document.getElementById(`rowIndex-generalLedgerGrpList-${itemIndex}`);
        ele?.focus();
        const selectIndex = itemIndex === arrLength - 1 ? arrLength - 2 : itemIndex + 1;
        const focusItem = costCenterLinkList[selectIndex];
        dispatch(selectGlListSelectedRow(focusItem));
      }
    }
  };

  const handleCheckboxChange = function () {
    if (!selectedRows?.some((item) => item?.budget_id === row?.budget_id)) {
      dispatch(centreLinksAction.selectCheckedRows([...selectedRows, row]));
    } else {
      dispatch(centreLinksAction.selectCheckedRows(selectedRows?.filter((item) => item?.budget_id !== row?.budget_id)));
    }
  };

  const getContent = () => {
    if (field === "actions") {
      return (
        <Button
          color={ButtonColor.Utility}
          className="segments-buttons"
          onClick={() => handleDelete()}
          disabled={isLoading || isBtnDisable}
          id="ccLedgerLink-delete-btn"
        >
          {t("common.delete")}
        </Button>
      );
    }
    if (field === "hideCCLedLink") {
      if (row?.hideCCLedLink === "Y") {
        return "Yes";
      }
      return "No";
    }

    if (field === "checkbox") {
      // eslint-disable-next-line
      return (
        <CheckBox
          disabled={isBtnDisable}
          isSelected={selectedRows?.some((item) => item?.budget_id === row?.budget_id)}
          // eslint-disable-next-line
          onChange={handleCheckboxChange}
        />
      );
    }
    return "";
  };
  return getContent();
};

export default CustomCell;

type OptionProps = {
  iconName?: string;
  optionName: string;
  children?: ReactNode;
};
const RowAction = ({ iconName, optionName, children }: OptionProps) => (
  <div className="option">
    {iconName ? (
      <Icon
        size={IconSize.Medium}
        name={iconName}
      />
    ) : (
      children
    )}
    {optionName}
  </div>
);

RowAction.defaultProps = {
  iconName: undefined,
  children: undefined
};
