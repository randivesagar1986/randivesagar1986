import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const CostCentreLinksColumnDef: TColumnDef = [
  {
    headerName: "Ledger-Fund",
    field: "ledger_fund",
    sequence: true,
    sequenceName: "Ledger/Fund Code",
    columnWidth: 10
  },
  {
    headerName: "Ledger Description",
    field: "ledger_des",
    columnWidth: 30,
    sequence: true,
    enableTooltip: true
  },
  {
    headerName: "Cost Centre Code",
    field: "cost_code",
    columnWidth: 20,
    sequence: true
  },
  {
    headerName: "Cost Centre Description",
    field: "cost_des",
    columnWidth: 30,
    sequence: true,
    enableTooltip: true
  },
  {
    headerName: "Hidden",
    field: "hideCCLedLink",
    columnWidth: 10,
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "",
    field: "actions",
    cellRenderer: "GridCellLink",
    columnWidth: 10
  }
];

export default CostCentreLinksColumnDef;
