import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const AvailableCostCentreColumnDef: TColumnDef = [
  {
    headerName: "Cost Centre Code",
    field: "cost_code",
    columnWidth: 15,
    sequenceName: "Code",
    sequenceIndex: 0,
    sequence: true
  },
  {
    headerName: "Cost Centre Description",
    field: "cost_des",
    columnWidth: 25,
    sequenceName: "Description",
    sequenceIndex: 1,
    sequence: true,
    enableTooltip: true
  },
  {
    headerCheckboxSelection: true,
    checkboxSelection: true,
    align: "center",
    field: "checkbox",
    cellRenderer: "GridCellLink",
    columnWidth: 5
  }
];

export default AvailableCostCentreColumnDef;
