import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const AvailableLedgerCodeColumnDef: TColumnDef = [
  {
    headerName: "Ledger Code",
    field: "ledger_fund",
    sequence: true,
    sequenceName: "Code",
    sequenceIndex: 2,
    columnWidth: 15
  },
  {
    headerName: "Ledger Code Description",
    field: "ledger_des",
    sequence: true,
    sequenceName: "Description",
    sequenceIndex: 3,
    columnWidth: 25,
    enableTooltip: true
  },
  {
    headerCheckboxSelection: true,
    checkboxSelection: true,
    align: "center",
    field: "checkbox",
    cellRenderer: "GridCellLink",
    columnWidth: 5
  }
];

export default AvailableLedgerCodeColumnDef;
