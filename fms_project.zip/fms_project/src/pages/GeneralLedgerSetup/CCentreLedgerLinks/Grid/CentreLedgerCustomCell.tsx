import { useAppSelector } from "@/store/store";
import { CheckBox } from "@essnextgen/ui-kit";

const CustomCell = ({ field, row }: any) => {
  const getContent = () => {
    if (field === "autorec_default") {
      const checked = row?.autorec_default === "*";
      return <CheckBox isSelected={checked} />;
    }
    return null;
  };
  return getContent();
};
export default CustomCell;
