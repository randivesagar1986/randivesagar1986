import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { Provider } from "react-redux";
import configureStore from "redux-mock-store";
import thunk from "redux-thunk";
import { BrowserRouter as Router } from "react-router-dom";
import { TabGroup } from "@essnextgen/ui-kit";
import LinkLedgerCodesToCostCentres from "../LinkLedgerCodesToCostCentres";

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

const mockInitialState = {
  glCentreLedgerLinksView: {
    availableCostCentreList: [{ cost_id: 1, isSelected: false }],
    availableLedgerCodeList: [{ ledger_id: 1, isSelected: false }],
    costCentreColumnDef: [],
    ledgerCodeColumnDef: [],
    status: "SUCCESS",
    selectedRowCostCentre: null,
    selectedRowLedgerFund: null
  },
  glCentreLedgerLinks: {
    costCenterLinkList: []
  },
  userAccessRights: {
    rights: []
  }
};

const store = mockStore(mockInitialState);

jest.mock("../../GeneralLedgerSetup", () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode }) => (
    <div>
      GeneralLedgerSetup Component
      {children}
    </div>
  )
}));

describe("Redux Store and Provider Test", () => {
  it("renders with Provider and store", () => {
    render(
      <Provider store={store}>
        <Router>
          <TabGroup>
            <LinkLedgerCodesToCostCentres />
          </TabGroup>
        </Router>
      </Provider>
    );

    expect(screen.getByText("generalLedgerSetup.availableCC")).toBeInTheDocument();
  });

  it("renders with Provider and store", () => {
    render(
      <Provider store={store}>
        <Router>
          <TabGroup>
            <LinkLedgerCodesToCostCentres />
          </TabGroup>
        </Router>
      </Provider>
    );
    expect(screen.getByText("generalLedgerSetup.availableLC")).toBeInTheDocument();
  });

  it("should handle modal dialog and create link button", async () => {
    render(
      <Provider store={store}>
        <Router>
          <TabGroup>
            <LinkLedgerCodesToCostCentres />
          </TabGroup>
        </Router>
      </Provider>
    );

    fireEvent.click(screen.getByText("common.help"));
  });

  it("should handle Create Link action", async () => {
    render(
      <Provider store={store}>
        <Router>
          <TabGroup>
            <LinkLedgerCodesToCostCentres />
          </TabGroup>
        </Router>
      </Provider>
    );

    fireEvent.click(screen.getByText("common.createLinks"));
  });

  it("should handle Cancel action", async () => {
    render(
      <Provider store={store}>
        <Router>
          <TabGroup>
            <LinkLedgerCodesToCostCentres />
          </TabGroup>
        </Router>
      </Provider>
    );

    fireEvent.click(screen.getByText("common.cancel"));
  });
});
