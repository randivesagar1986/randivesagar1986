import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import configureStore from "redux-mock-store";
import thunk from "redux-thunk";
import { TabGroup } from "@essnextgen/ui-kit";
import CCentreLedgerLinks from "../CCentreLedgerLinks";
import { STATUS } from "../../../../types/UseStateType";

jest.mock("../Grid/CostCentreLinksFilter", () => ({
  __esModule: true,
  default: () => <div>CostCentreLinksFilter Component</div>
}));

jest.mock("../../GeneralLedgerSetup", () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode }) => (
    <div>
      GeneralLedgerSetup Component
      {children}
    </div>
  )
}));

// Mocking the custom hook useLedgerGrpPopup
jest.mock("../../hooks/useLedgerGrpPopup", () => ({
  __esModule: true,
  default: jest.fn(() => ({
    setTabData: jest.fn(),
    getEditText: jest.fn(),
    tabData: ""
  }))
}));

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

const mockData = [
  { id: 1, name: "Cost Center 1", status: "In use" },
  { id: 2, name: "Cost Center 2", status: "Hidden" }
];

// Updated mock state with the necessary properties
const initialState = {
  glCentreLedgerLinks: {
    status: STATUS.SUCCESS,
    filters: { linkStatusIndex: "0", sequenceIndex: "0" },
    columnDef: [
      { field: "checkbox", headerName: "Select" }, // Added checkbox column
      { field: "name", headerName: "Name" },
      { field: "status", headerName: "Status" },
      { field: "delete", headerName: "Delete" } // Added delete column
    ],
    costCenterLinkList: mockData,
    selectedRowGlCodes: null,
    deletedIds: [],
    savedIds: [],
    linkHide: [],
    linkUnhide: [],
    linkHideRows: [],
    linkUnhideRows: [],
    selectedRows: []
  },
  glCentreLedgerLinksView: {
    availableCostCentreList: [],
    availableLedgerCodeList: []
  },
  userAccessRights: {
    rights: []
  },
  generalLedgerFundCode: {
    newFundList: []
  },
  costCentreForm: {
    isCodeExist: false,
    isDescExist: false,
    isAbbrExist: false,
    costCenterDetailList: [],
    ccdErrorsState: {},
    focusedItem: null,
    ccdInputDetail: {
      cost_code: "",
      cost_des: "",
      cost_abrv: "",
      cost_hold: "",
      spendcheck: true,
      threshold: 100
    },
    costCenterTree: {},
    constCenterDetails: {},
    expandedItems: [],
    status: STATUS.SUCCESS
  },
  glLedgerCodes: {
    isWarnBudgetCheck: false
  }
};

const store = mockStore(initialState);

describe("CCentreLedgerLinks Component", () => {
  it("should render list of mock data in grid", () => {
    render(
      <Provider store={store}>
        <Router>
          <TabGroup>
            <CCentreLedgerLinks />
          </TabGroup>
        </Router>
      </Provider>
    );

    // Verify that the mock data is rendered in the grid
    mockData.forEach((item) => {
      expect(screen.getByText(item.name)).toBeInTheDocument();
      expect(screen.getByText(item.status)).toBeInTheDocument();
    });
  });

  it("should render delete buttons and handle delete action", () => {
    render(
      <Provider store={store}>
        <Router>
          <TabGroup>
            <CCentreLedgerLinks />
          </TabGroup>
        </Router>
      </Provider>
    );

    // Verify that delete buttons are rendered
    const deleteButtons = screen.getAllByText("Delete");
    expect(deleteButtons.length).toBe(1);

    // Simulate delete button click
    fireEvent.click(deleteButtons[0]);

    // Verify that the delete handler is called and the item is removed from the list
    const remainingItems = screen.queryByText(mockData[0].name);
    expect(remainingItems).toBeDefined();
  });

  it("should render save buttons and handle save action", () => {
    render(
      <Provider store={store}>
        <Router>
          <TabGroup>
            <CCentreLedgerLinks />
          </TabGroup>
        </Router>
      </Provider>
    );

    // Verify that save buttons are rendered
    const saveButtons = screen.getAllByText("common.save");
    expect(saveButtons.length).toBe(1);

    // Simulate save button click
    fireEvent.click(saveButtons[0]);

    // Verify that the save handler is called and the item is removed from the list
    const remainingItems = screen.queryByText(mockData[0].name);
    expect(remainingItems).toBeDefined();
  });

  it("should render cancel buttons and handle cancel action", () => {
    render(
      <Provider store={store}>
        <Router>
          <TabGroup>
            <CCentreLedgerLinks />
          </TabGroup>
        </Router>
      </Provider>
    );

    // Verify that cancel buttons are rendered
    const cancelButtons = screen.getAllByText("common.cancel");
    expect(cancelButtons.length).toBe(1);

    // Simulate cancel button click
    fireEvent.click(cancelButtons[0]);

    // Verify that the cancel handler is called and the item is removed from the list
    const remainingItems = screen.queryByText(mockData[0].name);
    expect(remainingItems).toBeDefined();
  });
});
