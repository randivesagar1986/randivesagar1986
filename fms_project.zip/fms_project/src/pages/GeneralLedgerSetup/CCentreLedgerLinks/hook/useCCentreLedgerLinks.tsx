import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useAppSelector } from "@/store/store";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { centreLinksAction, saveCostCenterLedgerLink } from "../../State/glCentreLedgerLinks.slice";

type TConfirmationPopup = {
  yesFunc?: () => void;
  noFunc?: () => void;
  cancelFunc?: () => void;
  changeTab: () => void;
  inputValidation?: boolean;
};

const useCCentreLedgerLinks = () => {
  const { deletedIds, savedIds, linkHide, linkUnhide, costCenterLinkList } = useAppSelector(
    (state) => state.glCentreLedgerLinks
  );
  const { resetFilters, setSavedIds } = centreLinksAction;
  /* eslint-disable camelcase */
  const dispatch = useDispatch();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const onSuccessSubmit = () => {};

  const generateBudgetXML = (budgetIds: any) => {
    let xmlOutput = "<budget>";
    budgetIds.forEach((budgetId: any) => {
      xmlOutput += `<budget_id>${budgetId}</budget_id>`;
    });
    xmlOutput += "</budget>";
    return xmlOutput;
  };

  const confirmationPopupCCL = ({ yesFunc, noFunc, cancelFunc, inputValidation = false }: TConfirmationPopup) => {
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        message: t("common.keepChangesWishMsg"),
        title: t("common.simsFMSModule"),
        type: MODAL_TYPE.CONFIRMV2,
        yesCallback: async () => {
          if (
            (deletedIds && deletedIds.length > 0) ||
            (savedIds && savedIds.length > 0) ||
            linkHide.length > 0 ||
            linkUnhide.length > 0
          ) {
            const linkAdd: any = savedIds.map((savedId) => ({
              ledger_id: savedId.ledger_id,
              cost_id: savedId.cost_id
            }));

            const linkHideIds = generateBudgetXML(linkHide || []);
            const linkHidePayload = { budget_ids: linkHideIds, hideBudgetLink: "H" };

            const linkUnhideIds = generateBudgetXML(linkUnhide || []);
            const linkUnHidePayload = { budget_ids: linkUnhideIds, hideBudgetLink: "U" };

            await dispatch(
              saveCostCenterLedgerLink({
                linkAdd,
                linkDelete: deletedIds,
                linkHide: linkHidePayload,
                linkUnhide: linkUnHidePayload,
                callback: onSuccessSubmit
              })
            );
            dispatch(setSavedIds([]));
            dispatch(resetFilters());
          } else {
            dispatch(resetFilters());
            dispatch(setSavedIds([]));
          }

          if (typeof yesFunc === "function") yesFunc();
        },
        noCallback: () => {
          dispatch(resetFilters());
          dispatch(setSavedIds([]));
          if (typeof noFunc === "function") noFunc();
        },
        isCancelBtnEnable: true,
        cancelCallback: () => {
          if (typeof cancelFunc === "function") cancelFunc();
        }
      })
    );
  };

  const isPayloadValidCCL = () =>
    deletedIds.length > 0 || savedIds.length > 0 || linkHide.length > 0 || linkUnhide.length > 0;

  return {
    confirmationPopupCCL,
    isPayloadValidCCL
  };
};

export default useCCentreLedgerLinks;
