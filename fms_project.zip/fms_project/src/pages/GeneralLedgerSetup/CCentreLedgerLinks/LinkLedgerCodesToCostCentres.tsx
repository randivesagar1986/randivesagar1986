import React, { useEffect, useRef } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import { Button, ButtonColor, ButtonSize, Grid, GridItem, NotificationStatus, Notification } from "@essnextgen/ui-kit";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS, getCurrentFinancialYear } from "@/types/UseStateType";
import { useDispatch } from "react-redux";
import Layout from "@/components/Layout/Layout";
import { useHistory } from "react-router-dom";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import BodyUtil from "@/shared/utils/NoScroll";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import GeneralLedgerSetup from "../GeneralLedgerSetup";
import CentreLedgerLinksFilterCostCentre from "./Grid/CentreLedgerLinksFilterCostCentre";
import AvailableLedgerCodeColumnDef from "./Grid/AvailableLedgerCodeColumnDef";
import CustomCell from "./Grid/CentreLedgerCustomCell";
import GeneralLedgerFooter from "../GeneralLedgerFooter";
import {
  getAvailableCostCentres,
  getAvailableLedgerCodes,
  centreLinksActionView,
  postCentreLedgerBudget
} from "../State/glCentreLedgerLinksView.slice";
import CentreLedgerLinksFilterLedgerFund from "./Grid/CentreLedgerLinksFilterLedgerFund";
import { centreLinksAction } from "../State/glCentreLedgerLinks.slice";

const LinkLedgerCodesToCostCentres = () => {
  const [modalMessage, setModalMessage] = React.useState<string>("");
  const [showDialog, setShowDialog] = React.useState<boolean>(false);
  const history = useHistory();
  const dispatch = useDispatch<AppDispatch>();
  const yesButtonRef = useRef<HTMLButtonElement>(null);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    availableCostCentreList,
    availableLedgerCodeList,
    isSelectedAllCostCentre,
    isSelectedAllLedgerCodeCentre,
    costCentreColumnDef,
    ledgerCodeColumnDef,
    status,
    selectedRowCostCentre,
    selectedRowLedgerFund
  } = useAppSelector((state) => state.glCentreLedgerLinksView);
  const { costCenterLinkList } = useAppSelector((state) => state.glCentreLedgerLinks);
  const userAccessRights = useAppSelector((state) => state.userAccessRights); // get user access rights
  const isCCLinksAddEnable = canDo(userAccessRights, {
    action: ACCESS_RIGHTS_ACTION.Define,
    module: ACCESS_RIGHTS_MODULE.GLCCLCLinks
  });

  useEffect(() => {
    if (!isCCLinksAddEnable) return;
    const currentFinancialYear = getCurrentFinancialYear();
    dispatch(getAvailableCostCentres({ financialYear: Number(currentFinancialYear) }));
    dispatch(getAvailableLedgerCodes({ financialYear: Number(currentFinancialYear) }));
  }, [isCCLinksAddEnable]);

  useEffect(() => {
    dispatch(centreLinksActionView.resetIsSelectedAllCostCentre());
    dispatch(centreLinksActionView.resetIsSelectedAllLedgerCodes());
    dispatch(centreLinksActionView.resetCostCentreFilters());
    dispatch(centreLinksActionView.resetLedgerCodeFilters());
    dispatch(centreLinksActionView.setSelectedRowCostCentre(availableCostCentreList[0]));
    dispatch(centreLinksActionView.setSelectedRowLedgerFund(availableLedgerCodeList[0]));
  }, []);

  const handleCostCentreTableHead = () => {
    dispatch(centreLinksActionView.setisSelectedAllCostCentre(!isSelectedAllCostCentre));
  };

  const handleLedgerCodeTableHead = () => {
    dispatch(centreLinksActionView.setisSelectedAllLedgerCode(!isSelectedAllLedgerCodeCentre));
  };

  useEffect(() => {
    setTimeout(() => {
      if (showDialog && yesButtonRef?.current) {
        yesButtonRef.current?.focus();
      }
    }, 100);
  }, [showDialog, yesButtonRef?.current]);

  const handleCancelCallback = () => {
    history.replace("/tools/general-ledger-setup/c-centre-ledger-links");
  };

  const handleCreateLink = () => {
    const checkForCCList = availableCostCentreList.some((item) => item.isSelected);
    const checkForLCList = availableLedgerCodeList.some((item) => item.isSelected);

    if (!checkForCCList && !checkForLCList) {
      history.replace("/tools/general-ledger-setup/c-centre-ledger-links");
      return;
    }

    const ledger_ids = availableLedgerCodeList // eslint-disable-line
      .filter((item) => !!item?.isSelected);
    const cost_ids = availableCostCentreList.filter((item) => !!item?.isSelected); // eslint-disable-line

    const rawSavedIds: any[] = [];
    // eslint-disable-next-line camelcase
    ledger_ids.forEach((ledger_id) => {
      // eslint-disable-next-line camelcase
      cost_ids.forEach((cost_id) => {
        rawSavedIds.push({ ...ledger_id, ...cost_id }); // eslint-disable-line
      });
    });

    const savedIds = rawSavedIds.filter(
      (savedId: any) =>
        !costCenterLinkList.some(
          (costCenterLinkItem) =>
            costCenterLinkItem.ledger_id === savedId.ledger_id && costCenterLinkItem.cost_id === savedId.cost_id
        )
    );
    dispatch(centreLinksAction.setSavedIds(savedIds));

    dispatch(
      postCentreLedgerBudget({
        ledger_id: ledger_ids.map((ledger_id) => ledger_id.ledger_id) as number[], // eslint-disable-line
        cost_id: cost_ids.map((cost_id) => cost_id.cost_id) as number[], // eslint-disable-line
        financialYear: Number(getCurrentFinancialYear()),
        callback(response: any) {
          setModalMessage(response.message);
          setShowDialog(true);
        }
      })
    );
  };

  return (
    <>
      {showDialog && (
        <Modalv2
          className="verify-balances-modal"
          header={t("alertMessage.title")}
          isOpen={showDialog}
          primaryButton={
            <Button
              id="link-ledger-modal-create-link-button"
              size={ButtonSize.Small}
              className="link-ledger-modal-create-link-button"
              ref={yesButtonRef}
              onClick={() => {
                history.push("/tools/general-ledger-setup/c-centre-ledger-links");
                dispatch(centreLinksActionView.setisSelectedAllCostCentre(false));
                dispatch(centreLinksActionView.setisSelectedAllLedgerCode(false));
                setModalMessage("");
                BodyUtil.NoScroll.remove();
                setShowDialog(false);
              }}
            >
              {t("common.ok")}
            </Button>
          }
          onClose={() => {
            history.push("/tools/general-ledger-setup/c-centre-ledger-links");
            dispatch(centreLinksActionView.setisSelectedAllCostCentre(false));
            dispatch(centreLinksActionView.setisSelectedAllLedgerCode(false));
            setModalMessage("");
            BodyUtil.NoScroll.remove();
            setShowDialog(false);
          }}
        >
          <>
            <Notification
              actionElement={1}
              className="confirm-modal-text"
              dataTestId="switch-to-list-warning-id"
              escapeExits
              id="switch-to-list-warning-id"
              hideCloseButton
              status={NotificationStatus.HIGHLIGHT}
              title={modalMessage}
            />
          </>
        </Modalv2>
      )}
      <GeneralLedgerSetup>
        <div className="general-ledger-link-ledgercodes-costcentres cost-centre-ledger-codes-scroll-height">
          <Layout isBreadcrumbRequired={false}>
            <Grid
              container
              className="padding-top16"
            >
              <GridItem
                sm={4}
                md={8}
                lg={6}
                xl={6}
              >
                <Grid className="mb-16 mr-bt10">
                  <GridItem sm={4}>
                    <div className="essui-global-typography-default-subtitle pb-16">
                      {t("generalLedgerSetup.availableCC")}
                    </div>
                    <GridTableNew
                      dataTestId="cdgentralLedgerLinksListCostCentres"
                      filters={<CentreLedgerLinksFilterCostCentre />}
                      columnDef={costCentreColumnDef}
                      isLoading={status === STATUS.LOADING}
                      selectedRow={selectedRowCostCentre}
                      dataSource={availableCostCentreList || []}
                      isRowSelectionEnabled
                      isScrollable
                      customCell={CustomCell}
                      handleTableHeadChange={handleCostCentreTableHead}
                      isSelectedAll={isSelectedAllCostCentre}
                      checkedRows={availableCostCentreList.filter((item) => item.isSelected)}
                      checkedRowHandler={(rows) => {
                        dispatch(centreLinksActionView.setisSelectedAllCostCentre(false));
                        // eslint-disable-next-line
                        rows.map((row: any) => {
                          dispatch(
                            centreLinksActionView.setAvailableCostCentreList({
                              cost_id: row?.cost_id,
                              isSelected: true
                            })
                          );
                        });
                      }}
                    />
                  </GridItem>
                </Grid>
              </GridItem>
              <GridItem
                sm={4}
                md={8}
                lg={6}
                xl={6}
              >
                <Grid className="mb-16">
                  <GridItem sm={4}>
                    <div className="essui-global-typography-default-subtitle pb-16">
                      {t("generalLedgerSetup.availableLC")}
                    </div>
                    <GridTableNew
                      dataTestId="cdgentralLedgerLinksListLedgerCodes"
                      filters={<CentreLedgerLinksFilterLedgerFund />}
                      columnDef={ledgerCodeColumnDef}
                      isLoading={status === STATUS.LOADING}
                      dataSource={availableLedgerCodeList || []}
                      isRowSelectionEnabled
                      isScrollable
                      selectedRow={selectedRowLedgerFund}
                      customCell={CustomCell}
                      isSelectedAll={isSelectedAllLedgerCodeCentre}
                      handleTableHeadChange={handleLedgerCodeTableHead}
                      checkedRows={availableLedgerCodeList.filter((item) => item.isSelected)}
                      checkedRowHandler={(rows) => {
                        dispatch(centreLinksActionView.setisSelectedAllLedgerCode(false));
                        // eslint-disable-next-line
                        rows.map((row: any) => {
                          dispatch(
                            centreLinksActionView.setAvailableLedgerCodeList({
                              ledger_id: row?.ledger_id,
                              isSelected: true
                            })
                          );
                        });
                      }}
                    />
                  </GridItem>
                </Grid>
              </GridItem>
            </Grid>
          </Layout>
        </div>
        <GeneralLedgerFooter
          onCreateLink={handleCreateLink}
          cancelCallback={handleCancelCallback}
        />
      </GeneralLedgerSetup>
    </>
  );
};
export default LinkLedgerCodesToCostCentres;
