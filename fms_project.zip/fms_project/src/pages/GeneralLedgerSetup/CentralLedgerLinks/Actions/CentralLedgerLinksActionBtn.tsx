import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import useLinkUnlink from "../hook";

const CentralLedgerLinksActionBtn = ({ isDisabled = false }: { isDisabled: boolean }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const linkHandler = useLinkUnlink();

  return (
    <div className="d-flex mr-24 justify-end">
      <Button
        disabled={isDisabled}
        size={ButtonSize.Small}
        color={ButtonColor.Primary}
        onClick={linkHandler}
      >
        {t("generalLedgerSetup.centralLedgerLink.linkUnlink")}
      </Button>
    </div>
  );
};

export default CentralLedgerLinksActionBtn;
