import useDebounce from "@/hooks/useDebounce";
import { useAppSelector } from "@/store/store";
import findNearest from "@/utils/nearestSearch";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { FormLabel, Grid, GridItem, TextInput } from "@essnextgen/ui-kit";
import React, { useEffect, useRef } from "react";
import { useDispatch } from "react-redux";
import { el } from "date-fns/locale";
import { centralLinksAction } from "../../State/glCentralLedgerLinks.slice";

const CentralLedgerLinksFilter = () => {
  const dispatch = useDispatch();
  const lookingRef = useRef<HTMLInputElement | null>(null);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { setFilters, selectGlListSelectedRow, reset } = centralLinksAction;
  const { filters, centralLedgerLinksList } = useAppSelector((state) => state.glCentralLedgerLinks);
  const debouncedValue = useDebounce(filters?.lookingFor!, 600);
  useEffect(() => {
    if (debouncedValue !== "" && centralLedgerLinksList && centralLedgerLinksList?.length) {
      let found;
      found = [...centralLedgerLinksList]
        .filter((element) =>
          debouncedValue ? element.ledger_fund.toString()?.toUpperCase()?.startsWith(debouncedValue!) : false
        )
        .at(0);

      if (found && found !== undefined) selectGlListSelectedRow(found);
      if (found === undefined) {
        found = findNearest(
          [...centralLedgerLinksList],
          [{ fieldName: "ledger_fund", searchValue: debouncedValue }],
          true
        );
        selectGlListSelectedRow(found);
      }
      const element = document.getElementById(
        `rowIndex-centralLedgerLinksList-${centralLedgerLinksList.indexOf(found!)}`
      );
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
      dispatch(selectGlListSelectedRow(found));
    } else if (centralLedgerLinksList && centralLedgerLinksList?.length) {
      dispatch(selectGlListSelectedRow(centralLedgerLinksList.at(0)));
    }
  }, [debouncedValue]);

  useEffect(() => {
    dispatch(reset());
    if (lookingRef.current) {
      lookingRef.current.focus();
    }
  }, []);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    dispatch(setFilters({ lookingFor: value.toUpperCase() }));
  };

  return (
    <Grid>
      <GridItem
        sm={3}
        md={3}
        xl={3}
      >
        <div className="essui-global-typography-default-h2 ">
          <FormLabel forId="looking-for">{t("purchaseOrder.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              value={filters?.lookingFor}
              inputRef={lookingRef}
              onKeyDown={(event) => {
                // eslint-disable-next-line
                if (/^[a-zA-Z0-9\s\-]*$/.test(event.key) === false) {
                  event.preventDefault();
                }
              }}
              onChange={(e) => handleLookingForChange(e)}
              id="looking-for"
              autoComplete={false}
            />
          </div>
        </div>
      </GridItem>
    </Grid>
  );
};

export default CentralLedgerLinksFilter;
