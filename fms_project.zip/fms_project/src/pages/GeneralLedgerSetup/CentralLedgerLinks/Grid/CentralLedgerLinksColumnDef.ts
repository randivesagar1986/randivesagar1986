import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const CentralLedgerLinksColumnDef: TColumnDef = [
  {
    headerName: "Ledger-Fund",
    field: "ledger_fund",
    columnWidth: 10
  },
  {
    headerName: "Ledger Description",
    field: "ledger_des",
    columnWidth: 20
  },
  {
    headerName: "Cost Centre Code",
    field: "cost_code",
    columnWidth: 10
  },
  {
    headerName: "Cost Centre Description",
    field: "cost_des",
    columnWidth: 20
  },
  {
    headerName: "Link",
    align: "center",
    field: "autorec_default",
    cellRenderer: "GridCellLink",
    columnWidth: 5
  }
];

export default CentralLedgerLinksColumnDef;
