import { Grid, GridItem } from "@essnextgen/ui-kit";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { useDispatch } from "react-redux";
import React, { useEffect, useState } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import { useClickAway } from "@/hooks/useClickAway";
import GeneralLedgerSetup from "../GeneralLedgerSetup";
import GenralLedgerFooter from "../GeneralLedgerFooter";
import CentralLedgerLinksFilter from "./Filter/CentralLedgerLinksFilter";
import CentralLedgerLinksActionBtn from "./Actions/CentralLedgerLinksActionBtn";
import {
  centralLinksAction,
  getCentralLedgerLinksList,
  updateCentralLedgerLinksList
} from "../State/glCentralLedgerLinks.slice";
import CentralLedgerLinksColumnDef from "./Grid/CentralLedgerLinksColumnDef";
import CustomCell from "./Grid/CentralLedgerLinksCustomCell";
import useLedgerGrpPopup from "../hooks/useLedgerGrpPopup";

const CentralLedgerLinks: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { setTabData } = useLedgerGrpPopup();
  const { selectGlListSelectedRow, removeItemFromUpdateList, setCentralCancelBtnClick } = centralLinksAction;
  const { updateList, selectedRowGlCodes, viewCentralledgerlinkslist, status, costCenterLinkList } = useAppSelector(
    (state: any) => state.glCentralLedgerLinks
  );
  const [isListLoading, setIsListLoading] = useState(true);
  const userAccessRights = useAppSelector((state) => state.userAccessRights); // get user access rights
  const canAddEdit = canDo(userAccessRights, {
    action: ACCESS_RIGHTS_ACTION.Edit,
    module: ACCESS_RIGHTS_MODULE.GLCentralLedgerLinks
  });
  const isBtnDisable = canAddEdit !== undefined ? !canAddEdit : false;
  const isCentralLinksTabVisible = canDo(userAccessRights, {
    action: ACCESS_RIGHTS_ACTION.View,
    module: ACCESS_RIGHTS_MODULE.GLCentralLedgerLinks
  });

  const submitHandler = async () => {
    if (updateList && updateList?.length > 0) {
      setIsListLoading(true);
      await dispatch(updateCentralLedgerLinksList());
      await dispatch(getCentralLedgerLinksList());
      dispatch(removeItemFromUpdateList([]));
      setIsListLoading(false);
    }
  };
  const handleCancelCallBack = () => {
    setTabData("/");
    dispatch(setCentralCancelBtnClick(true));
  };

  useEffect(() => {
    if (!isCentralLinksTabVisible) return;
    dispatch(getCentralLedgerLinksList());
  }, [isCentralLinksTabVisible]);

  useEffect(() => {
    if (status !== STATUS.LOADING) {
      setTimeout(() => {
        setIsListLoading(false);
      }, 1500);
    }
  }, [status]);

  // Click Away Functionality Start Here

  const yesCallback = async () => {
    submitHandler();
    return true;
  };

  const noCallback = () => {
    dispatch(removeItemFromUpdateList([]));
    dispatch(getCentralLedgerLinksList());
  };
  useClickAway({
    isDirty: updateList && updateList?.length > 0,
    yesCallback,
    noCallback,
    cancelCallback: () => {}
  });
  // Click Away Functionality End Here
  return (
    <>
      <GeneralLedgerSetup>
        <div className="general-ledger-listing-container central-ledger-link-scroll-height">
          <Grid container>
            <GridItem
              sm={12}
              md={12}
              lg={12}
              xl={12}
            >
              <GridTableNew
                dataTestId="centralLedgerLinksList"
                filters={<CentralLedgerLinksFilter />}
                columnDef={CentralLedgerLinksColumnDef}
                isLoading={isListLoading}
                dataSource={viewCentralledgerlinkslist}
                isRowSelectionEnabled
                isScrollable
                actions={<CentralLedgerLinksActionBtn isDisabled={isBtnDisable} />}
                customCell={CustomCell}
                selectedRow={selectedRowGlCodes}
                selectedRowHandler={(row) => {
                  dispatch(selectGlListSelectedRow(row));
                }}
              />
            </GridItem>
          </Grid>
        </div>
        <GenralLedgerFooter
          disableSubmit={isBtnDisable}
          onSubmit={submitHandler}
          cancelCallback={handleCancelCallBack}
        />
      </GeneralLedgerSetup>
    </>
  );
};
export default CentralLedgerLinks;
