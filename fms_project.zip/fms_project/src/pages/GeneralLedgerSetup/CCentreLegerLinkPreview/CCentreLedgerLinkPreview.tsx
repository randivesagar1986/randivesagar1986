import PreviewSection from "@/shared/components/Preview/PreviewSection";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import { useCCentreLinkPreview } from "./useCCentreLegerLinkPre";

const CCentreLedgerLinkPreview = () => {
  const { handlePdfClick, handleCsvClick, handleXmlClick, t, isLoading, fileObj } = useCCentreLinkPreview();
  const loaderConfig: loadingConfig = {
    loadingText: t("generalLedgerSetup.centralLedgerLink.downloadingFile"),
    isLoaderModal: true
  };
  return (
    <>
      {isLoading ? <Loader loadingConfig={loaderConfig} /> : null}
      <PreviewSection
        pageTitle={t("generalLedgerSetup.centralLedgerLink.preview")}
        isBreadcrumbRequired
        className="c-centre-ledger-links wrapper__radius--0"
        pdfSrc={fileObj?.fileData}
        onPdfClick={handlePdfClick}
        onCsvClick={handleCsvClick}
        onXmlClick={handleXmlClick}
        isLoading={isLoading}
      />
    </>
  );
};

export default CCentreLedgerLinkPreview;
