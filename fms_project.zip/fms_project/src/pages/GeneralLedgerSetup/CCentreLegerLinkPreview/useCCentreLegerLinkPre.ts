import {
  getCCentreLinkBudgetPrintPDF,
  getCCentreLinkBudgetPrintCSV,
  getCCentreLinkBudgetPrintXML
} from "@/pages/GeneralLedgerSetup/State/CCentreLedgerLinkPreview.slice";
import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { getCurrentFinancialYear } from "@/types/UseStateType";
import { useHistory } from "react-router-dom";

export const useCCentreLinkPreview = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const { spid } = useAppSelector((state) => state.glCentreLedgerLinks);
  const [pdfUri, setPdfUri] = useState<string>("");
  const [isLoading, setLoading] = useState<boolean>(false);
  const history = useHistory();
  const historyState = { ...(history.location.state as any) };

  const [fileObj, setFileObj] = useState<{
    fileData: string;
  }>({
    fileData: ""
  });

  useEffect(() => {
    createPdfPreviewFromBase64();
  }, []);

  const createPdfPreviewFromBase64 = async () => {
    try {
      const { payload } = await dispatch(
        getCCentreLinkBudgetPrintPDF({
          payload: historyState?.ledgerBudgetLink?.centreLinkLedgerCostCentrePrintData,
          FinancialYear: getCurrentFinancialYear()
        })
      );
      const { data } = payload as any;
      const blob = new Blob([data], { type: "application/pdf" });
      const pdfUri = URL.createObjectURL(blob);
      setFileObj({
        fileData: pdfUri
      });
    } catch (error) {
      // console.error("Error decoding base64 string:", error);  //TODO: Error Handling
    }
  };

  const handlePdfClick = async () => {
    setLoading(true);
    const { payload } = await dispatch(
      getCCentreLinkBudgetPrintPDF({
        payload: historyState?.ledgerBudgetLink?.centreLinkLedgerCostCentrePrintData,
        FinancialYear: getCurrentFinancialYear()
      })
    );
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/pdf" });
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName || "Centre Ledger Links Failure Report.pdf";
    link.click();
    setLoading(false);
  };

  const handleCsvClick = async () => {
    setLoading(true);
    const { payload } = await dispatch(
      getCCentreLinkBudgetPrintCSV({
        payload: historyState?.ledgerBudgetLink?.centreLinkLedgerCostCentrePrintData,
        FinancialYear: getCurrentFinancialYear()
      })
    );
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName || "Centre Ledger Links Failure Report.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  const handleXmlClick = async () => {
    setLoading(true);
    const { payload } = await dispatch(
      getCCentreLinkBudgetPrintXML({
        payload: historyState?.ledgerBudgetLink?.centreLinkLedgerCostCentrePrintData,
        FinancialYear: getCurrentFinancialYear()
      })
    );
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/xml" });
    // Create a download link for the Blob
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName || "Centre Ledger Links Failure Report.xml";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  return {
    handlePdfClick,
    handleCsvClick,
    handleXmlClick,
    pdfUri,
    fileObj,
    t,
    isLoading
  };
};

export default useCCentreLinkPreview;
