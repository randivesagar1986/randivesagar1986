import { useEffect } from "react";
import Modal from "@/components/Modal/Modal";
import { Grid, GridItem } from "@essnextgen/ui-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { METHOD, specialCharacters, STATUS } from "@/types/UseStateType";
import { getDate, usNumberFormat } from "@/utils/getDataSource";
import BodyUtil from "@/shared/utils/NoScroll";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useHistory } from "react-router-dom";
import { getPettyCashExpenseFolio, viewPettyCashExpFolioAcitons } from "../state/ViewPettyCashExpenseFolio.slice";

type TPettyCashExpenseFolioModalProp = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  pcFolioId: string;
};

const loaderConfig: loadingConfig = {};
const ViewPettyCashExpenseFolioModal = ({ isOpen, setOpen, pcFolioId }: TPettyCashExpenseFolioModalProp) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const { expenseFolioDetails, status } = useAppSelector((state) => state.viewPettyCashExpenseFolio);
  const history = useHistory();
  const historyState = { ...(history.location.state as any) };

  const getDisplayValue = (code: any, description: any) => {
    if (code || description) {
      return `${code || ""}   ${description || ""}`;
    }
    return specialCharacters.HYPHEN;
  };

  useEffect(() => {
    if (pcFolioId && isOpen) {
      if (historyState?.mode === METHOD.ADJUST) {
        const selectedAjustedRow = historyState?.expenditureItems?.find((item: any) => item?.pc_folio_id === pcFolioId);
        dispatch(viewPettyCashExpFolioAcitons.resetExpenseFolioDetails(selectedAjustedRow));
      } else {
        dispatch(getPettyCashExpenseFolio({ pcFolioId }));
      }
    }
  }, [pcFolioId, isOpen]);

  return (
    <Modal
      isOpen={isOpen}
      primaryBtnText={t("common.close")}
      primaryBtnClick={() => {
        BodyUtil.NoScroll.remove();
        setOpen(false);
      }}
      fourthiaryBtnClick={() => {}}
      className="dialog__divider"
      onClose={() => {
        BodyUtil.NoScroll.remove();
        setOpen(false);
      }}
      header={t("viewExpenditure.viewExpenseFolioModalTitle")}
    >
      {status === STATUS.LOADING ? (
        <Loader loadingConfig={loaderConfig} />
      ) : (
        <div className="overflow-hidden">
          <Grid className="wrap-data row-gap-16">
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.folioNo")}</div>
              <div>{expenseFolioDetails?.pc_folio_no ?? specialCharacters.HYPHEN}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.receiptDate")}</div>
              <div>{getDate(expenseFolioDetails?.receipt_date)}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.costCentre")}</div>
              <div>{getDisplayValue(expenseFolioDetails?.cost_code, expenseFolioDetails?.cost_des)}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.ledgerCode")}</div>
              <div>{getDisplayValue(expenseFolioDetails?.ledger_code, expenseFolioDetails?.ledger_des)}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.fund")}</div>
              <div>{getDisplayValue(expenseFolioDetails?.fund_code, expenseFolioDetails?.fund_des)}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.vatRegNo")}</div>
              <div>{expenseFolioDetails?.vat_reg_no ?? specialCharacters.HYPHEN}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={12}
              lg={12}
              xl={12}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.desc")}</div>
              <div>{expenseFolioDetails?.description ?? specialCharacters.HYPHEN}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.totalIncVat")}</div>
              <div>{usNumberFormat(expenseFolioDetails?.line_cost)}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.vatCode")}</div>
              <div>{getDisplayValue(expenseFolioDetails?.vat_code, expenseFolioDetails?.vat_des)}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={3}
              xl={3}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.amountOfVat")}</div>
              <div>{usNumberFormat(expenseFolioDetails?.vat_amount)}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={3}
              xl={3}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.totalExcVat")}</div>
              <div>{usNumberFormat(expenseFolioDetails?.net_amount)}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={3}
              xl={3}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.costToEstablishment")}</div>
              <div>{usNumberFormat(expenseFolioDetails?.cost_to_establishment)}</div>
            </GridItem>
          </Grid>
        </div>
      )}
    </Modal>
  );
};
export default ViewPettyCashExpenseFolioModal;
