import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { OrderType, STATUS } from "@/types/UseStateType";

type TPettyCashExpenseFolioState = {
  error: string | undefined;
  status?: STATUS;
  expenseFolioDetails?: { [key: string]: any };
};

const initialState: TPettyCashExpenseFolioState = {
  error: "",
  expenseFolioDetails: undefined
};

/** Thunks */

export const getPettyCashExpenseFolio = createAsyncThunk(
  "pettyCash/petty-cash-exp-folios",
  async ({ pcFolioId, callback }: { pcFolioId: string; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/petty-cash/petty-cash-exp-folios`, {
      params: { pcFolioId }
    });
    if (callback) callback(response.data);
    return response.data;
  }
);

/**
 * This slice of state is responsible for storing petty cash expense folio state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** petty cash expense folio state */
    builder
      .addCase(getPettyCashExpenseFolio.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getPettyCashExpenseFolio.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.expenseFolioDetails = action.payload;
        state.error = undefined;
      })
      .addCase(getPettyCashExpenseFolio.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      });
  },
  initialState,
  name: "viewPettyCashExpenseFolio",
  reducers: {
    resetExpenseFolioDetails: (state, action: PayloadAction<any>) => {
      state.expenseFolioDetails = action.payload;
    }
  }
});

export const { actions: viewPettyCashExpFolioAcitons, reducer } = slice;
export default reducer;
