import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { OrderType, STATUS } from "@/types/UseStateType";

type TPettyCashExpenseFolio = {
  error: string | undefined;
  status?: STATUS;
  reimbursmentStatus?: STATUS;
  costEstdAmtAPIStatus?: STATUS;
  printChequeStatus?: STATUS;
  expenseItemDetailAPIStatus?: STATUS;
  expenseItemDetail: { [key: string]: any } | undefined;
  saveExpenseFolioItemStatus?: STATUS;
  deleteExpenseFolioStatus?: STATUS;
  fcSourceBalanceStatus?: STATUS;
  isAdjustDeleteTriggered?: boolean;
  adjustedData: { [key: string]: any } | undefined;
  isAdjustEditTriggered?: boolean;
};
const initialState: TPettyCashExpenseFolio = {
  error: "",
  isAdjustDeleteTriggered: false,
  adjustedData: undefined,
  isAdjustEditTriggered: false,
  expenseItemDetail: undefined
};

/** Thunks */
export const getVatAmount = createAsyncThunk(
  "petty-cash/petty-cash-calulate-vat",
  async ({ amount, vatId, callback }: { amount: string; vatId: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/petty-cash/petty-cash-calulate-vat`, {
      params: { amount, vatId }
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);
export const getVatId = createAsyncThunk(
  "common/default-vatId",
  async ({ leddefId, callback }: { leddefId: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/common/default-vatId`, {
      params: { leddefId }
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);
export const getCostEstablismentAmt = createAsyncThunk(
  "petty-cash/petty-cash-calulate-Establisment",
  async ({
    grossAmount,
    VatAmount,
    vatId,
    callback
  }: {
    grossAmount: string;
    VatAmount: string;
    vatId: number;
    callback?: (data: any) => void;
  }) => {
    const response = await client.get(`${apiRoot}/petty-cash/petty-cash-calulate-Establisment`, {
      params: { grossAmount, VatAmount, vatId }
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);
export const getNoOfPagesLeft = createAsyncThunk(
  "petty-cash/petty-cash-book-pages-left",
  async ({ bookId, callback }: { bookId: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/petty-cash/petty-cash-book-pages-left`, {
      params: { bookId }
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);
export const saveExpenseFolio = createAsyncThunk(
  "petty-cash/petty-cash-expenditure",
  async ({ formData, callback }: { formData: any; callback?: (data: any) => void }) => {
    const response = await client.post(`${apiRoot}/petty-cash/petty-cash-expenditure`, {
      ...formData
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const deleteExpenseFolio = createAsyncThunk(
  "petty-cash/petty-cash-exp-folios",
  async ({
    pcFolioId,
    autoCommit,
    callback
  }: {
    pcFolioId: number;
    autoCommit: string;
    callback?: (data: any) => void;
  }) => {
    const response = await client.delete(`${apiRoot}/petty-cash/petty-cash-exp-folios`, {
      params: { pcFolioId, autoCommit }
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);
export const getExpenseItemDetail = createAsyncThunk(
  "petty-cash/get-petty-cash-exp-folios",
  async ({ pcFolioId }: { pcFolioId: number }) => {
    const response = await client.get(`${apiRoot}/petty-cash/petty-cash-exp-folios`, {
      params: { pcFolioId }
    });
    return response.data;
  }
);

/**
 * This slice of state is responsible for storing PCView details state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** PCView details state */
    builder
      .addCase(getVatAmount.pending, (state) => {
        state.reimbursmentStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getVatAmount.fulfilled, (state, action: PayloadAction<any>) => {
        state.error = undefined;
        state.reimbursmentStatus = STATUS.SUCCESS;
      })
      .addCase(getVatAmount.rejected, (state, action: PayloadAction<any>) => {
        state.reimbursmentStatus = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      })
      .addCase(getCostEstablismentAmt.pending, (state) => {
        state.costEstdAmtAPIStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getCostEstablismentAmt.fulfilled, (state, action: PayloadAction<any>) => {
        state.error = undefined;
        state.costEstdAmtAPIStatus = STATUS.SUCCESS;
      })
      .addCase(getCostEstablismentAmt.rejected, (state, action: PayloadAction<any>) => {
        state.costEstdAmtAPIStatus = STATUS.FAILED;
      })
      .addCase(getExpenseItemDetail.pending, (state) => {
        state.expenseItemDetailAPIStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getExpenseItemDetail.fulfilled, (state, action: PayloadAction<any>) => {
        state.error = undefined;
        state.expenseItemDetailAPIStatus = STATUS.SUCCESS;
        state.expenseItemDetail = action.payload;
      })
      .addCase(getExpenseItemDetail.rejected, (state, action: PayloadAction<any>) => {
        state.expenseItemDetailAPIStatus = STATUS.FAILED;
      })
      .addCase(getNoOfPagesLeft.pending, (state) => {
        state.reimbursmentStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getNoOfPagesLeft.fulfilled, (state, action: PayloadAction<any>) => {
        state.error = undefined;
        state.reimbursmentStatus = STATUS.SUCCESS;
      })
      .addCase(getNoOfPagesLeft.rejected, (state, action: PayloadAction<any>) => {
        state.reimbursmentStatus = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      })
      .addCase(saveExpenseFolio.pending, (state) => {
        state.saveExpenseFolioItemStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(saveExpenseFolio.fulfilled, (state, action: PayloadAction<any>) => {
        state.error = undefined;
        state.saveExpenseFolioItemStatus = STATUS.SUCCESS;
      })
      .addCase(saveExpenseFolio.rejected, (state, action: PayloadAction<any>) => {
        state.saveExpenseFolioItemStatus = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      })
      .addCase(deleteExpenseFolio.pending, (state) => {
        state.deleteExpenseFolioStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(deleteExpenseFolio.fulfilled, (state, action: PayloadAction<any>) => {
        state.error = undefined;
        state.deleteExpenseFolioStatus = STATUS.SUCCESS;
      })
      .addCase(deleteExpenseFolio.rejected, (state, action: PayloadAction<any>) => {
        state.deleteExpenseFolioStatus = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      });
  },
  initialState,
  name: "PettyCashExpenseFolio",
  reducers: {
    setIsAdjustDeleteTriggered: (state, action: PayloadAction<any>) => {
      state.isAdjustDeleteTriggered = action.payload;
    },
    setIsAdjustEditTriggered: (state, action: PayloadAction<any>) => {
      state.isAdjustEditTriggered = action.payload;
    },
    setAdjustedData: (state, action: PayloadAction<any>) => {
      state.adjustedData = action.payload;
    },
    resetExpenseItemDetail: (state, action: PayloadAction<any>) => {
      state.expenseItemDetail = action.payload;
    }
  }
});
export const { actions: expenseFolioActions, reducer } = slice;
export default reducer;
