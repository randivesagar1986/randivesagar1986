import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { OrderType, STATUS } from "@/types/UseStateType";

type TPettyCashPostingDetailsState = {
  error: string | undefined;
  status?: STATUS;
  pettyCashPostingDetails?: { [key: string]: any };
};

const initialState: TPettyCashPostingDetailsState = {
  error: "",
  pettyCashPostingDetails: undefined
};

/** Thunks */

export const getPettyCashPostingDetails = createAsyncThunk(
  "pettyCash/petty-cash-posting-details",
  async ({ pcTransId, callback }: { pcTransId: string; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/petty-cash/petty-cash-posting-details`, {
      params: { pcTransId }
    });
    if (callback) callback(response.data);
    return response.data;
  }
);

/**
 * This slice of state is responsible for storing petty cash posting details state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** petty cash posting details state */
    builder
      .addCase(getPettyCashPostingDetails.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getPettyCashPostingDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.pettyCashPostingDetails = action.payload;
        state.error = undefined;
      })
      .addCase(getPettyCashPostingDetails.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      });
  },
  initialState,
  name: "pettyCashPostingDetails",
  reducers: {}
});

export const { actions, reducer } = slice;
export default reducer;
