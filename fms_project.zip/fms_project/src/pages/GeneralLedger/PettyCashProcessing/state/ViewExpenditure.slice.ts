import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { STATUS } from "@/types/UseStateType";

type TExpenditureDetails = {
  expenditureHeader: { [key: string]: any };
  expenditureItems: { [key: string]: any }[];
};

type TExpenditureDetailsState = {
  error: string | undefined;
  expenditureApiStatus?: STATUS;
  expenditureDetails: TExpenditureDetails;
  selectedExpenditureRow?: { [key: string]: any };
  isDirty?: boolean;
};

const initialState: TExpenditureDetailsState = {
  error: "",
  expenditureDetails: {
    expenditureHeader: {},
    expenditureItems: []
  }
};

/** Thunks */
export const getExpenditureDetails = createAsyncThunk(
  "pettyCash/expenditureDetails",
  async ({
    pcAccountId,
    transId,
    callback
  }: {
    pcAccountId: string;
    transId: string;
    callback?: (data: any) => void;
  }) => {
    const response = await client.get(`${apiRoot}/petty-cash/petty-cash-expendeture`, {
      params: { pcAccountId, transId }
    });
    if (callback) callback(response.data);
    return response.data;
  }
);

export const getUnpostedTransId = createAsyncThunk(
  "pettyCash/getUnpostedTransId",
  async ({ pcAccountId, callback }: { pcAccountId: string; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/petty-cash/petty-cash-unposted-exp`, {
      params: { pcAccountId }
    });
    if (callback) callback(response.data);
    return response.data;
  }
);

export const saveExpenditure = createAsyncThunk(
  "petty-cash/save-expenditure",
  async ({ formData, callback }: { formData: any; callback?: (data: any) => void }) => {
    const response = await client.post(`${apiRoot}/petty-cash/petty-cash-save-Expenditure-Header`, {
      ...formData
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * This slice of state is responsible for storing expenditure details state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** ExpenditureView details state */
    builder
      .addCase(getExpenditureDetails.pending, (state) => {
        state.expenditureApiStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getExpenditureDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.expenditureApiStatus = STATUS.SUCCESS;
        state.expenditureDetails = action.payload;
        state.error = undefined;
      })
      .addCase(getExpenditureDetails.rejected, (state, action: PayloadAction<any>) => {
        state.expenditureApiStatus = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      });
  },
  initialState,
  name: "ExpenditureDetails",
  reducers: {
    resetExpenditureDetails: (state) => {
      state.expenditureDetails = initialState.expenditureDetails;
    },
    setSelectedExpenditureRow: (state, action: PayloadAction<any>) => {
      state.selectedExpenditureRow = action.payload;
    },
    setPettyCashBookDirty: (state, action: PayloadAction<any>) => {
      state.isDirty = action.payload;
    }
  }
});
export const { actions: expenditureActions, reducer } = slice;
export default reducer;
