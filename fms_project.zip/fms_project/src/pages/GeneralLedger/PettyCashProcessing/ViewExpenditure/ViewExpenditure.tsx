import { useState } from "react";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  NotificationStatus,
  Notification,
  Tag,
  TagColor,
  TagSize
} from "@essnextgen/ui-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { METHOD, STATUS } from "@/types/UseStateType";
import { usNumberFormat } from "@/utils/getDataSource";
import { FormProvider } from "react-hook-form";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import Modal from "@/components/Modal/Modal";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import { SidebarMenu } from "@/components/SidebarMenu/SidebarMenu";
import useViewExpenditure from "./useViewExpenditure";
import expenditureColDef from "./Grid/columnDef";
import CustomCell from "./Grid/CustomCell";
import PettyCashToolbar from "../PettyCashToolbar";
import PettyCashPageToolbar from "../PettyCashPageToolbar";
import "./Style.scss";
import ViewExpenditureFilters from "./Grid/ViewExpenditureFilters";
import ViewPostingDetailsModal from "../ViewPostingDetailsModal/ViewPostingDetailsModal";
import { expenditureActions } from "../state/ViewExpenditure.slice";

const loaderConfig: loadingConfig = {};
const ViewExpenditure = () => {
  const dispatch = useDispatch<AppDispatch>();
  const [openInsufficientAccessModal, setOpenInsufficientAccessModal] = useState<boolean>(false);
  const {
    t,
    loading,
    expenditureApiStatus,
    onRowSelect,
    selectedExpenditureRow,
    selectedPettyCashRow,
    isUndoModalOpen,
    setIsUndoModalOpen,
    selectNextRecord,
    setOpenSaveChangesModal,
    openSaveChangesModal,
    undoChangeAndNavigate,
    selectPrevRecord,
    isCancelDisabled,
    isAdjustTransDisabled,
    handleViewAdjustmentClick,
    handleViewOriginalClick,
    onFocusClickHandler,
    undoChangeHandler,
    printButtonHandler,
    expenditureHeader,
    deleteRecord,
    setIsDeleteModalOpen,
    onFocusNoButton,
    onFocusYesButton,
    isDeleteModalOpen,
    expenditureItems,
    historyState,
    deletePettyCashStatus,
    printPettyCashStatus,
    getPageTitle,
    onDelete,
    getPettyCashAccountValue,
    isToolbarAddDisabled,
    isToolbarDeleteDisabled,
    isToolbarPrintDisabled,
    isViewPostingDetailsDisabled,
    isViewPostingDetailsModalOpen,
    setIsViewPostingDetailsModalOpen,
    transId,
    goToAdd,
    isPostDisabled,
    formMethods,
    onSubmitHandler,
    openAlertModal,
    setOpenAlertModal,
    alertMessage,
    postTransHandler,
    adjustTransHandler,
    setIsAdjustSubmitClicked
  } = useViewExpenditure();
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const canDoFolio = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.RaiseFolios
  });
  const goToAddExpenditure = () => {
    if (canDoFolio) {
      goToAdd();
    } else {
      setOpenInsufficientAccessModal(true);
    }
  };
  const UNPOSTED = {
    Unposted_Exp: "Unposted Expenditure"
  };
  const { deleteExpenseFolioStatus } = useAppSelector((state) => state.PettyCashExpenseFolio);
  const getLedgerStrings = () => {
    if (selectedExpenditureRow?.ledger_code) {
      return (
        <div className="ledger-fund-string">
          <div>{selectedExpenditureRow?.ledger_code}</div>
          <div>{selectedExpenditureRow?.fund_code}</div>
          <div>{selectedExpenditureRow?.ledger_des}</div>
        </div>
      );
    }
    return "-";
  };
  const getCostCenterString = () => {
    if (selectedExpenditureRow?.cost_code && selectedExpenditureRow?.cost_des) {
      return (
        <div className="ledger-fund-string">
          <div>{selectedExpenditureRow?.cost_code}</div>
          <div>{selectedExpenditureRow?.cost_des}</div>
        </div>
      );
    }
    return "-";
  };
  const getTagElement = () => (
    <div className="heading__tag expenditure-header">
      <Tag
        text={
          getPettyCashAccountValue("trans_no") && historyState?.mode !== METHOD.ADJUST
            ? getPettyCashAccountValue("trans_no")
            : t("viewExpenditure.pendingJournalNumber")
        }
        size={TagSize.Large}
        color={TagColor.Highlight}
      />
      <Tag
        text={
          getPettyCashAccountValue("narrative") && historyState?.mode !== METHOD.ADJUST
            ? getPettyCashAccountValue("narrative")
            : t("viewExpenditure.unpostedExpenditure")
        }
        size={TagSize.Large}
        color={TagColor.Highlight}
      />
    </div>
  );
  return (
    <>
      {loading || deletePettyCashStatus === STATUS.LOADING || printPettyCashStatus === STATUS.LOADING ? (
        <Loader loadingConfig={loaderConfig} />
      ) : (
        <FormProvider {...formMethods}>
          <>
            <Layout
              pageTitle={getPageTitle()}
              className="view-expenditure-page"
              isBreadcrumbRequired
              isSubTitle={getTagElement()}
              rightContent={
                <PettyCashToolbar
                  goToNextRecord={selectNextRecord}
                  goToPrevRecord={selectPrevRecord}
                  onFocusClickHandler={onFocusClickHandler}
                  undoChangeHandler={undoChangeHandler}
                  isAddDisable={isToolbarAddDisabled()}
                  onDelete={onDelete}
                  isDeleteDisable={getPettyCashAccountValue("narrative") !== UNPOSTED.Unposted_Exp || !canDoFolio}
                  isPrintDisable={isToolbarPrintDisabled()}
                  printButtonHandler={printButtonHandler}
                  goToAdd={goToAddExpenditure}
                  onSubmit={() => {
                    if (historyState?.mode === METHOD.ADJUST) {
                      setIsAdjustSubmitClicked(true);
                      setOpenSaveChangesModal(true);
                    } else {
                      onSubmitHandler();
                    }
                  }}
                />
              }
              toolbar={
                <PettyCashPageToolbar
                  adjustTransHandler={adjustTransHandler}
                  isPostDisabled={isPostDisabled()}
                  onSubmit={postTransHandler}
                  isCancelDisabled={isCancelDisabled()}
                  isAdjustTransDisabled={isAdjustTransDisabled()}
                  pcTransId={transId}
                />
              }
            >
              <Grid className="row-gap-16">
                <GridItem
                  lg={3}
                  xl={3}
                  md={4}
                  sm={4}
                >
                  <div>
                    <div className="essui-form-label">{t("viewExpenditure.pcAccount")}</div>
                    <div className="mt-8">{getPettyCashAccountValue("pc_acc_des")}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  xl={3}
                  md={4}
                  sm={4}
                >
                  <div>
                    <div className="essui-form-label">{t("viewExpenditure.cashInHand")}</div>
                    <div className="mt-8">{usNumberFormat(getPettyCashAccountValue("cash_in_hand"))}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  xl={3}
                  md={4}
                  sm={4}
                >
                  <div>
                    <div className="essui-form-label">{t("viewExpenditure.unpostedExpenditure")}</div>
                    <div className="mt-8">{usNumberFormat(getPettyCashAccountValue("unposted_exp"))}</div>
                  </div>
                </GridItem>
              </Grid>
            </Layout>

            <Layout
              className="view-expenditure-grid"
              isBreadcrumbRequired={false}
              type="transparent"
            >
              <GridTableNew
                id="expenditure-list-grid"
                isScrollable
                stickyHeader
                filters={<ViewExpenditureFilters />}
                dataTestId="expenditure-list-grid"
                dataSource={historyState?.expenditureItems || []}
                isLoading={expenditureApiStatus === STATUS.LOADING || deleteExpenseFolioStatus === STATUS.LOADING}
                columnDef={expenditureColDef}
                customCell={CustomCell}
                selectedRow={selectedExpenditureRow}
                selectedRowHandler={onRowSelect}
                className="expenditure-list-grid"
              />
            </Layout>

            <Layout
              className="ledger-cost-center"
              isBreadcrumbRequired={false}
            >
              <Grid className="row-gap-16">
                <GridItem
                  lg={4}
                  xl={4}
                  md={4}
                  sm={4}
                >
                  <div>
                    <div className="essui-form-label">{t("viewExpenditure.costCentre")}</div>
                    <div className="mt-8">{getCostCenterString()}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={4}
                  xl={4}
                  md={4}
                  sm={4}
                >
                  <div>
                    <div className="essui-form-label">{t("viewExpenditure.ledgerCode")}</div>
                    <div className="mt-8">{getLedgerStrings()}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={2}
                  xl={2}
                  md={4}
                  sm={4}
                >
                  <div>
                    <FormLabel forId="txtFolio">
                      {historyState?.expenditureItems?.length} {t("viewExpenditure.folio")}
                    </FormLabel>
                    <Button
                      className="mt-8"
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      aria-label="txtFolio"
                      onClick={() => setIsViewPostingDetailsModalOpen(true)}
                      disabled={isViewPostingDetailsDisabled()}
                    >
                      {t("viewExpenditure.btnViewPostingDetails")}
                    </Button>
                  </div>
                </GridItem>
              </Grid>
            </Layout>

            <Layout
              className=""
              isBreadcrumbRequired={false}
            >
              <Grid className="mb-8">
                <GridItem sm={4}>
                  <div className="essui-global-typography-default-subtitle">
                    {t("viewExpenditure.transactionTotals")}
                  </div>
                </GridItem>
              </Grid>
              <Grid className="row-gap-16">
                <GridItem
                  lg={4}
                  xl={4}
                  md={4}
                  sm={4}
                >
                  <div>
                    <div className="essui-form-label">{t("viewExpenditure.excVat")}</div>
                    <div className="mt-8">
                      {usNumberFormat(
                        Number(getPettyCashAccountValue("net_amount")) - Number(getPettyCashAccountValue("vat_amount"))
                      )}
                    </div>
                  </div>
                </GridItem>
                <GridItem
                  lg={4}
                  xl={4}
                  md={4}
                  sm={4}
                >
                  <div>
                    <div className="essui-form-label">{t("viewExpenditure.vat")}</div>
                    <div className="mt-8">{usNumberFormat(getPettyCashAccountValue("vat_amount"))}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={2}
                  xl={2}
                  md={4}
                  sm={4}
                >
                  <div>
                    <div className="essui-form-label">{t("viewExpenditure.incVat")}</div>
                    <div className="mt-8">{usNumberFormat(getPettyCashAccountValue("net_amount"))}</div>
                  </div>
                </GridItem>
              </Grid>
            </Layout>

            <Layout
              isBreadcrumbRequired={false}
              className=""
            >
              <Grid>
                <GridItem
                  sm={6}
                  md={{
                    offset: 2,
                    span: 6
                  }}
                  lg={{
                    offset: 6,
                    span: 6
                  }}
                  xl={{
                    offset: 6,
                    span: 6
                  }}
                >
                  <div className="d-flex gap-8 justify-end flex-wrap">
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      onClick={handleViewOriginalClick}
                      disabled={!expenditureHeader?.orig_trans_id || historyState?.mode === METHOD.ADJUST}
                    >
                      {t("viewExpenditure.btnViewOriginal")}
                    </Button>
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      onClick={handleViewAdjustmentClick}
                      disabled={!expenditureHeader?.adj_trans_id || historyState?.mode === METHOD.ADJUST}
                    >
                      {t("viewExpenditure.btnViewAdjustment")}
                    </Button>
                  </div>
                </GridItem>
              </Grid>
            </Layout>
            <AlertModal
              isOpen={openAlertModal}
              setOpen={setOpenAlertModal}
              title={t("alertMessage.title")}
              notificationType={NotificationStatus.ERROR}
              message={alertMessage}
              autoFocusPrimaryBtn
            />
            <AlertModal
              isOpen={openInsufficientAccessModal}
              setOpen={setOpenInsufficientAccessModal}
              title={t("alertMessage.title")}
              notificationType={NotificationStatus.ERROR}
              message={t("pettyCash.insufficientAccessExpenditure")}
              autoFocusPrimaryBtn
            />
            <ViewPostingDetailsModal
              isOpen={isViewPostingDetailsModalOpen}
              setOpen={setIsViewPostingDetailsModalOpen}
              pcTransId={transId}
            />
            <ConfirmModal
              className="delete-alert"
              isOpen={isDeleteModalOpen}
              setOpen={setIsDeleteModalOpen}
              title={t("alertMessage.title")}
              message={t("alertMessage.deleteAlert.message")}
              confirm={() => {
                deleteRecord();
              }}
              autoFocusTertiaryBtn
            />

            <ConfirmModal
              className="undu-alert delete-alert"
              isOpen={isUndoModalOpen}
              setOpen={setIsUndoModalOpen}
              title={t("alertMessage.title")}
              message={t("alertMessage.undoAlert.message")}
              confirm={() => {
                undoChangeAndNavigate();
              }}
              autoFocusPrimaryBtn
            />
            <Modal
              className="confirm-delete-modal"
              primaryBtnText={t("common.yes")}
              secondaryBtnText={t("common.no")}
              tertiaryBtnText={t("common.cancel")}
              primaryBtnType={ButtonColor.Primary}
              secondaryBtnType={ButtonColor.Secondary}
              tertiaryBtnClick={() => {
                setOpenSaveChangesModal(false);
                setIsAdjustSubmitClicked(false);
                dispatch(expenditureActions.setPettyCashBookDirty(false));
              }}
              secondaryBtnClick={() => {
                onFocusNoButton();
              }}
              primaryBtnClick={(e) => {
                setIsAdjustSubmitClicked(false);
                onFocusYesButton();
              }}
              isOpen={openSaveChangesModal}
              header={t("common.simsFMSModule")}
              autoFocusPrimaryBtn
            >
              <>
                <Notification
                  className="w-100 mb-18 confirm-modal-text"
                  actionElement={1}
                  dataTestId="delete-new-warning-id"
                  escapeExits
                  id="delete-new-warning-id"
                  hideCloseButton
                  status={NotificationStatus.WARNING}
                  title={t("supplier.payeeBrowser.keepChanges")}
                />
              </>
            </Modal>
          </>
        </FormProvider>
      )}
    </>
  );
};

export default ViewExpenditure;
