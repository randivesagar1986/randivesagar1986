import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import React, { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useHistory, useParams } from "react-router-dom";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import {
  METHOD,
  PETTY_CASH_TRANS_STATUS,
  STATUS,
  getCurrentFinancialYear,
  specialCharacters
} from "@/types/UseStateType";
import { deepEqual, isEmptyObject } from "@/utils/constants";
import { useForm } from "react-hook-form";
import { getSessionItem, usNumberFormat } from "@/utils/getDataSource";
import { get } from "http";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import { useClickAway } from "@/hooks/useClickAway";
import { actions as sidebarMenuActions } from "@/components/SidebarMenu/state/SidebarMenu.slice";
import {
  getExpenditureDetails,
  expenditureActions,
  getUnpostedTransId,
  saveExpenditure
} from "../state/ViewExpenditure.slice";
import {
  deletePettyCashTranscation,
  getPettyCashList,
  pettyCashActions,
  printPettyCashTranscation
} from "../state/PettyCashList.slice";
import { getPettyCashOpenBooks, actions as pettyCashOpenBookActions } from "../state/PettyCashOpenBook.slice";
import { expenseFolioActions } from "../state/PettyCashExpenseFolio.slice";

type expenditureFormData = {
  prefix?: string;
  range: string;
};

const useViewExpenditure = () => {
  const defaultValues = {
    prefix: "",
    range: ""
  };
  const formMethods = useForm<expenditureFormData>({
    mode: "all",
    shouldFocusError: false,
    defaultValues: {
      ...defaultValues
    }
  });
  const { handleSubmit, reset, setValue, getValues, watch } = formMethods;
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const { setIsSidebarOpen } = sidebarMenuActions;
  const canDoPostExp = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.PostExpenditure
  });
  const canDoCancel = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.Cancel
  });
  const canDoAdjust = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.AdjustTrans
  });
  const history = useHistory();
  const { pcAccountId, transId } = useParams<{
    pcAccountId: string;
    transId: string;
  }>();
  const editFieldValue = useRef<expenditureFormData | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [isViewPostingDetailsModalOpen, setIsViewPostingDetailsModalOpen] = useState<boolean>(false);
  const [openAlertModal, setOpenAlertModal] = useState<boolean>(false);
  const [alertMessage, setAlertMessage] = useState<string>("");
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [isUndoModalOpen, setIsUndoModalOpen] = useState<boolean>(false);
  const [openSaveChangesModal, setOpenSaveChangesModal] = useState<boolean>(false);
  const [expenditureRow, setExpenditureRow] = useState<any>();
  const dispatch = useDispatch<AppDispatch>();
  const {
    selectedPettyCashRow,
    filterState,
    deletePettyCashStatus,
    printPettyCashStatus,
    selectedPettyCashAccountBrowse,
    pettyCashList: { currentPage, totalPages, pageSize }
  } = useAppSelector((state) => state.pettyCashList);
  const pettyCashTransactionList = useAppSelector((state) => state.pettyCashList.pettyCashList?.pettyCashTransaction);
  const { expenditureApiStatus, selectedExpenditureRow, isDirty } = useAppSelector((state) => state.expenditureDetails);
  const { expenditureHeader, expenditureItems } = useAppSelector(
    (state) => state.expenditureDetails.expenditureDetails
  );
  const { pettyCashOpenBooks, pettyCashOpenBooksApiStatus, selectedPettyCashOpenBook } = useAppSelector(
    (state) => state.pettyCashOpenBooks
  );
  const historyState = { ...(history.location.state as any) };
  const { isAdjustDeleteTriggered, isAdjustEditTriggered, adjustedData } = useAppSelector(
    (state) => state.PettyCashExpenseFolio
  );
  const [isAdjustSubmitClicked, setIsAdjustSubmitClicked] = useState<boolean>(false);
  const [isFieldDirty, setIsFieldDirty] = useState<boolean>(false);

  const allWatchedFormValues: Record<string, any> = watch();
  const [initialValues] = useState<Record<string, any>>(() => getValues());

  const yesCallback = (target?: HTMLElement) => {
    onSubmitHandler();
  };

  const noCallback = (target: HTMLElement) => {
    reset(allWatchedFormValues);
    setIsFieldDirty(false);
    return true;
  };

  // Wrapper to handle noCallback with a parameter
  const noCallbackWrapper = (target: HTMLElement) => {
    noCallback(target); // Pass the event target to the actual noCallback function
  };

  const handleCancelCallback = () => {
    homeRef.current = null;
    menuRef.current = null;
  };

  const { menuRef, setHistoryRedirect, targetRef, reDispatchEvent, homeRef } = useClickAway({
    // common hook for click away functionality.
    isDirty: isFieldDirty || historyState?.isDirty,
    yesCallback: (e: HTMLElement) => yesCallback(e),
    noCallback: noCallbackWrapper,
    cancelCallback: handleCancelCallback,
    popupTitle: t("common.simsFMSModule"),
    popupMessage: t("alertMessage.keepChangesMsg"),
    unblockCondition:
      (history?.location?.pathname?.includes("/general-ledger/petty-cash/add-expenditure") ||
        history?.location?.pathname?.includes("/general-ledger/petty-cash/edit-expenditure")) &&
      !openSaveChangesModal &&
      !isUndoModalOpen,
    isNonReturnYesCallback: true,
    excludePath: [
      "/general-ledger/petty-cash/add-posting-details",
      "/general-ledger/petty-cash/adjust-expenditure",
      "expense-folio"
    ]
  });

  useEffect(() => {
    // create isfieldDirty flag and set by comparison of default values and current values
    const defaultKeys = Object.keys(defaultValues) as (keyof expenditureFormData)[];
    let hasNoChanges = true;
    if (historyState?.mode === METHOD.ADD && expenditureItems.length === 0) {
      hasNoChanges = defaultKeys.every((key) => {
        if (
          allWatchedFormValues[key] !== undefined &&
          allWatchedFormValues[key] !== "" &&
          allWatchedFormValues[key] !== null
        ) {
          return allWatchedFormValues[key] === initialValues[key];
        }
        return true;
      });
    } else if (historyState?.mode === METHOD.EDIT && expenditureItems.length === 0) {
      hasNoChanges = defaultKeys.every((key) => allWatchedFormValues[key] === editFieldValue.current?.[key]);
    } else {
      setIsFieldDirty(false);
    }
    if (isFieldDirty === hasNoChanges) {
      setIsFieldDirty(!hasNoChanges);
    }
  }, [initialValues, allWatchedFormValues, defaultValues, historyState?.mode, expenditureItems]);

  useEffect(() => {
    if (
      historyState?.mode === METHOD.EDIT &&
      expenditureItems?.length === 0 &&
      editFieldValue?.current === null &&
      selectedPettyCashOpenBook
    ) {
      editFieldValue.current = {
        prefix: selectedPettyCashOpenBook?.prefix,
        range: selectedPettyCashOpenBook?.range
      };
    }
  }, [selectedPettyCashOpenBook]);

  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;

  useEffect(() => {
    if (pcAccountId !== "0" && transId !== "0") {
      setLoading(true);
      dispatch(
        getExpenditureDetails({
          pcAccountId,
          transId,
          callback: (data) => {
            dispatch(getPettyCashOpenBooks(0));
            setLoading(false);
          }
        })
      );
    } else {
      dispatch(expenditureActions.resetExpenditureDetails());
    }
  }, [pcAccountId, transId]);

  useEffect(() => {
    if (
      !isEmptyObject(expenditureHeader) &&
      pettyCashOpenBooks?.length &&
      expenditureApiStatus === STATUS.SUCCESS &&
      historyState?.mode !== METHOD.ADD
    ) {
      const selectedPCashOpenBook = pettyCashOpenBooks.filter((s) => s.prefix === expenditureHeader?.prefix)[0];
      dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(selectedPCashOpenBook));
    } else if (
      pettyCashOpenBooksApiStatus === STATUS.SUCCESS &&
      historyState?.mode === METHOD.ADD &&
      pettyCashOpenBooks?.length === 1
    ) {
      dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(pettyCashOpenBooks[0]));
    }
  }, [expenditureHeader, pettyCashOpenBooks, expenditureApiStatus]);

  useEffect(() => {
    let timeoutId: any;
    if (expenditureItems.length > 0) {
      if (historyState?.lineItemMode === METHOD.ADD) {
        timeoutId = setTimeout(() => {
          dispatch(expenditureActions.setSelectedExpenditureRow(expenditureItems[expenditureItems.length - 1]));
          document.getElementById(getIndex("expenditure-list-grid", expenditureItems.length - 1))?.focus();
        }, 100);
      } else if (historyState?.lineItemMode === METHOD.EDIT) {
        timeoutId = setTimeout(() => {
          const selectedExpenditureRowData = expenditureItems.filter(
            (item: any) => item.pc_folio_id === historyState?.ExpenseFolioData?.pettyCashExpenditure?.pc_folio_id
          );
          dispatch(
            expenditureActions.setSelectedExpenditureRow(
              selectedExpenditureRowData.length ? selectedExpenditureRowData[0] : expenditureItems[0]
            )
          );
          document
            .getElementById(
              getIndex(
                "expenditure-list-grid",
                expenditureItems.indexOf(
                  selectedExpenditureRowData ? selectedExpenditureRowData[0] : expenditureItems[0]
                )
              )
            )
            ?.focus();
        }, 100);
      } else {
        timeoutId = setTimeout(() => {
          dispatch(expenditureActions.setSelectedExpenditureRow(expenditureItems[0]));
          document.getElementById(getIndex("expenditure-list-grid", 0))?.focus();
        }, 100);
      }
    }
    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    };
  }, [expenditureItems]);

  const onRowSelect: (row?: RowType | undefined) => void = (row) => {
    if (expenditureApiStatus === STATUS.SUCCESS) {
      dispatch(expenditureActions.setSelectedExpenditureRow(row));
      setExpenditureRow(row);
    }
  };
  const onDelete = () => {
    setIsDeleteModalOpen(true);
  };
  const deleteRecord = () => {
    dispatch(
      deletePettyCashTranscation({
        pcTransId: selectedPettyCashRow?.pc_trans_id ?? 0,
        callback: () => {
          history.push({
            pathname: `/general-ledger/petty-cash`
          });
          dispatch(
            pettyCashActions.setFilters({
              pageNumber: 1,
              pcTransId: 0,
              pcAccountId: selectedPettyCashAccountBrowse?.pc_account_id
            })
          );
        }
      })
    );
  };

  const updateHistoryState = (expenditureLineItems: any) => {
    history.replace({
      ...history.location,
      state: {
        ...historyState,
        expenditureItems: expenditureLineItems
      }
    });
  };

  useEffect(() => {
    if (historyState?.mode !== METHOD.ADJUST) {
      updateHistoryState(expenditureItems);
      if (expenditureItems.length) {
        onRowSelect(expenditureItems?.[0]);
      } else {
        onRowSelect(undefined);
      }
    } else if (
      expenditureItems.length &&
      historyState?.mode === METHOD.ADJUST &&
      !historyState?.expenditureItems?.length
    ) {
      updateHistoryState(expenditureItems);
      onRowSelect(expenditureItems?.[0]);
    }
  }, [historyState?.mode, expenditureItems]);

  const deleteItem = (index: number) => {
    const filteredItems = historyState?.expenditureItems.filter((_: any, itemIndex: any) => itemIndex !== index);
    onRowSelect(filteredItems?.[0]);
    updateHistoryState(filteredItems);
  };
  useEffect(() => {
    if (isAdjustDeleteTriggered) {
      const index = historyState?.expenditureItems.findIndex(
        (item: any) => item?.pc_folio_id === selectedExpenditureRow?.pc_folio_id
      );
      deleteItem(index);
      dispatch(expenseFolioActions.setIsAdjustDeleteTriggered(false));
    }
  }, [isAdjustDeleteTriggered]);

  const updateAdjustedItem = (index: number, updatedItem: any) => {};
  const handleItemEdit = (index: number, updatedItem: any) => {
    updateAdjustedItem(index, updatedItem);
  };
  useEffect(() => {
    if (isAdjustEditTriggered) {
      const index = historyState?.expenditureItems?.findIndex(
        (item: any) => item?.pc_folio_id === adjustedData?.pc_folio_id
      );
      handleItemEdit(index, adjustedData);
      dispatch(expenseFolioActions.setIsAdjustEditTriggered(false));
    }
  }, [isAdjustEditTriggered, adjustedData]);

  useEffect(() => {
    if (expenditureApiStatus === STATUS.FAILED) {
      setLoading(false);
    }
  }, [expenditureApiStatus]);

  const onFocusClickHandler = () => {
    if (historyState?.mode === METHOD.ADJUST || historyState?.mode === METHOD.ADD || isDirty) {
      setOpenSaveChangesModal(true);
    } else {
      dispatch(pettyCashActions.setIsFocus(false));
      dispatch(pettyCashActions.setFilters({ pcTransId: transId ? Number(transId) : 0 }));
      history.push(`/general-ledger/petty-cash`);
    }
  };

  const undoChangeHandler = () => {
    if (historyState?.mode === METHOD.ADD || historyState?.mode === METHOD.ADJUST || isDirty) {
      setIsUndoModalOpen(true);
    } else {
      dispatch(pettyCashActions.setFilters({ pcTransId: selectedPettyCashRow?.pc_trans_id }));
      history.push(`/general-ledger/petty-cash`);
    }
  };

  const onFocusNoButton = () => {
    setIsAdjustSubmitClicked(false);
    if (historyState?.mode === METHOD.ADJUST && isAdjustSubmitClicked) {
      updateHistoryState(expenditureItems);
    } else {
      history.push(`/general-ledger/petty-cash`);
      dispatch(expenditureActions.setPettyCashBookDirty(false));
    }
    setOpenSaveChangesModal(false);
  };
  const onFocusYesButton = () => {
    setOpenSaveChangesModal(false);
    onSubmitHandler();
  };
  const undoChangeAndNavigate = () => {
    dispatch(expenditureActions.setPettyCashBookDirty(false));
    dispatch(pettyCashActions.setFilters({ pcTransId: selectedPettyCashRow?.pc_trans_id }));
    history.push(`/general-ledger/petty-cash`);
  };
  const goToRecord = (row: any) => {
    dispatch(pettyCashActions.setSelectedPettyCashRow(row));
    dispatch(pettyCashActions.setSelectedPettyCashUndoRow(row));
    dispatch(pettyCashActions.setFilters({ highlightPcTransId: row?.id }));
    if (row?.trans_type === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/view-reimbursement/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          selectedRowState: row,
          isDirty: false
        }
      });
    } else if (row?.status === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/edit-expenditure/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          mode: METHOD.EDIT,
          selectedRowState: row,
          headerData: selectedPettyCashAccountBrowse,
          isDirty: false
        }
      });
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/view-expenditure/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          selectedRowState: row,
          isDirty: false
        }
      });
    }
  };

  const onChangeHandler = (page: number) => {
    dispatch(
      pettyCashActions.setFilters({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        highlightPcTransId: undefined,
        pcTransId: 0
      })
    );
    dispatch(
      getPettyCashList({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(pageSize),
        highlightPcTransId: undefined,
        pcTransId: 0,
        pcAccountId: Number(pcAccountId),
        callback: (data) => {
          const row = data?.pettyCashTransaction?.at(0);
          if (row) {
            goToRecord(row);
          }
        }
      })
    );
  };

  const onChangePrevRecord = (page: number) => {
    dispatch(
      pettyCashActions.setFilters({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        highlightPcTransId: undefined,
        pcTransId: 0
      })
    );
    dispatch(
      getPettyCashList({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(pageSize),
        highlightPcTransId: undefined,
        pcTransId: 0,
        pcAccountId: Number(pcAccountId),
        callback: (data) => {
          const row = data?.pettyCashTransaction?.at(data?.pettyCashTransaction.length - 1);
          if (row) {
            goToRecord(row);
          }
        }
      })
    );
  };

  const selectPrevRecord = () => {
    if (selectedPettyCashRow && pettyCashTransactionList) {
      const indexNo = pettyCashTransactionList.indexOf(selectedPettyCashRow);
      if (indexNo > 0) {
        const row = pettyCashTransactionList[indexNo - 1];
        dispatch(pettyCashActions.setSelectedPettyCashRow(pettyCashTransactionList[indexNo - 1]));
        goToRecord(row);
      } else if (currentPage > 1) {
        onChangePrevRecord(currentPage - 1);
      }
    }
  };
  const selectNextRecord = () => {
    if (selectedPettyCashRow && pettyCashTransactionList) {
      const indexNo = pettyCashTransactionList.indexOf(selectedPettyCashRow);
      if (indexNo < pettyCashTransactionList.length - 1) {
        const row = pettyCashTransactionList[indexNo + 1];
        dispatch(pettyCashActions.setSelectedPettyCashRow(pettyCashTransactionList[indexNo + 1]));
        goToRecord(row);
      } else if (currentPage < totalPages) {
        onChangeHandler(currentPage + 1);
      }
    }
  };

  const getPageTitle = () => {
    switch (historyState?.mode) {
      case METHOD.EDIT:
        return t("viewExpenditure.editExpenditureTitle");
      case METHOD.ADD:
      case METHOD.ADJUST:
        return t("viewExpenditure.addExpenditureTitle");
      default:
        return t("viewExpenditure.viewExpenditureTitle");
    }
  };

  const getUnpostedExpenditure = () => {
    let unpostedExp = 0;
    historyState?.expenditureItems?.forEach((item: any) => {
      unpostedExp += item.line_cost;
    });
    return unpostedExp;
  };
  const getVatAmount = () => {
    let vatAmount = 0;
    historyState?.expenditureItems?.forEach((item: any) => {
      vatAmount += item.vat_amount;
    });
    return vatAmount;
  };
  const getNetAmount = () => {
    let netAmount = 0;
    historyState?.expenditureItems?.forEach((item: any) => {
      netAmount += item.line_cost;
    });
    return netAmount;
  };
  const getPettyCashAccountValue = (fieldName: string) => {
    if (historyState?.mode === METHOD.ADD && isEmptyObject(expenditureHeader)) {
      return historyState?.headerData?.[fieldName] ?? "";
    }

    if (historyState?.mode === METHOD.ADJUST && !isEmptyObject(expenditureHeader)) {
      if (["cash_in_hand", "unposted_exp", "vat_amount", "net_amount"].includes(fieldName)) {
        switch (fieldName) {
          case "cash_in_hand":
            return expenditureHeader[fieldName] + expenditureHeader.line_cost;
          case "unposted_exp":
            return expenditureHeader[fieldName] + getUnpostedExpenditure();
          case "vat_amount":
            return getVatAmount();
          case "net_amount":
            return getNetAmount();
          default:
            return expenditureHeader[fieldName];
        }
      }
    }

    return expenditureHeader?.[fieldName] ?? "";
  };

  const isToolbarAddDisabled = () => {
    if (historyState?.mode === METHOD.ADD) {
      return true;
    }
    if (historyState?.mode === METHOD.EDIT) {
      return true;
    }
    return false;
  };
  const printButtonHandler = async () => {
    const { payload } = await dispatch(
      printPettyCashTranscation({
        accountid: selectedPettyCashRow?.pc_account_id ?? 0,
        transno: selectedPettyCashRow?.trans_no,
        yearId: getCurrentFinancialYear()
      })
    );
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/pdf" });
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName || t("pettyCash.fileName");
    link.click();
  };
  const isToolbarDeleteDisabled = () => {
    if (historyState?.mode === METHOD.EDIT) {
      return false;
    }
    return true;
  };
  const isToolbarPrintDisabled = () => {
    if (historyState?.mode === METHOD.ADD) {
      return true;
    }
    if (historyState?.mode === METHOD.EDIT && expenditureItems.length === 0) {
      return true;
    }
    return false;
  };

  const isViewPostingDetailsDisabled = () => {
    if (!historyState?.mode) {
      return false;
    }
    return true;
  };
  const goToAdd = () => {
    dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(undefined));
    checkForUnpostedExp();
  };

  const checkForUnpostedExp = () => {
    dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(undefined));
    setLoading(true);
    dispatch(
      getUnpostedTransId({
        pcAccountId: expenditureHeader?.pc_account_id,
        callback: (data) => {
          setValue("prefix", specialCharacters.BLANKVALUE);
          setValue("range", specialCharacters.BLANKVALUE);
          reset();
          setLoading(false);
          if (data?.at_pc_trans_id > 0) {
            history.push({
              pathname: `/general-ledger/petty-cash/edit-expenditure/${expenditureHeader?.pc_account_id}/${data?.at_pc_trans_id}`,
              state: {
                mode: METHOD.EDIT,
                headerData: expenditureHeader,
                redirect: false
              }
            });
          } else {
            history.push({
              pathname: `/general-ledger/petty-cash/add-expenditure/${expenditureHeader?.pc_account_id}/${data?.at_pc_trans_id}`,
              state: {
                mode: METHOD.ADD,
                headerData: selectedPettyCashAccountBrowse,
                redirect: false
              }
            });
          }
        }
      })
    );
  };

  const isPostDisabled = () => {
    if (!canDoPostExp) {
      return true;
    }
    if (
      ((expenditureHeader?.trans_type !== 0 &&
        expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.UNPOSTED &&
        expenditureHeader?.foliocount > 0) ||
        historyState?.mode === METHOD.ADJUST) &&
      canDoPostExp
    ) {
      return false;
    }
    return true;
  };
  const onSubmitHandler = async () => {
    const formSumbit = handleSubmit(
      async (data) => {
        if (data.prefix === selectedPettyCashOpenBook?.prefix) {
          if (historyState?.mode === METHOD.ADD || historyState?.mode === METHOD.EDIT) {
            setLoading(true);
            await saveExpenditureHandler();
            dispatch(expenditureActions.setPettyCashBookDirty(false));
          }
        }
      },
      () => {
        setOpenAlertModal(true);
        setAlertMessage(t("common.invalidData"));
        dispatch(setIsSidebarOpen(false));
        setHistoryRedirect(true);
      }
    );
    if (historyState?.mode === METHOD.ADJUST) {
      postTransHandler();
    } else {
      await formSumbit();
    }
  };

  const saveExpenditureHandler = async () => {
    const formData = {
      pcAccountId,
      pc_trans_id: transId || 0,
      book_id: selectedPettyCashOpenBook?.book_id
    };
    dispatch(
      saveExpenditure({
        formData,
        callback: (data) => {
          setLoading(false);
          if (getSessionItem("redirectPath") || homeRef.current || menuRef.current) {
            if (homeRef.current) {
              history.push({
                pathname: "/",
                state: {
                  redirect: true
                }
              });
              setHistoryRedirect(true);
            } else if (menuRef.current) {
              dispatch(setIsSidebarOpen(true));
              setHistoryRedirect(false);
              menuRef.current = null;
              return;
            } else {
              reDispatchEvent(targetRef.current);
              setHistoryRedirect(true);
            }
            homeRef.current = null;
          } else if (data?.pc_trans_id && historyState?.mode === METHOD.ADD) {
            history.push({
              pathname: `/general-ledger/petty-cash/edit-expenditure/${formData?.pcAccountId}/${data?.pc_trans_id}`,
              state: {
                mode: METHOD.EDIT
              }
            });
          } else {
            dispatch(getExpenditureDetails({ pcAccountId, transId }));
          }
        }
      })
    );
  };

  const postTransHandler = () => {
    const overDrawn =
      Number(getPettyCashAccountValue("unposted_exp")) - Number(getPettyCashAccountValue("cash_in_hand"));
    if (overDrawn > 0) {
      setOpenAlertModal(true);
      const message = `${expenditureHeader?.pc_acc_des} ${t("viewExpenditure.overDrawnError")} ${usNumberFormat(
        overDrawn
      )}`;
      setAlertMessage(message);
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/add-posting-details/${expenditureHeader?.pc_account_id}/${expenditureHeader?.pc_trans_id}`,
        state: {
          ...(history.location.state as any),
          selectedRowState: expenditureHeader,
          navigateFrom: "detail",
          redirect: false
        }
      });
    }
  };
  const handleViewOriginalClick = () => {
    if (expenditureHeader?.orig_trans_id) {
      const origTransId = expenditureHeader.orig_trans_id;
      history.push({
        pathname: `/general-ledger/petty-cash/view-expenditure/${pcAccountId}/${origTransId}`
      });
    }
  };

  const handleViewAdjustmentClick = () => {
    if (expenditureHeader?.adj_trans_id) {
      const adjTransId = expenditureHeader.adj_trans_id;
      history.push({
        pathname: `/general-ledger/petty-cash/view-expenditure/${pcAccountId}/${adjTransId}`
      });
    }
  };

  const isCancelDisabled = () =>
    !canDoPostExp ||
    !canDoCancel ||
    !(
      !historyState.mode &&
      (expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.NORMAL ||
        expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.ADJUST ||
        expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.ADJUST_OF_ADJUST)
    );

  const isAdjustTransDisabled = () =>
    !canDoAdjust ||
    !canDoPostExp ||
    !(
      !historyState.mode &&
      (expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.NORMAL ||
        expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.ADJUST ||
        expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.ADJUST_OF_ADJUST)
    );

  const adjustTransHandler = () => {
    history.push({
      pathname: `/general-ledger/petty-cash/adjust-expenditure/${expenditureHeader?.pc_account_id}/${expenditureHeader?.pc_trans_id}`,
      state: {
        headerData: expenditureHeader,
        selectedRowState: selectedPettyCashRow,
        mode: METHOD.ADJUST
      }
    });
  };

  return {
    t,
    loading,
    expenditureApiStatus,
    onRowSelect,
    selectedExpenditureRow,
    selectedPettyCashRow,
    isUndoModalOpen,
    setIsUndoModalOpen,
    selectNextRecord,
    selectPrevRecord,
    isCancelDisabled,
    isAdjustTransDisabled,
    handleViewAdjustmentClick,
    handleViewOriginalClick,
    onFocusClickHandler,
    undoChangeHandler,
    expenditureHeader,
    expenditureItems,
    historyState,
    getPageTitle,
    onDelete,
    setIsDeleteModalOpen,
    isDeleteModalOpen,
    getPettyCashAccountValue,
    isToolbarAddDisabled,
    isToolbarDeleteDisabled,
    isToolbarPrintDisabled,
    isViewPostingDetailsDisabled,
    isViewPostingDetailsModalOpen,
    setIsViewPostingDetailsModalOpen,
    printButtonHandler,
    transId,
    goToAdd,
    isPostDisabled,
    deleteRecord,
    onSubmitHandler,
    undoChangeAndNavigate,
    setOpenSaveChangesModal,
    onFocusNoButton,
    onFocusYesButton,
    openSaveChangesModal,
    formMethods,
    openAlertModal,
    setOpenAlertModal,
    alertMessage,
    postTransHandler,
    deletePettyCashStatus,
    printPettyCashStatus,
    adjustTransHandler,
    setIsAdjustSubmitClicked
  };
};

export default useViewExpenditure;
