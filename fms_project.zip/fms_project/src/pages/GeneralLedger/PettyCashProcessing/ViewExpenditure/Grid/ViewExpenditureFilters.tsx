import React from "react";
import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  TextInput,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import Input from "@/components/Input/Input";
import { AddLarge } from "@carbon/icons-react";
import { METHOD } from "@/types/UseStateType";
import PettyCashOpenBookModal from "@/shared/components/PettyCashOpenBookModal/PettyCashOpenBookModal";
import { useFormContext } from "react-hook-form";
import { useAppSelector } from "@/store/store";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import useExpenditureFilters from "./useExpenditureFilters";

const ViewExpenditureFilters = () => {
  const {
    register,
    getValues,
    trigger,
    formState: { errors }
  } = useFormContext();
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const canDoFolio = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.RaiseFolios
  });
  const {
    t,
    expenditureHeader,
    pettyCashOpenBooks,
    historyState,
    handleSelectedPettyCashBook,
    pettyCashBookModalOpen,
    setPettyCashBookModalOpen,
    onSelectPettyCashBook,
    handleOnChangePettyCashBook,
    handlePettyCashOpenBookPendingState,
    isPettyCashBookSearchDisabled,
    isAddButtonDisabled,
    nameInputRef,
    addExpenseFolioItem,
    openBookModalOpen
  } = useExpenditureFilters();

  return (
    <>
      <Grid className="row-gap-16">
        <GridItem
          sm={4}
          md={8}
          lg={9}
          xl={9}
        >
          <Grid>
            <GridItem className="mr-24">
              <div>
                <div className="essui-form-label">{t("viewExpenditure.transactionNumber")}</div>
                <div className="height__equal--input">
                  {expenditureHeader?.trans_no && historyState?.mode !== METHOD.ADJUST
                    ? expenditureHeader?.trans_no
                    : t("viewExpenditure.pendingJournalNumber")}
                </div>
              </div>
            </GridItem>
            <GridItem className="">
              <div>
                <FormLabel forId="txtPettyCash">{t("viewExpenditure.pettyCashBook")}</FormLabel>
                <Grid className="">
                  <GridItem
                    lg={12}
                    md={8}
                    sm={4}
                    xl={12}
                    xxl={12}
                    className="pr-8"
                  >
                    <Input
                      id="txtPettyCash"
                      searchable
                      // value={expenditureHeader?.prefix}
                      searchItems={(pettyCashOpenBooks || []).map((pRow) => ({
                        text: pRow?.prefix,
                        value: pRow?.range
                      }))}
                      onSelect={(selectedItem) => {
                        handleSelectedPettyCashBook(selectedItem);
                      }}
                      onNoSelection={() => {
                        setPettyCashBookModalOpen(true);
                      }}
                      onChange={(e) => {
                        handleOnChangePettyCashBook(e);
                      }}
                      // onBlur={() => trigger("prefix")}
                      value={getValues("prefix")}
                      inputRef={(e) => {
                        register("prefix").ref(e);
                        nameInputRef.current = e; // Assign the ref to the input element
                      }}
                      name={register("prefix", { required: true }).name}
                      onPending={handlePettyCashOpenBookPendingState}
                      disabled={isPettyCashBookSearchDisabled()}
                      inputWidth={110}
                      validationTextLevel={errors.prefix ? ValidationTextLevel.Error : undefined}
                      button={
                        <>
                          <TextInput
                            id="range"
                            inputWidth={220}
                            className="width-55 read-only"
                            value={getValues("range")}
                            name={register("range", { required: true }).name}
                            onChange={(e) => {
                              register("range").onChange(e);
                            }}
                            readOnly
                            disabled
                          />

                          <Button
                            size={ButtonSize.Small}
                            color={ButtonColor.Secondary}
                            aria-label="search"
                            className="essui-button-icon-only--small"
                            onClick={() => {
                              openBookModalOpen();
                            }}
                            disabled={isPettyCashBookSearchDisabled()}
                          >
                            <Icon
                              color={IconColor.Primary500}
                              size={IconSize.Medium}
                              name="search"
                            />
                          </Button>
                        </>
                      }
                    />
                  </GridItem>
                </Grid>
              </div>
            </GridItem>
          </Grid>
        </GridItem>
        <GridItem
          sm={4}
          md={8}
          lg={3}
          xl={3}
          className="d-flex align-center justify-end exp-filter-button"
        >
          <Button
            className={`essui-button essui-button--utility essui-button--small br-0 ${
              !canDoFolio || (canDoFolio && isAddButtonDisabled) ? "disabled" : ""
            }`}
            size={ButtonSize.Small}
            disabled={!canDoFolio || (canDoFolio && isAddButtonDisabled)}
            onClick={() => addExpenseFolioItem()}
          >
            <AddLarge
              size={18}
              color="black"
            />
          </Button>
        </GridItem>
      </Grid>
      <PettyCashOpenBookModal
        isOpen={pettyCashBookModalOpen}
        setOpen={setPettyCashBookModalOpen}
        selectedRow={(row) => {
          onSelectPettyCashBook(row);
        }}
      />
    </>
  );
};
export default ViewExpenditureFilters;
