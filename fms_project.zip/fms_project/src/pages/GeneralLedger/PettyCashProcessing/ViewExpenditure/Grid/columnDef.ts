import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const expenditureColDef: TColumnDef = [
  {
    headerName: "Folio No.",
    field: "pc_folio_no"
  },
  {
    headerName: "Description",
    field: "description",
    enableTooltip: true
  },
  {
    headerName: "Excluding VAT",
    field: "exc_vat",
    align: "right",
    cellRenderer: "GridCellLink",
    enableTooltip: true
  },
  {
    headerName: "VAT amount",
    field: "vat_amount",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Including VAT",
    field: "net_amount",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "VAT",
    field: "vat_code"
  },
  {
    headerName: "",
    field: "detailLink",
    cellRenderer: "GridCellLink"
  }
];

export default expenditureColDef;
