import { cellRendererType } from "@/components/GridTable/GridTable";
import { Button, ButtonColor, ButtonSize, ISelectedItem, Icon, IconSize } from "@essnextgen/ui-kit";
import { usNumberFormat } from "@/utils/getDataSource";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { ReactNode, SyntheticEvent, useState } from "react";
import GridRowActions, { OptionsType } from "@/components/GridRowActions/GridRowActions";
import { useHistory, useParams } from "react-router-dom";
import { AppDispatch, useAppSelector } from "@/store/store";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { useDispatch } from "react-redux";
import BodyUtil from "@/shared/utils/NoScroll";
import { METHOD } from "@/types/UseStateType";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import useExpenditureFilters from "./useExpenditureFilters";
import ViewPettyCashExpenseFolioModal from "../../PettyCashExpenseFolioModal/ViewPettyCashExpenseFolioModal";
import { deleteExpenseFolio, expenseFolioActions } from "../../state/PettyCashExpenseFolio.slice";
import { getExpenditureDetails } from "../../state/ViewExpenditure.slice";

type clickHandlerType = (e: SyntheticEvent, selectedItem: ISelectedItem) => void;

const CustomCell = ({ field, row }: cellRendererType) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { isAddLineItemBtnDisabled, selectedExpenditureRow } = useExpenditureFilters();
  const [isViewExpenseFolioModalOpen, setIsViewExpenseFolioModalOpen] = useState<boolean>(false);
  const { pettyCashOpenBooks, selectedPettyCashOpenBook } = useAppSelector((state) => state.pettyCashOpenBooks);
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const canDoFolio = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.RaiseFolios
  });

  const dispatch = useDispatch<AppDispatch>();
  const { pcAccountId, transId } = useParams<{
    pcAccountId: string;
    transId: string;
  }>();

  const [isDeleteExpenseLineItem, setIsDeleteExpenseLineItem] = useState<boolean>(false);

  const history = useHistory();
  const historyState = { ...(history.location.state as any) };

  const isDeleteButtonDisabled = () => {
    if (
      !canDoFolio ||
      (canDoFolio && historyState.mode === METHOD.ADJUST && historyState?.expenditureItems?.length === 1)
    ) {
      return true;
    }
    return false;
  };

  const options: OptionsType[] = [
    {
      text: "edit",
      value: "edit",
      disabled: !canDoFolio,
      children: <RowAction optionName={t("common.edit")} />
    },
    {
      text: "delete",
      value: "delete",
      disabled: isDeleteButtonDisabled(),
      children: <RowAction optionName={t("common.delete")} />
    },
    {
      text: "view",
      value: "view",
      children: <RowAction optionName={t("common.view02")} />
    }
  ];
  const deleteExpenseLineItem = () => {
    if (historyState.mode === METHOD.ADJUST) {
      dispatch(expenseFolioActions.setIsAdjustDeleteTriggered(true));
    } else {
      dispatch(
        deleteExpenseFolio({
          pcFolioId: selectedExpenditureRow?.pc_folio_id,
          autoCommit: "T",
          callback: (res) => {
            dispatch(
              getExpenditureDetails({
                pcAccountId,
                transId
              })
            );
          }
        })
      );
    }
  };
  const handleButtonClick: clickHandlerType = async (e, selectedItem) => {
    if (selectedItem.value === "delete") {
      setIsDeleteExpenseLineItem(true);
    } else if (selectedItem.value === "view") {
      setIsViewExpenseFolioModalOpen(true);
    }
    if (selectedItem.value === "edit") {
      history.push({
        pathname: `${history.location.pathname}/edit/expense-folio`,
        state: {
          ...historyState,
          lineItemMode: METHOD.EDIT,
          selectedExpenditureRow,
          selectedBook: selectedPettyCashOpenBook,
          redirect: false
        }
      });
    }
  };

  const getContent = () => {
    if (isDeleteExpenseLineItem) {
      return (
        <>
          <ConfirmModal
            className="delete-alert"
            isOpen={isDeleteExpenseLineItem}
            setOpen={setIsDeleteExpenseLineItem}
            title={t("alertMessage.title")}
            message={t("alertMessage.deleteAlert.message")}
            confirm={() => {
              deleteExpenseLineItem();
            }}
            callback={({ confirm }) => {
              BodyUtil.NoScroll.remove();
            }}
            autoFocusTertiaryBtn
          />
        </>
      );
    }
    if (isViewExpenseFolioModalOpen) {
      return (
        <ViewPettyCashExpenseFolioModal
          isOpen={isViewExpenseFolioModalOpen}
          setOpen={setIsViewExpenseFolioModalOpen}
          pcFolioId={row?.pc_folio_id}
        />
      );
    }
    switch (field) {
      case "detailLink":
        if (historyState.mode) {
          return (
            <GridRowActions
              name={
                <Icon
                  size={IconSize.Medium}
                  name="overflow-menu--horizontal"
                />
              }
              options={options}
              onClick={handleButtonClick}
              selectedRow={selectedExpenditureRow}
            />
          );
        }
        return (
          <>
            <Button
              color={ButtonColor.Utility}
              className="segments-buttons"
              onClick={() => setIsViewExpenseFolioModalOpen(true)}
            >
              {t("common.view02")}
            </Button>
            <ViewPettyCashExpenseFolioModal
              isOpen={isViewExpenseFolioModalOpen}
              setOpen={setIsViewExpenseFolioModalOpen}
              pcFolioId={row?.pc_folio_id}
            />
          </>
        );
      case "net_amount":
        return <>{usNumberFormat(row?.line_cost)}</>;
      case "vat_amount":
        return <>{usNumberFormat(row?.vat_amount)}</>;
      case "exc_vat": {
        const excVat = Number(row?.net_amount);
        return <>{usNumberFormat(excVat)}</>;
      }
      default: {
        return <div />;
      }
    }
  };
  return getContent();
};

export default CustomCell;

type OptionProps = {
  iconName?: string;
  optionName: string;
  children?: ReactNode;
};
const RowAction = ({ iconName, optionName, children }: OptionProps) => (
  <div className="option">
    {iconName ? (
      <Icon
        size={IconSize.Medium}
        name={iconName}
      />
    ) : (
      children
    )}
    {optionName}
  </div>
);

RowAction.defaultProps = {
  iconName: undefined,
  children: undefined
};
