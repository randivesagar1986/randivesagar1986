import {
  Button,
  ButtonColor,
  ButtonSize,
  DateInput,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  ISelectedItem,
  NotificationStatus,
  Textarea,
  TextInput,
  Tooltip
} from "@essnextgen/ui-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import Input from "@/components/Input/Input";
import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import CostCentersModal from "@/shared/components/CostCenterModal/CostCenterModal";
import LedgerCodesModal from "@/shared/components/LedgerCodesModal/LedgerCodesModal";
import FundCodesModal from "@/shared/components/FundCodesModal/fundCodesModal";
import VatCodesModal from "@/shared/components/VatCodesModal/VatCodesModal";
import InvoiceFundCodesModal from "@/shared/components/FundCodesModal/InvoicefundCodesModal";
import InputDate from "@/shared/components/InputDate/InputDate";
import NumberInput from "@/components/NumberInput/NumberInput";
import { isDateInFinancialYear, setToSession, usNumberFormat } from "@/utils/getDataSource";
import React, { ChangeEvent, useState, useEffect } from "react";
import TextInputMask from "@/components/Input/InputMask";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import { METHOD, STATUS } from "@/types/UseStateType";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { formatDateInYYYYMMDD } from "@/shared/components/InputDate/formatDate";
import InputNumberMask from "@/components/Input/InputNumberMask";
import usePettyCashExpenseFolio from "./usePettyCashExpenseFolio";

const loaderConfig: loadingConfig = {};
const PettyCashExpenseFolio = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const vatInputNumRef = React.useRef<HTMLInputElement>(null);
  const totalVatInputNumRef = React.useRef<HTMLInputElement>(null);
  const vatFieldDirtyRef = React.useRef<boolean>(false);

  const {
    expenseFolioDate,
    setValue,
    watch,
    costCenters,
    register,
    getValues,
    setIsOpenCostCenterModal,
    errors,
    ValidationTextLevel,
    onCostCentreChange,
    onCostCentreSelect,
    onCostCentrePending,
    isOpenCostCenterModal,
    FormProvider,
    formMethods,
    costCenterClick,
    ledgerCodeClick,
    isOpenLedgerCodesModal,
    setIsOpenLedgerCodesModal,
    onLedgerCodeSelect,
    ledgerCodes,
    onLedgerCodeChange,
    onLedgerCodePending,
    onFundCodeSelect,
    setIsOpenFundCodesModal,
    isDisabled,
    onFundCodeChange,
    fundCodes,
    onFundCodePending,
    fundCodeClick,
    isOpenFundCodesModal,
    setIsDisabled,
    vatCodes,
    onVatCodeSelect,
    setIsOpenVatCodesModal,
    vatCodeClick,
    onVatCodeChange,
    onVatCodePending,
    isOpenVatCodesModal,
    calculateVatAmount,
    trigger,
    clearErrors,
    setIsInCurrFinYr,
    isInCurrFinYr,
    getVatRegNoInputData,
    vatRegNoBlurEvent,
    isFutureDate,
    isVatAmtErr,
    onVatAmountChange,
    setOpenValidationModal,
    openValidationModal,
    vatRegInputValue,
    onSubmitHandler,
    saveExpenseFolioItemStatus,
    costCenterStatus,
    ledgerCodeStatus,
    navigateBack,
    transId,
    isVatRegNoErr,
    historyState,
    setIsTotalIncVatChanged,
    isTotalIncVatChanged
  } = usePettyCashExpenseFolio();

  useEffect(() => {
    const el = document.getElementById("txtVATRegistration");
    // eslint-disable-next-line
    const handleFocus = () => {
      if (vatFieldDirtyRef.current) {
        return false;
      }

      getVatRegNoInputData({
        target: {
          value: "000-0000-00"
        }
      } as ChangeEvent<HTMLInputElement>);

      vatFieldDirtyRef.current = true;
      if (el) {
        (el as HTMLInputElement).setSelectionRange(0, 0);
      }
    };

    el?.addEventListener("focus", handleFocus);

    return () => {
      el?.removeEventListener("focus", handleFocus);
    };
  }, []);

  return (
    <FormProvider {...formMethods}>
      <Layout
        pageTitle={
          historyState.lineItemMode === METHOD.EDIT
            ? t("pettyCashExpenseFolio.editpageTitle")
            : t("pettyCashExpenseFolio.pageTitle")
        }
        className="add--pety__cash--expense--folio"
        dataTestId="add-petty-cash-expense-folio"
      >
        <div className="selection-panel">
          {costCenterStatus === STATUS.LOADING ||
          ledgerCodeStatus === STATUS.LOADING ||
          saveExpenseFolioItemStatus === STATUS.LOADING ? (
            <Loader loadingConfig={loaderConfig} />
          ) : null}
          <div className="mt-10">
            <Grid className="row-gap-8">
              <GridItem
                sm={4}
                md={12}
                lg={8}
                xl={8}
              >
                <Grid className="row-gap-8">
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={6}
                    xxl={6}
                  >
                    <div>
                      <div className="essui-form-label mb-5">{t("pettyCashExpenseFolio.folioNo")}</div>
                      <div className="height__equal--input">{getValues("pc_folio_no") ?? "-"}</div>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={6}
                    xxl={6}
                  >
                    <div>
                      <FormLabel
                        forId="txtReceiptDate"
                        className="mb-5"
                      >
                        {t("pettyCashExpenseFolio.receiptDate")}
                      </FormLabel>
                      <InputDate
                        autoFocus
                        id="txtReceiptDate"
                        className="margin-top"
                        value={watch("receipt_date")}
                        inputRef={(e: any) => register("receipt_date").ref(e)}
                        name={register("receipt_date", { required: true }).name}
                        onDateChange={(date, e) => {
                          trigger("receipt_date");
                          register("receipt_date").onChange(e);
                        }}
                        onBlur={(date) => {
                          const formattedDate = formatDateInYYYYMMDD(date);
                          setValue("receipt_date", formattedDate);

                          const isInFinancialYear = isDateInFinancialYear(date);
                          const futureDate = isFutureDate(date);
                          setIsInCurrFinYr(!isInFinancialYear || futureDate);
                        }}
                        validationTextLevel={isInCurrFinYr ? ValidationTextLevel.Error : undefined}
                      />
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={6}
                    xxl={6}
                  >
                    <div>
                      <FormLabel
                        className="mb-5"
                        forId="txtCostCentre"
                      >
                        {t("pettyCashExpenseFolio.costCentre")}
                      </FormLabel>
                      <Grid className="">
                        <GridItem
                          sm={1}
                          md={2}
                          lg={4}
                          xl={4}
                          xxl={4}
                          className="pr-8"
                        >
                          <Input
                            isLabel={false}
                            maxLength={100}
                            value={watch("cost_code")}
                            searchable
                            searchItems={costCenters?.map((b) => ({ text: b.code, value: b.code }))}
                            inputRef={(e) => register("cost_code").ref(e)}
                            name={register("cost_code", { required: true }).name}
                            onChange={(e) => onCostCentreChange(e)}
                            onBlur={(e: any) => {
                              register("cost_code").onBlur(e);
                            }}
                            onSelect={(selectedItem: ISelectedItem | undefined) => onCostCentreSelect(selectedItem)}
                            onPending={(selectedItem: ISelectedItem | undefined) => onCostCentrePending(selectedItem)}
                            onNoSelection={() => setIsOpenCostCenterModal(true)}
                            validationTextLevel={errors.cost_code ? ValidationTextLevel.Error : undefined}
                          />
                        </GridItem>
                        <GridItem
                          sm={3}
                          md={10}
                          lg={8}
                          xl={8}
                          xxl={8}
                          className="pl-0"
                        >
                          <div className="d-flex align-center">
                            <Tooltip content={watch("cost_des")}>
                              <div className="essui-textinput essui-textinput--medium read-only mr-8 input__calc--width wrap-input-data">
                                {watch("cost_des")}
                              </div>
                            </Tooltip>

                            <Button
                              color={ButtonColor.Secondary}
                              onClick={costCenterClick}
                              size={ButtonSize.Small}
                              className="essui-button-icon-only--small"
                            >
                              <Icon
                                color={IconColor.Primary500}
                                size={IconSize.Medium}
                                name="search"
                              />
                            </Button>
                          </div>
                        </GridItem>
                      </Grid>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={6}
                    xxl={6}
                  >
                    <div>
                      <FormLabel
                        className="mb-5"
                        forId="txtLedgerCode"
                      >
                        {t("pettyCashExpenseFolio.ledgerCode")}
                      </FormLabel>
                      <Grid className="">
                        <GridItem
                          sm={1}
                          md={2}
                          lg={4}
                          xl={4}
                          xxl={4}
                          className="pr-8"
                        >
                          <Input
                            onSelect={(selectedItem) => {
                              onLedgerCodeSelect(selectedItem);
                            }}
                            onNoSelection={() => setIsOpenLedgerCodesModal(true)}
                            isLabel={false}
                            maxLength={100}
                            value={watch("ledger_code")}
                            searchable
                            searchItems={ledgerCodes.map((b) => ({ text: b.code, value: b.code }))}
                            inputRef={(e) => register("ledger_code").ref(e)}
                            name={register("ledger_code", { required: true }).name}
                            onBlur={(e) => register("ledger_code").onBlur(e)}
                            onChange={(e) => {
                              onLedgerCodeChange(e);
                            }}
                            onPending={(selectedItem: ISelectedItem | undefined) => {
                              onLedgerCodePending(selectedItem);
                            }}
                            validationTextLevel={errors.ledger_code ? ValidationTextLevel.Error : undefined}
                          />
                        </GridItem>
                        <GridItem
                          sm={3}
                          md={10}
                          lg={8}
                          xl={8}
                          xxl={8}
                          className="pl-0"
                        >
                          <div className="d-flex align-center">
                            <Tooltip content={getValues("ledger_des")}>
                              <div className="read-only essui-textinput essui-textinput--medium mr-8 input__calc--width wrap-input-data">
                                {watch("ledger_des")}
                              </div>
                            </Tooltip>

                            <Button
                              color={ButtonColor.Secondary}
                              onClick={ledgerCodeClick}
                              size={ButtonSize.Small}
                              className="essui-button-icon-only--small"
                            >
                              <Icon
                                color={IconColor.Primary500}
                                size={IconSize.Medium}
                                name="search"
                              />
                            </Button>
                          </div>
                        </GridItem>
                      </Grid>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={6}
                    xxl={6}
                  >
                    <div>
                      <FormLabel
                        className="mb-5"
                        forId="txtFund"
                      >
                        {t("pettyCashExpenseFolio.fund")}
                      </FormLabel>
                      <Grid className="">
                        <GridItem
                          sm={1}
                          md={2}
                          lg={4}
                          xl={4}
                          xxl={4}
                          className="pr-8"
                        >
                          <Input
                            onSelect={(selectedItem) => {
                              onFundCodeSelect(selectedItem);
                            }}
                            onNoSelection={() => setIsOpenFundCodesModal(true)}
                            isLabel={false}
                            maxLength={100}
                            value={watch("fund_code")}
                            searchable
                            disabled={isDisabled || watch("ledger_code") === ""}
                            searchItems={fundCodes?.map((b) => ({ text: b.code, value: b.code }))}
                            inputRef={(e) => register("fund_code").ref(e)}
                            name={register("fund_code", { required: true }).name}
                            onBlur={(e) => register("fund_code").onBlur(e)}
                            onChange={(e) => {
                              onFundCodeChange(e);
                            }}
                            onPending={(selectedItem: ISelectedItem | undefined) => {
                              onFundCodePending(selectedItem);
                            }}
                            validationTextLevel={errors.fund_code ? ValidationTextLevel.Error : undefined}
                          />
                        </GridItem>
                        <GridItem
                          sm={3}
                          md={10}
                          lg={8}
                          xl={8}
                          xxl={8}
                          className="pl-0"
                        >
                          <div className="d-flex align-center">
                            <Tooltip content={getValues("fund_des")}>
                              <div
                                className={`${
                                  isDisabled ? "disabled-input" : null
                                } read-only essui-textinput essui-textinput--medium  mr-8 input__calc--width wrap-input-data`}
                              >
                                {watch("fund_des")}
                              </div>
                            </Tooltip>

                            <Button
                              color={ButtonColor.Secondary}
                              onClick={fundCodeClick}
                              size={ButtonSize.Small}
                              className={`essui-button-icon-only--small btnclass ${
                                isDisabled || watch("ledger_code") === "" ? "disabled" : null
                              }`}
                              disabled={isDisabled || watch("ledger_code") === ""}
                            >
                              <Icon
                                color={IconColor.Primary500}
                                size={IconSize.Medium}
                                name="search"
                              />
                            </Button>
                          </div>
                        </GridItem>
                      </Grid>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={6}
                    xxl={6}
                  >
                    <div className="vat-registration--number">
                      <FormLabel
                        forId="txtVATRegistration"
                        className="mb-5"
                      >
                        {t("pettyCashExpenseFolio.vatRegNo")}
                      </FormLabel>
                      <TextInputMask
                        className={`essui-textinput essui-textinput--medium ${
                          isVatRegNoErr ? "essui-textinput--error" : ""
                        }`}
                        maskId="txtVATRegistration"
                        maskType="tel"
                        maskElement="999-9999-99"
                        maskChar=" "
                        value={vatRegInputValue}
                        inputRef={(e) => register("vat_reg_no").ref(e)}
                        onChange={getVatRegNoInputData}
                        name="vat_reg_no"
                        onBlur={() => {
                          trigger("vat_reg_no");
                          return vatRegNoBlurEvent();
                        }}
                      />
                    </div>
                  </GridItem>
                </Grid>
              </GridItem>
              <GridItem
                sm={4}
                md={12}
                lg={4}
                xl={4}
                className="border-left"
              >
                <Grid>
                  <GridItem
                    sm={4}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <FormLabel className="essui-global-typography-default-subtitle">
                      {t("pettyCashExpenseFolio.budgetRemaining")}
                    </FormLabel>
                  </GridItem>
                  <GridItem
                    sm={2}
                    md={4}
                    lg={12}
                    xl={12}
                  >
                    <div className="mt-16">
                      <FormLabel forId="costCentre">{t("pettyCashExpenseFolio.costCentre")}</FormLabel>
                      <div className={parseFloat(getValues("cost_budget")) < 0 ? "playback-error" : ""}>
                        {watch("cost_budget") ? watch("cost_budget") : "0.00"}
                      </div>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={2}
                    md={4}
                    lg={12}
                    xl={12}
                  >
                    <div className="mt-16">
                      <FormLabel forId="combination">{t("pettyCashExpenseFolio.combination")}</FormLabel>
                      <div className={parseFloat(getValues("combination")) < 0 ? "playback-error" : ""}>
                        {watch("combination") ? watch("combination") : "0.00"}
                      </div>
                    </div>
                  </GridItem>
                </Grid>
              </GridItem>
            </Grid>
            <Grid className="row-gap-8 mt-8">
              <GridItem
                sm={4}
                md={8}
                lg={8}
                xl={8}
                xxl={8}
              >
                <div className="desc-fullwidth-input">
                  <FormLabel
                    forId="txtDescription"
                    className="mb-5"
                  >
                    {t("pettyCashExpenseFolio.description")}
                  </FormLabel>

                  <Textarea
                    {...register("description", { required: true })}
                    id="txtDescription"
                    rows={6}
                    className="width-100 min-w-100"
                    maxLength={80}
                    value={watch("description")}
                    onChange={(e) => {
                      setValue(
                        "description",
                        e.target.value.trim(),
                        ...(historyState?.lineItemMode === METHOD.ADD
                          ? [{ shouldDirty: true }]
                          : [{ shouldDirty: true }])
                      );
                      if (e.target.value.trim()) {
                        clearErrors("description");
                      } else {
                        trigger("description");
                      }
                    }}
                    validationTextLevel={errors.description ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </GridItem>
            </Grid>
            <Grid className="row-gap-8">
              <GridItem
                sm={4}
                md={3}
                lg={3}
                xl={3}
                xxl={3}
              >
                <div>
                  <FormLabel
                    forId="txtTotalIncVat"
                    className="mb-5"
                  >
                    {t("pettyCashExpenseFolio.totalIncVat")}
                  </FormLabel>
                  <InputNumberMask
                    allowNegative={false}
                    id="txtTotalIncVat"
                    beforeDecimalMaxLength={5}
                    afterDecimalCursorIndex={7}
                    beforeDecimalCursorIndex={6}
                    value={getValues("total_inc_vat") || "0.00"}
                    className="essui-textinput essui-textinput--medium w-100 custom-placeholder"
                    placeholder="0.00"
                    getInputRef={totalVatInputNumRef}
                    decimalSeparator="."
                    decimalScale={2}
                    fixedDecimalScale
                    thousandSeparator
                    name={
                      register("total_inc_vat", {
                        required: true,
                        validate: (value) => {
                          let isValid = (parseFloat(value) || 0) >= 0.0 && (parseFloat(value) || 0) < 100000000.0;
                          if (isValid && getValues("quantity")) {
                            isValid =
                              (parseInt(getValues("quantity"), 10) || 0) * (parseFloat(value) || 0) < 100000000.0;
                          }
                          return isValid;
                        }
                      }).name
                    }
                    onValueChange={(inputVal) => {
                      const { formattedValue, value, floatValue } = inputVal;
                      if (value !== "0.00") {
                        setValue(
                          "total_inc_vat",
                          value,
                          ...(historyState?.lineItemMode === METHOD.EDIT && isTotalIncVatChanged
                            ? [{ shouldDirty: false }]
                            : [{ shouldDirty: true }])
                        );
                        trigger("total_inc_vat");
                        if (isTotalIncVatChanged) {
                          setIsTotalIncVatChanged(false);
                        }
                      } else {
                        setValue("total_inc_vat", "");
                        trigger("total_inc_vat");
                      }
                    }}
                    onBlur={() => {
                      calculateVatAmount();
                      trigger("total_inc_vat");
                    }}
                    validationTextLevel={errors.total_inc_vat ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={3}
                lg={3}
                xl={3}
                xxl={3}
              >
                <div>
                  <FormLabel
                    className="mb-5"
                    forId="txtVatCode"
                  >
                    {t("pettyCashExpenseFolio.vatCode")}
                  </FormLabel>
                  <Grid className="">
                    <GridItem
                      sm={1}
                      md={2}
                      lg={3}
                      xl={3}
                      xxl={3}
                      className="pr-8"
                    >
                      <Input
                        onSelect={(selectedItem) => {
                          onVatCodeSelect(selectedItem);
                        }}
                        onNoSelection={() => setIsOpenVatCodesModal(true)}
                        isLabel={false}
                        maxLength={100}
                        value={watch("vat_code")}
                        searchable
                        searchItems={vatCodes.map((b) => ({ text: b.vat_code, value: b.vat_code }))}
                        inputRef={(e) => {
                          register("vat_code").ref(e);
                        }}
                        name={register("vat_code", { required: true }).name}
                        onBlur={(e) => register("vat_code").onBlur(e)}
                        validationTextLevel={errors.vat_code ? ValidationTextLevel.Error : undefined}
                        onChange={(e) => onVatCodeChange(e)}
                        onPending={(selectedItem) => {
                          onVatCodePending(selectedItem);
                        }}
                      />
                    </GridItem>
                    <GridItem
                      sm={3}
                      md={10}
                      lg={9}
                      xl={9}
                      xxl={9}
                      className="pl-0"
                    >
                      <div className="d-flex align-center">
                        <Tooltip content={getValues("vat_des")}>
                          <div className="read-only essui-textinput essui-textinput--medium  mr-8 input__calc--width wrap-input-data">
                            {getValues("vat_des")}
                          </div>
                        </Tooltip>
                        <Button
                          color={ButtonColor.Secondary}
                          onClick={vatCodeClick}
                          size={ButtonSize.Small}
                          className="essui-button-icon-only--small btncls"
                        >
                          <Icon
                            color={IconColor.Primary500}
                            size={IconSize.Medium}
                            name="search"
                          />
                        </Button>
                      </div>
                    </GridItem>
                  </Grid>
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
                xxl={2}
              >
                <div>
                  <FormLabel
                    forId="txtAmountVat"
                    className="mb-5"
                  >
                    {t("pettyCashExpenseFolio.amountOfVat")}
                  </FormLabel>
                  <InputNumberMask
                    allowNegative={false}
                    className="essui-textinput essui-textinput--medium w-100 custom-placeholder"
                    placeholder="0.00"
                    value={getValues("vat_amount") || "0.00"}
                    decimalSeparator="."
                    decimalScale={2}
                    getInputRef={vatInputNumRef}
                    beforeDecimalMaxLength={5}
                    afterDecimalCursorIndex={7}
                    beforeDecimalCursorIndex={6}
                    id="txtAmountVat"
                    fixedDecimalScale
                    thousandSeparator
                    name={
                      register("vat_amount", {
                        validate: (value) => {
                          let isValid = (parseFloat(value) || 0) >= 0.0 && (parseFloat(value) || 0) < 100000000.0;
                          if (isValid && getValues("quantity")) {
                            isValid =
                              (parseInt(getValues("quantity"), 10) || 0) * (parseFloat(value) || 0) < 100000000.0;
                          }
                          return isValid;
                        }
                      }).name
                    }
                    onValueChange={(inputVal) => {
                      const { formattedValue, value, floatValue } = inputVal;
                      setValue("vat_amount", value);
                      trigger("vat_amount");
                    }}
                    onBlur={onVatAmountChange}
                    validationTextLevel={isVatAmtErr ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
                xxl={2}
              >
                <div>
                  <div className="essui-form-label mb-5">{t("pettyCashExpenseFolio.totalExcvat")}</div>
                  <div className="height__equal--input">
                    {usNumberFormat(Number(getValues("total_exc_vat"))) ?? "0.00"}
                  </div>
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
                xxl={2}
              >
                <div>
                  <div className="essui-form-label mb-5">{t("pettyCashExpenseFolio.costToEstd")}</div>
                  <div className="height__equal--input">
                    {usNumberFormat(Number(getValues("cost_to_establishment"))) ?? "0.00"}
                  </div>
                </div>
              </GridItem>
            </Grid>
            <Grid className="flex-rev">
              <GridItem
                sm={2}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="rightbtn">
                  <Button
                    id="add-expense-folio-btn-save"
                    className="activate-route"
                    size={ButtonSize.Small}
                    color={ButtonColor.Primary}
                    onClick={() => {
                      setToSession("redirectPath", "");
                      onSubmitHandler();
                    }}
                  >
                    {t("common.save")}
                  </Button>
                  <Button
                    id="add-expense-folio-btn-cancel"
                    className="activate-route"
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    onClick={() => {
                      setToSession("redirectPath", "");
                      navigateBack(Number(transId));
                    }}
                  >
                    {t("common.cancel")}
                  </Button>
                </div>
              </GridItem>
              <GridItem
                sm={2}
                md={4}
                lg={6}
                xl={6}
              >
                <div>
                  <HelpButton
                    identifier="testIdentifier"
                    labelName={t("common.help")}
                  />
                </div>
              </GridItem>
            </Grid>
          </div>
        </div>
      </Layout>
      {/* )} */}
      <CostCentersModal
        isOpen={isOpenCostCenterModal}
        setOpen={setIsOpenCostCenterModal}
        headerTitle={t("pettyCashExpenseFolio.costCentreModalHeader")}
      />
      <LedgerCodesModal
        isOpen={isOpenLedgerCodesModal}
        setOpen={setIsOpenLedgerCodesModal}
        headerTitle={t("pettyCashExpenseFolio.ledgerCodeModalHeader")}
      />
      <FundCodesModal
        isOpen={isOpenFundCodesModal}
        setOpen={setIsOpenFundCodesModal}
        setIsDisabled={setIsDisabled}
        headerTitle={t("pettyCashExpenseFolio.fundCodeModalHeader")}
      />
      <VatCodesModal
        isOpen={isOpenVatCodesModal}
        setOpen={setIsOpenVatCodesModal}
        headerTitle={t("pettyCashExpenseFolio.vatCodeModalHeader")}
      />
      <AlertModal
        isOpen={openValidationModal}
        setOpen={setOpenValidationModal}
        title={t("alertMessage.title")}
        notificationType={NotificationStatus.HIGHLIGHT}
        message={t("common.invalidData")}
        autoFocusPrimaryBtn
      />
    </FormProvider>
  );
};

export default PettyCashExpenseFolio;
