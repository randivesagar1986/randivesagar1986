import { render, screen } from "@testing-library/react";
import { Provider } from "react-redux";
import configureStore from "redux-mock-store";
import "@testing-library/jest-dom/extend-expect";
import { NotificationStatus, ValidationTextLevel } from "@essnextgen/ui-kit";
import { STATUS } from "@/types/UseStateType";
import { FieldValues, useForm, UseFormReturn } from "react-hook-form";
import PettyCashExpenseFolio from "../PettyCashExpenseFolio";
import usePettyCashExpenseFolio from "../usePettyCashExpenseFolio";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn(),
  useLocation: jest.fn().mockReturnValue({ search: "" }),
  useRouteMatch: jest.fn()
}));
jest.mock("../../../../../../routes/Routes", () => ({
  useAppContext: () => ({
    setGlobalPaths: jest.fn()
  })
}));

jest.mock("../../../../../../store/store", () => ({
  useAppSelector: jest.fn().mockImplementation((selector) =>
    selector({
      ui: {
        alert: {
          className: "test-class"
        }
      },
      supplierCatalogue: {
        catalogueData: {
          catalogueList: {
            catalogue: [],
            currentPage: 1,
            totalCount: "",
            pageSize: 10
          }
        }
      }
    })
  )
}));

const mockUsePettyCashExp = usePettyCashExpenseFolio as jest.MockedFunction<typeof usePettyCashExpenseFolio>;
const mockUsePettyCashExpenseFolio = {
  onVatAmountChange: jest.fn(),
  setOpenValidationModal: jest.fn(),
  openValidationModal: false,
  vatRegInputValue: "",
  onSubmitHandler: jest.fn(),
  saveExpenseFolioItemStatus: "IDLE",
  costCenterStatus: "IDLE",
  ledgerCodeStatus: "IDLE",
  navigateBack: jest.fn(),
  transId: "123",
  isVatRegNoErr: false,
  historyState: { lineItemMode: "ADD" }
};

describe("PettyCashExpenseFolio", () => {
  let formMethods: UseFormReturn<FieldValues, any, undefined>;

  beforeEach(() => {
    formMethods = useForm();
    (usePettyCashExpenseFolio as jest.Mock).mockReturnValue({
      ...mockUsePettyCashExpenseFolio,
      formMethods: {
        ...formMethods,
        setValue: jest.fn(),
        register: jest.fn(),
        trigger: jest.fn(),
        clearErrors: jest.fn(),
        setError: jest.fn(),
        getValues: jest.fn(),
        control: formMethods.control,
        formState: {
          errors: {},
          isDirty: false,
          isSubmitted: false,
          submitCount: 0,
          isLoading: false,
          isSubmitSuccessful: false,
          isSubmitting: false,
          isValidating: false,
          isValid: false,
          disabled: false,
          dirtyFields: {},
          touchedFields: {},
          validatingFields: {}
        }
      }
    });
  });
  // Use the props object in your test case

  const mockStore = configureStore([]);
  const store = mockStore({
    supplierCatalogue: {
      status: STATUS.IDLE,
      catalogueData: {
        catalogueList: {
          catalogue: [],
          currentPage: 1,
          totalCount: "",
          pageSize: 10
        }
      }
    },
    supplierData: {
      supplierCatalogue: {
        catalogueData: {
          catalogueList: {
            catalogue: [],
            currentPage: 1,
            totalCount: "",
            pageSize: 10
          }
        }
      }
    }
  });

  test("should render CashBook component", () => {
    render(
      <Provider store={store}>
        <PettyCashExpenseFolio />
      </Provider>
    );
    expect(screen.getByTestId("add-petty-cash-expense-folio")).toBeInTheDocument();
  });

  // test("should render Recurrence Pattern buttons", () => {
  //   render(
  //     <Provider store={store}>
  //       <CashBook />
  //     </Provider>
  //   );
  //   expect(screen.getByTestId("btnAddRecurrence")).toBeInTheDocument();
  //   expect(screen.getByTestId("btnEditRecurrence")).toBeInTheDocument();
  //   expect(screen.getByTestId("btnDeleteRecurrence")).toBeInTheDocument();
  // });

  // test("should render AlertModal when isOpenAlert is true", () => {
  //   mockUseCashBook.mockReturnValueOnce({
  //     t: (key: string) => key,
  //     isOpenAlert: true,
  //     setIsOpenAlert: jest.fn(),
  //     alertType: NotificationStatus.HIGHLIGHT,
  //     setAlertType: jest.fn(),
  //     message: "Test Alert Message",
  //     setMessage: jest.fn(),
  //     getValues: jest.fn(),
  //     onSubmit: jest.fn(),
  //     watch: jest.fn()
  //   });
  //   render(
  //     <Provider store={store}>
  //       <CashBook />
  //     </Provider>
  //   );
  //   expect(screen.getByText("Test Alert Message")).toBeInTheDocument();
  // });

  // test("should display correct values in input fields", () => {
  //   render(
  //     <Provider store={store}>
  //       <CashBook />
  //     </Provider>
  //   );
  //   expect(screen.getByDisplayValue("1")).toBeInTheDocument();
  //   expect(screen.getByDisplayValue("Apr")).toBeInTheDocument();
  //   expect(screen.getByDisplayValue("1st Glass")).toBeInTheDocument();
  //   expect(screen.getByDisplayValue("Test")).toBeInTheDocument();
  //   expect(screen.getByDisplayValue("BK01")).toBeInTheDocument();
  //   expect(screen.getByDisplayValue("Bank Account")).toBeInTheDocument();
  // });
});
