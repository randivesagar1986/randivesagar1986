import "./Style.scss";
import { useHistory, useLocation, useParams } from "react-router-dom";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { ChangeEvent, useEffect, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { getDefaultPaymentPeriod } from "@/store/state/defaultYear.slice";
import { ISelectedItem, NotificationStatus, ValidationTextLevel } from "@essnextgen/ui-kit";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import UseStateType, { METHOD, specialCharacters, STATUS } from "@/types/UseStateType";
import { actions as ledgerActions } from "@/shared/components/LedgerCodesModal/state/LedgerCodes.slice";
import { actions as costActions, getLinks } from "@/shared/components/CostCenterModal/state/costCenters.slice";
import { actions as fundActions } from "@/shared/components/FundCodesModal/state/FundCodes.slice";
import { actions as vatActions } from "@/shared/components/VatCodesModal/state/VatCodes.slice";
import { actions as sidebarMenuActions } from "@/components/SidebarMenu/state/SidebarMenu.slice";
import {
  expenseFolioActions,
  getCostEstablismentAmt,
  getExpenseItemDetail,
  getVatAmount,
  getVatId,
  saveExpenseFolio
} from "@/pages/GeneralLedger/PettyCashProcessing/state/PettyCashExpenseFolio.slice";
import { formatDateInYYYYMMDD } from "@/shared/components/InputDate/formatDate";
import {
  dateConvertInSlashFormat,
  getDateTime,
  getSessionItem,
  setToSession,
  usNumberFormat
} from "@/utils/getDataSource";
import { isAfter, parse } from "date-fns";
import { useClickAway } from "@/hooks/useClickAway";
import { expenditureActions } from "../../state/ViewExpenditure.slice";
import { getPettyCashList } from "../../state/PettyCashList.slice";

/* eslint-disable camelcase */
type FormData = {
  cost_code: string;
  cost_des: string;
  cost_budget: string;
  fullCC: string;
  ledger_code: string;
  ledger_des: string;
  fullLC: string;
  fund_code: string;
  fund_des: string;
  combination: string;
  pc_folio_no: string;
  pc_folio_id: number;
  pc_trans_id: number;
  ledger_id: number;
  cost_id: number;
  net_amount: string;
  vat_amount: string;
  vat_id: number;
  cost_to_establishment: string;
  description: string;
  receipt_date: string;
  vat_reg_no: string;
  vat_des: string;
  vat_code: string;
  total_inc_vat: string;
  total_exc_vat: string;
  quantity: string;
};
const numberFormatter: any = new Intl.NumberFormat("en-US", {
  style: "decimal",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});

const VAT_CODE = {
  Default_Value: "000000000"
};

let isIncVatAPICalled = false;
let isSaveAPICalled = false;
let isVatAmtAPICalled = false;

const usePettyCashExpenseFolio = () => {
  const mandFieldDefaultValues = {
    cost_des: "",
    ledger_code: "",
    ledger_des: "",
    fund_code: "",
    fund_des: "",
    vat_reg_no: "",
    description: "",
    total_inc_vat: "",
    vat_code: "",
    vat_des: "",
    vat_amount: "0.00"
  };

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const historyState = { ...(history.location.state as any) };
  const location = useLocation();
  const dispatch = useDispatch<AppDispatch>();
  const nameInputRef = useRef<HTMLInputElement | null>(null);
  const { costCenters, selectedCostCentre, filters: costFilters } = useAppSelector((state) => state.costCenters);
  const { status: costCenterStatus } = useAppSelector((state) => state.costCenters);
  const [isInCurrFinYr, setIsInCurrFinYr] = useState<boolean>(false);
  const [isReceiptFutureDate, setIsReceiptFutureDate] = useState<boolean>(false);
  const [isVatAmtErr, setIsVatAmtErr] = useState<boolean>(false);
  const [openValidationModal, setOpenValidationModal] = useState<boolean>(false);
  const { expenditureItems } = useAppSelector((state) => state.expenditureDetails.expenditureDetails);
  const { confirm } = useAppSelector((state) => state.ui);
  const { setIsSidebarOpen } = sidebarMenuActions;
  const {
    status: ledgerCodeStatus,
    ledgerCodes,
    selectedLedgerCode,
    filters: ledgerFilters
  } = useAppSelector((state) => state.ledgerCodes);
  const {
    vatCodes,
    selectedVatCode,
    prevSelectedVatCode,
    isOpen,
    status: vatCodeStatus
  } = useAppSelector((state) => state.vatCodes);
  const { status: fundCodeStatus, fundCodes, selectedfundCode } = useAppSelector((state) => state.fundCodes);
  const { saveExpenseFolioItemStatus, expenseItemDetail } = useAppSelector((state) => state.PettyCashExpenseFolio);
  const { filterState } = useAppSelector((state) => state.pettyCashList);
  const [expenseFolioDate, setExpenseFolioDate] = useState<string>("");
  const [isOpenCostCenterModal, setIsOpenCostCenterModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isOpenLedgerCodesModal, setIsOpenLedgerCodesModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isOpenFundCodesModal, setIsOpenFundCodesModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isOpenVatCodesModal, setIsOpenVatCodesModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isDisabled, setIsDisabled] = useState<boolean>(true);
  const [callVatAmtAPI, setCallVatAmtAPI] = useState<boolean>(false);
  const [isVatRegNoErr, setIsVatRegNoErr] = useState<boolean>(false);
  const [vatRegInputValue, setVatRegInputValue] = useState("");
  const [isTotalIncVatChanged, setIsTotalIncVatChanged] = useState<boolean>(true);
  const { pcAccountId, transId } = useParams<{ pcAccountId: string; transId: string }>();
  const editFieldValue = useRef<FormData | null>(null);

  const formMethods = useForm<FormData>({
    mode: "all",
    defaultValues: {
      cost_budget: "0.00",
      combination: "0.00",
      quantity: "0",
      ...mandFieldDefaultValues
    }
  });

  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    watch,
    reset,
    clearErrors,
    setError,
    formState: { errors, isDirty, dirtyFields },
    getValues,
    getFieldState
  } = formMethods;

  const flag = false;
  const allWatchedFormValues: Record<string, any> = watch();
  const [initialValues] = useState<Record<string, any>>(() => getValues());
  const [isFieldDirty, setIsFieldDirty] = useState<boolean>(false);
  const [hasReset, setHasReset] = useState<boolean>(false);

  useEffect(() => {
    reset({
      pc_folio_id: expenseItemDetail?.pc_folio_id,
      pc_folio_no: expenseItemDetail?.pc_folio_no,
      cost_code: expenseItemDetail?.cost_code ?? "",
      cost_des: expenseItemDetail?.cost_des ?? "",
      ledger_code: expenseItemDetail?.ledger_code ?? "",
      ledger_des: expenseItemDetail?.ledger_des ?? "",
      fund_code: expenseItemDetail?.fund_code ?? "",
      fund_des: expenseItemDetail?.fund_des ?? "",
      pc_trans_id: expenseItemDetail?.pc_trans_id ?? 0,
      ledger_id: expenseItemDetail?.ledger_id ?? "",
      cost_id: expenseItemDetail?.cost_id ?? "",
      net_amount: expenseItemDetail?.net_amount ?? "0.00",
      vat_amount: expenseItemDetail?.vat_amount ?? "0.00",
      vat_id: expenseItemDetail?.vat_id ?? "",
      cost_to_establishment: expenseItemDetail?.cost_to_establishment ?? "0.00",
      description: expenseItemDetail?.description ?? "",
      vat_reg_no: expenseItemDetail?.vat_reg_no ?? "",
      vat_code: expenseItemDetail?.vat_code ?? "",
      total_inc_vat: expenseItemDetail?.line_cost
    });
    if (expenseItemDetail?.line_cost) {
      const totalExcVat = expenseItemDetail?.line_cost - expenseItemDetail?.vat_amount;
      setValue("total_exc_vat", String(totalExcVat.toFixed(2)));
    } else {
      setValue("total_exc_vat", "0.00");
    }

    const date1 = expenseItemDetail?.receipt_date ? expenseItemDetail?.receipt_date : String(new Date());
    const formattedDate = formatDateInYYYYMMDD(date1); // `${day}/${month}/${year}`;

    setValue("receipt_date", formattedDate);
    setExpenseFolioDate(formattedDate);
    setVatRegInputValue(expenseItemDetail?.vat_reg_no);
    editFieldValue.current = {
      pc_folio_id: expenseItemDetail?.pc_folio_id,
      pc_folio_no: expenseItemDetail?.pc_folio_no,
      cost_code: expenseItemDetail?.cost_code ?? "",
      cost_des: expenseItemDetail?.cost_des ?? "",
      ledger_code: expenseItemDetail?.ledger_code ?? "",
      ledger_des: expenseItemDetail?.ledger_des ?? "",
      fund_code: expenseItemDetail?.fund_code ?? "",
      fund_des: expenseItemDetail?.fund_des ?? "",
      pc_trans_id: expenseItemDetail?.pc_trans_id ?? 0,
      ledger_id: expenseItemDetail?.ledger_id ?? "",
      cost_id: expenseItemDetail?.cost_id ?? "",
      net_amount: expenseItemDetail?.net_amount ?? "0.00",
      vat_amount: String(expenseItemDetail?.vat_amount?.toFixed(2)) ?? "0.00",
      vat_id: expenseItemDetail?.vat_id ?? "",
      cost_to_establishment: expenseItemDetail?.cost_to_establishment ?? "0.00",
      description: expenseItemDetail?.description ?? "",
      vat_reg_no: expenseItemDetail?.vat_reg_no ?? "",
      vat_code: expenseItemDetail?.vat_code ?? "",
      total_inc_vat: String(expenseItemDetail?.line_cost?.toFixed(2)),
      vat_des: expenseItemDetail?.vat_des ?? ""
    } as FormData;
  }, [expenseItemDetail]);

  const noCallback = (target: HTMLElement) => {
    reset(allWatchedFormValues);
    setIsFieldDirty(false);
    setHistoryRedirect(false);
    return true;
  };

  // Wrapper to handle noCallback with a parameter
  const noCallbackWrapper = (target: HTMLElement) => {
    noCallback(target); // Pass the event target to the actual noCallback function
  };

  const yesCallback = (e: HTMLElement) => {
    onSubmitHandler();
  };

  const handleCancelCallback = () => {
    homeRef.current = null;
    menuRef.current = null;
  };
  const { menuRef, setHistoryRedirect, reDispatchEvent, targetRef, homeRef } = useClickAway({
    isDirty: isFieldDirty || historyState?.isDirty, // Check if the form is dirty or the history state is dirty
    yesCallback: (e) => yesCallback(e),
    noCallback: noCallbackWrapper,
    cancelCallback: handleCancelCallback,
    popupTitle: t("common.simsFMSModule"),
    popupMessage: t("alertMessage.keepChangesMsg"),
    unblockCondition:
      (history?.location?.pathname?.includes("/general-ledger/petty-cash/add-expenditure") ||
        history?.location?.pathname?.includes("/general-ledger/petty-cash/edit-expenditure")) &&
      history?.location?.pathname?.includes("expense-folio"), // extra condition to check for the specific page
    isNonReturnYesCallback: true
  });

  useEffect(() => {
    // create isfieldDirty flag and set by comparison of default values and current values
    const defaultKeys = Object.keys(mandFieldDefaultValues) as (keyof FormData)[];
    let hasNoChanges = true;
    if (historyState?.lineItemMode === METHOD.ADD) {
      hasNoChanges = defaultKeys.every((key) => {
        if (getValues(key) !== undefined && getValues(key) !== "" && getValues(key) !== null) {
          return getValues(key) === initialValues[key];
        }
        return true;
      });
    } else {
      hasNoChanges = defaultKeys.every((key) => allWatchedFormValues[key] === editFieldValue.current?.[key]);
    }
    if (isFieldDirty === hasNoChanges) {
      setIsFieldDirty(!hasNoChanges);
    }
  }, [mandFieldDefaultValues, getValues, initialValues, expenseItemDetail, editFieldValue.current]);

  useEffect(() => {
    if (historyState?.lineItemMode === METHOD.ADD) {
      const date1 = String(new Date());
      const formattedDate = formatDateInYYYYMMDD(date1); // `${day}/${month}/${year}`;
      setValue("receipt_date", formattedDate);
      setExpenseFolioDate(formattedDate);
    }

    // if this page open in EDIT Mode
    if (historyState?.lineItemMode === METHOD.EDIT && historyState?.selectedExpenditureRow?.pc_folio_id) {
      if (historyState.mode === METHOD.ADJUST) {
        const selectedAjustedRow = historyState?.expenditureItems?.find(
          (item: any) => item?.pc_folio_id === historyState?.selectedExpenditureRow?.pc_folio_id
        );
        dispatch(expenseFolioActions.resetExpenseItemDetail(selectedAjustedRow));
      } else {
        dispatch(
          getExpenseItemDetail({
            pcFolioId: Number(historyState?.selectedExpenditureRow?.pc_folio_id)
          })
        );
      }
    }

    return () => {
      isVatAmtAPICalled = false;
      dispatch(costActions.reset());
      dispatch(ledgerActions.reset());
      dispatch(fundActions.reset());
      dispatch(vatActions.reset());
      dispatch(expenseFolioActions.resetExpenseItemDetail({}));
    };
  }, []);

  const onSelectCostHandler = (row?: { [key: string]: any }) => {
    const validOptions = row ? { shouldDirty: true, shouldTouch: true, shouldValidate: true } : undefined;
    setValue("cost_code", row?.code ? row?.code : "", validOptions);
    setValue("cost_des", row?.description ? row?.description : "", validOptions);
    setValue("cost_budget", row ? usNumberFormat(row?.cost_centre_balance) : "0.00");
    setValue("fullCC", `(${row?.code}) ${row?.description}`);
    dispatch(costActions.selectRow(row));
  };
  const onSelectLedgerHandler = (row?: { [key: string]: any }) => {
    const validOptions = row ? { shouldValidate: true } : undefined;
    setValue("ledger_code", row?.code ? row?.code : "", validOptions);
    setValue("ledger_des", row?.description, validOptions);
    setValue("fullLC", `(${row?.code}) ${row?.description}`);
    dispatch(ledgerActions.selectRowLedgerCode(row));
  };
  useEffect(() => {
    if (
      !selectedCostCentre &&
      !selectedLedgerCode &&
      watch("cost_code") &&
      watch("ledger_code") &&
      costCenterStatus === STATUS.SUCCESS &&
      ledgerCodeStatus === STATUS.SUCCESS
    ) {
      const costRow = costCenters.find((c) => c.code === watch("cost_code"));
      const ledgerRow = ledgerCodes.find((c) => c.code === watch("ledger_code"));
      if (costRow) {
        onSelectCostHandler(costRow);
      }
      if (ledgerRow) {
        onSelectLedgerHandler(ledgerRow);
      }
    }
  }, [selectedCostCentre, selectedLedgerCode, costCenterStatus, ledgerCodeStatus]);

  useEffect(() => {
    if (!selectedLedgerCode) {
      setValue("vat_code", "");
      setValue("vat_des", "");
      dispatch(vatActions.selectVatCode({ row: {} }));
    } else if (!selectedLedgerCode?.vat_id && !selectedCostCentre && vatCodes) {
      dispatch(
        getVatId({
          leddefId: selectedLedgerCode?.id,
          callback: (res) => {
            const vatRowData = vatCodes.find((l: any) => l?.vat_id === res);
            setValue("vat_code", vatRowData?.vat_code);
            setValue("vat_des", vatRowData?.vat_des);
            dispatch(vatActions.selectVatCode({ row: vatRowData }));
          }
        })
      );
    }
  }, [selectedLedgerCode]);

  useEffect(() => {
    const promise = dispatch(
      getLinks({
        cost: {
          leddefid: selectedLedgerCode?.id
        },
        ledger: {
          costId: selectedCostCentre?.id,
          callback: (data) => {
            const row = data.find((l: any) => l?.id === selectedLedgerCode?.id);
            if (data.length === 1 && selectedLedgerCode?.id !== data?.at(0).id) {
              onSelectLedgerHandler(data?.at(0));
              return;
            }
            if (!row && selectedCostCentre) {
              onSelectLedgerHandler(undefined);
            }
          }
        }
      })
    );

    return () => promise.abort();
  }, [selectedCostCentre]);

  useEffect(() => {
    const promise = dispatch(
      getLinks({
        cost: {
          leddefid: selectedLedgerCode?.id,
          callback: (data) => {
            if (data.length === 1 && selectedCostCentre?.id !== data?.at(0).id) {
              onSelectCostHandler(data?.at(0));
              return;
            }
            const row = data.find((c: any) => c?.id === selectedCostCentre?.id);
            if (!row && selectedLedgerCode) {
              onSelectCostHandler(undefined);
            }
          }
        },
        ledger: {
          costId: selectedCostCentre?.id
        }
      })
    );

    return () => promise.abort();
  }, [selectedLedgerCode]);

  const onCostCentreChange = (e: any) => {
    setValue("cost_code", e.target.value);
    setValue("cost_des", e.target.value ? getValues("cost_des") : specialCharacters.BLANKVALUE);
  };

  const onCostCentreSelect = (selectedItem: ISelectedItem | undefined) => {
    const costCenter = costCenters.filter((s) => s.code === selectedItem?.value).at(0);
    setValue(
      "cost_des",
      costCenters.length === 1 || (selectedItem?.text && getValues("cost_code") !== "")
        ? costCenter?.description
        : specialCharacters.BLANKVALUE
    );
    setValue("cost_code", selectedItem?.text ? selectedItem.text! : specialCharacters.BLANKVALUE);
    setValue("cost_budget", costCenter ? usNumberFormat(costCenter?.cost_centre_balance) : "0.00");
    setValue("fullCC", `(${costCenter?.code}) ${costCenter?.description}`);
    dispatch(costActions.selectRow(costCenter));
  };

  const onCostCentrePending = (selectedItem: ISelectedItem | undefined) => {
    const costCenter = costCenters.filter((s) => s.code === selectedItem?.value).at(0);
    setValue("cost_des", costCenter?.description);
    setValue("cost_budget", costCenter?.cost_centre_balance);
    if (costCenter === undefined) {
      dispatch(costActions.selectRow(undefined));
    }
  };

  const costCenterClick = () => {
    setCallVatAmtAPI(true);
    setIsOpenCostCenterModal(true);
  };

  const ledgerCodeClick = () => {
    setIsOpenLedgerCodesModal(true);
    setCallVatAmtAPI(true);
    trigger("cost_code");
  };

  const onLedgerCodeSelect = (selectedItem: ISelectedItem | undefined) => {
    const ledgerCodeValue = ledgerCodes?.filter((s) => s.code === selectedItem?.value)[0];
    setValue(
      "ledger_des",
      ledgerCodes?.length === 1 || (selectedItem?.text && getValues("ledger_code") !== "")
        ? ledgerCodeValue?.description
        : specialCharacters.BLANKVALUE
    );
    setValue("ledger_code", selectedItem?.text ? selectedItem.text! : specialCharacters.BLANKVALUE);
    setValue("fullLC", `(${ledgerCodeValue?.code}) ${ledgerCodeValue?.description}`);
    dispatch(ledgerActions.selectRowLedgerCode(ledgerCodeValue));
  };

  const onLedgerCodeChange = (e: any) => {
    register("ledger_code").onChange(e);
    if (!e.target.value) {
      setValue("ledger_code", specialCharacters.BLANKVALUE);
      setValue("ledger_des", specialCharacters.BLANKVALUE);
    }
  };

  const onLedgerCodePending = (selectedItem: ISelectedItem | undefined) => {
    const row = ledgerCodes.filter((s) => s.code === selectedItem?.value).at(0);
    if (row) {
      setValue("ledger_des", row?.description);
    } else {
      setValue("fund_code", "");
      setValue("fund_des", "");
      setValue("vat_code", "");
      setValue("vat_des", "");
      dispatch(vatActions.selectVatCode({ row: {} }));
      setValue("combination", "0.00");
      dispatch(ledgerActions.selectRowLedgerCode(undefined));
    }
  };

  const onFundCodeSelect = (selectedItem: ISelectedItem | undefined) => {
    const fundCodeValue = fundCodes.filter((s) => s.code === selectedItem?.value).at(0);
    setValue(
      "fund_des",
      fundCodes.length === 1 || (selectedItem?.text && getValues("fund_code") !== "")
        ? fundCodeValue?.description
        : specialCharacters.BLANKVALUE
    );
    if (selectedItem?.text) {
      setValue("fund_code", selectedItem.text!);
    } else {
      setValue("fund_code", specialCharacters.BLANKVALUE);
    }
    dispatch(fundActions.selectRow(fundCodeValue));
  };

  const onFundCodeChange = (e: any) => {
    register("fund_code").onChange(e);
    if (!e.target.value) {
      setValue("fund_code", specialCharacters.BLANKVALUE);
      setValue("fund_des", specialCharacters.BLANKVALUE);
    }
  };
  const onFundCodePending = (selectedItem: ISelectedItem | undefined) => {
    const row = fundCodes?.filter((s) => s.code === selectedItem?.value).at(0);
    setValue("fund_des", row?.description);
    if (row === undefined) {
      dispatch(fundActions.selectRow(undefined));
    }
  };
  const fundCodeClick = () => {
    setIsOpenFundCodesModal(true);
  };

  const onVatCodeSelect = (selectedItem: ISelectedItem | undefined) => {
    const vatcodesValue = vatCodes.filter((s) => s.vat_code === selectedItem?.value)[0];
    setValue(
      "vat_des",
      vatCodes.length === 1 || (selectedItem?.text && getValues("vat_code") !== "")
        ? vatcodesValue?.vat_des
        : specialCharacters.BLANKVALUE
    );
    setValue("vat_code", selectedItem?.text ? selectedItem.text! : specialCharacters.BLANKVALUE);
    dispatch(vatActions.selectVatCode({ row: vatcodesValue }));
  };

  const vatCodeClick = () => {
    setCallVatAmtAPI(true);
    setIsOpenVatCodesModal(true);
  };

  const setVatAmount = () => {
    if ((callVatAmtAPI || isVatAmtAPICalled) && getValues("total_inc_vat") && selectedVatCode?.vat_id) {
      isIncVatAPICalled = true;
      dispatch(
        getVatAmount({
          amount: getValues("total_inc_vat"),
          vatId: selectedVatCode?.vat_id,
          callback: (res: any) => {
            clearErrors("vat_amount");
            setIsVatAmtErr(false);
            setValue("cost_to_establishment", String(Number(res?.establisamt)?.toFixed(2)));
            setValue("vat_amount", Number(res?.vatamount)?.toFixed(2));
            const totExcVat = Number(getValues("total_inc_vat")) - Number(res?.vatamount);
            setValue("total_exc_vat", String(totExcVat.toFixed(2)));
            trigger("total_exc_vat");
            isIncVatAPICalled = false;
            if (isSaveAPICalled) {
              isSaveAPICalled = false;
              submitHandler();
            }
          }
        })
      );
    } else if (!getValues("total_inc_vat")) {
      setValue("cost_to_establishment", "0.00");
      setValue("vat_amount", "");
      setValue("total_exc_vat", "0.00");
    }
  };

  const calculateVatAmount = () => {
    isVatAmtAPICalled = true;
    setVatAmount();
  };

  useEffect(() => {
    if (getValues("vat_code") && getValues("total_inc_vat")) setVatAmount();
  }, [getValues("vat_des"), selectedVatCode]);

  const onVatCodeChange = (e: any) => {
    setCallVatAmtAPI(true);
    register("vat_code").onChange(e);
    if (e.target.value) {
      if (getValues("vat_code") && getValues("total_inc_vat")) setVatAmount();
    } else {
      setValue("vat_code", specialCharacters.BLANKVALUE);
      setValue("vat_des", specialCharacters.BLANKVALUE);
    }
  };
  const onVatCodePending = (selectedItem: ISelectedItem | undefined) => {
    const row = vatCodes.filter((s) => s.vat_code === selectedItem?.value).at(0);
    setValue("vat_des", row?.vat_des);
    if (row === undefined) {
      dispatch(vatActions.selectVatCode({ row: undefined }));
    }
    return null;
  };

  const getVatRegNoInputData = (event: ChangeEvent<HTMLInputElement>) => {
    setVatRegInputValue(event.target.value);
    if (vatRegInputValue === "") {
      setVatRegInputValue(VAT_CODE.Default_Value);
      setValue("vat_reg_no", "");
      register("vat_reg_no").onChange(event);
    }
  };

  const vatRegNoBlurEvent = () => {
    setIsVatRegNoErr(false);
    let Code = vatRegInputValue;
    let sVatA = "";
    let sVatB = "";
    let sVatC = "";

    if (Code !== "") {
      const parts = Code?.split("-");
      sVatA = parts[0]?.split(" ").join("") || "";
      sVatB = parts[1]?.split(" ").join("") || "";
      sVatC = parts[2]?.split(" ").join("") || "";

      while (sVatA.length < 3) {
        sVatA = `0${sVatA}`;
      }
      while (sVatB.length < 4) {
        sVatB = `0${sVatB}`;
      }
      while (sVatC.length < 2) {
        sVatC = `0${sVatC}`;
      }

      Code = sVatA + sVatB + sVatC;
      if (
        getValues("vat_amount") &&
        Number(getValues("vat_amount")) > 0 &&
        !(!Number.isNaN(Code) && Number(Code) > 0)
      ) {
        setIsVatRegNoErr(true);
      }
      const modifiedCodeString = `${sVatA}${"-"}${sVatB}${"-"}${sVatC}`;
      setVatRegInputValue(Code);
      if (!Number.isNaN(Code) && Number(Code) > 0) {
        setValue("vat_reg_no", modifiedCodeString);
        setVatRegInputValue(modifiedCodeString);
      }
      // All zeroes isn't valid so treat as empty
      if (Code === VAT_CODE.Default_Value) {
        Code = VAT_CODE.Default_Value;
        setVatRegInputValue(modifiedCodeString);
      }
    }
    return Code;
  };

  const isFutureDate = (dateString: string) => {
    const date = parse(dateString, "yyyy-MM-dd", new Date());
    const currentDate = new Date();
    const isAfterDate = isAfter(date, currentDate);
    setIsReceiptFutureDate(isAfterDate);
    return isAfterDate;
  };

  const onVatAmountChange = () => {
    setIsVatAmtErr(false);
    setIsVatRegNoErr(false);
    const grossAmt = getValues("total_inc_vat");
    const vatId = selectedVatCode?.vat_id;
    const vatAmt = getValues("vat_amount");
    if (grossAmt && vatAmt) {
      const totExcVat = Number(grossAmt) - Number(vatAmt);
      const isVatAmtGreater = Number(grossAmt) < Number(vatAmt);
      if (isVatAmtGreater) {
        setValue("cost_to_establishment", String(totExcVat.toFixed(2)));
        setValue("total_exc_vat", String(totExcVat.toFixed(2)));
        setIsVatAmtErr(isVatAmtGreater);
        return null;
      }
      if (selectedVatCode?.rate === 0 && Number(vatAmt) > 0) {
        setIsVatAmtErr(true);
      }
      if (grossAmt && vatAmt && vatId) {
        dispatch(
          getCostEstablismentAmt({
            grossAmount: grossAmt,
            VatAmount: vatAmt,
            vatId,
            callback: (res: number) => {
              setValue("cost_to_establishment", Math.abs(res).toFixed(2));
              setValue("total_exc_vat", String(totExcVat.toFixed(2)));
              trigger("cost_to_establishment");
            }
          })
        );
      } else {
        setValue("cost_to_establishment", `-${Number(grossAmt).toFixed(2)}`);
        setValue("total_exc_vat", `-${Number(grossAmt).toFixed(2)}`);
        trigger("cost_to_establishment");
      }
    }
    return null;
  };

  const navigateBack = (transId: number) => {
    let pagePrefix = "";
    switch (historyState.mode) {
      case METHOD.EDIT:
        pagePrefix = "edit-expenditure";
        break;
      case METHOD.ADJUST:
        pagePrefix = "adjust-expenditure";
        break;
      default:
        pagePrefix = "add-expenditure";
        break;
    }
    history.push({
      pathname: `/general-ledger/petty-cash/${pagePrefix}/${pcAccountId}/${transId}`,
      state: { ...historyState, redirect: true }
    });
  };
  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;

  const adjustSubmitHandler = (data: any) => {
    const selectedAjustedRow = historyState?.expenditureItems?.find(
      (item: any) => item?.pc_folio_id === historyState?.selectedExpenditureRow?.pc_folio_id
    );
    const updatedData = {
      ...selectedAjustedRow,
      ...data,
      vat_amount: Number(data.vat_amount),
      cost_to_establishment: Number(data.cost_to_establishment),
      receipt_date: getDateTime(data?.receipt_date),
      ledger_id: selectedLedgerCode?.id,
      net_amount: Number(data.total_exc_vat),
      line_cost: Number(data.total_inc_vat),
      fund_id: selectedfundCode?.id
    };
    const index = historyState?.expenditureItems.findIndex(
      (item: any) => item?.pc_folio_id === selectedAjustedRow?.pc_folio_id
    );
    const oldExpenditureItems = [...historyState?.expenditureItems];
    if (oldExpenditureItems[index]) {
      oldExpenditureItems[index] = updatedData;

      dispatch(expenditureActions.setSelectedExpenditureRow(updatedData));
      // To keep the row selected after edit
      history.push({
        pathname: `/general-ledger/petty-cash/adjust-expenditure/${pcAccountId}/${transId}`,
        state: {
          ...historyState,
          expenditureItems: oldExpenditureItems
        }
      });
    }
  };
  const getListPettyCashList = (submitResponse: any) => {
    dispatch(
      getPettyCashList({
        ...filterState,
        pcAccountId: Number(pcAccountId),
        pcTransId: submitResponse?.pc_trans_id,
        callback: (data) => {}
      })
    );
  };
  const saveSubmitHandler = (data: any) => {
    const pettyCashExpenditureData: any = {};
    pettyCashExpenditureData.pc_folio_id = getValues("pc_folio_id") ?? 0;
    pettyCashExpenditureData.pc_trans_id = Number(transId);
    pettyCashExpenditureData.ledger_id = selectedLedgerCode?.id;
    pettyCashExpenditureData.cost_id = selectedCostCentre?.id;
    pettyCashExpenditureData.net_amount = String(data.total_exc_vat);
    pettyCashExpenditureData.vat_amount = String(data.vat_amount);
    pettyCashExpenditureData.fundId = selectedfundCode?.id;
    pettyCashExpenditureData.ledgersourceid = 0;
    pettyCashExpenditureData.vat_id = selectedVatCode?.vat_id;
    pettyCashExpenditureData.cost_to_establishment = String(data.cost_to_establishment);
    pettyCashExpenditureData.description = data.description;
    pettyCashExpenditureData.receipt_date = data.receipt_date.split("-").reverse().join("/");
    pettyCashExpenditureData.vat_reg_no = vatRegInputValue;

    const formData: any = {};
    formData.pcAccountId = Number(pcAccountId);
    formData.pc_trans_id = Number(transId);
    formData.book_id = Number(historyState?.selectedBook?.book_id);
    formData.pettyCashExpenditure = pettyCashExpenditureData;
    historyState.ExpenseFolioData = formData;
    dispatch(
      saveExpenseFolio({
        formData,
        callback: (res) => {
          // This if condition is added to check if the save is successful then only get the list of petty cash list to handle next and previous button
          if (historyState.mode === METHOD.ADD) {
            getListPettyCashList(res);
          }
          // Saved Success. Return to Expense Folio Listing Page
          historyState.mode = METHOD.EDIT;
          dispatch(expenditureActions.setPettyCashBookDirty(false));
          if (getSessionItem("redirectPath") || homeRef.current || menuRef.current) {
            if (homeRef.current) {
              history.push({
                pathname: "/",
                state: {
                  redirect: true
                }
              });
              setHistoryRedirect(true);
            } else if (menuRef.current) {
              dispatch(setIsSidebarOpen(true));
              setHistoryRedirect(false);
              menuRef.current = null;
              return;
            } else {
              reDispatchEvent(targetRef.current);
              setHistoryRedirect(true);
            }
            homeRef.current = null;
          } else {
            navigateBack(Number(res?.pc_trans_id));
          }
        }
      })
    );
  };
  const submitHandler = handleSubmit(
    (data) => {
      isSaveAPICalled = false;
      isIncVatAPICalled = false;
      const regex = /[1-9]/;
      if (
        isVatAmtErr ||
        isInCurrFinYr ||
        (getValues("vat_amount") && Number(getValues("vat_amount")) > 0 && !regex.test(vatRegInputValue))
      ) {
        setIsVatRegNoErr(!regex.test(vatRegInputValue));
        setOpenValidationModal(true);
        return null;
      }
      if (historyState.mode === METHOD.ADJUST) {
        adjustSubmitHandler(data);
      } else {
        saveSubmitHandler(data);
      }

      return null;
    },
    (error) => {
      isSaveAPICalled = false;
      isIncVatAPICalled = false;
      setOpenValidationModal(true);
      dispatch(setIsSidebarOpen(false));
      setHistoryRedirect(true);
    }
  );

  const onSubmitHandler = () => {
    isSaveAPICalled = true;
    if (!isIncVatAPICalled) {
      submitHandler();
    }
  };

  return {
    expenseFolioDate,
    setValue,
    watch,
    costCenters,
    register,
    getValues,
    setIsOpenCostCenterModal,
    errors,
    ValidationTextLevel,
    onCostCentreChange,
    onCostCentreSelect,
    onCostCentrePending,
    isOpenCostCenterModal,
    FormProvider,
    formMethods,
    costCenterClick,
    ledgerCodeClick,
    isOpenLedgerCodesModal,
    setIsOpenLedgerCodesModal,
    onLedgerCodeSelect,
    ledgerCodes,
    onLedgerCodeChange,
    onLedgerCodePending,
    onFundCodeSelect,
    setIsOpenFundCodesModal,
    isDisabled,
    onFundCodeChange,
    fundCodes,
    onFundCodePending,
    fundCodeClick,
    isOpenFundCodesModal,
    setIsDisabled,
    vatCodes,
    onVatCodeSelect,
    setIsOpenVatCodesModal,
    vatCodeClick,
    onVatCodeChange,
    onVatCodePending,
    isOpenVatCodesModal,
    calculateVatAmount,
    submitHandler,
    nameInputRef,
    trigger,
    clearErrors,
    setIsInCurrFinYr,
    isInCurrFinYr,
    getVatRegNoInputData,
    vatRegNoBlurEvent,
    isFutureDate,
    isVatAmtErr,
    onVatAmountChange,
    setOpenValidationModal,
    openValidationModal,
    vatRegInputValue,
    onSubmitHandler,
    saveExpenseFolioItemStatus,
    costCenterStatus,
    ledgerCodeStatus,
    navigateBack,
    transId,
    setError,
    isVatRegNoErr,
    historyState,
    setIsVatRegNoErr,
    setCallVatAmtAPI,
    setIsTotalIncVatChanged,
    isTotalIncVatChanged
  };
};

export default usePettyCashExpenseFolio;
