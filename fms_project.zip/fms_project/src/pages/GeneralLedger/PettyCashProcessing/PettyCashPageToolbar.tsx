import { LicenseDraft, Purchase, TaskRemove, MailAll, PageNumber } from "@carbon/icons-react";
import { Button, ButtonColor, ButtonSize, Grid, GridItem } from "@essnextgen/ui-kit";
import { RouteComponentProps, useHistory, withRouter } from "react-router-dom";

import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import { PETTY_CASH_TRANS_STATUS } from "@/types/UseStateType";
import {
  cancelPettyCashTransaction,
  getPettyCashAccountBrowse,
  getPettyCashList,
  pettyCashActions
} from "./state/PettyCashList.slice";

type PCPageToolbarType = {
  onSubmit?: () => void;
  adjustTransHandler?: () => void;
  isPostDisabled?: boolean;
  isCancelDisabled?: boolean;
  isAdjustTransDisabled?: boolean;
  pcTransId?: string;
} & RouteComponentProps;

const PettyCashPageToolbar = ({
  onSubmit,
  adjustTransHandler,
  isPostDisabled,
  isCancelDisabled,
  isAdjustTransDisabled,
  pcTransId
}: PCPageToolbarType) => {
  const [isPettycashCancelModalOpen, setIsPettycashCancelModalOpen] = useState<boolean>(false);
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();

  const handleCancelTransaction = () => {
    dispatch(cancelPettyCashTransaction({ pcTransId })).then((response) => {
      const { contraPcTransId } = response.payload as { contraPcTransId?: number };
      if (contraPcTransId) {
        dispatch(getPettyCashAccountBrowse());
        dispatch(pettyCashActions.setFilters({ pcTransId: contraPcTransId }));
      }
      history.push("/general-ledger/petty-cash");
    });
    setIsPettycashCancelModalOpen(false);
  };

  return (
    <>
      <Grid
        justify="flex-end"
        className="tools"
      >
        <GridItem>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            title={t("common.adjustTrans")}
            onClick={() => {
              if (adjustTransHandler) adjustTransHandler();
            }}
            disabled={isAdjustTransDisabled}
          >
            <LicenseDraft size={22} />
          </Button>
        </GridItem>
        <GridItem>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            title={t("common.cancelTrans")}
            onClick={() => {
              setIsPettycashCancelModalOpen(true);
              dispatch(pettyCashActions.setCancelTransactionClicked(true));
            }}
            disabled={isCancelDisabled}
          >
            <TaskRemove size={22} />
          </Button>
        </GridItem>
        <GridItem>
          <Button
            // ref={directPaymentBtnRef}
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            title={t("common.postTrans")}
            disabled={isPostDisabled}
            onClick={() => {
              if (onSubmit) onSubmit();
            }}
          >
            <MailAll size={22} />
          </Button>
        </GridItem>
      </Grid>

      <ConfirmModal
        className="cancel-pettycash-confirm-modal delete-alert"
        isOpen={isPettycashCancelModalOpen}
        setOpen={setIsPettycashCancelModalOpen}
        title={t("common.simsFMSModule")}
        message={t("confirmMsg1.pettycashCancelTitle")}
        confirm={handleCancelTransaction}
        autoFocusTertiaryBtn
      />
    </>
  );
};

PettyCashPageToolbar.defaultProps = {
  isPostDisabled: true,
  isCancelDisabled: false,
  isAdjustTransDisabled: false,
  onSubmit: undefined,
  adjustTransHandler: undefined,
  pcTransId: undefined
};

export default withRouter(PettyCashPageToolbar);
