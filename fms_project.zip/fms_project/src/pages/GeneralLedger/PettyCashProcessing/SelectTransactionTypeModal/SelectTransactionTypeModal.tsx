import { useEffect, useRef, useState } from "react";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  RadioButton,
  RadioLabelPosition,
  useTranslation
} from "@essnextgen/ui-kit";
import { useHistory } from "react-router-dom";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import { PC_TRANSACTION_TYPE } from "@/types/UseStateType";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import BodyUtil from "@/shared/utils/NoScroll";
import "./Style.scss";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import { actions as reimburAction } from "../state/ViewReimbursement.slice";

const SelectTransactionTypeModal = ({
  isOpen,
  setOpen,
  pettyCashBrowseRowData,
  checkForUnpostedExp,
  setOpenInsufficientAccessModal
}: {
  isOpen: boolean;
  setOpen: (flag: boolean) => void;
  pettyCashBrowseRowData: any;
  checkForUnpostedExp: () => void;
  setOpenInsufficientAccessModal: (flag: boolean) => void;
}) => {
  const [selected, setSelected] = useState<PC_TRANSACTION_TYPE>(PC_TRANSACTION_TYPE.EXPENDITURE);
  const history = useHistory();
  const selectBtnRef = useRef<HTMLButtonElement | null>(null);
  const closeHandler = () => {
    setOpen(false);
  };
  const dispatch = useDispatch<AppDispatch>();
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const canDoReimb = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.Reimburse
  });
  const onSelect = () => {
    setOpen(false);
    BodyUtil.NoScroll.remove();
    if (selected === PC_TRANSACTION_TYPE.REIMBURSEMENT) {
      if (canDoReimb) {
        const addReimbursementData = {
          pettyCashAccountsHidden: undefined,
          pettyCashTransaction: undefined
        };
        dispatch(reimburAction.setReimbursementDetails(addReimbursementData));
        history.push({
          pathname: `/general-ledger/petty-cash/add-reimbursement`,
          state: {
            mode: "add",
            headerData: pettyCashBrowseRowData,
            redirect: false
          }
        });
      } else {
        setOpenInsufficientAccessModal(true);
      }
    } else {
      checkForUnpostedExp();
    }
  };
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const secondaryButton = (
    <Button
      size={ButtonSize.Small}
      color={ButtonColor.Secondary}
      onClick={closeHandler}
    >
      {t("common.cancel")}
    </Button>
  );

  const primaryButton = (
    <Button
      ref={selectBtnRef}
      size={ButtonSize.Small}
      onClick={onSelect}
      id="txnTypeSelectBtn"
    >
      {t("common.select")}
    </Button>
  );

  useEffect(() => {
    setTimeout(() => {
      if (isOpen) {
        setSelected(PC_TRANSACTION_TYPE.EXPENDITURE);
        selectBtnRef?.current?.focus();
      }
    }, 10);
  }, [isOpen]);

  return (
    <Modalv2
      isOpen={isOpen}
      onClose={closeHandler}
      header="Select Transaction Type"
      className="select-transaction-type-modal"
      primaryButton={primaryButton}
      secondaryButton={secondaryButton}
    >
      <div className="multiple__radio--btnfield row-gap-8">
        <div className="d-flex align-center">
          <RadioButton
            label={t("pettyCash.expenditure")}
            labelPosition={RadioLabelPosition.Right}
            value={PC_TRANSACTION_TYPE.EXPENDITURE}
            isSelected={selected === PC_TRANSACTION_TYPE.EXPENDITURE}
            onChange={() => setSelected(PC_TRANSACTION_TYPE.EXPENDITURE)}
            name="selected"
            id={PC_TRANSACTION_TYPE.EXPENDITURE}
          />
        </div>
        <div className="d-flex align-center">
          <RadioButton
            label={t("pettyCash.reimbursement")}
            labelPosition={RadioLabelPosition.Right}
            value={PC_TRANSACTION_TYPE.REIMBURSEMENT}
            isSelected={selected === PC_TRANSACTION_TYPE.REIMBURSEMENT}
            onChange={() => setSelected(PC_TRANSACTION_TYPE.REIMBURSEMENT)}
          />
        </div>
      </div>
    </Modalv2>
  );
};

export default SelectTransactionTypeModal;
