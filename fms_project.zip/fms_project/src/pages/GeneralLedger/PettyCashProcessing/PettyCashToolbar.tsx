import {
  AddLarge,
  ArrowDown,
  ArrowUp,
  Printer,
  Save,
  /* eslint-disable camelcase */
  Thumbnail_2,
  Subtract,
  Undo,
  ScalesTipped,
  FaceSatisfied
} from "@carbon/icons-react";
import { ButtonSize } from "@essnextgen/ui-kit";
import { RouteComponentProps, useHistory, withRouter } from "react-router-dom";
import Toolbar, { ToolbarType } from "@/components/Toolbar/Toolbar";
import { BaseSyntheticEvent, SyntheticEvent, useEffect, useState } from "react";
import { useAppSelector } from "@/store/store";
import { KEYBOARD_STRING, PC_TRANSACTION_TYPE } from "@/types/UseStateType";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import SelectTransactionTypeModal from "./SelectTransactionTypeModal/SelectTransactionTypeModal";

type PCToolbarType = {
  onSubmit?: () => void;
  goToPrevRecord?: () => void;
  goToNextRecord?: () => void;
  goToAdd?: () => void;
  onDelete?: () => void;
  printButtonHandler?: () => void;
  isAddDisable?: boolean;
  onFocusClickHandler?: () => void;
  isPrintDisable?: boolean;
  isDeleteDisable?: boolean;
  undoChangeHandler?: () => void;
  isRowDataAvailable?: boolean;
} & RouteComponentProps;

const PettyCashToolbar = ({
  onSubmit,
  goToPrevRecord,
  goToNextRecord,
  goToAdd,
  isAddDisable,
  onFocusClickHandler,
  isPrintDisable,
  isDeleteDisable,
  onDelete,
  undoChangeHandler,
  printButtonHandler,
  isRowDataAvailable
}: PCToolbarType) => {
  const handleKeyDown = (e: any) => {
    if (e.key === KEYBOARD_STRING.Escape) {
      e.preventDefault();
      if (undoChangeHandler) {
        undoChangeHandler();
      }
    }
  };

  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const canDoFolio = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.RaiseFolios
  });

  const canDoReimb = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.Reimburse
  });

  const canRecordPrint = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.Print
  });

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleKeyDown]);

  const buttons: ToolbarType[] = [
    {
      title: "Focus Mode",
      /* eslint-disable react/jsx-pascal-case */
      element: <Thumbnail_2 size={18} />,
      size: ButtonSize.Small,
      onClick: () => {
        if (onFocusClickHandler) onFocusClickHandler();
      },
      disabled: isRowDataAvailable
    },
    {
      title: "Previous Record",
      element: <ArrowUp size={18} />,
      size: ButtonSize.Small,
      onClick: () => {
        if (goToPrevRecord) goToPrevRecord();
      },
      disabled: isRowDataAvailable
    },
    {
      title: "Next Record",
      element: <ArrowDown size={18} />,
      size: ButtonSize.Small,
      id: "btnNextRec",
      onClick: (e) => {
        if (goToNextRecord) goToNextRecord();
      },
      disabled: isRowDataAvailable
    },
    {
      title: "Add Record",
      element: <AddLarge size={18} />,
      onClick: () => {
        if (goToAdd) goToAdd();
      },
      disabled: (!canDoFolio && !canDoReimb) || isAddDisable,
      size: ButtonSize.Small
    },
    {
      title: "Delete Record",
      element: <Subtract size={18} />,
      size: ButtonSize.Small,
      onClick: () => {
        if (onDelete) onDelete();
      },
      disabled: isDeleteDisable
    },
    {
      title: "Save Record Changes",
      element: <Save size={18} />,
      onClick: () => {
        if (onSubmit) onSubmit();
      },
      size: ButtonSize.Small,
      disabled: !canDoFolio && !canDoReimb
    },
    {
      title: "Undo Record Changes",
      element: <Undo size={18} />,
      onClick: () => {
        if (undoChangeHandler) undoChangeHandler();
      },
      size: ButtonSize.Small,
      disabled: !canDoFolio && !canDoReimb
    },
    {
      title: "Print/Dispatch",
      element: <Printer size={18} />,
      size: ButtonSize.Small,
      onClick: async () => {
        if (printButtonHandler) printButtonHandler();
      },
      disabled: !canRecordPrint || isPrintDisable
    }
  ];

  return (
    <div>
      <Toolbar buttons={buttons} />
    </div>
  );
};

PettyCashToolbar.defaultProps = {
  onSubmit: undefined,
  goToPrevRecord: undefined,
  goToNextRecord: undefined,
  goToAdd: undefined,
  isAddDisable: false,
  onFocusClickHandler: undefined,
  isPrintDisable: false,
  isDeleteDisable: false,
  onDelete: undefined,
  printButtonHandler: undefined,
  undoChangeHandler: undefined,
  isRowDataAvailable: false
};

export default withRouter(PettyCashToolbar);
