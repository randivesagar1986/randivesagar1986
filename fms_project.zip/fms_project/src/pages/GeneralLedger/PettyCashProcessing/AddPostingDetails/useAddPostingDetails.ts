import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import React, { ChangeEvent, useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { actions as periodActions } from "@/shared/components/PettyCashPeriodBrowse/state/PettyCashPeriodBrowse.slice";
import { useDispatch } from "react-redux";
import { ISelectedItem } from "@essnextgen/ui-kit";
import { getCurrentDate, getDefaultPaymentPeriod } from "@/store/state/defaultYear.slice";
import { useHistory } from "react-router";
import { getCurrentFinancialYear, METHOD } from "@/types/UseStateType";
import { dateConvertInDDslashMMslashYYYY, getSessionItem, setToSession } from "@/utils/getDataSource";
import { tr } from "date-fns/locale";
import { useClickAway } from "@/hooks/useClickAway";
import { actions as sidebarMenuActions } from "@/components/SidebarMenu/state/SidebarMenu.slice";
import { postExpenditure, ajustExpenditure } from "../state/PostExpenditure.slice";
import { pettyCashActions } from "../state/PettyCashList.slice";

type FormData = {
  paymentPeriod: string;
  paymentDescription: string;
  narrative: string;
};
const useAddPostingDetails = () => {
  const defaultValues = {
    paymentPeriod: "",
    narrative: ""
  };
  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    watch,
    reset,
    formState: { errors, isDirty, dirtyFields },
    getValues
  } = useForm<FormData>({
    shouldFocusError: false,
    defaultValues: {
      ...defaultValues
    }
  });
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;
  const [showPostingPeriodModal, setShowPostingPeriodModal] = useState<boolean>(false);
  const [postingPeriodMonth, setPostingPeriodMonth] = useState<string>("");
  const [openAlertModal, setOpenAlertModal] = useState<boolean>(false);
  const [alertMessage, setAlertMessage] = useState<string>("");
  const { postingPeriodDetails, selectedValuePostingPeriod } = useAppSelector((state) => state.pettyCashPeriodBrowse);
  const filterState = useAppSelector((state) => state.pettyCashList?.filterState);
  const { defaultPeriod } = useAppSelector(({ defaultPeriod }) => defaultPeriod);
  const { setIsSidebarOpen } = sidebarMenuActions;
  const periodPosted = historyState?.selectedRowState?.period_posted;
  const allWatchedFormValues: Record<string, any> = watch();
  const [initialValues] = useState<Record<string, any>>(() => getValues());
  const [isFieldDirty, setIsFieldDirty] = useState<boolean>(false);

  const yesCallback = (target?: HTMLElement) => {
    onPostHandler();
  };

  const noCallback = (target: HTMLElement) => {
    reset(allWatchedFormValues);
    setIsFieldDirty(false);
    setHistoryRedirect(false);
    return true;
  };

  // Wrapper to handle noCallback with a parameter
  const noCallbackWrapper = (target: HTMLElement) => {
    noCallback(target); // Pass the event target to the actual noCallback function
  };

  const handleCancelCallback = () => {
    homeRef.current = null;
    menuRef.current = null;
  };

  const { menuRef, setHistoryRedirect, reDispatchEvent, homeRef, targetRef } = useClickAway({
    isDirty: isFieldDirty || historyState?.isDirty,
    yesCallback: (target: HTMLElement) => yesCallback(target),
    noCallback: noCallbackWrapper,
    cancelCallback: handleCancelCallback,
    popupTitle: t("common.simsFMSModule"),
    popupMessage: t("alertMessage.keepChangesMsg"),
    unblockCondition: history?.location?.pathname?.includes("/general-ledger/petty-cash/add-posting-details"),
    isNonReturnYesCallback: true
  });

  useEffect(() => {
    // create isfieldDirty flag and set by comparison of default values and current values
    const defaultKeys = Object.keys(defaultValues) as (keyof FormData)[];
    const hasNoChanges = defaultKeys.every((key) => {
      if (getValues(key) !== undefined && getValues(key) !== "" && getValues(key) !== null) {
        return getValues(key) === initialValues[key];
      }
      return true;
    });
    if (isFieldDirty === hasNoChanges) {
      setIsFieldDirty(!hasNoChanges);
    }
  }, [getValues, initialValues, allWatchedFormValues, defaultValues, historyState?.mode]);

  const onPaymentPeriodNoSelection = () => {
    setShowPostingPeriodModal(true);
    setValue("paymentPeriod", "0");
    setPostingPeriodMonth("");
  };

  const onPaymentPeriodChange = (e: ChangeEvent<HTMLInputElement>) => {
    register("paymentPeriod").onChange(e);
    const { value } = e.target;
    if (!value.trim()) {
      setPostingPeriodMonth("");
      dispatch(periodActions.selectPostingPeriod(undefined));
      dispatch(periodActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(periodActions.setFilters({ lookingFor: value }));
      const found = postingPeriodDetails.find((s) => s.formattedCode === value);
      if (found) {
        setPostingPeriodMonth(found?.description);
        setValue("paymentPeriod", found?.formattedCode);
      }
    }
  };
  const onPaymentPeriodSelection = (selectedItem: ISelectedItem | undefined) => {
    const found = postingPeriodDetails.find((s) => s.formattedCode === selectedItem?.text);
    if (selectedItem?.text) {
      dispatch(periodActions.setFilters({ lookingFor: "" }));
      setValue("paymentPeriod", found?.formattedCode);
      setValue("paymentDescription", found?.description);
      setPostingPeriodMonth(found?.description);
      dispatch(periodActions.selectPostingPeriod(found));
    } else {
      dispatch(periodActions.selectPostingPeriod(undefined));
    }
  };
  const onBlurHandler = (e: any) => {
    if (selectedValuePostingPeriod && e.target.value === "0") {
      setValue("paymentPeriod", selectedValuePostingPeriod?.formattedCode);
      trigger("paymentPeriod");
    }
  };
  const handlePostingPeriodPendingState = useCallback(
    (suggested: any) => {
      if (suggested) {
        const found = postingPeriodDetails?.find((t) => t?.formattedCode === suggested?.text);
        setValue("paymentDescription", found?.description);
        setPostingPeriodMonth(found?.description);
        setValue("paymentPeriod", found?.formattedCode);
        trigger("paymentPeriod");
        trigger("paymentDescription");
      }
    },
    [postingPeriodDetails]
  );
  const onPostingPeriodSelectedRow = (row: any) => {
    dispatch(periodActions.selectPostingPeriod(row));
    setPaymentPeriodDetails(row);
  };
  const setPaymentPeriodDetails = (row: any) => {
    setValue("paymentPeriod", row.formattedCode);
    setPostingPeriodMonth(row.description);
  };
  const onSelectRowDate = (value: any) => {
    if (!value.trim()) {
      dispatch(periodActions.selectPostingPeriod(undefined));
      dispatch(periodActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(periodActions.setFilters({ lookingFor: value }));
    }
  };
  useEffect(() => {
    dispatch(getDefaultPaymentPeriod({ date: getCurrentDate() }));
  }, []);

  useEffect(() => {
    const found = postingPeriodDetails.find((t) => Number(t.code) === defaultPeriod);
    if (found) {
      setPaymentPeriodDetails(found);
      dispatch(periodActions.selectPostingPeriod(found));
    }
  }, [defaultPeriod]);

  const getFolioData = () => {
    if (!historyState?.expenditureItems) return [];

    return historyState.expenditureItems.map((item: any) => ({
      pc_folio_id: item?.pc_folio_id,
      pc_trans_id: item?.pc_trans_id,
      ledger_id: item?.leddef_id,
      cost_id: item?.cost_id,
      net_amount: String(item?.net_amount),
      vat_amount: String(item?.vat_amount),
      vat_id: item?.vat_id,
      cost_to_establishment: String(item?.cost_to_establishment),
      description: item?.description,
      receipt_date: dateConvertInDDslashMMslashYYYY(item?.receipt_date, true),
      vat_reg_no: item?.vat_reg_no,
      fundId: item?.fund_id,
      ledgersourceid: 0
    }));
  };
  const onAdjustPostHandler = async (data: any) => {
    const formData = {
      pcAccountId: historyState?.selectedRowState?.pc_account_id,
      pc_trans_id: historyState?.selectedRowState?.pc_trans_id,
      book_id: historyState?.selectedRowState?.book_id,
      pettyCashExpenditurePostingDetail: {
        year_id: Number(getCurrentFinancialYear()),
        period_posted: Number(data.paymentPeriod),
        narrative: data.narrative,
        pc_trans_id: Number(historyState?.selectedRowState?.pc_trans_id)
      },
      pettyCashAdjustedFolios: getFolioData()
    };
    dispatch(
      ajustExpenditure({
        formData,
        callback: (data: any) => {
          if (data.validationType === 0) {
            history.push({
              pathname: `/general-ledger/petty-cash`,
              state: {
                ...(history.location.state as any),
                redirect: true
              }
            });
          } else {
            setOpenAlertModal(true);
            setAlertMessage(data.message);
          }
        }
      })
    );
  };

  const onExpenditurePostHandler = async (data: any) => {
    const formData = {
      year_id: Number(getCurrentFinancialYear()),
      period_posted: Number(data.paymentPeriod),
      narrative: data.narrative,
      pc_trans_id: Number(historyState?.selectedRowState?.pc_trans_id)
    };
    dispatch(
      postExpenditure({
        formData,
        callback: (data: any) => {
          if (data.validationType === 0) {
            if (getSessionItem("redirectPath") || homeRef.current || menuRef.current) {
              if (homeRef.current) {
                history.push({
                  pathname: "/",
                  state: {
                    redirect: true
                  }
                });
                setHistoryRedirect(true);
              } else if (menuRef.current) {
                dispatch(setIsSidebarOpen(true));
                setHistoryRedirect(false);
                menuRef.current = null;
                return;
              } else {
                reDispatchEvent(targetRef.current);
                setHistoryRedirect(true);
              }
              homeRef.current = null;
            } else {
              dispatch(
                pettyCashActions.setFilters({
                  lookingFor: "",
                  view: filterState?.view
                })
              );
              history.push({
                pathname: `/general-ledger/petty-cash`,
                state: {
                  ...(history.location.state as any),
                  redirect: true
                }
              });
            }
          } else {
            setOpenAlertModal(true);
            setAlertMessage(data.message);
          }
        }
      })
    );
  };
  const onPostHandler = async () => {
    const formSumbit = handleSubmit(
      async (data) => {
        if (historyState?.mode === METHOD.ADJUST) {
          onAdjustPostHandler(data);
        } else {
          onExpenditurePostHandler(data);
        }
      },
      () => {
        setOpenAlertModal(true);
        setAlertMessage(t("common.invalidData"));
        dispatch(setIsSidebarOpen(false));
        setHistoryRedirect(true);
      }
    );
    await formSumbit();
    dispatch(pettyCashActions.resetFilter({}));
  };

  const onCancelHandler = () => {
    reset();
    dispatch(periodActions.selectPostingPeriod(undefined));
    dispatch(periodActions.setFilters({ lookingFor: "" }));
    if (historyState.mode === METHOD.ADJUST) {
      history.push({
        pathname: `/general-ledger/petty-cash/adjust-expenditure/${historyState?.selectedRowState?.pc_account_id}/${historyState?.selectedRowState?.pc_trans_id}`,
        state: {
          ...(history.location.state as any),
          redirect: true
        }
      });
    } else if (historyState.navigateFrom === "list") {
      history.push({
        pathname: `/general-ledger/petty-cash`,
        state: {
          ...(history.location.state as any),
          redirect: true
        }
      });
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/edit-expenditure/${historyState?.selectedRowState?.pc_account_id}/${historyState?.selectedRowState?.pc_trans_id}`,
        state: {
          ...(history.location.state as any),
          redirect: true
        }
      });
    }
  };
  return {
    t,
    postingPeriodDetails,
    onPaymentPeriodNoSelection,
    register,
    setValue,
    trigger,
    handleSubmit,
    watch,
    reset,
    getValues,
    errors,
    showPostingPeriodModal,
    setShowPostingPeriodModal,
    onPaymentPeriodChange,
    onPaymentPeriodSelection,
    onPostingPeriodSelectedRow,
    onSelectRowDate,
    postingPeriodMonth,
    onPostHandler,
    openAlertModal,
    setOpenAlertModal,
    alertMessage,
    onCancelHandler,
    periodPosted,
    handlePostingPeriodPendingState,
    onBlurHandler
  };
};

export default useAddPostingDetails;
