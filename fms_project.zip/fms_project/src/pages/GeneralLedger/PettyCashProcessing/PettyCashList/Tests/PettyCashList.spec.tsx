import React from "react";
import { AnyAction } from "redux";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider, useDispatch } from "react-redux";
import { BrowserRouter as Router, useParams } from "react-router-dom";
import configureStore, { MockStoreEnhanced } from "redux-mock-store";
import { PC_TRANSACTION_TYPE, STATUS } from "@/types/UseStateType";
import { useAppSelector } from "@/store/store";
import { TabGroup } from "@essnextgen/ui-kit";
import PettyCashList from "../PettyCashList";
import PettyCashToolbar from "../../PettyCashToolbar";
import { pettyCashActions } from "../../state/PettyCashList.slice";

const selectedPettyCashRow = {
  adj_trans_id: null,
  amount: 100,
  bank_statement_no: "-1",
  book_id: 34,
  cheque_book_id: 0,
  cheque_no: null,
  date_posted: "2011-03-31T00:00:00",
  det_num: 60545,
  disp_amount: 100,
  foliocount: 6,
  narrative: "Petty Cash Year End",
  next_no: null,
  number_range: null,
  orig_journal_id: 60556,
  orig_trans_id: null,
  payee_name: null,
  pc_account_id: 13,
  pc_trans_id: 595,
  period_posted: 12,
  status: 1,
  trans_no: "00000524",
  trans_type: 0,
  user_id: 21
};

const expenditureRecord = {
  adj_trans_id: null,
  amount: 75,
  bank_statement_no: "-1",
  book_id: 2051,
  cheque_book_id: 0,
  cheque_no: null,
  date_posted: "2024-09-17T00:00:00",
  det_num: 0,
  disp_amount: 75,
  foliocount: 2,
  narrative: "Unposted Expenditure",
  next_no: null,
  number_range: null,
  orig_journal_id: 0,
  orig_trans_id: null,
  payee_name: null,
  pc_account_id: 27,
  pc_trans_id: 2450,
  period_posted: 0,
  status: 0,
  trans_no: "#0002450",
  trans_type: 1,
  user_id: 21
};
const pettyCashAccessRights = {
  accessArea: "Petty Cash",
  accessRights: [
    {
      access_right: "Adjust Trans",
      result: "T"
    },
    {
      access_right: "Allocate Source",
      result: "T"
    },
    {
      access_right: "Cancel",
      result: "T"
    },
    {
      access_right: "Post expenditure",
      result: "T"
    },
    {
      access_right: "Print",
      result: "F"
    },
    {
      access_right: "Raise folios",
      result: "F"
    },
    {
      access_right: "Reimburse",
      result: "F"
    },
    {
      access_right: "Set reimbursement level",
      result: "T"
    },
    {
      access_righ: "View",
      result: "T"
    }
  ]
};
const initialState = {
  pettyCashList: {
    selectedPettyCashRow,
    selectedPettyCashUndoRow: null,
    filterState: {
      view: "A"
    },
    pettyCashApiStatus: STATUS.SUCCESS,
    selectedPettyCashAccountBrowse: {
      unposted_exp: 0,
      cash_in_hand: 0,
      pc_acc_des: ""
    },
    pCashViewSelected: {
      value: PC_TRANSACTION_TYPE.REIMBURSEMENT
    },
    conlumnDef: [],
    pettyCashList: {
      pageSize: 10,
      currentPage: 1,
      totalPages: 2,
      pettyCashTransaction: [selectedPettyCashRow, expenditureRecord]
    },
    sortedPettyCashAccount: null,
    printPettyCashStatus: STATUS.SUCCESS,
    deletePettyCashStatus: STATUS.SUCCESS,
    isFocus: false
  },
  userAccessRights: {
    data: [{ ...pettyCashAccessRights }]
  },
  supplierCatalogue: {
    catalogueData: null,
    status: "idle"
  },
  glCentreLedgerLinksView: {
    availableCostCentreList: [],
    availableLedgerCodeList: []
  },
  ui: {
    alert: ""
  }
};
const PettyCashToolbarProps = {
  onSubmit: jest.fn(),
  goToPrevRecord: jest.fn(),
  goToNextRecord: jest.fn(),
  goToAdd: jest.fn().mockImplementation(() => {
    window.location.pathname = "/general-ledger/petty-cash/add-reimbursement";
  }),
  isAddDisable: false,
  onFocusClickHandler: jest.fn().mockImplementation(() => {
    window.location.pathname = `/general-ledger/petty-cash/view-reimbursement/${selectedPettyCashRow?.pc_account_id}/${selectedPettyCashRow?.pc_trans_id}`;
  }),
  isPrintDisable: false,
  isDeleteDisable: initialState.pettyCashList.selectedPettyCashRow.narrative !== "Unposted Expenditure",
  onDelete: jest.fn(),
  printButtonHandler: jest.fn(),
  undoChangeHandler: jest.fn()
};
const mockStore = configureStore<Partial<typeof initialState>, AnyAction>([]);
const mockPropsforInputNumberMask = {
  onChange: jest.fn(),
  name: "mockName",
  value: "12345.67",
  className: "mockClassName",
  validationTextLevel: undefined, // Assuming ValidationTextLevel is an enum or similar
  onValueChange: jest.fn(),
  getInputRef: jest.fn(),
  onKeyDown: jest.fn(),
  beforeDecimalMaxLength: 5,
  onBlur: jest.fn(),
  beforeDecimalCursorIndex: 2,
  afterDecimalCursorIndex: 2,
  allowNegative: true
  // Add any additional props required by NumericFormatProps
};

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn().mockImplementation((selector) => selector(initialState))
}));

jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn()
}));

const renderPettyCashToolBarComponent = (
  store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>,
  PettyCashToolbarProps: any
) => {
  render(
    <Provider store={store}>
      <Router>
        <TabGroup>
          <PettyCashToolbar {...PettyCashToolbarProps} />
        </TabGroup>
      </Router>
    </Provider>
  );
};

const renderPettyCashListComponent = (store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>) => {
  render(
    <Provider store={store}>
      <Router>
        <PettyCashList />
      </Router>
    </Provider>
  );
};

describe("PettyCashList successfully loaded", () => {
  let store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>;
  let mockDispatch: jest.Mock;

  beforeEach(() => {
    store = mockStore(initialState);
    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(initialState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("Renders PettyCashList component", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      expect(screen.getByText("pettyCashList.pageTitle")).toBeInTheDocument();
      expect(screen.getByText("Petty Cash Account")).toBeInTheDocument();
      expect(screen.getByText("pettyCashList.cashInHand")).toBeInTheDocument();
      expect(screen.getByText("pettyCashList.unpostedExpenditure")).toBeInTheDocument();
    });
  });

  test("Renders PettyCashList Pagination Footer", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      expect(screen.getByTestId("pettyCashFooter")).toBeInTheDocument();
    });
  });

  test("Reimbursement Highlighted", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      expect(screen.getByText("pettyCashList.reimbursementHighlighted")).toBeInTheDocument();
    });
  });

  test("Opens petty cash account browse modal on button click", () => {
    renderPettyCashListComponent(store);
    const button = screen.getByLabelText("petty-btn");
    fireEvent.click(button);
    expect(window.location.pathname).toBe("/general-ledger/petty-cash/petty-cash-account-browse");
  });

  test("Adjust Transaction disable", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      const adjustTransbutton = screen.getByTitle("common.adjustTrans");
      expect(adjustTransbutton).toBeInTheDocument();
      expect(adjustTransbutton).toBeDisabled();
    });
  });

  test("Cancel Transaction disable", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      const adjustTransbutton = screen.getByTitle("common.cancelTrans");
      expect(adjustTransbutton).toBeInTheDocument();
      expect(adjustTransbutton).toBeDisabled();
    });
  });

  test("Post Transaction disable", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      const adjustTransbutton = screen.getByTitle("common.postTrans");
      expect(adjustTransbutton).toBeInTheDocument();
      expect(adjustTransbutton).toBeDisabled();
    });
  });
});

describe("PettyCashList loading", () => {
  let store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>;
  let mockDispatch: jest.Mock;

  const testInitilaState = {
    ...initialState,
    pettyCashList: {
      ...initialState.pettyCashList,
      printPettyCashStatus: STATUS.LOADING
    }
  };

  beforeEach(() => {
    store = mockStore(testInitilaState);
    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(testInitilaState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("displays loader when loading", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      expect(screen.getByText("common.loading")).toBeInTheDocument();
    });
  });
});

describe("PettyCashListToolBar successfully render", () => {
  let store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>;
  let mockDispatch: jest.Mock;

  beforeEach(() => {
    store = mockStore(initialState);
    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(initialState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("Length of action button in petty cash toolbar", () => {
    renderPettyCashToolBarComponent(store, PettyCashToolbarProps);
    const toolButtons = screen.getAllByRole("button");
    expect(toolButtons).toHaveLength(8);
  });

  test("Click on focus mode", () => {
    renderPettyCashToolBarComponent(store, PettyCashToolbarProps);
    const toolButtons = screen.getAllByRole("button");
    const addButton = toolButtons[0];
    expect(addButton).toBeEnabled();
    fireEvent.click(addButton);
    expect(PettyCashToolbarProps.onFocusClickHandler).toHaveBeenCalledTimes(1);
  });

  test("Click on previous record button", () => {
    renderPettyCashToolBarComponent(store, PettyCashToolbarProps);
    const toolButtons = screen.getAllByRole("button");
    const previousButton = toolButtons[1];
    expect(previousButton).toBeEnabled();
    fireEvent.click(previousButton);
    expect(PettyCashToolbarProps.goToPrevRecord).toHaveBeenCalledTimes(1);
  });

  test("selectPrevRecord sets onChangePrevRecord to true if on first page", () => {
    renderPettyCashListComponent(store);
    const toolButtons = screen.getAllByRole("button");
    const previousButton = toolButtons[1];
    fireEvent.click(previousButton);
    expect(mockDispatch).toHaveBeenCalledWith(expect.any(Function));
  });

  test("Click on next record button", () => {
    renderPettyCashToolBarComponent(store, PettyCashToolbarProps);
    const toolButtons = screen.getAllByRole("button");
    const addButton = toolButtons[2];
    expect(addButton).toBeEnabled();
    fireEvent.click(addButton);
    expect(PettyCashToolbarProps.goToNextRecord).toHaveBeenCalledTimes(1);
  });

  test("Is delete record button disable?", () => {
    renderPettyCashToolBarComponent(store, PettyCashToolbarProps);
    const toolButtons = screen.getAllByRole("button");
    const deleteButton = toolButtons[4];
    expect(deleteButton).toBeDisabled();
  });

  test("Is add record button didsable?", () => {
    renderPettyCashToolBarComponent(store, PettyCashToolbarProps);
    const toolButtons = screen.getAllByRole("button");
    const addButton = toolButtons[3];
    expect(addButton).toBeDisabled();
  });
});

describe("PettyCashList selectPrevRecord", () => {
  let store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>;
  let mockDispatch: jest.Mock;
  const modifiedState = {
    ...initialState,
    pettyCashList: {
      ...initialState.pettyCashList,
      selectedPettyCashRow: null
    }
  };
  beforeEach(() => {
    store = mockStore(initialState);
    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(modifiedState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("selectPrevRecord selects the previous record", () => {
    renderPettyCashListComponent(store);
    const toolButtons = screen.getAllByRole("button");
    const previousButton = toolButtons[1];
    fireEvent.click(previousButton);
    expect(mockDispatch).toHaveBeenCalledWith(
      pettyCashActions.setSelectedPettyCashRow(initialState.pettyCashList.pettyCashList.pettyCashTransaction[0])
    );
  });
});

describe("Post Transaction click redirection to add-posting-details", () => {
  let store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>;
  let mockDispatch: jest.Mock;

  const testInitilaState = {
    ...initialState,
    pettyCashList: {
      ...initialState.pettyCashList,
      selectedPettyCashRow: expenditureRecord,
      selectedPettyCashAccountBrowse: {
        unposted_exp: 9,
        cash_in_hand: 10,
        pc_acc_des: "Petty Cash Account"
      }
    }
  };

  beforeEach(() => {
    store = mockStore(testInitilaState);
    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(testInitilaState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("Post Transaction enable", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      const adjustTransbutton = screen.getByTitle("common.postTrans");
      expect(adjustTransbutton).toBeEnabled();
    });
  });

  test("overDrawn less than 0", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      const postTransbutton = screen.getByTitle("common.postTrans");
      fireEvent.click(postTransbutton);
      expect(window.location.pathname).toBe(
        `/general-ledger/petty-cash/add-posting-details/${expenditureRecord?.pc_account_id}/${expenditureRecord?.pc_trans_id}`
      );
    });
  });
});

describe("Post Transaction click alert modal open", () => {
  let store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>;
  let mockDispatch: jest.Mock;

  const testInitilaState = {
    ...initialState,
    pettyCashList: {
      ...initialState.pettyCashList,
      selectedPettyCashRow: expenditureRecord,
      selectedPettyCashAccountBrowse: {
        unposted_exp: 10,
        cash_in_hand: 9,
        pc_acc_des: "Petty Cash Account"
      }
    }
  };

  beforeEach(() => {
    store = mockStore(testInitilaState);
    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(testInitilaState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("overDrawn greater than 0", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      const postTransbutton = screen.getByTitle("common.postTrans");
      fireEvent.click(postTransbutton);
      const alertModal = screen.getByText("alertMessage.title");
      expect(alertModal).toBeInTheDocument();
    });
  });

  test("Expenditure Highlighted", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      expect(screen.getByText("pettyCashList.expenditureHighlighted")).toBeInTheDocument();
    });
  });
});

describe("Cancel and Adjust Transaction enable", () => {
  let store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>;
  let mockDispatch: jest.Mock;

  const testInitilaState = {
    ...initialState,
    pettyCashList: {
      ...initialState.pettyCashList,
      selectedPettyCashRow: { ...expenditureRecord, status: 1 }
    }
  };

  beforeEach(() => {
    store = mockStore(testInitilaState);
    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(testInitilaState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("Adjust Transaction enable", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      const adjustTransbutton = screen.getByTitle("common.adjustTrans");
      expect(adjustTransbutton).toBeEnabled();
    });
  });

  test("Adjust Transaction Click adjust-expenditure redirection", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      const adjustTransbutton = screen.getByTitle("common.adjustTrans");
      fireEvent.click(adjustTransbutton);
      expect(window.location.pathname).toBe(
        `/general-ledger/petty-cash/adjust-expenditure/${expenditureRecord?.pc_account_id}/${expenditureRecord?.pc_trans_id}`
      );
    });
  });

  test("Cancel Transaction enable", async () => {
    renderPettyCashListComponent(store);
    await waitFor(() => {
      const adjustTransbutton = screen.getByTitle("common.cancelTrans");
      expect(adjustTransbutton).toBeEnabled();
    });
  });
});

describe("PettyCashList Delete, Undo, Save, Print Button", () => {
  let store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>;
  let mockDispatch: jest.Mock;

  beforeEach(() => {
    store = mockStore(initialState);
    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(initialState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("onDelete sets isDeleteModalOpen to true", () => {
    renderPettyCashListComponent(store);
    const toolButtons = screen.getAllByRole("button");
    const deleteButton = toolButtons[4];
    expect(deleteButton).toBeEnabled();
  });

  test("undoChangeHandler sets selectedPettyCashRow to the correct row", () => {
    renderPettyCashListComponent(store);
    const toolButtons = screen.getAllByRole("button");
    const undoButton = toolButtons[6];
    fireEvent.click(undoButton);
    expect(mockDispatch).toHaveBeenCalledWith(
      pettyCashActions.setSelectedPettyCashRow(initialState.pettyCashList.pettyCashList.pettyCashTransaction[0])
    );
  });

  test("Save button enable", () => {
    const saveFunc = jest.fn();
    renderPettyCashListComponent(store);
    const toolButtons = screen.getAllByRole("button");
    const saveButton = toolButtons[5];
    expect(saveButton).toBeEnabled();
    expect(saveFunc).not.toHaveBeenCalled();
  });

  test("Print button disable", () => {
    renderPettyCashListComponent(store);
    const toolButtons = screen.getAllByRole("button");
    const printButton = toolButtons[7];
    expect(printButton).toBeDisabled();
  });
});

describe("PettyCashList selectNextRecord", () => {
  let store: MockStoreEnhanced<Partial<typeof initialState>, AnyAction>;
  let mockDispatch: jest.Mock;

  const modifiedState = {
    ...initialState,
    pettyCashList: {
      ...initialState.pettyCashList,
      selectedPettyCashRow: null
    }
  };

  beforeEach(() => {
    store = mockStore(initialState);
    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(modifiedState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("selectNextRecord selects the next record", () => {
    renderPettyCashListComponent(store);
    const toolButtons = screen.getAllByRole("button");
    const nextButton = toolButtons[2];
    fireEvent.click(nextButton);
    expect(mockDispatch).toHaveBeenCalledWith(
      pettyCashActions.setSelectedPettyCashRow(initialState.pettyCashList.pettyCashList.pettyCashTransaction[0])
    );
  });

  test("selectNextRecord focuses the next record element", async () => {
    renderPettyCashListComponent(store);
    const toolButtons = screen.getAllByRole("button");
    const nextButton = toolButtons[2];
    fireEvent.click(nextButton);
    waitFor(() => {
      const nextElement = document.getElementById("rowIndex-pettyCashListGrid-1");
      expect(nextElement).toHaveFocus();
    });
  });
});
