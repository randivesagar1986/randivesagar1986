import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

export const pettyCashBrowseColDef: TColumnDef = [
  {
    headerName: "Petty Cash Account",
    field: "pc_acc_des",
    enableTooltip: true,
    columnWidth: 25
  },
  {
    headerName: "Funding Source",
    field: "source_des",
    enableTooltip: true,
    columnWidth: 25
  },

  {
    headerName: "Cash In Hand",
    field: "cash_in_hand",
    cellRenderer: "GridCellLink",
    align: "right",
    columnWidth: 25
  },
  {
    headerName: "Unposted Expenditure",
    field: "unposted_exp",
    cellRenderer: "GridCellLink",
    align: "right",
    columnWidth: 25
  }
];
export const fundingSourceColDef: TColumnDef = [
  {
    headerName: "Funding Source",
    field: "ledger_des",
    enableTooltip: true
  },

  {
    headerName: "Balance",
    field: "balance",
    cellRenderer: "GridCellLink",
    align: "right"
  }
];
