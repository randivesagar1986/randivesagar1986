import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const pettyCashColDef: TColumnDef = [
  {
    headerName: "Date",
    field: "date_posted",
    cellRenderer: "GridCellLink",
    sequence: true,
    sequenceName: "Date"
  },
  {
    headerName: "Transaction No.",
    field: "trans_no",
    sequence: true,
    sequenceName: "Transaction No."
  },
  {
    headerName: "Amount",
    field: "disp_amount",
    align: "right",
    cellRenderer: "GridCellLink",
    enableTooltip: true
  },
  {
    headerName: "Description",
    field: "narrative"
  },
  {
    headerName: "",
    field: "detailLink",
    cellRenderer: "GridCellLink"
  }
];

export default pettyCashColDef;
