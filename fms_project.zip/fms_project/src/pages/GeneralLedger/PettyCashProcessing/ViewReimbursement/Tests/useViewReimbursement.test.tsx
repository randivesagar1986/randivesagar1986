import { renderHook, act } from "@testing-library/react-hooks";
import { Provider } from "react-redux";
import configureMockStore from "redux-mock-store";
import thunk from "redux-thunk";
import { useHistory } from "react-router-dom";
import { ReactNode, useEffect } from "react";
import { useLocation } from "react-router";
import { createMemoryHistory } from "history";
import { getFCSourceBalance, getReimbursementDetails } from "../../state/ViewReimbursement.slice";
import setSelectedPettyCashRow from "../../state/PettyCashList.slice";
import useViewReimbursement from "../useViewReimbursement";

const history = createMemoryHistory();

jest.mock("../../state/ViewReimbursement.slice", () => ({
  getFCSourceBalance: jest.fn().mockResolvedValue({
    balance: 1000,
    currency: "USD"
  }),
  getPettyCashList: jest.fn(),
  getReimbursementDetails: jest.fn()
}));

jest.mock("../../state/PettyCashList.slice", () => ({
  setSelectedPettyCashRow: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn().mockReturnValue({ id: "123" })
}));
jest.mock("react-router", () => ({
  useHistory: jest.fn().mockReturnValue({
    push: jest.fn()
  }),
  useLocation: jest.fn()
}));

const mockUseLocation = useLocation as jest.Mock;
const mockStore = configureMockStore([thunk]);
const store = mockStore({});
const wrapper = ({ children }: { children: ReactNode }) => <Provider store={store}>{children}</Provider>;

describe("useViewReimbursement", () => {
  const mockUseViewReimbursement = {
    onSubmit: jest.fn(),
    adjustTransHandler: jest.fn(),
    isAdjustTransDisabled: jest.fn(),
    selectNextRecord: jest.fn(),
    handleInputChange: jest.fn(),
    goToAdd: jest.fn(),
    printChequePostReimbursement: jest.fn(),
    getInitialPayeeCheque: jest.fn(),
    uniqueChequeErrMsg: "",
    setShowUniqueChequeError: jest.fn(),
    pettyCashTransaction: null,
    historyState: null,
    pettyCashAccountsHidden: null,
    selectedPettyCashRow: null,
    pettyCashTransactionList: [],
    currentPage: 1,
    totalPages: 1,
    chequeNoVal: "123000"
  };

  const mockDispatch = jest.fn();
  store.dispatch = mockDispatch;

  const pcAccountId = "test-account-id";
  const pcTransId = "test-trans-id";
  const historyState = { mode: "view", isAdjust: false };

  jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useEffect: jest.fn((fn) => fn())
  }));

  const mockSetShowUniqueChequeError = jest.fn();
  const mockSetUniqueChequeErrMsg = jest.fn();
  const mockSetShowOverdrawnErrorModal = jest.fn();
  const mockSetFormDataToSave = jest.fn();
  const mockCallSaveAPI = jest.fn();

  jest.mock("../useViewReimbursement", () => () => ({
    ...mockUseViewReimbursement,
    setShowUniqueChequeError: mockSetShowUniqueChequeError,
    setUniqueChequeErrMsg: mockSetUniqueChequeErrMsg,
    setShowOverdrawnErrorModal: mockSetShowOverdrawnErrorModal,
    setFormDataToSave: mockSetFormDataToSave,
    callSaveAPI: mockCallSaveAPI
  }));

  mockUseLocation.mockReturnValue({
    pathname: "/test-path",
    search: "",
    hash: "",
    state: null
  });

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("should call dispatch with getFCSourceBalance on form submit", async () => {
    const { result } = renderHook(() => useViewReimbursement(), { wrapper });

    // Simulate data and mock dispatch
    const mockData = {
      amount: "100",
      period_posted: "202410",
      narrative: "Test Narrative",
      cheque_no: "123456",
      payee_name: "Test Payee",
      number_range: "range1"
    };

    await act(async () => {
      result.current.onSubmit({ target: { value: mockData } } as any);
    });

    expect(getFCSourceBalance).toHaveBeenCalled();
  });

  test("should not allow adjusting if isAdjustTransDisabled returns true", () => {
    const { result } = renderHook(() => useViewReimbursement(), { wrapper });

    // Mock necessary state
    result.current.isAdjustTransDisabled = jest.fn().mockReturnValue(true); // Mock the isAdjustTransDisabled method

    const isDisabled = result.current.isAdjustTransDisabled();

    expect(isDisabled).toBe(true);
  });

  test("should call handleInputChange correctly", () => {
    const { result } = renderHook(() => useViewReimbursement(), { wrapper });

    const mockEvent = {
      target: { value: " 123 " }
    };

    act(() => {
      result.current.handleInputChange(mockEvent as any);
    });

    expect(result.current.chequeNoVal).toBe("123000");
  });

  test("should call getReimbursementDetails on mount", async () => {
    renderHook(() => useViewReimbursement(), { wrapper });

    expect(getReimbursementDetails).toHaveBeenCalled();
  });

  test("should call onChangeHandler if on the last record of the current page", () => {
    const { result } = renderHook(() => useViewReimbursement(), { wrapper });

    const mockDispatch = jest.fn();
    store.dispatch = mockDispatch;

    const mockSelectedPettyCashRow = { id: 2 };
    const mockPettyCashTransactionList = [{ id: 1 }, { id: 2 }];
    const mockGoToRecord = jest.fn();
    const mockOnChangeHandler = jest.fn();

    result.current.selectedPettyCashRow = mockSelectedPettyCashRow;
    result.current.pettyCashTransactionList = mockPettyCashTransactionList;
    result.current.goToRecord = mockGoToRecord;
    result.current.onChangeHandler = mockOnChangeHandler;
    result.current.currentPage = 1;
    result.current.totalPages = 2;

    act(() => {
      result.current.selectNextRecord();
    });

    expect(mockDispatch).not.toHaveBeenCalled();
    expect(mockGoToRecord).not.toHaveBeenCalled();
  });

  test("should render useViewReimbursement hook correctly", () => {
    const { result } = renderHook(() => useViewReimbursement(), { wrapper });

    expect(result.current).toBeDefined();
    expect(result.current.onSubmit).toBeInstanceOf(Function);
    expect(result.current.adjustTransHandler).toBeInstanceOf(Function);
    expect(result.current.isAdjustTransDisabled).toBeInstanceOf(Function);
    expect(result.current.selectNextRecord).toBeInstanceOf(Function);
    expect(result.current.handleInputChange).toBeInstanceOf(Function);
    expect(result.current.goToAdd).toBeInstanceOf(Function);
    expect(result.current.printChequePostReimbursement).toBeInstanceOf(Function);
    expect(result.current.getInitialPayeeCheque).toBeInstanceOf(Function);
    expect(result.current.setShowUniqueChequeError).toBeInstanceOf(Function);
    expect(result.current.setShowOverdrawnErrorModal).toBeInstanceOf(Function);
    expect(result.current.formDataToSave).toBeUndefined();
    expect(result.current.uniqueChequeErrMsg).toBe("");
    expect(result.current.historyState).toEqual({});
    expect(result.current.pettyCashAccountsHidden).toBeUndefined();
    expect(result.current.selectedPettyCashRow).toBeUndefined();
    expect(result.current.pettyCashTransactionList).toBeUndefined();
    expect(result.current.getValues).toBeInstanceOf(Function);
  });

  test("should update state correctly on handleInputChange", () => {
    const { result } = renderHook(() => useViewReimbursement(), { wrapper });

    const mockEvent = {
      target: { value: " 123 " }
    };

    act(() => {
      result.current.handleInputChange(mockEvent as any);
    });

    expect(result.current.chequeNoVal).toBe("123000");
  });

  test("should handle overdrawn error modal correctly", () => {
    const { result } = renderHook(() => useViewReimbursement(), { wrapper });

    act(() => {
      result.current.setShowOverdrawnErrorModal(true);
    });

    expect(result.current.showOverdrawnErrorModal).toBe(true);
  });

  test("should handle unique cheque error correctly", () => {
    const { result } = renderHook(() => useViewReimbursement(), { wrapper });

    act(() => {
      result.current.setShowUniqueChequeError(true);
    });

    expect(result.current.showUniqueChequeError).toBe(true);
  });

  test("should handle unique cheque error message correctly", () => {
    const { result } = renderHook(() => useViewReimbursement(), { wrapper });

    act(() => {
      result.current.uniqueChequeErrMsg = "Unique cheque error";
    });

    expect(result.current.uniqueChequeErrMsg).toBe("Unique cheque error");
  });
});
