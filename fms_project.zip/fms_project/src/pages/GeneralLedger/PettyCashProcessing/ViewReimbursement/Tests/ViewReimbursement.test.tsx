import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import configureStore from "redux-mock-store";
import { Provider, useDispatch, useSelector } from "react-redux";
import { MemoryRouter, Router, useLocation } from "react-router-dom";
import { createMemoryHistory } from "history";
import { useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import useViewReimbursement from "../useViewReimbursement";
import ViewReimbursement from "../ViewReimbursement";

const pettyCashAccessRights = {
  accessArea: "Petty Cash",
  accessRights: [
    {
      access_right: "Adjust Trans",
      result: "T"
    },
    {
      access_right: "Allocate Source",
      result: "T"
    },
    {
      access_right: "Cancel",
      result: "T"
    },
    {
      access_right: "Post expenditure",
      result: "T"
    },
    {
      access_right: "Print",
      result: "F"
    },
    {
      access_right: "Raise folios",
      result: "F"
    },
    {
      access_right: "Reimburse",
      result: "F"
    },
    {
      access_right: "Set reimbursement level",
      result: "T"
    },
    {
      access_righ: "View",
      result: "T"
    }
  ],
  redirectToInvoiceDetailsLink: jest.fn(),
  redirectToManualJournalDetails: jest.fn(),
  setTitle: jest.fn(),
  title: ""
};

const initialState = {
  userAccessRights: {
    data: [{ ...pettyCashAccessRights }]
  }
};

const history = createMemoryHistory();

jest.mock("react-redux", () => ({
  useDispatch: jest.fn(),
  useSelector: jest.fn()
}));

jest.mock("react-router", () => ({
  ...jest.requireActual("react-router"),
  useLocation: jest.fn()
}));

const mockUseLocation = useLocation as jest.Mock;

jest.mock("react-hook-form", () => ({
  useForm: jest.fn()
}));

jest.mock("../useViewReimbursement", () => ({
  __esModule: true,
  default: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    init: jest.fn()
  }
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn().mockImplementation((selector) => selector(initialState))
}));

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn().mockReturnValue({ id: "123" })
}));

const mockRegister = jest.fn();
const mockGetValues = jest.fn();

jest.mock("react-hook-form", () => ({
  useForm: jest.fn(() => ({
    register: mockRegister,
    getValues: mockGetValues,
    errors: {}
  }))
}));

const mockStore = configureStore([]);

describe("ViewReimbursement", () => {
  const mockDispatch = jest.fn();
  const mockUseViewReimbursement = {
    historyState: {},
    postingPeriodMonth: "",
    numberFormatter: jest.fn(),
    reimbursmentStatus: "",
    pettyCashAccountsHidden: false,
    pettyCashTransaction: {},
    chequeNoVal: "",
    handleViewAdjustmentClick: jest.fn(),
    handleViewOriginalClick: jest.fn(),
    selectNextRecord: jest.fn(),
    selectPrevRecord: jest.fn(),
    pcTransId: "",
    postingPeriodDetails: {},
    printChequeStatus: "",
    printButtonClicked: false,
    onSelectRowDate: jest.fn(),
    handleCheckNo: jest.fn(),
    onPostingPeriodSelectedRow: jest.fn(),
    onPaymentPeriodChange: jest.fn(),
    onPaymentPeriodNoSelection: jest.fn(),
    onPaymentPeriodSelection: jest.fn(),
    onSelectRowCheque: jest.fn(),
    onChequeBookSelectedRow: jest.fn(),
    onChequeBookNoSelection: jest.fn(),
    onChequeBookChange: jest.fn(),
    onChequeBookSelection: jest.fn(),
    setShowPostingPeriodModal: jest.fn(),
    chequeBookList: [],
    reimbursmentSaveStatus: "",
    setIsChequeBookModalOpen: jest.fn(),
    isChequeBookModalOpen: false,
    showPostingPeriodModal: false,
    setValue: jest.fn(),
    trigger: jest.fn(),
    getValues: jest.fn(),
    getHeaderValue: jest.fn(),
    handleInputChange: jest.fn(),
    errors: {},
    isRequiredPayeeName: false,
    ValidationTextLevel: "",
    register: jest.fn(),
    onSubmit: jest.fn(),
    watch: jest.fn(),
    saveChangesModal: jest.fn(),
    openSaveChangesModal: false,
    setOpenSaveChangesModal: jest.fn(),
    setOpenValidationModal: jest.fn(),
    openValidationModal: false,
    showUniqueChequeError: false,
    setShowUniqueChequeError: jest.fn(),
    uniqueChequeErrMsg: "",
    onFocusClickHandler: jest.fn(),
    resetOnFocus: jest.fn(),
    goToAdd: jest.fn(),
    undoChangeHandler: jest.fn(),
    isUndoModalOpen: false,
    setIsUndoModalOpen: jest.fn(),
    resetOnFocusAndNavigate: jest.fn(),
    undoChangeAndNavigate: jest.fn(),
    formDataToSave: {},
    saveReimbursementData: jest.fn(),
    openInvalidChequeNoErr: false,
    setOpenInvalidChequeNoErr: jest.fn(),
    isInputClassReq: false,
    getInitialPayeeCheque: jest.fn(),
    adjustTransHandler: jest.fn(),
    isCancelDisabled: jest.fn(),
    isAdjustTransDisabled: jest.fn(),
    showOverdrawnErrorModal: false,
    setShowOverdrawnErrorModal: jest.fn(),
    postReimbursementData: jest.fn(),
    onPrintCheque: jest.fn()
  };

  mockUseLocation.mockReturnValue({
    pathname: "/test-path",
    search: "",
    hash: "",
    state: null
  });
  let mockOnPrintCheque: jest.Mock;
  let store: any;
  const mockContextValue = {
    resolve: jest.fn(),
    setPromise: jest.fn(),
    redirectToPurchaseOrderLink: jest.fn(),
    redirectToBankReconciledDetails: jest.fn(),
    redirectToPettyCashDetails: jest.fn(),
    redirectToPettyCashAdjustment: jest.fn(),
    redirectToPettyCashReimbursement: jest.fn(),
    redirectToPettyCashPostingPeriod: jest.fn(),
    redirectToInvoiceDetailsLink: jest.fn(),
    redirectToManualJournalDetails: jest.fn(),
    setTitle: jest.fn(),
    title: ""
  };
  beforeEach(() => {
    store = mockStore({
      reimbursement: {
        historyState: {
          mode: true,
          headerData: { source_type: "BK" },
          isAdjust: false,
          selectedRowState: { cheque_book_id: null }
        },
        pettyCashAccountsHidden: { source_type: "BK" },
        reimbursmentSaveStatus: STATUS.SUCCESS,
        printChequeStatus: STATUS.SUCCESS
      }
    });

    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useViewReimbursement as jest.Mock).mockReturnValue(mockUseViewReimbursement);
    (useAppSelector as jest.Mock).mockReturnValue({
      ...initialState
    });
    mockOnPrintCheque = jest.fn();
    mockOnPrintCheque.mockClear();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("renders ViewReimbursement component", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      pettyCashAccountsHidden: false
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );
    expect(screen.getByText("viewReimbursement.viewReimbursTitle")).toBeInTheDocument();
  });

  test("calls goToAdd when Add button is clicked", () => {
    const history = createMemoryHistory();
    const mockUseViewReimbursement = {
      goToAdd: jest.fn()
    };
    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );
    const addButton = screen.getByTestId("add-reimbursement-title");
    fireEvent.click(addButton);
  });

  test("displays validation error modal when validation fails", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      openValidationModal: true
    });
    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );
    expect(screen.getByText("common.invalidData")).toBeInTheDocument();
  });

  test("displays unique cheque error modal when unique cheque error occurs", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      showUniqueChequeError: true,
      uniqueChequeErrMsg: "Unique Cheque Error"
    });
    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );
    expect(screen.getByText("Unique Cheque Error")).toBeInTheDocument();
  });

  it("should render view original and view adjustment buttons when conditions are met", () => {
    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    // Check if the view original button is rendered and enabled
    const viewOriginalButton = screen.getByText("viewReimbursement.viewOriginal");
    expect(viewOriginalButton).toBeInTheDocument();
    expect(viewOriginalButton).toBeDisabled();

    // Check if the view adjustment button is rendered and enabled
    const viewAdjustmentButton = screen.getByText("viewReimbursement.viewAdjustment");
    expect(viewAdjustmentButton).toBeInTheDocument();
    expect(viewAdjustmentButton).toBeDisabled();
  });

  test("renders correct page title based on history state", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      historyState: { mode: true, isAdjust: false }
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByText("viewReimbursement.addReimbursTitle")).toBeInTheDocument();
  });

  test("renders correct page title when not in add or adjust mode", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      historyState: { mode: false, isAdjust: false }
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByText("viewReimbursement.viewReimbursTitle")).toBeInTheDocument();
  });

  test("renders correct tag elements based on history state", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      historyState: { mode: true, isAdjust: true }
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    const pendingTags = screen.getAllByText("viewExpenditure.pendingJournalNumber");
    const unpostedTags = screen.getAllByText("viewReimbursement.unpostedReimbursement");

    expect(pendingTags.length).toBeGreaterThan(0);
    expect(unpostedTags.length).toBeGreaterThan(0);
  });

  test("renders transaction number and narrative tags when available", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      pettyCashTransaction: { trans_no: "12345", narrative: "Test Narrative" }
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    const transactionNumbers = screen.getAllByText("12345");
    expect(transactionNumbers.length).toBeGreaterThan(0);
    expect(screen.getByText("Test Narrative")).toBeInTheDocument();
  });

  test("renders correct date format for transaction date", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      pettyCashTransaction: { date_posted: "2023-10-01T00:00:00Z" }
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByText("01 Oct 2023")).toBeInTheDocument();
  });

  test("renders correct amount format", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      pettyCashTransaction: { amount: 1234.56 },
      getValues: jest.fn().mockReturnValue("1234.56")
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  test("renders cheque book input when conditions are met", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      historyState: { mode: true, headerData: { source_type: "BK" }, isAdjust: false },
      chequeBookList: [{ number_range: "001-100", next_no: "001" }]
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByLabelText("pettyCash.chequeBook")).toBeInTheDocument();
  });

  test("renders cheque payee input when conditions are met", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      historyState: { mode: true, headerData: { source_type: "BK" }, isAdjust: false }
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByText("viewReimbursement.chequePayee")).toBeInTheDocument();
  });

  test("renders narrative input when conditions are met", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      historyState: { mode: true, isAdjust: true }
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByText("viewReimbursement.narrative")).toBeInTheDocument();
  });

  test("renders correct period posted value", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      getValues: jest.fn().mockReturnValue("2023-09"),
      postingPeriodMonth: "Sep 2023"
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByText("2023-09 Sep 2023")).toBeInTheDocument();
  });

  test("renders correct cheque payee value", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      getInitialPayeeCheque: jest.fn().mockReturnValue("John Doe")
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByDisplayValue("John Doe")).toBeInTheDocument();
  });

  test("renders correct narrative value", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      getValues: jest.fn().mockReturnValue("Test Narrative")
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByDisplayValue("Test Narrative")).toBeInTheDocument();
  });

  test("renders correct reconciled bank statement number when not available", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      pettyCashTransaction: { bank_statement_no: "-1" },
      historyState: { mode: false }
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.queryByLabelText("viewReimbursement.reconciledBankStatement")).not.toBeInTheDocument();
  });

  test("renders correct cheque payee input when conditions are met", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      historyState: { mode: true, headerData: { source_type: "BK" }, isAdjust: false },
      getInitialPayeeCheque: jest.fn().mockReturnValue("John Doe")
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByDisplayValue("John Doe")).toBeInTheDocument();
  });

  test("renders correct amount display when conditions are not met", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      historyState: { mode: false, isAdjust: false },
      getValues: jest.fn().mockReturnValue("1234.56")
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  test("renders correct cheque book input when conditions are met", () => {
    (useViewReimbursement as jest.Mock).mockReturnValueOnce({
      ...mockUseViewReimbursement,
      historyState: { mode: true, headerData: { source_type: "BK" }, isAdjust: false },
      chequeBookList: [{ number_range: "001-100", next_no: "001" }]
    });

    render(
      <Router history={history}>
        <ViewReimbursement />
      </Router>
    );

    expect(screen.getByLabelText("pettyCash.chequeBook")).toBeInTheDocument();
  });
});
