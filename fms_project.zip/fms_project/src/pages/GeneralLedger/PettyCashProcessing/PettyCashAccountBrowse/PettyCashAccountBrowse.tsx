import GridTableNew, { cellRendererType } from "@/components/GridTableNew/GridTableNew";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  NotificationStatus,
  Notification,
  DialogContent,
  DialogFooter,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import "./PettyCashAccountBrowse.scss";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { usNumberFormat } from "@/utils/getDataSource";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { useEffect, useRef, useState } from "react";
import Layout from "@/components/Layout/Layout";
import { useHistory } from "react-router-dom";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import { usePettyCashAccountBrowse } from "./usePettyCashAccountBrowse";
import { getPettyCashAccountBrowse, getPettyCashFundingSource, pettyCashActions } from "../state/PettyCashList.slice";

const PettyCashAccountBrowsePage = () => {
  const {
    openFundSourceToPettyCashAccount,
    setOpenFundSourceToPettyCashAccount,
    checkFundingSource,
    setFundingSourceTableEnable,
    setSelectedRow,
    selectedRow,
    isCancel,
    cancelHandler,
    UpdateFundingSourceData,
    fundingSourceTableEnable,
    fundingSourceTableTitle,
    selectedPettyCashAccountBrowse,
    selectedPersistPettyCashBrowseRow,
    pettyCashAccountBrowse,
    pettyCashFundingStatus,
    pettyCashAccountBrowseClose,
    pettyCashFundingSource,
    pettyCashBrowseStatus,
    selectedPettyCashFundingSource,
    pettyCashBrowseColumnDef: pettyCashBrowseColDef,
    pettyFundingSourceColumnDef: fundingSourceColDef,
    selectButtonDisabled,
    t,
    setFundingSourceTableTitle
  } = usePettyCashAccountBrowse();
  const dispatch = useDispatch<AppDispatch>();
  const selectBtnRef = useRef<HTMLButtonElement | null>(null);
  const history = useHistory();
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const loaderConfig: loadingConfig = {};
  const [openInsufficientAccessModal, setOpenInsufficientAccessModal] = useState<boolean>(false);
  const canDoReimb = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.PettyCash,
    action: ACCESS_RIGHTS_ACTION.Reimburse
  });

  const setSelectedData = () => {
    if (!fundingSourceTableEnable && !selectedRow?.source_des) {
      setFundingSourceTableEnable(true);
      dispatch(getPettyCashFundingSource());
      setFundingSourceTableTitle(selectedRow?.pc_acc_des);
    } else if (fundingSourceTableEnable) {
      if (canDoReimb) {
        setOpenFundSourceToPettyCashAccount(true);
      } else {
        setOpenInsufficientAccessModal(true);
      }
    } else {
      dispatch(pettyCashActions.setSelectedPettyCashBrowseRow(selectedRow));
      dispatch(pettyCashActions.setPersistPettyCashBrowseRow(selectedRow));
      dispatch(pettyCashActions.setAccountBrowseButtonClicked(true));
      history.goBack();
    }
  };
  useEffect(() => {
    if (pettyCashAccountBrowseClose) {
      history.goBack();
    }
  }, [pettyCashAccountBrowseClose]);

  useEffect(() => {
    dispatch(getPettyCashAccountBrowse());
  }, []);

  useEffect(() => {
    const timerID = setTimeout(() => {
      const ele = document.querySelector(`.pettycash-account .generic-table .selected-row`) as HTMLElement;
      ele?.focus();
    }, 500);

    return () => {
      clearTimeout(timerID);
    };
  }, []);

  const CustomCell = ({ field, row }: cellRendererType) => {
    const getContent = () => {
      switch (field) {
        case "cash_in_hand":
          return <>{usNumberFormat(row?.cash_in_hand)}</>;
        case "unposted_exp":
          return <>{usNumberFormat(row?.unposted_exp)}</>;
        case "balance":
          return <>{usNumberFormat(row?.balance)}</>;
        default: {
          return <div />;
        }
      }
    };
    return getContent();
  };

  return (
    <>
      {pettyCashBrowseStatus === STATUS.LOADING ? (
        <Loader loadingConfig={loaderConfig} />
      ) : (
        <>
          <Layout
            pageTitle={t("pettyCashList.pettyCashBrowseTitle")}
            isBreadcrumbRequired
            className="petty-cash-processing wrapper__radius--0"
            type="transparent"
          >
            <Grid>
              <GridItem
                sm={12}
                md={12}
                lg={12}
                xl={12}
                className="payee-table table__hegiht--320"
              >
                <div className="pettycash-account top--1">
                  <GridTableNew
                    onFocus={(e) => {
                      const index = e.target?.id?.split("-")[2];
                      const selectedRowIndex = pettyCashAccountBrowse.at(Number(index));
                      if (!selectedRowIndex?.source_des) {
                        setSelectedRow(selectedRowIndex);
                        // dispatch(pettyCashActions.setSelectedPettyCashBrowseRow(selectedRowIndex));
                        dispatch(pettyCashActions.setPersistPettyCashBrowseRow(selectedRowIndex));
                      }
                    }}
                    dataTestId="pettycash"
                    selectedRow={selectedPersistPettyCashBrowseRow}
                    dataSource={pettyCashAccountBrowse}
                    isLoading={false}
                    customCell={CustomCell}
                    columnDef={pettyCashBrowseColDef}
                    selectedRowHandler={(row) => {
                      if (isCancel) {
                        dispatch(pettyCashActions.setCancelButtonClicked(false));
                      }
                      checkFundingSource(row);
                      setSelectedRow(row);
                      dispatch(pettyCashActions.setPersistPettyCashBrowseRow(row));
                    }}
                    onEnterKeyPress={() => {
                      dispatch(pettyCashActions.setPersistPettyCashBrowseRow(selectedPettyCashAccountBrowse));
                      history.goBack();
                    }}
                    isScrollable
                    enableScrollIntoView
                  />
                </div>
              </GridItem>
            </Grid>
          </Layout>

          {fundingSourceTableEnable && (
            <div>
              <div>
                <Layout isBreadcrumbRequired={false}>
                  <div className="petty-cash-browse mt-16">
                    <div className="essui-form-label">{t("pettyCashList.fundingSourcePettyCashAccount")}</div>
                    <div className="mt-15">{fundingSourceTableTitle}</div>
                  </div>
                </Layout>
              </div>

              <div>
                <Layout
                  isBreadcrumbRequired={false}
                  type="transparent"
                >
                  <div className="petty-cash-browse mt-16">
                    <GridTableNew
                      selectedRow={selectedPettyCashFundingSource}
                      dataSource={pettyCashFundingSource}
                      isScrollable
                      isLoading={pettyCashFundingStatus === STATUS.LOADING}
                      customCell={CustomCell}
                      columnDef={fundingSourceColDef}
                      selectedRowHandler={(row) => {
                        dispatch(pettyCashActions.setSelectedPettyFundingSourceRow(row));
                      }}
                    />
                  </div>
                </Layout>
              </div>
            </div>
          )}

          <Layout isBreadcrumbRequired={false}>
            <Grid className="flex-rev">
              <GridItem
                sm={2}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="rightbtn">
                  <Button
                    ref={selectBtnRef}
                    size={ButtonSize.Small}
                    onClick={setSelectedData}
                    disabled={pettyCashAccountBrowse.length === 0}
                  >
                    {t("common.selectButton")}
                  </Button>
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    onClick={() => {
                      history.goBack();
                      cancelHandler();
                    }}
                  >
                    {t("common.cancel")}
                  </Button>
                </div>
              </GridItem>
              <GridItem
                sm={2}
                md={4}
                lg={6}
                xl={6}
              >
                <div>
                  <HelpButton
                    identifier="testIdentifier"
                    labelName={t("common.help")}
                  />
                </div>
              </GridItem>
            </Grid>
          </Layout>
        </>
      )}

      <ConfirmModal
        className="delete-alert"
        isOpen={openFundSourceToPettyCashAccount}
        setOpen={setOpenFundSourceToPettyCashAccount}
        message={t("pettyCashList.fundingSourcePettyCashAccountModalMsg")}
        title={t("common.simsFMSModule")}
        confirm={UpdateFundingSourceData}
        callback={({ confirm }) => {
          if (!confirm) {
            // setIsSupplierDetailUndo(false);
          }
        }}
      />
      <AlertModal
        isOpen={openInsufficientAccessModal}
        setOpen={setOpenInsufficientAccessModal}
        title={t("alertMessage.title")}
        notificationType={NotificationStatus.ERROR}
        message={t("pettyCashList.allocateFundingSourceAccess")}
        autoFocusPrimaryBtn
      />
    </>
  );
};
PettyCashAccountBrowsePage.defaultProps = {
  selectedRows: undefined
};
export default PettyCashAccountBrowsePage;
