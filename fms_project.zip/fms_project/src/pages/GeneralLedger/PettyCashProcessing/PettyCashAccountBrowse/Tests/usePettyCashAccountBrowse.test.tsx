import React from "react";
import { renderHook, act } from "@testing-library/react-hooks";
import { Provider, useDispatch } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { useHistory } from "react-router-dom";
import pettyCashReducer from "../../state/PettyCashList.slice";
import { usePettyCashAccountBrowse } from "../usePettyCashAccountBrowse";

jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn(),
  Provider: jest.requireActual("react-redux").Provider
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    init: jest.fn()
  }
}));

// Setting up a mock store with pettyCashReducer
const setupStore = () =>
  configureStore({
    reducer: {
      pettyCashList: pettyCashReducer
    }
  });

describe("usePettyCashAccountBrowse", () => {
  let store: any;
  let mockDispatch: jest.Mock;

  beforeEach(() => {
    store = setupStore();
    mockDispatch = jest.fn();
    const mockHistoryPush = jest.fn();
    (useTranslation as jest.Mock).mockReturnValue({ t: (key: any) => key });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue({ push: mockHistoryPush, location: { state: {} } });
    (useAppSelector as jest.Mock).mockImplementation((selector: any) => {
      if (selector.name === "pettyCashList") {
        return {
          filterState: {},
          selectedPettyCashAccountBrowse: {},
          selectedPersistPettyCashBrowseRow: {},
          pettyCashAccountBrowse: [],
          pettyCashFundingStatus: "",
          pettyCashFundingSource: [],
          sortedPettyCashAccount: [],
          pettyCashBrowseStatus: "",
          isCancel: false,
          selectedPettyCashFundingSource: {},
          pettyCashBrowseColumnDef: [],
          pettyFundingSourceColumnDef: []
        };
      }
      return {};
    });
    jest.clearAllMocks();
  });

  const renderUsePettyCashAccountBrowse = () =>
    renderHook(() => usePettyCashAccountBrowse(), {
      wrapper: ({ children }: { children: React.ReactNode }) => <Provider store={store}>{children}</Provider>
    });

  it("should initialize with default values", () => {
    const { result } = renderUsePettyCashAccountBrowse();

    expect(result.current.filterState).toEqual({});
    expect(result.current.selectedRow).toBeUndefined();
    expect(result.current.fundingSourceTableEnable).toBe(false);
    expect(result.current.pettyCashAccountBrowseClose).toBe(false);
    expect(result.current.selectButtonDisabled).toBe(true);
  });

  it("should disable select button if source_des is not present in selected row", () => {
    const { result } = renderUsePettyCashAccountBrowse();

    act(() => {
      store.dispatch({
        type: "pettyCashList/setSelectedPersistPettyCashBrowseRow",
        payload: { source_des: null }
      });
    });

    expect(result.current.selectButtonDisabled).toBe(true);
  });

  it("should enable select button if source_des is present in selected row", () => {
    const { result } = renderUsePettyCashAccountBrowse();

    act(() => {
      store.dispatch({
        type: "pettyCashList/setSelectedPersistPettyCashBrowseRow",
        payload: { source_des: "Some Source" }
      });
    });

    expect(result.current.selectButtonDisabled).toBe(false);
  });

  it("should scroll to the selected row on pettyCashAccountBrowse update", () => {
    const { result } = renderUsePettyCashAccountBrowse();
    const scrollIntoViewMock = jest.fn();

    document.getElementById = jest.fn((id) => {
      if (id === "pc_account_id_1") {
        return {
          scrollIntoView: scrollIntoViewMock
        } as unknown as HTMLElement;
      }
      return null;
    });

    act(() => {
      store.dispatch({
        type: "pettyCashList/setPettyCashAccountBrowse",
        payload: [{ pc_account_id: 1 }]
      });
      store.dispatch({
        type: "pettyCashList/setSelectedPersistPettyCashBrowseRow",
        payload: { pc_account_id: 1 }
      });
    });

    expect(scrollIntoViewMock).toHaveBeenCalledWith({ block: "center", behavior: "smooth" });
  });

  it("should reset selected row on cancel", () => {
    const { result } = renderUsePettyCashAccountBrowse();

    act(() => {
      result.current.setSelectedRow({ pc_account_id: 1 });
      result.current.cancelHandler();
    });

    expect(result.current.selectedRow).toBeUndefined();
  });

  it("should call updatingPettyCashFundingSource with correct data", () => {
    const mockDispatch = jest.fn();
    store.dispatch = mockDispatch;

    const { result } = renderUsePettyCashAccountBrowse();

    act(() => {
      result.current.setSelectedRow({ pc_account_id: 1 });
      result.current.UpdateFundingSourceData();
    });

    expect(mockDispatch).toHaveBeenCalledWith({
      type: "pettyCashList/updatingPettyCashFundingSource",
      payload: {
        pc_account_id: 1,
        source_leddef_id: result.current.selectedPettyCashFundingSource?.leddef_id || null,
        callback: expect.any(Function)
      }
    });
  });
});
