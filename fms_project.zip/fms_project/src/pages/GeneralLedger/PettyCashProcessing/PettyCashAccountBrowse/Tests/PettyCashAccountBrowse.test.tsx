import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import configureStore from "redux-mock-store";
import thunk from "redux-thunk";
import { STATUS } from "@/types/UseStateType";
import PettyCashAccountBrowsePage from "../PettyCashAccountBrowse";
import { usePettyCashAccountBrowse } from "../usePettyCashAccountBrowse";

jest.mock("../usePettyCashAccountBrowse");

const mockStore = configureStore([thunk]);

describe("PettyCashAccountBrowsePage", () => {
  let store: ReturnType<typeof mockStore>;

  beforeEach(() => {
    store = mockStore({
      userAccessRights: {},
      pettyCash: {
        pettyCashAccountBrowse: [],
        pettyCashFundingSource: [],
        pettyCashBrowseStatus: STATUS.IDLE,
        pettyCashFundingStatus: STATUS.IDLE
      }
    });

    const setOpenFundSourceToPettyCashAccount = jest.fn();
    const setSelectButtonDisabled = jest.fn();

    (usePettyCashAccountBrowse as jest.Mock).mockReturnValue({
      openFundSourceToPettyCashAccount: false,
      setOpenFundSourceToPettyCashAccount,
      checkFundingSource: jest.fn(),
      setFundingSourceTableEnable: jest.fn(),
      setSelectedRow: jest.fn(),
      selectedRow: null,
      isCancel: false,
      cancelHandler: jest.fn(),
      UpdateFundingSourceData: jest.fn(),
      fundingSourceTableEnable: false,
      fundingSourceTableTitle: "",
      selectedPettyCashAccountBrowse: null,
      selectedPersistPettyCashBrowseRow: null,
      pettyCashAccountBrowse: [],
      pettyCashFundingStatus: STATUS.IDLE,
      pettyCashAccountBrowseClose: false,
      pettyCashFundingSource: [],
      pettyCashBrowseStatus: STATUS.IDLE,
      selectedPettyCashFundingSource: null,
      pettyCashBrowseColumnDef: [],
      pettyFundingSourceColumnDef: [],
      selectButtonDisabled: false,
      t: (key: string) => key,
      setFundingSourceTableTitle: jest.fn(),
      openInsufficientAccessModal: false,
      allocateFundingSourceAccess: jest.fn(),
      setSelectButtonDisabled
    });
  });

  it("should render the PettyCashAccountBrowsePage component", () => {
    render(
      <Provider store={store}>
        <Router>
          <PettyCashAccountBrowsePage />
        </Router>
      </Provider>
    );

    expect(screen.getByText("pettyCashList.pettyCashBrowseTitle")).toBeInTheDocument();
  });

  it("should handle cancel button click", () => {
    render(
      <Provider store={store}>
        <Router>
          <PettyCashAccountBrowsePage />
        </Router>
      </Provider>
    );

    const cancelButton = screen.getByText("common.cancel");
    fireEvent.click(cancelButton);

    expect(usePettyCashAccountBrowse().cancelHandler).toHaveBeenCalled();
  });

  it("should handle useEffect for scrolling into view", () => {
    const mockPettyCashAccountBrowse = [{ pc_account_id: 1 }, { pc_account_id: 2 }, { pc_account_id: 3 }];
    const mockSelectedPersistPettyCashBrowseRow = { pc_account_id: 2 };

    (usePettyCashAccountBrowse as jest.Mock).mockReturnValue({
      ...usePettyCashAccountBrowse(),
      pettyCashAccountBrowse: mockPettyCashAccountBrowse,
      selectedPersistPettyCashBrowseRow: mockSelectedPersistPettyCashBrowseRow
    });
    render(
      <Provider store={store}>
        <Router>
          <PettyCashAccountBrowsePage />
        </Router>
      </Provider>
    );
  });

  it("should handle UpdateFundingSourceData function", () => {
    const dispatch = jest.fn();
    const selectedRow = { pc_account_id: 1 };
    const selectedPettyCashFundingSource = { leddef_id: 2 };
    const filterState = { someFilter: "value" };
    const setPettyCashAccountBrowseClose = jest.fn();

    const updatingPettyCashFundingSource = jest.fn();
    const getPettyCashAccountBrowse = jest.fn();
    const pettyCashActions = {
      setSelectedPettyCashBrowseRow: jest.fn(),
      setFilters: jest.fn(),
      setSortedPettyCashAccount: jest.fn(),
      setPersistPettyCashBrowseRow: jest.fn()
    };

    const UpdateFundingSourceData = () => {
      dispatch(
        updatingPettyCashFundingSource({
          pc_account_id: selectedRow?.pc_account_id,
          source_leddef_id: selectedPettyCashFundingSource?.leddef_id,
          callback: (res: any) => {
            dispatch(getPettyCashAccountBrowse());
            dispatch(pettyCashActions.setSelectedPettyCashBrowseRow(selectedRow));
            setPettyCashAccountBrowseClose(true);
            pettyCashActions.setFilters({
              ...filterState,
              pcAccountId: selectedRow?.pc_account_id,
              pcTransId: 0
            });
            dispatch(pettyCashActions.setSortedPettyCashAccount(selectedRow));
            dispatch(pettyCashActions.setPersistPettyCashBrowseRow(selectedRow));
          }
        })
      );
    };

    UpdateFundingSourceData();

    expect(dispatch).toHaveBeenCalledWith(
      updatingPettyCashFundingSource({
        pc_account_id: selectedRow?.pc_account_id,
        source_leddef_id: selectedPettyCashFundingSource?.leddef_id,
        callback: expect.any(Function)
      })
    );
  });

  it("should handle cancelHandler function with missing data", () => {
    const dispatch = jest.fn();
    const setSelectedRow = jest.fn();
    const pettyCashActions = {
      setCancelButtonClicked: jest.fn()
    };

    const cancelHandler = () => {
      dispatch(pettyCashActions.setCancelButtonClicked(true));
      setSelectedRow(undefined);
    };

    cancelHandler();

    expect(dispatch).toHaveBeenCalledWith(pettyCashActions.setCancelButtonClicked(true));
    expect(setSelectedRow).toHaveBeenCalledWith(undefined);
  });

  const renderComponent = () => {
    render(
      <Provider store={store}>
        <Router>
          <PettyCashAccountBrowsePage />
        </Router>
      </Provider>
    );
  };

  it("should handle onEnterKeyPress function", () => {
    const dispatch = jest.fn();
    const history = { goBack: jest.fn() };
    const selectedPettyCashAccountBrowse = { pc_account_id: 1 };
    const pettyCashActions = {
      setPersistPettyCashBrowseRow: jest.fn()
    };

    const onEnterKeyPress = () => {
      dispatch(pettyCashActions.setPersistPettyCashBrowseRow(selectedPettyCashAccountBrowse));
      history.goBack();
    };

    onEnterKeyPress();

    expect(dispatch).toHaveBeenCalledWith(
      pettyCashActions.setPersistPettyCashBrowseRow(selectedPettyCashAccountBrowse)
    );
    expect(history.goBack).toHaveBeenCalled();
  });

  it("should handle setSelectedData function", () => {
    const dispatch = jest.fn();
    const setFundingSourceTableEnable = jest.fn();
    const setFundingSourceTableTitle = jest.fn();
    const setOpenFundSourceToPettyCashAccount = jest.fn();
    const setOpenInsufficientAccessModal = jest.fn();
    const history = { goBack: jest.fn() };
    const getPettyCashFundingSource = jest.fn();
    const canDoReimb = true;
    const selectedRow = { pc_acc_des: "Account Description", source_des: null };
    const fundingSourceTableEnable = false;
    const pettyCashActions = {
      setSelectedPettyCashBrowseRow: jest.fn(),
      setPersistPettyCashBrowseRow: jest.fn(),
      setAccountBrowseButtonClicked: jest.fn()
    };

    const setSelectedData = () => {
      if (!fundingSourceTableEnable && !selectedRow?.source_des) {
        setFundingSourceTableEnable(true);
        dispatch(getPettyCashFundingSource());
        setFundingSourceTableTitle(selectedRow?.pc_acc_des);
      } else if (fundingSourceTableEnable) {
        if (canDoReimb) {
          setOpenFundSourceToPettyCashAccount(true);
        } else {
          setOpenInsufficientAccessModal(true);
        }
      } else {
        dispatch(pettyCashActions.setSelectedPettyCashBrowseRow(selectedRow));
        dispatch(pettyCashActions.setPersistPettyCashBrowseRow(selectedRow));
        dispatch(pettyCashActions.setAccountBrowseButtonClicked(true));
        history.goBack();
      }
    };

    setSelectedData();

    expect(setFundingSourceTableEnable).toHaveBeenCalledWith(true);
    expect(dispatch).toHaveBeenCalledWith(getPettyCashFundingSource());
    expect(setFundingSourceTableTitle).toHaveBeenCalledWith(selectedRow?.pc_acc_des);
  });
});
