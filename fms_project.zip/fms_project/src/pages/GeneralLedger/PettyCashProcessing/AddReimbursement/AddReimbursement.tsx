import React, { useEffect, useState } from "react";
import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  ISelectedItem,
  Icon,
  IconColor,
  IconSize,
  TextInput,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useForm } from "react-hook-form";
import PostingPeriodModal from "@/shared/components/PostingPeriod/PostingPeriodModal";
import { actions as periodActions } from "@/pages/Invoice/State/InvoicePostingPeriod.slice";
import SelectChequeBookModal from "@/shared/components/SelectChequeBookModal/SelectChequeBookModal";
import { actions as cbActions } from "@/shared/components/SelectChequeBookModal/state/SelectChequeBook.slice";
import { getPettyCashAccountBrowse } from "../state/PettyCashList.slice";
import "./Style.scss";

type FormData = {
  nextChequeNumber: string;
  numberRange: string;
  paymentPeriod: string;
  paymentDescription: string;
};

const AddReimbursement = () => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const [isChequeBookModalOpen, setIsChequeBookModalOpen] = useState<boolean>(false);
  const [showPostingPeriodModal, setShowPostingPeriodModal] = useState<boolean>(false);
  const { status, selectedChequeBook, chequeBookList, filters } = useAppSelector((state) => state.selectChequeBook);
  const { postingPeriodDetails } = useAppSelector((state) => state.invoicePostingPeriod);

  const {
    register,
    reset,
    setError,
    handleSubmit,
    formState: { errors },
    getValues,
    setValue,
    trigger,
    clearErrors
  } = useForm<FormData>({
    shouldFocusError: false
  });

  const onChequeBookSelection = (selectedItem: ISelectedItem | undefined) => {
    const found = chequeBookList.find((row) => row?.number_range === selectedItem?.text);
    if (selectedItem?.text) {
      dispatch(cbActions.setFilters({ lookingFor: "" }));
      setValue("numberRange", found?.number_range);
      setValue("nextChequeNumber", found?.next_no);
      dispatch(cbActions.selectChequeBook(found));
    } else {
      dispatch(cbActions.selectChequeBook(undefined));
    }
  };

  useEffect(() => {
    dispatch(getPettyCashAccountBrowse());
  }, []);

  const onChequeBookNoSelection = () => {
    setIsChequeBookModalOpen(true);
    setValue("nextChequeNumber", "");
    setValue("numberRange", "");
  };

  const onChequeBookChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    register("numberRange").onChange(e);

    const { value } = e.target;
    if (!value.trim()) {
      dispatch(cbActions.selectChequeBook(undefined));
      dispatch(cbActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(cbActions.setFilters({ lookingFor: value }));
    }
  };

  const setChequeBookDetails = (row: any) => {
    setValue("numberRange", row?.number_range);
    setValue("nextChequeNumber", row?.next_no);
    trigger("numberRange");
    trigger("nextChequeNumber");
  };

  const onChequeBookSelectedRow = (row: any) => {
    dispatch(cbActions.selectChequeBook(row));
    setChequeBookDetails(row);
  };

  const onSelectRowCheque = (value: string) => {
    if (!value.trim()) {
      dispatch(cbActions.selectChequeBook(undefined));
      dispatch(cbActions.setFilters({ lookingFor: "" }));
      // setPaymentPeriod(true);
    } else {
      dispatch(cbActions.setFilters({ lookingFor: value }));
      // setPaymentPeriod(false);
    }
  };

  const setPaymentPeriodDetails = (row: any) => {
    setValue("paymentPeriod", row.code);
    setValue("paymentDescription", row.description);
    trigger("paymentPeriod");
    trigger("paymentDescription");
  };

  const onPaymentPeriodSelection = (selectedItem: ISelectedItem | undefined) => {
    const found = postingPeriodDetails.find((s) => s.code === selectedItem?.text);
    if (selectedItem?.text) {
      dispatch(periodActions.setFilters({ lookingFor: "" }));
      setValue("paymentDescription", found?.description);
      dispatch(periodActions.selectPostingPeriod(found));
    } else {
      dispatch(periodActions.selectPostingPeriod(undefined));
    }
  };

  const onPaymentPeriodNoSelection = () => {
    setShowPostingPeriodModal(true);
    setValue("paymentPeriod", "");
    setValue("paymentDescription", "");
  };

  const onPaymentPeriodChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    register("paymentPeriod").onChange(e);

    const { value } = e.target;
    if (!value.trim()) {
      dispatch(periodActions.selectPostingPeriod(undefined));
      dispatch(periodActions.setFilters({ lookingFor: "" }));
      // setPaymentPeriod(true);
    } else {
      dispatch(periodActions.setFilters({ lookingFor: value }));
      // setPaymentPeriod(false);
    }
  };

  const onPostingPeriodSelectedRow = (row: any) => {
    dispatch(periodActions.selectPostingPeriod(row));
    setPaymentPeriodDetails(row);
  };

  const onSelectRowDate = (value: any) => {
    if (!value.trim()) {
      dispatch(periodActions.selectPostingPeriod(undefined));
      dispatch(periodActions.setFilters({ lookingFor: "" }));
      // setPaymentPeriod(true);
    } else {
      dispatch(periodActions.setFilters({ lookingFor: value }));
      // setPaymentPeriod(false);
    }
  };

  return (
    <>
      <Layout
        pageTitle="Add Reimbursement"
        className=""
        isBreadcrumbRequired
      >
        <Grid className="row-gap-16 br-0">
          <GridItem
            lg={3}
            xl={3}
            md={4}
            sm={4}
          >
            <div>
              <div className="essui-form-label">Petty Cash Account</div>
              <div className="mt-8">Petty Cash New</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            md={4}
            sm={4}
          >
            <div>
              <div className="essui-form-label">Cash In Hand</div>
              <div className="mt-8">0.00</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            md={4}
            sm={4}
          >
            <div>
              <div className="essui-form-label">Unposted Expenditure</div>
              <div className="mt-8">0.00</div>
            </div>
          </GridItem>
        </Grid>
      </Layout>

      <Layout
        className=""
        isBreadcrumbRequired={false}
      >
        <Grid className="row-gap-16">
          <GridItem
            sm={4}
            md={12}
            lg={12}
            xl={12}
          >
            <div>
              <div className="essui-form-label">Transaction Number</div>
              <div className="mt-8">#0002476</div>
            </div>
          </GridItem>
        </Grid>
        <Grid className="mt-8 row-gap-8">
          <GridItem
            xl={3}
            lg={3}
            md={4}
            sm={4}
          >
            <div className="mb-16">
              <div className="essui-form-label">Date</div>
              <div className="mt-8">31 Jan 2024</div>
            </div>
          </GridItem>
          <GridItem
            xl={3}
            lg={3}
            md={4}
            sm={4}
          >
            <div className="mb-16">
              <div className="essui-form-label">General Ledger Journal</div>
              <div className="mt-8">-</div>
            </div>
          </GridItem>
          <GridItem
            xl={3}
            lg={3}
            md={4}
            sm={4}
          >
            <Grid>
              <GridItem>
                <Input
                  id="txtPaymentPeriod"
                  searchable
                  searchItems={postingPeriodDetails.map((p) => ({ text: p.code, value: p.description }))}
                  onSelect={(selectedItem: ISelectedItem | undefined) => onPaymentPeriodSelection(selectedItem)}
                  labelText={t("pettyCash.period")}
                  inputWidth={50}
                  onNoSelection={onPaymentPeriodNoSelection}
                  value={getValues("paymentPeriod")}
                  inputRef={(e) => register("paymentPeriod").ref(e)}
                  name={register("paymentPeriod").name}
                  onChange={onPaymentPeriodChange}
                  validationTextLevel={errors.paymentPeriod ? ValidationTextLevel.Error : undefined}
                  button={
                    <>
                      <TextInput
                        id="txtPaymentDescription"
                        className="width55"
                        inputWidth={60}
                        value={getValues("paymentPeriod") === "" ? "" : getValues("paymentDescription")}
                        name={register("paymentDescription").name}
                        disabled
                      />
                      <Button
                        color={ButtonColor.Secondary}
                        onClick={() => setShowPostingPeriodModal(true)}
                        size={ButtonSize.Small}
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </>
                  }
                />
              </GridItem>
            </Grid>
          </GridItem>
          <GridItem
            xl={3}
            lg={3}
            md={4}
            sm={4}
          >
            <div>
              <FormLabel forId="txtAmount">Amount</FormLabel>
              <Input
                value="0.00"
                searchable
                id="txtAmount"
              />
            </div>
          </GridItem>
          <GridItem
            xl={3}
            lg={3}
            md={4}
            sm={4}
          >
            <div className="mb-16">
              <div className="essui-form-label">drawn from</div>
              <div className="mt-8">Capital(Control)</div>
            </div>
          </GridItem>
          <GridItem
            xl={3}
            lg={3}
            md={4}
            sm={4}
          >
            <Input
              id="txtChequeBooks"
              searchable
              searchItems={chequeBookList.map((row) => ({ text: row?.number_range, value: row?.next_no }))}
              onSelect={(selectedItem: ISelectedItem | undefined) => onChequeBookSelection(selectedItem)}
              labelText={t("pettyCash.chequeBook")}
              onNoSelection={onChequeBookNoSelection}
              value={getValues("numberRange")}
              inputRef={(e) => register("numberRange").ref(e)}
              name={register("numberRange").name}
              onChange={onChequeBookChange}
              inputWidth={150}
              validationTextLevel={errors.numberRange ? ValidationTextLevel.Error : undefined}
              button={
                <>
                  <TextInput
                    id="txtPaymentDescription"
                    value={getValues("numberRange") === "" ? "" : getValues("nextChequeNumber")}
                    name={register("nextChequeNumber").name}
                    disabled
                  />
                  <Button
                    color={ButtonColor.Secondary}
                    onClick={() => {
                      setIsChequeBookModalOpen(true);
                    }}
                    size={ButtonSize.Small}
                    className="essui-button-icon-only--small"
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                </>
              }
            />
          </GridItem>
          <GridItem
            xl={3}
            lg={3}
            md={4}
            sm={4}
          >
            <div>
              <FormLabel forId="txtChequeNumber">Cheque Number</FormLabel>
              <div className="d-flex align-center gap-8 cheque__number">
                <Input
                  value="008455"
                  searchable
                  id="txtChequeNumber"
                />
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                >
                  Print Cheque
                </Button>
              </div>
            </div>
          </GridItem>
          <GridItem
            xl={3}
            lg={3}
            md={4}
            sm={4}
          >
            <div>
              <FormLabel forId="txtChequePayee">Cheque Payee</FormLabel>
              <Input
                value="Test"
                searchable
                id="txtChequePayee"
              />
            </div>
          </GridItem>
          <GridItem
            xl={12}
            lg={12}
            md={12}
            sm={4}
          >
            <div className="">
              <FormLabel
                forId="txtNarrative"
                className="essui-form-label"
              >
                Narrative
              </FormLabel>
              <TextInput
                className="width100"
                value="Test Narrative"
                id="txtNarrative"
              />
            </div>
          </GridItem>
        </Grid>
      </Layout>
      <Layout
        isBreadcrumbRequired={false}
        className=""
      >
        <Grid>
          <GridItem
            sm={6}
            md={{
              offset: 2,
              span: 6
            }}
            lg={{
              offset: 6,
              span: 6
            }}
            xl={{
              offset: 6,
              span: 6
            }}
          >
            <div className="d-flex gap-8 justify-end flex-wrap">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                disabled
              >
                View Original
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                disabled
              >
                View Adjustment
              </Button>
            </div>
          </GridItem>
        </Grid>
        <SelectChequeBookModal
          isOpen={isChequeBookModalOpen}
          setOpen={setIsChequeBookModalOpen}
          onSelectRowChequeBook={onChequeBookSelectedRow}
          selectedRow={onSelectRowCheque}
        />
        <PostingPeriodModal
          isOpen={showPostingPeriodModal}
          setOpen={setShowPostingPeriodModal}
          selectedRow={onPostingPeriodSelectedRow}
          onSelectRowDate={onSelectRowDate}
        />
      </Layout>
    </>
  );
};

export default AddReimbursement;
