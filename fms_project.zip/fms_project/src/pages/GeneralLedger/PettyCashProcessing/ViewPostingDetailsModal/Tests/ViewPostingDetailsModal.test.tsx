import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { getPCPostingPeriod } from "@/pages/BankReconciliation/state/PettyCashDetails.slice";
import { STATUS, specialCharacters } from "@/types/UseStateType";
import ViewPostingDetailsModal from "../ViewPostingDetailsModal";
import { getPettyCashPostingDetails } from "../../state/PettyCashPostingDetails.slice";

// Mock Redux hooks and actions
jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn()
}));
jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));
const mockedDispatch = jest.fn();
(useDispatch as jest.Mock).mockReturnValue(mockedDispatch);

describe("ViewPostingDetailsModal", () => {
  const setOpenMock = jest.fn();

  const mockPettyCashPostingDetails = {
    date_posted: "2024-10-24",
    period_posted: "5",
    narrative: "Sample Narrative",
    det_num: "GL123456"
  };

  const mockPostingPeriodDetails = [
    { code: "05", description: "May" },
    { code: "06", description: "June" }
  ];

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("renders modal title and close button", () => {
    (useAppSelector as jest.Mock)
      .mockReturnValueOnce({
        pettyCashPostingDetails: mockPettyCashPostingDetails,
        status: STATUS.IDLE
      })
      .mockReturnValueOnce({
        postingPeriodDetails: mockPostingPeriodDetails
      });

    render(
      <ViewPostingDetailsModal
        isOpen
        setOpen={setOpenMock}
        pcTransId="123"
      />
    );

    expect(screen.getByText("pettyCash.viewPostingDetailsModalTitle")).toBeInTheDocument();
    expect(screen.getByText("common.close")).toBeInTheDocument();
  });

  it("calls setOpen with false when close button is clicked", () => {
    (useAppSelector as jest.Mock).mockReturnValue({
      pettyCashPostingDetails: mockPettyCashPostingDetails,
      status: STATUS.IDLE,
      postingPeriodDetails: mockPostingPeriodDetails
    });

    render(
      <ViewPostingDetailsModal
        isOpen
        setOpen={setOpenMock}
        pcTransId="123"
      />
    );

    const closeButton = screen.getByText("common.close");
    fireEvent.click(closeButton);
    expect(setOpenMock).toHaveBeenCalledWith(false);
  });

  it("displays posting details when available", () => {
    (useAppSelector as jest.Mock).mockReturnValue({
      pettyCashPostingDetails: mockPettyCashPostingDetails,
      status: STATUS.IDLE,
      postingPeriodDetails: mockPostingPeriodDetails
    });

    render(
      <ViewPostingDetailsModal
        isOpen
        setOpen={setOpenMock}
        pcTransId="123"
      />
    );
    expect(screen.getByText("common.date")).toBeInTheDocument();
    expect(screen.getByText("pettyCash.period")).toBeInTheDocument();
    expect(screen.getByText("common.narrative")).toBeInTheDocument();
    expect(screen.getByText("Sample Narrative")).toBeInTheDocument();
    expect(screen.getByText("viewExpenditure.generalLedgerJournal")).toBeInTheDocument();
  });

  it("displays hyphen if posting details are not available", () => {
    (useAppSelector as jest.Mock).mockReturnValue({
      pettyCashPostingDetails: {},
      status: STATUS.IDLE,
      postingPeriodDetails: []
    });

    render(
      <ViewPostingDetailsModal
        isOpen
        setOpen={setOpenMock}
        pcTransId="123"
      />
    );

    expect(screen.getAllByText(specialCharacters.HYPHEN).length).toBeGreaterThan(0);
  });
});
