import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { AppDispatch, RootState } from "@/store/store"; // Adjust the import based on your project structure
import { apiRoot, client } from "@/config";
import { STATUS } from "@/types/UseStateType";
import { RowType, TColumnDef } from "@/components/GridTableNew/GridTableNew";
import vatSelectPeriodColumnDef from "../ManualJournalDetailsPage/VatSelectPeriodModal/Grid/VatSelectPeriodsColumnDef";

/* eslint-disable camelcase */
export type PeriodRowType = {
  period_no: number;
  description: string;
  startDate: string;
  start_date: string;
};

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

type PeriodsState = {
  isOpenModal: boolean;
  periods: PeriodRowType[];
  closingPeriods: PeriodRowType[];
  status: STATUS;
  error: string | null;
  columnDef: TColumnDef;
  filters?: TFilters;
  selectedRow?: PeriodRowType;
  reversalPeriodRow?: PeriodRowType;
  filteredReversalPeriods?: { [key: string]: any };
};

const initialState: PeriodsState = {
  isOpenModal: false,
  columnDef: vatSelectPeriodColumnDef,
  periods: [],
  filteredReversalPeriods: [],
  closingPeriods: [],
  status: STATUS.IDLE,
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: vatSelectPeriodColumnDef.filter((col) => !!col.sequence).at(0)?.field
  },
  error: null
};

export const fetchPeriods = createAsyncThunk<
  PeriodRowType[],
  { sequence?: any; yearId?: any; callback?: (result: PeriodRowType[] | string) => void } | void,
  { rejectValue: string }
>("periods/fetchPeriods", async (payload, thunkAPI) => {
  try {
    const url = payload?.yearId
      ? `${apiRoot}/Manual-Journal/open-periods`
      : `${apiRoot}/Manual-Journal/open-periods-sequence`;
    const response = await client.get(url, {
      params: { sequence: payload?.sequence || 0, yearId: payload?.yearId }
    }); // Adjust the API endpoint as necessary

    const data = response.data as PeriodRowType[];

    if (payload && payload.callback) {
      payload.callback(data);
    }
    return data;
  } catch (error) {
    return thunkAPI.rejectWithValue("Network error");
  }
});

/** Api call for fetching period of contra journal with yearId and period param */
export const fetchContraPeriods = createAsyncThunk<
  PeriodRowType[],
  { period?: any; yearId?: any; callback?: (result: PeriodRowType[] | string) => void } | void
>("manualJournalDetails/fetchContraPeriods", async (payload, thunkAPI) => {
  try {
    // Make your axios API call here
    const response = await client.get(`${apiRoot}/Manual-Journal/manual-journal-contra-period`, {
      params: {
        yearId: payload?.yearId,
        period: payload?.period
      }
    });

    const data = response.data as PeriodRowType[];

    if (payload && payload.callback) {
      payload.callback(data);
    }
    return data;
  } catch (error) {
    return thunkAPI.rejectWithValue("Network error");
  }
});

export const getManualJournalClosingPeriods = createAsyncThunk(
  "Manual-Journal/closing-periods",
  async (yearId: string) => {
    const response = await client.get(`${apiRoot}/Manual-Journal/closing-periods`, {
      params: { yearId }
    });

    return response.data;
  }
);

const periodsSlice = createSlice({
  name: "manualJournalPeriods",
  initialState,
  reducers: {
    setSelectedRow: (state, actions: PayloadAction<PeriodRowType | undefined>) => {
      state.selectedRow = actions.payload;
    },
    setReversalPeriodRow: (state, actions: PayloadAction<PeriodRowType | undefined>) => {
      state.reversalPeriodRow = actions.payload;
    },
    setReversalPeriods: (state, actions: PayloadAction<any>) => {
      state.filteredReversalPeriods = actions.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = initialState.filters;
    },
    setIsOpenModal: (state, action: PayloadAction<boolean>) => {
      state.isOpenModal = action.payload;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchPeriods.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = null;
      })
      .addCase(fetchPeriods.fulfilled, (state, action: PayloadAction<PeriodRowType[]>) => {
        state.status = STATUS.SUCCESS;
        state.periods = action.payload;
      })
      .addCase(fetchPeriods.rejected, (state, action: PayloadAction<string | undefined>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload || "Failed to fetch periods";
      });
    builder
      .addCase(fetchContraPeriods.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = null;
      })
      .addCase(fetchContraPeriods.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.periods = action.payload;
      })
      .addCase(fetchContraPeriods.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload || "Failed to fetch periods";
      });
    builder
      .addCase(getManualJournalClosingPeriods.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = null;
      })
      .addCase(getManualJournalClosingPeriods.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.closingPeriods = action.payload;
      })
      .addCase(getManualJournalClosingPeriods.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload || "Failed to fetch periods";
      });
  }
});

export const { actions: mjPeriodssActions, reducer } = periodsSlice;
export default reducer;
