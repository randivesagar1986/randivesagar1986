import { KeyValueType, RowType } from "@/components/GridTableNew/GridTableNew";
import { apiRoot, client } from "@/config";
import { RootState, useAppSelector } from "@/store/store";
import { getCurrentFinancialYear, KEYBOARD_STRING, STATUS } from "@/types/UseStateType";
import { createSlice, PayloadAction, createAsyncThunk, current } from "@reduxjs/toolkit";
import axios from "axios";
import { mjActions } from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalTypeList/state/ManualJournal.slice";
import { deepEqual } from "@/utils/constants";
import {
  getBankreconBankAccounts,
  actions as bankReconActions,
  getUnhiddenBankAccounts
} from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import {
  fetchSuppliersWithPagination,
  getSuppliersAll,
  supplierActions
} from "@/pages/PurchaseOrder/state/Suppliers.slice";
import { fetchPeriods, getManualJournalClosingPeriods, mjPeriodssActions } from "./ManualJournalPeriods.slice";
import { fetchManualJournalFinancialYear } from "./ManualJournalFinancialYears.slice";

// Define the initial state interface
export type JournalDetailsType = {
  journalHeader?: KeyValueType;
  journalLines: KeyValueType[];
  voucherJournal?: KeyValueType;
  [key: string]: any;
};

export type RollBackDetailType = {
  journalHeader?: KeyValueType;
  journalLines: KeyValueType[];
  voucherJournal?: KeyValueType;
  deletedJournalLines: KeyValueType[];
  [key: string]: any;
};
type initialStateType = {
  data: JournalDetailsType;
  rollbackData: RollBackDetailType;
  saveJournalStatus?: STATUS;
  copyJournalStatus?: STATUS;
  contraJournalStatus?: STATUS;
  status: STATUS;
  copyJournalId?: any;
  journalLedgerCodes?: any;
  contraYear?: any;
  rollbackStatus?: STATUS;
  error: string | null;
  selectedRow?: RowType;
  selectedRowVat?: RowType;
  isDeleteJournalFlag: boolean;
  isDeleteCashReimbursmentJournal: boolean;
  isPostJournalEnableFlag: boolean;
  balance?: string;
  updateBankStatus?: STATUS;
  deletedJournalLinesLength: number;
  deletedJournalCashReimbursment: any;
  isJournalLineDirty: boolean;
};

// Define the initial state
const initialState: initialStateType = {
  data: {
    journalHeader: undefined,
    journalLines: [],
    voucherJournal: undefined
  },
  rollbackData: {
    journalHeader: undefined,
    deletedJournalLines: [],
    journalLines: [],
    voucherJournal: undefined
  },
  error: null,
  copyJournalId: undefined,
  status: STATUS.IDLE,
  rollbackStatus: STATUS.IDLE,
  isDeleteJournalFlag: false,
  isDeleteCashReimbursmentJournal: false,
  isPostJournalEnableFlag: false,
  deletedJournalLinesLength: 0,
  deletedJournalCashReimbursment: undefined,
  isJournalLineDirty: false
};

// Define your async thunk function
export const fetchManualJournalDetails = createAsyncThunk(
  "manualJournalDetails/fetch",
  async (
    {
      voucherId,
      templateVoucherId,
      callback
    }: {
      voucherId: string;
      templateVoucherId: string | undefined;
      callback?: (data?: KeyValueType) => void;
    },
    thunkAPI
  ) => {
    const { dispatch, getState } = thunkAPI;
    const { manualJournalPeriods } = getState() as RootState;
    try {
      // Make your axios API call here
      const response = await axios.get(`${apiRoot}/Manual-Journal/journal-details`, {
        params: {
          voucherId,
          templateVoucherId: templateVoucherId !== "" ? templateVoucherId : undefined
        }
      });

      // Get Bank Accounts
      if (
        (response.data as any).voucherJournal.voucher_type === "CB" ||
        (response.data as any).voucherJournal.voucher_type === "VR"
      ) {
        await dispatch(getUnhiddenBankAccounts({ sequence: Number(KEYBOARD_STRING.Zero) }));
      }
      if ((response.data as any).voucherJournal.voucher_type === "CB") {
        await dispatch(
          fetchSuppliersWithPagination({
            lookingFor: "",
            pageNumber: 1,
            pageSize: 5,
            sequence: 0,
            highLightedRecordId: (response.data as any)?.journalHeader?.client_id ?? 0
          })
        );
      }

      if (!manualJournalPeriods?.closingPeriods?.length) {
        await dispatch(getManualJournalClosingPeriods(getCurrentFinancialYear()));
      }

      if (!manualJournalPeriods?.periods?.length) {
        const { payload: periods }: any = await dispatch(fetchPeriods());
        const selectedPeriod = periods.find(
          (p: any) => p?.period_no === (response?.data as any)?.journalHeader?.period
        );
        if (selectedPeriod?.period_no) {
          dispatch(mjPeriodssActions.setSelectedRow(selectedPeriod));
        }
      }

      if ((response?.data as { [key: string]: any })?.journalHeader?.reverse === "T") {
        const finYearResponse = await dispatch(fetchManualJournalFinancialYear());
        if ((finYearResponse?.payload as any)?.length) {
          const selectedFinancialYear = (finYearResponse?.payload as any).find(
            (f: any) => f?.year_des === String(Number((response?.data as any)?.year) + 1)
          );
          if (selectedFinancialYear?.year_id) {
            await dispatch(fetchPeriods({ yearId: selectedFinancialYear?.year_id }));
          }
        }
      }

      // manual journal period select
      if (manualJournalPeriods.periods?.length) {
        const selectedPeriod = manualJournalPeriods.periods.find(
          (p: any) => p?.period_no === (response?.data as any)?.journalHeader?.period
        );
        if (selectedPeriod?.period_no) {
          dispatch(mjPeriodssActions.setSelectedRow(selectedPeriod));
        }
      }

      // Select First Row of Journal Lines

      if (callback) callback(response?.data!);
      return response.data;
    } catch (error) {
      // Handle any errors that occur during the API call
      throw new Error("Failed to fetch manual journal details");
    }
  }
);

export const getJournalLedgerCodes = createAsyncThunk(
  "journalLedgerCodes/get",
  async ({
    journalType,
    sequence,
    costId,
    callback
  }: {
    journalType: number;
    sequence: number;
    costId?: number;
    callback?: (data: any) => void;
  }) => {
    const response = await client.get(`${apiRoot}/Manual-Journal/manual-journal-ledger`, {
      params: {
        journalType,
        sequence,
        costId
      }
    });

    if (callback) callback(response.data);

    return response.data;
  }
);

// Define copy journal async thunk function
export const copyAllTypeJournal = createAsyncThunk(
  "manualJournalDetails/copyAllTypeJournal",
  async (
    {
      voucherId,
      period,
      callback
    }: { voucherId: string; period?: number | undefined; callback?: (data?: KeyValueType) => void },
    thunkAPI
  ) => {
    const { dispatch } = thunkAPI;
    try {
      // Make your axios API call here
      const response = await axios.post(
        `${apiRoot}/Manual-Journal/manual-journal-JV-Copy?voucherId=${voucherId}${
          period !== undefined ? `&period=${period}` : ""
        }`
      );

      if (callback) callback(response);

      return response.data;
    } catch (error) {
      // Handle any errors that occur during the API call
      throw new Error("Failed to copy manual journal details");
    }
  }
);
// Define contra journal async thunk function
export const contraJournalDetail = createAsyncThunk(
  "manualJournalDetails/contraJournalDetail",
  async ({ data, callback }: { data: any; callback?: (data?: KeyValueType) => void }, thunkAPI) => {
    try {
      // Make your axios API call here
      const response = await axios.post(`${apiRoot}/Manual-Journal/manual-journal-contra-save`, data);

      if (callback) callback(response);

      return response.data;
    } catch (error) {
      // Handle any errors that occur during the API call
      throw new Error("Failed to copy manual journal details");
    }
  }
);

// Create an async thunk function to update the manual journal details
export const saveJournalDetails = createAsyncThunk(
  "manualJournalDetails/save",
  async (
    { data, callback, isDelete }: { data: KeyValueType; callback?: (data?: KeyValueType) => void; isDelete?: boolean },
    thunkAPI
  ) => {
    const { dispatch, getState } = thunkAPI;
    const state = getState() as RootState;
    const { manualJournalDetails, manualJournal } = state;
    const uppdatedJournalLines = manualJournalDetails.data?.journalLines.map((e) => ({
      temp_id: undefined,
      ledger_id: e.leddef_id,
      ...e
    }));

    const payloadData = {
      header: {
        ...manualJournalDetails.data?.journalHeader,
        bank_id: data?.bank_id ?? 0,
        period: data?.period_no ? data?.period_no : 0,
        narrative: data?.narrative,
        reverse_year_id: data?.reverse_year_id ? data?.reverse_year_id : 0,
        reverse_period_no: data?.reversal_period_no ? data?.reversal_period_no : -1,
        client_id: data?.client_id ? Number(data?.client_id) : null,
        bank_reference: data?.bank_reference ?? "",
        isRecurring: data?.isRecurring ?? false
      },

      journalLine: uppdatedJournalLines
    };

    if (
      manualJournalDetails.data?.journalHeader?.voucher_type === "CL" &&
      payloadData.header?.reverse_period_no === -1
    ) {
      payloadData.header.reverse_period_no = 1;
    }
    try {
      // Make your axios API call here to update the manual journal details
      const response = await axios.post(`${apiRoot}/Manual-Journal/manual-journal-line-save`, payloadData);
      if (isDelete !== undefined && isDelete !== true) {
        // Restricted for Delete operation
        dispatch(mjDetailsActions.resetRollbackDetails());
      }
      await dispatch(fetchPeriods());

      await dispatch(getManualJournalClosingPeriods(getCurrentFinancialYear()));

      if ((response?.data as { [key: string]: any })?.journalHeader?.reverse === "T") {
        await dispatch(fetchManualJournalFinancialYear());
      }

      if (response.data && callback) {
        callback(response.data);
      }
      dispatch(
        mjActions.setFilters({
          ...manualJournal?.filterState,
          viewcode: "AL",
          includeTemplates: manualJournalDetails.data?.journalHeader?.template === "T",
          highlightVoucherId: manualJournalDetails.data?.journalHeader?.voucher_id
        })
      );
      return response.data;
    } catch (error) {
      // Handle any errors that occur during the API call
      throw new Error("Failed to update manual journal details");
    }
  }
);

export const rollbackJournalDetails = createAsyncThunk(
  "manualJournalDetails/rollback",
  async ({ type, isSoftSaveEnable }: { type: number; isSoftSaveEnable?: boolean }, thunkAPI) => {
    const { dispatch, getState } = thunkAPI;
    const state = getState() as RootState;
    const { data, rollbackData } = state.manualJournalDetails;
    const header = deepEqual(data.journalHeader, rollbackData.journalHeader)
      ? data.journalHeader
      : rollbackData.journalHeader;
    if (rollbackData.journalHeader?.bank_id === null) {
      dispatch(bankReconActions.resetSelectedRow());
    }
    const addlines = (data.journalLines || []).filter(
      ({ voucher_line_id: id1 }) => !rollbackData.journalLines.some(({ voucher_line_id: id2 }) => id2 === id1)
    );

    let updatedlines = (rollbackData.journalLines || []).filter(
      (line1) => !data.journalLines.some((line2) => deepEqual(line1, line2))
    );
    updatedlines = updatedlines.map((line) => {
      const voucher = { ...line, isEdited: true, ledger_id: line.leddef_id };
      return voucher;
    });
    const deletedLines = rollbackData.deletedJournalLines
      ? rollbackData.journalLines.map((e) => {
          if ((rollbackData.deletedJournalLines || []).some((l) => l?.voucher_line_id === e?.voucher_line_id)) {
            delete e.isDeleted;
          }
          return { ...e, voucher_line_id: 0, ledger_id: e.leddef_id };
        })
      : rollbackData.journalLines.map((e) => ({ ...e, voucher_line_id: 0, ledger_id: e.leddef_id }));

    // Filter out the deleted lines from the journal lines
    let filteredJournalLines = rollbackData.journalLines.filter(
      (line) =>
        rollbackData.deletedJournalLines &&
        !rollbackData.deletedJournalLines.some((deletedLine) => deletedLine.voucher_line_id === line.voucher_line_id)
    );

    filteredJournalLines = filteredJournalLines.length === 0 ? data.journalLines : filteredJournalLines;
    const mergedArray = [
      ...new Map([...filteredJournalLines, ...addlines].map((item) => [item.voucher_line_id, item])).values()
    ];
    const journalLines = filteredJournalLines.length ? mergedArray : [...addlines];

    try {
      const rbLines = isSoftSaveEnable ? data.journalLines : journalLines;
      // Make your axios API call here to update the manual journal details
      const response = await axios.post(`${apiRoot}/Manual-Journal/manual-journal-cash-book-save?type=${type}`, {
        header: {
          ...header,
          reverse_year_id: header?.reverse_year_id === null ? 0 : header?.reverse_year_id,
          reverse_period_no: header?.reverse_period_no === null ? 0 : header?.reverse_period_no,
          bank_id: header?.bank_id === null ? 0 : header?.bank_id,
          bank_reference: header?.bank_reference === null ? "" : header?.bank_reference,
          ledger_id: header?.ledger_id === null ? null : header?.ledger_id,
          period: header?.period === null ? -1 : header?.period
        },
        journalLine: deletedLines.length ? deletedLines : [],
        rollBackJournalLine: rbLines
      });

      return response.data;
    } catch (error) {
      // Handle any errors that occur during the API call
      throw new Error("Failed to rollback manual journal details");
    }
  }
);

// update bank
export const updateBank = createAsyncThunk(
  "manualJournalDetails/updateBank",
  async (
    { voucherId, bankId, lineItemsPresent }: { voucherId: string; bankId: string; lineItemsPresent: boolean },
    thunkAPI
  ) => {
    const { dispatch } = thunkAPI;
    try {
      const response1 = await axios.post(`${apiRoot}/Manual-Journal/manual-journal-update-bank`, null, {
        params: {
          voucherId,
          bankId,
          lineItemsPresent
        }
      });

      const response2 = await axios.get(`${apiRoot}/Manual-Journal/journal-details`, {
        params: {
          voucherId,
          templateVoucherId: undefined
        }
      });
      // const [response1, response2] = await Promise.all([api1, api2]);

      dispatch(mjDetailsActions.updateJournalDetails(response2.data as any));
      dispatch(mjDetailsActions.setSelectedRow((response2.data as JournalDetailsType).journalLines.at(0)));

      return response1.data;
    } catch (error) {
      throw new Error("Failed to update bank");
    }
  }
);

// Add the async thunk function to the reducers
const slice = createSlice({
  name: "manualJournalDetails",
  initialState,
  reducers: {
    // Define your actions and their corresponding reducers here
    setSelectedRow: (state, action: PayloadAction<RowType | undefined>) => {
      state.selectedRow = action.payload;
    },
    setSelectedRowVat: (state, action: PayloadAction<RowType | undefined>) => {
      state.selectedRowVat = action.payload;
    },
    addJournalLine: (state, action: PayloadAction<any>) => {
      const newPayload = { ...action.payload, temp_id: state.data.journalLines.length + 1 };
      state.data.journalLines.push(newPayload);
      state.selectedRow = newPayload;
    },
    updateNextJournalLine: (state, action: PayloadAction<any>) => {
      const newPayload = { ...action.payload, temp_id: state.data.journalLines.length + 1 };
      state.data.journalLines.push(newPayload);
    },
    deleteSelectedJournalLine: (state, action: PayloadAction<any>) => {
      const newPayload = { ...action.payload, temp_id: state.data.journalLines.length - 1 };
      // eslint-disable-next-line
      const indexToRemove = state.data.journalLines.findIndex(
        (obj) => JSON.stringify(obj) === JSON.stringify(action.payload)
      );

      if (indexToRemove !== -1) {
        state.data.journalLines.splice(indexToRemove, 1);
      }
      state.selectedRow = newPayload;
    },
    setJournalLines: (state, action: PayloadAction<any>) => {
      state.data.journalLines = action.payload;
      state.selectedRow = action.payload;
    },
    setDeletedJournalLines: (state, action: PayloadAction<any>) => {
      state.deletedJournalLinesLength = action.payload;
    },
    setDeleteJournalFlag: (state, action: PayloadAction<any>) => {
      state.isDeleteJournalFlag = action.payload;
    },
    setDeleteCashReimbursmentJournal: (state, action: PayloadAction<any>) => {
      state.isDeleteCashReimbursmentJournal = action.payload;
    },

    setDeletedJournalCashReimbursment: (state, action: PayloadAction<KeyValueType>) => {
      if (action.payload !== undefined) {
        const data = { ...state.rollbackData };
        data.deletedJournalLines = Array.isArray(data.deletedJournalLines) ? data.deletedJournalLines : [];
        let row = action.payload;
        row = { ...row };
        data.deletedJournalLines = [...data.deletedJournalLines, row];
        state.rollbackData = data;
      }
    },
    setPostJournalEnableFlag: (state, action: PayloadAction<any>) => {
      state.isPostJournalEnableFlag = action.payload;
    },
    resetDetails: (state) => {
      state.data = {
        journalHeader: undefined,
        journalLines: [],
        voucherJournal: undefined
      };
      state.rollbackData = initialState.rollbackData;
      state.status = STATUS.IDLE;
    },
    resetJournalDetails: (state) => {
      state.data = {
        journalHeader: undefined,
        journalLines: [],
        voucherJournal: undefined
      };
      state.status = STATUS.IDLE;
    },
    resetStatus: (state) => {
      state.status = STATUS.IDLE;
    },
    resetRollbackDetails: (state) => {
      state.rollbackData = initialState.rollbackData;
    },
    addJournalDetails: (state, action: PayloadAction<JournalDetailsType>) => {
      state.data = {
        ...state.data,
        ...action.payload
      };
      state.status = STATUS.SUCCESS;
    },
    updateJournalDetails: (state, action: PayloadAction<JournalDetailsType>) => {
      state.data = {
        ...state.data,
        journalLines: action.payload.journalLines
      };
      state.status = STATUS.SUCCESS;
    },
    setBalance: (state, action: PayloadAction<any>) => {
      state.balance = action.payload;
    },
    resetCopyJournalId: (state) => {
      state.copyJournalId = undefined;
    },
    resetManualJounralDetailStatus: (state) => {
      state.status = STATUS.IDLE;
    },
    setContraYear: (state, action: PayloadAction<any>) => {
      state.contraYear = action.payload;
    },
    setIsJournalLineDirty: (state, action: PayloadAction<any>) => {
      state.isJournalLineDirty = action.payload;
    }
  },
  extraReducers: (builder) => {
    builder.addCase(fetchManualJournalDetails.fulfilled, (state, action) => {
      // Handle the successful API response and update the state accordingly
      state.data = action.payload as any;
      const { journalHeader } = current(state.rollbackData);
      if (journalHeader === undefined) {
        state.rollbackData = action.payload as any;
      }

      state.deletedJournalLinesLength = state.data.journalLines.length;
      state.status = STATUS.SUCCESS;
      state.error = null;
    });
    builder.addCase(fetchManualJournalDetails.pending, (state) => {
      // Handle the pending state while the API call is in progress
      state.status = STATUS.LOADING;
      state.error = null;
    });
    builder.addCase(fetchManualJournalDetails.rejected, (state, action) => {
      // Handle any errors that occur during the API call
      state.status = STATUS.FAILED;
      state.error = action.error.message || null;
    });

    // Rollback Journal Details
    builder
      .addCase(rollbackJournalDetails.pending, (state) => {
        state.rollbackStatus = STATUS.LOADING;
      })
      .addCase(rollbackJournalDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.rollbackStatus = STATUS.SUCCESS;
      })
      .addCase(rollbackJournalDetails.rejected, (state, action: PayloadAction<any>) => {
        state.rollbackStatus = STATUS.FAILED;
        state.error = action.payload.error.message;
      });

    builder
      .addCase(getJournalLedgerCodes.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getJournalLedgerCodes.fulfilled, (state, action: PayloadAction<any>) => {
        state.journalLedgerCodes = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getJournalLedgerCodes.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });

    // save Journal Details with lines
    builder
      .addCase(saveJournalDetails.pending, (state) => {
        state.saveJournalStatus = STATUS.LOADING;
      })
      .addCase(saveJournalDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.saveJournalStatus = STATUS.SUCCESS;
      })
      .addCase(saveJournalDetails.rejected, (state, action: PayloadAction<any>) => {
        state.saveJournalStatus = STATUS.FAILED;
        state.error = action.payload?.error?.message;
      });
    // copy Journal Details with voucherId
    builder
      .addCase(copyAllTypeJournal.pending, (state) => {
        state.copyJournalStatus = STATUS.LOADING;
      })
      .addCase(copyAllTypeJournal.fulfilled, (state, action: PayloadAction<any>) => {
        state.copyJournalId = action.payload;
        state.copyJournalStatus = STATUS.SUCCESS;
      })
      .addCase(copyAllTypeJournal.rejected, (state, action: any) => {
        state.copyJournalStatus = STATUS.FAILED;
        state.error = action.error.message;
      });
    // contra Journal Details with voucherId
    builder
      .addCase(contraJournalDetail.pending, (state) => {
        state.contraJournalStatus = STATUS.LOADING;
      })
      .addCase(contraJournalDetail.fulfilled, (state, action: PayloadAction<any>) => {
        state.contraJournalStatus = STATUS.SUCCESS;
      })
      .addCase(contraJournalDetail.rejected, (state, action: any) => {
        state.contraJournalStatus = STATUS.FAILED;
        state.error = action.error.message;
      });
    // update Bank
    builder
      .addCase(updateBank.pending, (state) => {
        state.updateBankStatus = STATUS.LOADING;
      })
      .addCase(updateBank.fulfilled, (state, action: PayloadAction<any>) => {
        state.updateBankStatus = STATUS.SUCCESS;
      })
      .addCase(updateBank.rejected, (state, action: PayloadAction<any>) => {
        state.updateBankStatus = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  }
});

// Export the actions and reducer
export const { actions: mjDetailsActions, reducer } = slice;
export default reducer;
