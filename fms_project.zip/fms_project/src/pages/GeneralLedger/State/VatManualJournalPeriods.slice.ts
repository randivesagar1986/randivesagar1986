import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import { apiRoot, client } from "@/config";
import { STATUS } from "@/types/UseStateType";
import vatSelectPeriodColumnDef from "../ManualJournalDetailsPage/VatSelectPeriodModal/Grid/VatSelectPeriodsColumnDef";

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

type VatPeriodsState = {
  vatPeriods: { [key: string]: any }[];
  columnDef: TColumnDef;
  filters?: TFilters;
  status: STATUS;
  error: string | null;
  selectedRowVat?: { [key: string]: any };
};

const initialState: VatPeriodsState = {
  columnDef: vatSelectPeriodColumnDef,
  vatPeriods: [],
  status: STATUS.IDLE,
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: undefined
  },
  error: null
};

export const getVatPeriods = createAsyncThunk("Manual-Journal/open-periods-sequence", async (sequence?: any) => {
  const response = await client.get(`${apiRoot}/Manual-Journal/open-periods-sequence?sequence=${sequence || 0}`);
  return response.data;
});

const periodsSlice = createSlice({
  name: "vatManualJournalPeriods",
  initialState,
  reducers: {
    setSelectedRowVat: (state, actions: PayloadAction<any>) => {
      state.selectedRowVat = actions.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(getVatPeriods.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = null;
      })
      .addCase(getVatPeriods.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.vatPeriods = action.payload;
      })
      .addCase(getVatPeriods.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload?.error.message;
      });
  }
});

export const { actions: vatPeriodAction, reducer } = periodsSlice;
export default reducer;
