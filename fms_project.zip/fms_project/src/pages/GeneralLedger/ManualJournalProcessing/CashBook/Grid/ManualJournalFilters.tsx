import { saveJournalDetails } from "@/pages/GeneralLedger/State/ManualJournalDetails.slice";
import { canDo } from "@/store/state/userAccessRights.slice";
import { AppDispatch, useAppSelector } from "@/store/store";
import { AddLarge } from "@carbon/icons-react";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Grid, GridItem, Button, ButtonSize, ButtonColor } from "@essnextgen/ui-kit";
import { FC } from "react";
import { useFormContext } from "react-hook-form";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";

type cashBookFilterProps = {
  onSubmit?: (isRedirect?: boolean) => Promise<boolean>;
  isDirty?: boolean;
  voucherType?: string;
};

const ManualJournalFilters: FC<cashBookFilterProps> = ({ onSubmit, isDirty, voucherType }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { data } = useAppSelector((state) => state.manualJournalDetails);
  const {
    suppliers: { selectedSupplier }
  } = useAppSelector((state) => state);
  const { selectedBankAccount, selectedRow } = useAppSelector((state) => state.bankreconBankAccounts);
  const dispatch = useDispatch<AppDispatch>();
  const { getValues } = useFormContext();
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const mCanDefineTempl = canDo(userAccessRights, { action: "Define templates", module: "Manual Journals" });
  const mCanAddNormal = canDo(userAccessRights, { module: "Manual Journals", action: "Add normal" });
  const mCanAddOpeningBal = canDo(userAccessRights, { module: "Manual Journals", action: "Add opening balance" });
  const mCanAddCashbook = mCanAddNormal;
  const mCanAddVATReimbursement = mCanAddNormal;
  const mCanAddVATTransfer = mCanAddNormal;
  const mCanAddClosingBal = mCanAddNormal;
  const isAddBtnEnable =
    mCanAddNormal ||
    mCanAddOpeningBal ||
    mCanAddCashbook ||
    mCanDefineTempl ||
    mCanAddVATReimbursement ||
    mCanAddVATTransfer;

  return (
    <Grid justify="space-between">
      <GridItem>
        <h2 className="essui-global-typography-default-subtitle">{t("manualJournalPage.journalLines")}</h2>
      </GridItem>
      <GridItem>
        <Button
          className="br-0"
          id="manual-journal-addNewLine"
          size={ButtonSize.Small}
          color={ButtonColor.Utility}
          title={t("purchaseOrder.addNewLine")}
          aria-label={t("purchaseOrder.addNewLineAriaText")}
          onClick={async () => {
            if (onSubmit) {
              const payload = getValues();
              await dispatch(saveJournalDetails({ data: payload }));
              const payloadVR = {
                journalHeader: {
                  ...data.journalHeader,
                  period: payload.period_no,
                  narrative: payload.narrative,
                  bank_reference: payload.bank_referenceref
                }
              };

              if (voucherType === "CB") {
                history.push({
                  pathname: `${history.location.pathname}/cash-book-journal-line/add`,
                  state: {
                    ...historyState,
                    voucherType: data?.journalHeader?.voucher_type,
                    selectedSupplier,
                    selectedBankAccount: selectedRow,
                    isDirty: historyState?.isDirty || isDirty
                  }
                });
              } else {
                history.push({
                  pathname: `${history.location.pathname}/vat-reimbursement-journal-line/add`,
                  state: {
                    ...historyState,
                    voucherType: data?.journalHeader?.voucher_type,
                    isShowNarrative: true,
                    mjDetail: payloadVR,
                    isDirty: historyState?.isDirty || isDirty
                  }
                });
              }
            }
          }}
          disabled={data?.journalHeader?.temp_no !== null || selectedRow === undefined || !isAddBtnEnable}
        >
          <AddLarge size="18" />
        </Button>
      </GridItem>
    </Grid>
  );
};

ManualJournalFilters.defaultProps = {
  onSubmit: undefined,
  isDirty: undefined,
  voucherType: undefined
};

export default ManualJournalFilters;
