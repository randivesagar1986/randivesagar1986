import GridRowActions, { OptionsType } from "@/components/GridRowActions/GridRowActions";
import { AppDispatch, useAppSelector } from "@/store/store";
import { Icon, IconSize, ISelectedItem } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { ReactNode, SyntheticEvent, useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { mjDetailsActions } from "@/pages/GeneralLedger/State/ManualJournalDetails.slice";
import { JOURNALTYPE, METHOD } from "@/types/UseStateType";
import { useFormContext } from "react-hook-form";
import { cellRendererType } from "@/components/GridTableNew/GridTableNew";
import { canDo } from "@/store/state/userAccessRights.slice";

type clickHandlerType = (e: SyntheticEvent, selectedItem: ISelectedItem) => void;

type OptionProps = {
  iconName?: string;
  optionName: string;
  children?: ReactNode;
};

const CustomCell = ({ field, row, onSubmit }: cellRendererType) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { data, deletedJournalLinesLength } = useAppSelector((state) => state.manualJournalDetails);
  const { selectedBankAccount, selectedRow: bankAccountSelectRow } = useAppSelector(
    (state) => state.bankreconBankAccounts
  );
  const { journalLedgerCodes } = useAppSelector((state) => state.journalLedgerCode);
  const selectedRow = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.selectedRow);
  const { selectedSupplier } = useAppSelector((state) => state.suppliers);
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { getValues } = useFormContext();
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const mCanDefineTempl = canDo(userAccessRights, { action: "Define templates", module: "Manual Journals" });
  const mCanAddNormal = canDo(userAccessRights, { module: "Manual Journals", action: "Add normal" });
  const mCanAddOpeningBal = canDo(userAccessRights, { module: "Manual Journals", action: "Add opening balance" });
  const mCanAddCashbook = mCanAddNormal;
  const mCanAddVATReimbursement = mCanAddNormal;
  const mCanAddVATTransfer = mCanAddNormal;
  const mCanAddClosingBal = mCanAddNormal;
  const isAddBtnEnable =
    mCanAddNormal ||
    mCanAddOpeningBal ||
    mCanAddCashbook ||
    mCanDefineTempl ||
    mCanAddVATReimbursement ||
    mCanAddVATTransfer;

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const onDeleteJournalLines = (val: any) => {
    if (val) {
      const journalLinePayload = data.journalLines.map((record) => {
        if (record.voucher_line_id === val && deletedJournalLinesLength !== 2) {
          dispatch(mjDetailsActions.setDeletedJournalLines(deletedJournalLinesLength - 1));
          return {
            ...record,
            isDeleted: true
          };
        }
        if (deletedJournalLinesLength === 2) {
          dispatch(mjDetailsActions.setDeletedJournalLines(0));

          return {
            ...record,
            isDeleted: true
          };
        }
        return record;
      });

      const deleteJounalToAdd = journalLinePayload.filter((record) => record.isDeleted && record.ledger_type !== "BK");
      const deletedJournalLines = journalLinePayload.filter((record) => !record.isDeleted);
      dispatch(mjDetailsActions.setJournalLines([...deletedJournalLines, ...deleteJounalToAdd]));
      dispatch(mjDetailsActions.setDeletedJournalCashReimbursment(deleteJounalToAdd[0]));
      dispatch(mjDetailsActions.setDeleteJournalFlag(true));
      dispatch(mjDetailsActions.setDeleteCashReimbursmentJournal(true));
      const updatedSelectedRow = journalLinePayload.filter((record) => !record.isDeleted);
      dispatch(mjDetailsActions.setSelectedRow(updatedSelectedRow[updatedSelectedRow.length - 1]));
    } else if (val === 0) {
      const journalLinePayload = data.journalLines.filter((record) => record.temp_id !== selectedRow?.temp_id);
      dispatch(mjDetailsActions.setJournalLines(journalLinePayload));
      dispatch(mjDetailsActions.setSelectedRow(journalLinePayload[journalLinePayload.length - 1]));
      dispatch(mjDetailsActions.setDeleteJournalFlag(true));
    } else {
      dispatch(mjDetailsActions.setDeleteJournalFlag(false));
    }
  };
  const options = [
    {
      text: "editLine",
      value: "editLine",
      disabled:
        data?.journalHeader?.temp_no !== null ||
        bankAccountSelectRow === undefined ||
        row?.ledger_type === "BK" ||
        (!isAddBtnEnable && data?.voucherJournal?.posted === "F"),
      children: <RowAction optionName={t("manualJournalPage.editLine")} />
    },
    {
      text: "deleteLine",
      value: "deleteLine",
      disabled:
        data?.journalHeader?.temp_no !== null ||
        bankAccountSelectRow === undefined ||
        row?.ledger_type === "BK" ||
        (data?.journalHeader?.voucher_type === "CB" && (row?.ledger_type === "VO" || row?.ledger_type === "VI")) ||
        (!isAddBtnEnable && data?.voucherJournal?.posted === "F"),
      children: <RowAction optionName={t("manualJournalPage.deleteLine")} />
    }
  ];

  const orderLineActionHandler: clickHandlerType = async (e, selectedItem) => {
    const payload = getValues();
    const payloadVR = {
      journalHeader: {
        ...data.journalHeader,
        period: payload?.period_no,
        narrative: payload?.narrative,
        bank_reference: payload?.bank_referenceref
      }
    };
    switch (selectedItem.value) {
      case "editLine":
        // TODO: Implement edit line
        if (data?.journalHeader?.voucher_type === JOURNALTYPE.VAT_REIMBURSMENT) {
          if (onSubmit) {
            const isError = await onSubmit(false, undefined, true);
            if (!isError) {
              history.push({
                pathname: `/general-ledger/manual-journal-list/edit/${row?.voucher_id}/vat-reimbursement-journal-line/edit/${row?.voucher_line_id}`,
                state: {
                  ...historyState,
                  voucherType: data?.journalHeader?.voucher_type,
                  selectedBankAccount: row,
                  isShowNarrative: true,
                  mjDetail: payloadVR,
                  selectedRow,
                  mode: METHOD.EDIT
                }
              });
            }
          }
        } else if (row?.ledger_type === "VO" || row?.ledger_type === "VI") {
          if (onSubmit) {
            const isError = await onSubmit(false, undefined, true);
            if (!isError) {
              history.push({
                pathname: `/general-ledger/manual-journal-list/edit/${row?.voucher_id}/cash-book-vat-journal-line/edit/${row?.voucher_line_id}`,
                state: {
                  ...historyState,
                  voucherType: data?.journalHeader?.voucher_type,
                  selectedBankAccount: row,
                  mjDetail: undefined,
                  selectedRow,
                  mode: METHOD.EDIT
                }
              });
            }
          }
        } else if (onSubmit) {
          const isError = await onSubmit(false, undefined, true);
          if (!isError) {
            history.push({
              pathname: `/general-ledger/manual-journal-list/edit/${row?.voucher_id}/cash-book-journal-line/edit/${row?.voucher_line_id}`,
              state: {
                ...historyState,
                voucherType: data?.journalHeader?.voucher_type,
                selectedBankAccount: row,
                selectedSupplier,
                mjDetail: payloadVR,
                mode: METHOD.EDIT
              }
            });
          }
        }
        break;
      case "deleteLine":
        onDeleteJournalLines(row?.voucher_line_id);
        break;
      default:
        break;
    }
  };

  const getContent = () => {
    switch (field) {
      case "debit":
        return <div>{numberFormatter.format(row?.debit)}</div>;
      case "credit":
        return <div>{numberFormatter.format(row?.credit)}</div>;
      case "actions":
        return (
          <>
            <GridRowActions
              name={
                <Icon
                  size={IconSize.Medium}
                  name="overflow-menu--horizontal"
                />
              }
              options={options}
              onClick={orderLineActionHandler}
              selectedRow={row}
            />
          </>
        );
      default: {
        return <div />;
      }
    }
    // TODO: Implement Edit Vat Modal
  };
  return getContent();
};

export default CustomCell;

const RowAction = ({ iconName, optionName, children }: OptionProps) => (
  <div className="option">
    {iconName ? (
      <Icon
        size={IconSize.Medium}
        name={iconName}
      />
    ) : (
      children
    )}
    {optionName}
  </div>
);

RowAction.defaultProps = {
  iconName: undefined,
  children: undefined
};
