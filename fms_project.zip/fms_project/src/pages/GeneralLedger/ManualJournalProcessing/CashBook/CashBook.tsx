import { useEffect, useMemo, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { Controller, FormProvider, useForm } from "react-hook-form";
import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  Notification,
  NotificationStatus,
  Tag,
  TagColor,
  TagSize,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import GridTableNew, { KeyValueType } from "@/components/GridTableNew/GridTableNew";
import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import ManualJournalPageToolbar, {
  BalanceType,
  JournalEditorMode
} from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalPageToolbar";
import ManualJournalToolbar from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalToolbar";
import {
  getManualJournal,
  actions as mjActions,
  postJournalData
} from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalTypeList/state/ManualJournal.slice";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import {
  JOURNALTYPE,
  KEYBOARD_STRING,
  LEDGER_BALANCE,
  NUMBER_LENGTH,
  specialCharacters,
  STATUS
} from "@/types/UseStateType";
import { getDataFormat, usNumberFormat } from "@/utils/getDataSource";
import { useHistory, useParams } from "react-router-dom";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { supplierActions } from "@/pages/PurchaseOrder/state/Suppliers.slice";
import { localRoutes } from "@/utils/constants";
import { actions as bankReconActions } from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import MannualJournalProcessingColumnDefs from "@/pages/BankReconciliation/MannualJournalProcessing/Grid/columnDef";
import { voucherTypeMapping } from "@/pages/GeneralLedgerSetup/utils";
import { canDo, fetchUserAccessRights, Screen } from "@/store/state/userAccessRights.slice";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import { useClickAway } from "@/hooks/useClickAway";
import CustomCell from "./Grid/CustomCell";
import columnDef from "./Grid/columnDef";
import SupplierInput from "./Fields/SupplierInput";
import BankLedgerInput from "./Fields/BankLedgerInput";
import PeriodInput from "./Fields/PeriodInput";
import ManualJournalFilters from "./Grid/ManualJournalFilters";
import {
  saveJournalDetails,
  fetchManualJournalDetails,
  copyAllTypeJournal,
  mjDetailsActions,
  rollbackJournalDetails
} from "../../State/ManualJournalDetails.slice";
import AddRecurrencePattern from "./RecurrencePattern/RecurrencePatternDetails";
import {
  getFirstJournalCheck,
  getFirstPostedCheck,
  getJPayments,
  deleteRecurrencePattern,
  actions as recPatternActions
} from "./RecurrencePattern/state/RecurrencePattern.slice";
import {
  periodBreakPoints,
  yearBreakPoints,
  voucherBreakPoints,
  narrativeBreakPoints,
  supplierBreakPoints,
  bankLedgerBreakPoints,
  bankAccountBreakPoints,
  referenceBreakPoints,
  balanceBreakPoints,
  footerNarrativeBreakPoints
} from "./CashBook.utils";
import { mjPeriodssActions } from "../../State/ManualJournalPeriods.slice";
import {
  actions as cbJLDActions,
  postCashBookDetails
} from "./CashBookJournalLineDetails/State/CashBookJournalLineDetails.slice";

const validationSchema = yup.object().shape({
  bank_reference: yup.string().required(),
  narrative: yup.string().required(),
  client_id: yup.string(),
  period_no: yup.number().nullable(),
  period_description: yup.string(),
  bank_account: yup.string(),
  bank_sort_code: yup.string(),
  bank_id: yup.number().nullable(),
  statement_no: yup.string(),
  voucher_Date: yup.string(),
  year: yup.string(),
  posting_date: yup.string().nullable(),
  journal_number: yup.string(),
  client_name: yup.string().required(),
  ledger_code: yup.string().required(),
  ledger_des: yup.string().nullable(),
  orig_no: yup.string().nullable()
});

const loaderConfig: loadingConfig = {};
const CashBook = ({ voucherType }: { voucherType: string }) => {
  const dispatch = useDispatch<AppDispatch>();
  const { t } = useTranslation();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { voucherId } = useParams<{ voucherId: string }>();
  const [isUndoModalOpen, setIsUndoModalOpen] = useState<boolean>(false);
  const data = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.data);
  const copyJStatus = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.copyJournalStatus);
  const selectedRow = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.selectedRow);
  const status = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.status);
  const isSaveAPIRequired = useAppSelector(
    ({ cashbookJournalLinesDetails }) => cashbookJournalLinesDetails.isSaveAPIRequired
  );
  const { bankStatus } = useAppSelector((state) => state.bankreconBankAccounts);
  const saveJournalStatus = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.saveJournalStatus);
  const pStatus = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.status);
  const { isOpenModal: isOpen } = useAppSelector((state) => state.manualJournalPeriods);
  const postStatus = useAppSelector(({ manualJournal }) => manualJournal.postStatus);
  const printStatus = useAppSelector(({ manualJournal }) => manualJournal.printStatus);
  const financialYearDetails = useAppSelector(({ manualJournal }) => manualJournal.financialYearDetails);
  const isPostJournalValidation = useAppSelector(({ manualJournal }) => manualJournal.isPostJournalValidation);
  const { selectedView: templateView } = useAppSelector((state) => state.manualJournalType);
  const { filterState, selectedRow: mjSelectedRow } = useAppSelector((state) => state.manualJournal);
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const canPost = canDo(userAccessRights, {
    action: ACCESS_RIGHTS_ACTION.Post,
    module: ACCESS_RIGHTS_MODULE.ManualJournals
  });
  const canDelete = canDo(userAccessRights, {
    action: ACCESS_RIGHTS_ACTION.Delete,
    module: ACCESS_RIGHTS_MODULE.ManualJournals
  });
  const mappedVoucherType = voucherTypeMapping[data?.journalHeader?.voucher_type];
  const isDeleteJournalFlag = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.isDeleteJournalFlag);
  const { suppliersList, selectedSupplier, status: supplierStatus } = useAppSelector((state) => state.suppliers);
  const [isSuppliersModal, setIsSuppliersModal] = useState<boolean>(false);
  const [isRecurrencePatternOpen, setIsRecurrencePatternOpen] = useState<boolean>(false);
  const [isAddingPattern, setIsAddingPattern] = useState<boolean>(false);
  const [isEditPattern, setIsEditPattern] = useState<boolean>(false);
  const [isDeletePattern, setIsDeletePattern] = useState<boolean>(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [openRecurringEditModal, setOpenRecurringEditModal] = useState<boolean>(false);
  const teritaryBtnRef = useRef<HTMLButtonElement | null>(null);
  const firstPostedCheckStatus = useAppSelector(({ recurrencePattern }) => recurrencePattern.firstPostedCheckStatus);
  const firstJournalCheckStatus = useAppSelector(({ recurrencePattern }) => recurrencePattern.firstJournalCheckStatus);
  const { isRecurrencePatterDirty } = useAppSelector((state) => state.recurrencePattern);
  const difference = Math.abs(
    (data?.journalLines ?? []).reduce((acc: any, curr: any) => {
      if (curr?.isDeleted) {
        return acc;
      }
      return acc + Number(curr?.debit) - Number(curr?.credit);
    }, 0)
  );
  const formattedDifference = usNumberFormat(difference);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const credit = (data?.journalLines ?? []).reduce((acc: any, curr: any) => {
    if (curr?.isDeleted) {
      return acc;
    }
    return acc + Number(curr?.credit);
  }, 0);
  const debit = (data?.journalLines ?? []).reduce((acc: any, curr: any) => {
    if (curr?.isDeleted) {
      return acc;
    }
    return acc + Number(curr?.debit);
  }, 0);
  const periodRow = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.selectedRow);

  const getBalance = () => {
    let balance;

    if (formattedDifference !== "0.00") {
      balance = formattedDifference;
      dispatch(mjDetailsActions.setPostJournalEnableFlag(false));
    } else if (credit !== 0 && debit !== 0 && credit === debit && data?.journalLines?.length) {
      balance = t("manualJournalPage.balanced");
      dispatch(mjDetailsActions.setPostJournalEnableFlag(true));
    } else if (data?.journalLines?.length === 0) {
      balance = specialCharacters.HYPHEN;
      dispatch(mjDetailsActions.setPostJournalEnableFlag(false));
    } else {
      balance = t("manualJournalPage.noValues");
      dispatch(mjDetailsActions.setPostJournalEnableFlag(false));
    }

    return balance;
  };

  const getTagElement = () =>
    data?.journalHeader?.narrative ? (
      <div className="heading-tag journal-header">
        <Tag
          text={data?.journalHeader?.narrative}
          size={TagSize.Large}
          color={TagColor.Highlight}
        />
      </div>
    ) : undefined;

  const formMethods = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      narrative: "",
      period_description: "",
      bank_reference: "",
      bank_account: "",
      bank_sort_code: "",
      bank_id: 0,
      statement_no: "",
      client_id: "",
      client_name: "",
      orig_no: "",
      ledger_des: ""
    },
    values: {
      narrative: data?.journalHeader?.narrative,
      voucher_Date: data.journalHeader?.voucher_date,
      year: data?.year,
      posting_date: data?.journalHeader?.posting_date,
      period_no: data?.journalHeader?.period,
      bank_id: data?.journalHeader?.bank_id ?? 0,
      journal_number: data?.journalHeader?.journal_number,
      bank_reference: data?.journalHeader?.bank_reference,
      client_id: data?.journalHeader?.client_id,
      client_name: "",
      ledger_code: "",
      ledger_des: "",
      orig_no: data?.orig_no,
      bank_sort_code: ""
    }
  });

  const {
    control,
    register,
    handleSubmit,
    setValue,
    formState: { errors, isDirty },
    reset,
    getValues,
    setError,
    clearErrors,
    watch
  } = formMethods;

  const errorHandler = (error: KeyValueType) => {
    const errors = Object.entries(error)
      .map(([key, value]) => ({ key, value }))
      .shift();
    let message;
    switch (errors?.key!) {
      case "bank_reference":
        message = t("manualJournal.cashbookRecurrencePattern.addReference");
        break;
      case "narrative":
        message = t("manualJournal.cashbookRecurrencePattern.addNarrative");
        break;
      case "client_name":
        if (watch("narrative").trim().length >= NUMBER_LENGTH.FIFTY) {
          message = t("manualJournal.cashbookRecurrencePattern.narrativeLength");
        } else {
          message = t("manualJournal.cashbookRecurrencePattern.addSupplier");
        }
        break;
      case "client_id":
        message = t("manualJournal.cashbookRecurrencePattern.addSupplier");
        break;
      default: {
        message = errors?.value?.message;
        break;
      }
    }
    if (errors && errors.key !== "ledger_code") {
      jPaymentsValidation(message, NotificationStatus.HIGHLIGHT);
    } else if (errors && errors.key === "ledger_code" && (historyState?.isDirty || isDirty)) {
      const message = t("manualJournal.cashbookRecurrencePattern.saveChangesCashBook", {
        commonPattern: "adding"
      });
      jPaymentsValidation(message, NotificationStatus.HIGHLIGHT);
    }
  };
  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;

  const onUndoClick = () => {
    if (isDirty || historyState?.isDirty || isDeleteJournalFlag || isRecurrencePatterDirty) {
      setIsUndoModalOpen(true);
    } else {
      setIsUndoModalOpen(false);
    }
  };
  const handleKeyDown = (e: any) => {
    if (e.key === "Escape" && (isDirty || historyState?.isDirty || isDeleteJournalFlag || isRecurrencePatterDirty)) {
      e.preventDefault();
      setIsUndoModalOpen(true);
    }
  };

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleKeyDown]);

  // Focus of the tertiary button(Cancel) when the EDIT modal is opened

  useEffect(() => {
    const timer: any = null;
    if (openRecurringEditModal) {
      setTimeout(() => {
        teritaryBtnRef?.current?.focus();
      }, 10);
    }
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [openRecurringEditModal]);

  const onUndoChange = async () => {
    dispatch(mjDetailsActions.setDeleteJournalFlag(false));
    dispatch(recPatternActions.setIsRecurrencePatterDirty(false));
    await dispatch(
      rollbackJournalDetails({ type: mappedVoucherType, isSoftSaveEnable: historyState?.isSoftSaveEnable })
    );
    await dispatch(
      fetchManualJournalDetails({
        voucherId,
        templateVoucherId: templateView?.value,
        callback(data) {
          if (data) {
            dispatch(mjDetailsActions.setSelectedRow(data.journalLines[0]));
            dispatch(mjDetailsActions.resetRollbackDetails());
            dispatch(supplierActions.resetSelectedRow());
          }
        }
      })
    );
    history.replace({
      ...history.location,
      state: {
        ...historyState,
        isDirty: false
      }
    });
  };

  const getInitialErrorStatus: (isDelete?: boolean, isOpenEditPage?: boolean) => Promise<boolean> = async (
    isDelete,
    isOpenEditPage
  ) => {
    const isValidate =
      (isDelete === undefined || isDelete === false) && (isOpenEditPage === undefined || isOpenEditPage === false);
    dispatch(mjDetailsActions.setDeleteCashReimbursmentJournal(false));
    let isError = false;
    const payload = getValues();
    const inUse: string | undefined = selectedSupplier?.in_use;
    const openDate = selectedSupplier?.opened.split("T").at(0);
    const date: Date = data?.journalHeader?.voucher_date.split("T").at(0);
    const supplierOpenDate: Date = new Date(openDate);
    const voucherDate: Date = new Date(date);
    let jPaymentsData: any;
    if (selectedSupplier?.client_id && isValidate) {
      jPaymentsData = await dispatch(getJPayments({ voucherId: Number(voucherId) }));
    }
    if (!payload?.bank_id) {
      isError = true;
      const message = t("manualJournal.cashbookRecurrencePattern.addBankLedger");
      jPaymentsValidation(message, NotificationStatus.HIGHLIGHT);
      setError("ledger_code", { type: "manual", message });
    }

    if (
      ((jPaymentsData as any)?.payload?.correct_types === false ||
        (jPaymentsData as any)?.payload?.one_bank === false) &&
      isValidate
    ) {
      const message = t("manualJournal.supplierESOrEXAlert");
      jPaymentsValidation(message, NotificationStatus.HIGHLIGHT);
      isError = true;
    }

    if (!selectedSupplier?.client_id && data?.journalHeader?.recurrence_pattern_id !== null && !isError) {
      // Check that a supplier is selected if a recurring pattern has been defined
      isError = true;
      const message = t("manualJournal.supplierRecurringPaymentAlert");
      jPaymentsValidation(message, NotificationStatus.ERROR);
      setError("client_name", { type: "manual", message });
    }

    if (inUse === "F" || supplierOpenDate > voucherDate) {
      isError = true;
      const message = t("manualJournal.supplierNotInUseAlert");
      jPaymentsValidation(message, NotificationStatus.ERROR);
    }
    return isError;
  };

  const resetAllData = async (isOpenEdit?: boolean) => {
    reset();
    if (!isOpenEdit) {
      dispatch(supplierActions.resetSelectedRow());
      dispatch(mjDetailsActions.setSelectedRow(undefined));
    }
    dispatch(bankReconActions.resetStatus());
    dispatch(supplierActions.resetStatus());
    dispatch(supplierActions.resetSupplierList());
    dispatch(mjDetailsActions.resetJournalDetails());

    history.replace({
      ...history?.location,
      state: {
        ...historyState,
        isDirty: false,
        isSoftSaveEnable: undefined
      }
    });
  };
  const jPaymentsValidation = (message: string, notificationType?: NotificationStatus) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        notificationType: notificationType || NotificationStatus.HIGHLIGHT,
        title: t("common.simsFMSModule"),
        message: message ?? "",
        className: "primary-focus"
      })
    );
  };

  const onSubmit = async (isRedirect?: boolean, isDelete?: boolean, isOpenEditPage?: boolean) => {
    let isError = await getInitialErrorStatus(isDelete, isOpenEditPage);
    const payload = getValues();
    if (!payload?.ledger_code) {
      const message = t("manualJournal.cashbookRecurrencePattern.addBankLedger");
      jPaymentsValidation(message, NotificationStatus.HIGHLIGHT);
    } else {
      let result;
      if (!isError) {
        result = await dispatch(saveJournalDetails({ data: payload, isDelete }));
      }
      if (result?.type !== "manualJournalDetails/save/fulfilled") {
        isError = true;
      }
      if (!isError) {
        resetAllData(isOpenEditPage);
      }
      if (!isRedirect && !isError) {
        await dispatch(
          fetchManualJournalDetails({
            voucherId,
            templateVoucherId: templateView?.value
          })
        );
      }
    }
    return isError;
  };

  const onFinalSubmit = async (isRedirect?: boolean, isDelete?: boolean) => {
    if (isDirty || isSaveAPIRequired) {
      dispatch(mjDetailsActions.setDeleteJournalFlag(false));
      let isError = await getInitialErrorStatus(undefined, undefined);
      const payload = getValues();
      if (!payload?.ledger_code) {
        const message = t("manualJournal.cashbookRecurrencePattern.addBankLedger");
        jPaymentsValidation(message, NotificationStatus.HIGHLIGHT);
      } else {
        let result;
        if (!isError) {
          if (!voucherId && mjSelectedRow?.recurrence_pattern_id > 0) {
            setOpenRecurringEditModal(true);
            return;
          }
          if (voucherId && data?.voucherJournal?.recurrence_pattern_id > 0) {
            setOpenRecurringEditModal(true);
            return;
          }
          result = await dispatch(saveJournalDetails({ data: payload, isDelete: false }));
        }
        if (result?.type !== "manualJournalDetails/save/fulfilled") {
          isError = true;
        }
        if (!isError) {
          resetAllData();
        }
        if (!isRedirect && !isError) {
          await dispatch(
            fetchManualJournalDetails({
              voucherId,
              templateVoucherId: templateView?.value,
              callback(data) {
                dispatch(supplierActions.resetSelectedRow());
              }
            })
          );
        }
      }
      // eslint-disable-next-line consistent-return
      return isError;
    }
    // eslint-disable-next-line consistent-return
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  useEffect(() => {
    let enableAdd = true;
    if (data?.voucherJournal?.recurrence_pattern_id !== 0 || data?.voucherJournal?.posted === "T") {
      enableAdd = false;
    }
    setIsAddingPattern(enableAdd);

    let enableEdit = true;
    if (
      data?.voucherJournal?.recurrence_pattern_id === 0 ||
      (data?.journalHeader?.orig_journal_id !== 0 && data?.journalHeader?.orig_journal_id !== null)
    ) {
      enableEdit = false;
    }
    setIsEditPattern(enableEdit);

    let enableDelete = true;
    if (data?.voucherJournal?.recurrence_pattern_id === 0) {
      enableDelete = false;
    }

    if (voucherType === "CB") {
      dispatch(
        getFirstJournalCheck({
          voucherId: Number(voucherId),
          callback: (firstJournalRes) => {
            if (!firstJournalRes) {
              enableDelete = false;
            }
            dispatch(
              getFirstPostedCheck({
                voucherId: Number(voucherId),
                callback: (firstPostedRes) => {
                  enableDelete = !firstPostedRes && enableDelete;
                  setIsDeletePattern(enableDelete);
                }
              })
            );
          }
        })
      );
    }
    return () => {
      dispatch(mjActions.setSelectedRow(data?.journalHeader));
      dispatch(supplierActions.resetStatus());
      dispatch(supplierActions.resetSupplierList());
      dispatch(bankReconActions.resetStatus());
      dispatch(mjDetailsActions.setSelectedRow(undefined));
    };
  }, []);

  useEffect(() => {
    if (status === STATUS.SUCCESS && supplierStatus === STATUS.SUCCESS && isPostJournalValidation) {
      setTimeout(() => {
        postJournal();
        dispatch(mjActions.setIsPostJournalValidation(false));
      }, 500);
    }
  }, [status, supplierStatus]);

  const postJournal = () => {
    if (!watch("period_no")) {
      jPaymentsValidation(t("common.invalidData"), NotificationStatus.HIGHLIGHT);
      setError("period_no", { type: "manual", message: t("common.invalidData") });
    } else if (watch("narrative") === "") {
      jPaymentsValidation(t("common.invalidData"), NotificationStatus.HIGHLIGHT);
      setError("narrative", { type: "manual", message: t("common.invalidData") });
    } else if (watch("bank_reference") === "") {
      jPaymentsValidation(t("common.invalidData"), NotificationStatus.HIGHLIGHT);
      setError("bank_reference", { type: "manual", message: t("common.invalidData") });
    } else {
      dispatch(
        postJournalData({
          voucherId,
          callback: async (data) => {
            if (data?.messageCode === "LRM20") {
              dispatch(
                uiActions.alertPopup({
                  enable: true,
                  type: MODAL_TYPE?.ALERT,
                  message: t("manualJournal.invalidLine"),
                  title: t("common.simsFMSModule"),
                  notificationType: NotificationStatus?.WARNING
                })
              );
            } else if (data?.messageCode?.includes("LR")) {
              dispatch(
                uiActions.alertPopup({
                  enable: true,
                  type: MODAL_TYPE?.ALERT,
                  message: data?.message,
                  title: t("common.simsFMSModule"),
                  notificationType: NotificationStatus?.ERROR
                })
              );
            } else {
              clearHistoryState();
              reset();
              dispatch(supplierActions.resetSelectedRow());
              dispatch(bankReconActions.resetStatus());
              dispatch(mjDetailsActions.setSelectedRow(undefined));
              dispatch(mjDetailsActions.resetRollbackDetails());
              dispatch(supplierActions.resetStatus());
              dispatch(supplierActions.resetSupplierList());
              dispatch(mjDetailsActions.resetJournalDetails());
              dispatch(
                mjActions.setFilters({
                  ...filterState,
                  includePosted: true
                })
              );
              dispatch(
                fetchManualJournalDetails({
                  voucherId,
                  templateVoucherId: templateView?.value
                })
              );
            }
          }
        })
      );
    }
  };

  const isEnabledPostBtn = useMemo(() => {
    const isPosted = data?.voucherJournal?.posted !== "T";
    const isTemplate = data?.journalHeader?.template === "F";
    const balance = getBalance();
    const isBalanced = balance === BalanceType.Balanced;
    return (
      isPosted &&
      isTemplate &&
      isBalanced &&
      (financialYearDetails?.year_state === "S" || financialYearDetails?.year_state === "P") &&
      JournalEditorMode.jvExternalPayment !== data?.journalHeader?.voucher_type &&
      JournalEditorMode.jvAssetManagement !== data?.journalHeader?.voucher_type &&
      canPost
    );
  }, [data, financialYearDetails, canPost]);

  const addRecurrencePattern = handleSubmit(
    (response) => {
      if (watch("narrative").trim().length >= NUMBER_LENGTH.FIFTY) {
        const message = t("manualJournal.cashbookRecurrencePattern.narrativeLength");
        jPaymentsValidation(message);
        setError("narrative", { type: "manual", message });
      } else if (historyState?.isDirty || isDirty) {
        const message = t("manualJournal.cashbookRecurrencePattern.saveChangesCashBook", {
          commonPattern: "adding"
        });
        jPaymentsValidation(message);
      } else if (data?.voucherJournal?.recurrence_pattern_id === 0 || isAddingPattern) {
        dispatch(
          getJPayments({
            voucherId: Number(voucherId),
            callback: (jPayments) => {
              if (!jPayments?.non_zero_line) {
                const message = t("manualJournal.cashbookRecurrencePattern.addNonZeroValueLine", {
                  isAddingPattern: isAddingPattern
                    ? "adding a recurrence pattern to this journal."
                    : "this journal can be saved."
                });
                jPaymentsValidation(message);
              } else if (!jPayments?.all_debits) {
                const message = t("manualJournal.cashbookRecurrencePattern.addDebitLines", {
                  isAddingPattern: isAddingPattern
                    ? "adding a recurrence pattern to this journal."
                    : "this journal can be saved."
                });
                jPaymentsValidation(message);
              } else {
                setIsRecurrencePatternOpen(true);
              }
            }
          })
        );
      }
    },
    (error) => {
      errorHandler(error);
    }
  );

  const clearHistoryState = () => {
    history.replace({ ...history.location, state: undefined });
  };

  const copyJournalData = async () => {
    let period;
    if (
      mjSelectedRow?.voucher_type === JOURNALTYPE.OPENING_BALANCE ||
      mjSelectedRow?.voucher_type === JOURNALTYPE.JW_CL
    ) {
      if (mjSelectedRow?.voucher_type === JOURNALTYPE.OPENING_BALANCE) {
        period = 0;
      } else {
        period = 13;
      }
    }
    dispatch(mjActions.setManualJournalView({ ...filterState, includeSeries: false }));
    await dispatch(
      copyAllTypeJournal({
        voucherId,
        period,
        callback: async (res: any) => {
          if (res) {
            clearHistoryState();
            history.push(`${localRoutes.manualtJournalProcessing.manualJournalEdit}/${res?.data}`, {
              ...(history.location.state as any)
            });
            setValue("period_no", Number(""), { shouldDirty: true });
            setValue("period_description", "", { shouldDirty: true });
            dispatch(mjPeriodssActions.setSelectedRow(undefined));
          }
        }
      })
    );
  };

  const deleteRecurrencePatternHandler = () => {
    if (historyState?.isDirty || isDirty) {
      const message = t("manualJournal.cashbookRecurrencePattern.saveChangesCashBook", {
        commonPattern: "deleting"
      });
      jPaymentsValidation(message);
    } else {
      setIsDeleteModalOpen(true);
      setTimeout(() => {
        const deleteRecurrencePattern = document.querySelector(".delete-alert .essui-button--secondary") as HTMLElement;
        if (deleteRecurrencePattern) {
          deleteRecurrencePattern.focus();
        }
      }, 10);
    }
  };

  const editRecurrencePattern = () => {
    if (historyState?.isDirty || isDirty) {
      const message = t("manualJournal.cashbookRecurrencePattern.saveChangesCashBook", {
        commonPattern: "editing"
      });
      jPaymentsValidation(message);
    } else {
      setIsRecurrencePatternOpen(true);
    }
  };

  useEffect(() => {
    if (supplierStatus === STATUS.SUCCESS) {
      dispatch(supplierActions.resetStatus());
    }
  }, [supplierStatus]);

  const callSaveJournalDetailsWithRecurringAPI = async (isRecurring?: boolean) => {
    let isError;
    const payload = getValues();
    const updatedPayload = { ...payload, isRecurring };
    const result = await dispatch(saveJournalDetails({ data: updatedPayload }));
    if (result?.type !== "manualJournalDetails/save/fulfilled") {
      isError = true;
    }
    if (!isError) {
      dispatch(cbJLDActions.setIsSaveAPIRequired(false));
      resetAllData();
    }
    if (!isError) {
      await dispatch(
        fetchManualJournalDetails({
          voucherId,
          templateVoucherId: templateView?.value
        })
      );
    }
  };

  const tertiaryButton = (
    <Button
      className="recurring-payment-delete-alert-button"
      color={ButtonColor.Secondary}
      id="journal-review-select-btn"
      ref={teritaryBtnRef}
      size={ButtonSize.Small}
      onClick={() => {
        setOpenRecurringEditModal(false);
      }}
    >
      {t("manualJournal.recurringPaymentEditOptions.cancelEdit")}
    </Button>
  );

  const primaryButton = (
    <Button
      color={ButtonColor.Secondary}
      id="journal-review-select-btn"
      size={ButtonSize.Small}
      onClick={async () => {
        callSaveJournalDetailsWithRecurringAPI(true);
      }}
    >
      {t("manualJournal.recurringPaymentEditOptions.updateSubsequentJournal")}
    </Button>
  );

  const secondaryButton = (
    <Button
      className="recurring-payment-delete-alert-button"
      color={ButtonColor.Secondary}
      id="journal-review-select-btn"
      size={ButtonSize.Small}
      onClick={async () => {
        callSaveJournalDetailsWithRecurringAPI(false);
      }}
    >
      {t("manualJournal.recurringPaymentEditOptions.updateOnlyThisJournal")}
    </Button>
  );

  const deleteEnableHandler = () =>
    !!(
      (historyState?.selectedRow?.posted === "T" && historyState?.selectedRow?.balanced === LEDGER_BALANCE.BALANCED) ||
      data?.voucherJournal?.posted === "T" ||
      canDelete === false
    );

  return (pStatus === STATUS.LOADING && isOpen !== true) ||
    status === STATUS.LOADING ||
    saveJournalStatus === STATUS.LOADING ||
    copyJStatus === STATUS.LOADING ||
    printStatus === STATUS.LOADING ||
    postStatus === STATUS.LOADING ||
    bankStatus === STATUS.LOADING ||
    firstPostedCheckStatus === STATUS.LOADING ||
    firstJournalCheckStatus === STATUS.LOADING ||
    isLoading === true ||
    (supplierStatus === STATUS.LOADING && isSuppliersModal === false && suppliersList.clientDetails.length === 0) ? (
    <Loader loadingConfig={loaderConfig} />
  ) : (
    <FormProvider {...formMethods}>
      <Layout
        pageTitle={voucherType === "CB" ? t("manualJournal.cashBook") : t("manualJournal.vatReimbursement")}
        isSubTitle={getTagElement()}
        rightContent={
          <ManualJournalToolbar
            onSubmit={onSubmit}
            onFinalSubmit={onFinalSubmit}
            isDirty={isDirty}
            onUndoClick={onUndoClick}
            disableHandler={deleteEnableHandler}
          />
        }
        toolbar={
          <ManualJournalPageToolbar
            isDirty={isDirty}
            isEnabledPostBtn={isEnabledPostBtn}
            postJournal={postJournal}
            contraJournal={() => {
              dispatch(mjDetailsActions.setContraYear(data?.year));
              history.push(`/general-ledger/manual-journal-list/edit/${voucherId}/contra/${voucherId}`);
            }}
            copyJournal={() => copyJournalData()}
          />
        }
        dataTestId="manaalJournalDetails-page"
        className="manual-journal-details"
      >
        <Grid className="row-gap-16">
          <GridItem {...yearBreakPoints}>
            <div className="essui-form-label">{t("manualJournal.year")}</div>
            <div className="height__equal--input">{data?.year}</div>
          </GridItem>

          <GridItem {...periodBreakPoints}>
            {data.voucherJournal?.posted === "T" ? (
              <div>
                <div className="essui-form-label">{t("manualJournalPage.period")}</div>
                <div className="height__equal--input">
                  {data.journalHeader?.period} {periodRow?.description ?? ""}
                </div>
              </div>
            ) : (
              <PeriodInput />
            )}
          </GridItem>

          <GridItem {...voucherBreakPoints}>
            <div className="essui-form-label">{t("manualJournal.voucharDate")}</div>
            <div className="height__equal--input">
              {data.journalHeader?.voucher_date
                ? getDataFormat(data.journalHeader?.voucher_date)
                : specialCharacters.HYPHEN}
            </div>
          </GridItem>

          <GridItem
            {...supplierBreakPoints}
            className="input-set-gap8"
          >
            {/* // Get Supplier Input Component */}
            <SupplierInput
              voucherType={voucherType}
              isSuppliersModal={isSuppliersModal}
              setIsSuppliersModal={setIsSuppliersModal}
            />
          </GridItem>

          <GridItem {...voucherBreakPoints}>
            <div className="essui-form-label">{t("manualJournal.postingDate")}</div>
            <div className="height__equal--input">
              {data.journalHeader?.posting_date
                ? getDataFormat(data.journalHeader?.posting_date)
                : specialCharacters.HYPHEN}
            </div>
          </GridItem>

          <GridItem {...narrativeBreakPoints}>
            <div>
              <Controller
                render={({ field }) => (
                  <Input
                    id="narrative-input"
                    labelText={t("manualJournalPage.narrative")}
                    maxLength={60}
                    isViewOnly={data?.journalHeader?.temp_no !== null}
                    {...field}
                    onBlur={() => (getValues("narrative") ? clearErrors("narrative") : null)}
                    validationTextLevel={errors.narrative ? ValidationTextLevel.Error : undefined}
                  />
                )}
                name="narrative"
                control={control}
              />
            </div>
          </GridItem>

          {/* Get Bank Ledger Code Component */}
          <GridItem
            {...bankLedgerBreakPoints}
            className="set__table--hegiht"
          >
            <BankLedgerInput />
          </GridItem>

          <GridItem {...bankAccountBreakPoints}>
            <div className="essui-form-label">{t("manualJournal.bankAccount")}</div>
            <div className="height__equal--input">
              {getValues("bank_account") ? getValues("bank_account") : specialCharacters.HYPHEN}
            </div>
          </GridItem>

          <GridItem {...bankAccountBreakPoints}>
            <div className="essui-form-label">{t("manualJournal.sortCode")}</div>
            <div className="height__equal--input">
              {getValues("bank_sort_code") ? getValues("bank_sort_code") : specialCharacters.HYPHEN}
            </div>
          </GridItem>

          <GridItem {...bankAccountBreakPoints}>
            <div className="essui-form-label">{t("manualJournal.journalNumber")}</div>
            <div className="height__equal--input">
              {getValues("orig_no") ? getValues("orig_no") : specialCharacters.HYPHEN}
            </div>
          </GridItem>

          <GridItem {...referenceBreakPoints}>
            <div>
              <Controller
                render={({ field }) => (
                  <Input
                    id="reference-input"
                    labelText={t("manualJournal.reference")}
                    maxLength={20}
                    isViewOnly={data?.journalHeader?.temp_no !== null}
                    {...field}
                    onBlur={() => (getValues("bank_reference") ? clearErrors("bank_reference") : null)}
                    validationTextLevel={errors.bank_reference ? ValidationTextLevel.Error : undefined}
                  />
                )}
                name="bank_reference"
                control={control}
              />
            </div>
          </GridItem>
          {voucherType === "CB" && (
            <GridItem {...bankLedgerBreakPoints}>
              <FormLabel className="mb-8">{t("manualJournal.recurrencePattern")}</FormLabel>
              <div className="d-flex justify-start flex-wrap justify-start-resposnive gap-8">
                <Button
                  id="addRecurrencePattern"
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={addRecurrencePattern}
                  disabled={!isAddingPattern}
                >
                  {t("manualJournal.add")}
                </Button>
                <Button
                  id="editRecurrencePattern"
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={editRecurrencePattern}
                  disabled={!isEditPattern}
                >
                  {t("manualJournal.edit")}
                </Button>
                <Button
                  id="deleteRecurrencePattern"
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={deleteRecurrencePatternHandler}
                  disabled={!isDeletePattern}
                >
                  {t("manualJournal.delete")}
                </Button>
              </div>
            </GridItem>
          )}
          {isRecurrencePatternOpen && (
            <AddRecurrencePattern
              setIsRecurrencePatternOpen={setIsRecurrencePatternOpen}
              isAddingPattern={isAddingPattern}
            />
          )}
        </Grid>
      </Layout>

      <Layout
        isBreadcrumbRequired={false}
        type="transparent"
        className="manual-journal-details__grid"
      >
        <GridTableNew
          id="journalLinesGrid"
          dataTestId="journalLinesGrid"
          customCell={CustomCell}
          onSubmit={onSubmit}
          filters={
            <ManualJournalFilters
              onSubmit={onSubmit}
              voucherType={voucherType}
              isDirty={isDirty}
            />
          }
          columnDef={data?.voucherJournal?.posted === "T" ? MannualJournalProcessingColumnDefs : columnDef}
          dataSource={data?.journalLines ? data?.journalLines.filter((item: any) => !item?.isDeleted) : []}
          isLoading={false}
          selectedRow={selectedRow}
          isScrollable
          isAutoFocusInitially={data.voucherJournal?.posted === "T"}
          selectedRowHandler={(row) => {
            dispatch(mjDetailsActions.setSelectedRow(row));
          }}
        />
      </Layout>

      <Layout isBreadcrumbRequired={false}>
        <div className="container">
          <Grid className="row-gap-16">
            <GridItem {...footerNarrativeBreakPoints}>
              <div className="mb-8">
                <div className="essui-form-label mb-5">Narrative</div>
                <div>{selectedRow?.narrative ? selectedRow?.narrative : specialCharacters.HYPHEN}</div>
              </div>
            </GridItem>
          </Grid>
          <Grid className="row-gap-16">
            <GridItem {...balanceBreakPoints}>
              <div className="essui-form-label mb-5">Balance</div>
              <div>{getBalance()}</div>
            </GridItem>
            <GridItem {...balanceBreakPoints}>
              <div className="essui-form-label mb-5">Total Debits</div>
              <div>{usNumberFormat(debit ?? specialCharacters.zero)}</div>
            </GridItem>
            <GridItem {...balanceBreakPoints}>
              <div className="essui-form-label mb-5">Total Credits</div>
              <div>{usNumberFormat(credit ?? specialCharacters.zero)}</div>
            </GridItem>
          </Grid>
        </div>
      </Layout>
      <ConfirmModal
        isOpen={isDeleteModalOpen}
        setOpen={setIsDeleteModalOpen}
        title={t("alertMessage.title")}
        message={t("manualJournal.cashbookRecurrencePattern.deleteRecurrencePattern")}
        className="delete-alert"
        confirm={() => {
          setIsDeletePattern(false);
          setIsAddingPattern(true);
          setIsEditPattern(false);
          dispatch(
            deleteRecurrencePattern({
              voucherId: Number(voucherId),
              callback: () => {
                dispatch(
                  getManualJournal({
                    ...filterState,
                    callback: (data) => {
                      history.replace({
                        ...history.location,
                        state: {
                          ...(history.location.state as any),
                          manualJournalList: data
                        }
                      });
                    }
                  })
                );
                setIsRecurrencePatternOpen(false);
              }
            })
          );
        }}
      />

      <Modalv2
        className="delete-alert recurring__payment--delete--alert"
        header={t("manualJournal.recurringPaymentEditOptions.title")}
        isOpen={openRecurringEditModal}
        primaryButton={tertiaryButton}
        secondaryButton={primaryButton}
        tertiaryButton={secondaryButton}
      >
        <Notification
          actionElement={1}
          dataTestId="warning-id"
          escapeExits
          id="warning-id"
          hideCloseButton
          status={NotificationStatus.WARNING}
          title={t("manualJournal.recurringPaymentEditOptions.message")}
          className="mb-18 confirm-modal-text"
        />
      </Modalv2>
      <ConfirmModal
        className="delete-alert"
        isOpen={isUndoModalOpen}
        setOpen={setIsUndoModalOpen}
        title={t("alertMessage.title")}
        message={t("alertMessage.undoAlert.message")}
        confirm={() => {
          onUndoChange();
        }}
        callback={({ confirm }) => {}}
        autoFocusPrimaryBtn
      />
    </FormProvider>
  );
};
export default CashBook;
