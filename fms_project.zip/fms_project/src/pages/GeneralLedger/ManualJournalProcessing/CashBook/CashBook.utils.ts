const yearBreakPoints = {
  lg: 3,
  md: 4,
  sm: 4,
  xl: 3,
  xxl: 3
};

const periodBreakPoints = {
  lg: 2,
  md: 12,
  sm: 12,
  xl: 2,
  xxl: 2
};

const voucherBreakPoints = {
  lg: 2,
  md: 4,
  sm: 4,
  xl: 2,
  xxl: 2
};

const narrativeBreakPoints = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 12,
  xxl: 12
};

const supplierBreakPoints = {
  sm: 4,
  md: 3,
  lg: 3,
  xl: 3,
  xxl: 3
};

const bankLedgerBreakPoints = {
  sm: 4,
  md: 8,
  lg: 4,
  xl: 3,
  xxl: 3
};

const bankAccountBreakPoints = {
  sm: 4,
  md: 4,
  lg: 4,
  xl: 2,
  xxl: 2
};

const referenceBreakPoints = {
  sm: 4,
  md: 4,
  lg: 4,
  xl: 3,
  xxl: 3
};

const balanceBreakPoints = {
  lg: 3,
  md: 3,
  sm: 2,
  xl: 3,
  xxl: 3
};

const footerNarrativeBreakPoints = {
  lg: 12,
  md: 12,
  sm: 4,
  xl: 12,
  xxl: 12
};
export {
  yearBreakPoints,
  periodBreakPoints,
  voucherBreakPoints,
  narrativeBreakPoints,
  supplierBreakPoints,
  bankLedgerBreakPoints,
  bankAccountBreakPoints,
  referenceBreakPoints,
  balanceBreakPoints,
  footerNarrativeBreakPoints
};
