import { Button, ButtonColor, ButtonSize, Icon, IconSize, IconColor } from "@essnextgen/ui-kit";
import { forwardRef } from "react";

const EndDateButton = forwardRef(({ value, onClick }: any, ref: any) => (
  <Button
    id="recurrencePatternEndDate"
    color={ButtonColor.Secondary}
    onClick={onClick}
    className="input-search-button essui-button-icon-only--small"
    size={ButtonSize.Small}
    disabled={false}
    ref={ref}
    aria-label="search"
  >
    <Icon
      size={IconSize.Medium}
      color={IconColor.Primary500}
      name="calendar"
    />
  </Button>
));

export default EndDateButton;
