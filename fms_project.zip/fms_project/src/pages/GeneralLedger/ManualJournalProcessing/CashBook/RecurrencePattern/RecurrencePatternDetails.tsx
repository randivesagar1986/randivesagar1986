import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  NotificationStatus,
  TextInputSize,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import { Dispatch, FC, forwardRef, SetStateAction, useEffect, useState } from "react";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import InputDate from "@/shared/components/InputDate/InputDate";
import DatePicker from "react-datepicker";
import { dateFormat, datePicker, getDateInStringFormat } from "@/utils/constants";
import "./Style.scss";
import { useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { format, isAfter, isToday, min, parse, set } from "date-fns";
import NumberInput from "@/components/NumberInput/NumberInput";
import { useHistory, useParams } from "react-router-dom";
import { formatDateInYYYYMMDD } from "@/shared/components/InputDate/formatDate";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { actions, validateJournalRecurrenceStartDate, saveRecurrencePattern } from "./state/RecurrencePattern.slice";
import StartDateButton from "./StartDateButton";
import EndDateButton from "./EndDateButton";

type RecurrencePropsType = {
  setIsRecurrencePatternOpen: Dispatch<SetStateAction<boolean>>;
  isAddingPattern: boolean;
};

/* eslint-disable camelcase */
type FormData = {
  start_date: string;
  end_date: string;
  months: string;
};

const AddRecurrencePattern: FC<RecurrencePropsType> = ({ setIsRecurrencePatternOpen, isAddingPattern }) => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const { voucherId } = useParams<{ voucherId: string }>();
  const { firstJournalCheck, firstPostedCheck } = useAppSelector((state) => state.recurrencePattern);
  const journalDetails = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.data);
  const [selectedStartDate, setSelectedStartDate] = useState<any>(undefined);
  const [selectedEndDate, setSelectedEndDate] = useState<any>(undefined);
  const [isStartDateError, setIsStartDateError] = useState<boolean>(false);
  const [isEndDateError, setIsEndDateError] = useState<boolean>(false);
  const [isMonthsError, setIsMonthsError] = useState<boolean>(false);

  const formMethods = useForm<FormData>({
    mode: "all",
    shouldFocusError: false,
    defaultValues: {
      start_date: "",
      end_date: "",
      months: "1"
    }
  });

  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    setFocus,
    setError,
    reset,
    watch,
    clearErrors,
    formState: { errors, isDirty },
    getValues
  } = formMethods;

  useEffect(() => {
    const startDate = formatDateInYYYYMMDD(String(new Date()));
    const editedStartDate = formatDateInYYYYMMDD(journalDetails?.recurrencePattern?.start_date);
    const endDate = journalDetails?.recurrencePattern?.end_date
      ? formatDateInYYYYMMDD(journalDetails?.recurrencePattern?.end_date)
      : "";
    setValue("start_date", isAddingPattern ? startDate : editedStartDate);
    setValue("months", isAddingPattern ? "1" : journalDetails?.recurrencePattern?.no_of_months);
    if (!isAddingPattern) {
      setValue("end_date", endDate);
      setSelectedEndDate(new Date(journalDetails?.recurrencePattern?.end_date));
    } else {
      setValue("end_date", "");
    }
  }, []);

  useEffect(() => {
    if (isDirty) {
      dispatch(actions.setIsRecurrencePatterDirty(true));
    }
  }, [isDirty]);

  const datepickerStartDateChangeHandler = (newDate: any) => {
    setSelectedStartDate(newDate);
    const value = formatDateInYYYYMMDD(newDate); // getDateInStringFormat(newDate);
    const startDate = parse(value, "yyyy-MM-dd", new Date());
    if (!isToday(startDate) && !isAfter(startDate, new Date())) {
      setIsStartDateError(true);
    } else {
      setIsStartDateError(false);
    }
    setValue("start_date", value);
    dispatch(actions.setIsRecurrencePatterDirty(true));
  };

  const datepickerEndDateChangeHandler = (newDate: any) => {
    setSelectedEndDate(newDate);
    const value = formatDateInYYYYMMDD(newDate);
    const endDate = parse(value, "yyyy-MM-dd", new Date());
    if (!isToday(endDate) && !isAfter(endDate, new Date())) {
      setIsEndDateError(true);
    } else {
      setIsEndDateError(false);
    }
    setValue("end_date", value);
    dispatch(actions.setIsRecurrencePatterDirty(true));
  };

  const jPaymentsValidation = (message: string, startDateInput: string, endDateInput?: string) => {
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        message: message ?? "",
        title: t("common.simsFMSModule"),
        type: MODAL_TYPE.CONFIRMV2,
        className: "delete-alert",
        noCallback: () => {},
        yesCallback: async () => {
          await dispatch(
            saveRecurrencePattern({
              recurrencePatternId: 0,
              voucherId: Number(voucherId),
              startDate: startDateInput,
              months: Number(watch("months")),
              endDate: endDateInput ?? null,
              callback: async (response) => {
                if (response) {
                  setIsRecurrencePatternOpen(false);
                }
              }
            })
          );
        },
        isCancelBtnEnable: false
      })
    );
  };

  const onSubmit = handleSubmit(async (inputData) => {
    dispatch(actions.setIsRecurrencePatterDirty(false));
    const startDate = parse(inputData.start_date, "yyyy-MM-dd", new Date());
    const endDate = parse(inputData.end_date, "yyyy-MM-dd", new Date());
    const noOfMonths = Number(inputData.months);
    const voucherDate = new Date(journalDetails?.journalHeader?.voucher_date);
    const formattedStartDate = formatDateInYYYYMMDD(inputData.start_date);
    const startDateInput = new Date(formattedStartDate).toISOString().split(".")[0];

    let isReturn = false;
    const validateDates = () => {
      if (inputData?.end_date) {
        const months = parseInt(inputData.months, 10);
        const minEndDate = startDate;
        minEndDate.setMonth(minEndDate.getMonth() + months);
        if (voucherDate > endDate || endDate < minEndDate || (!isToday(endDate) && !isAfter(endDate, new Date()))) {
          setIsEndDateError(true);
          isReturn = true;
        }
      }
      return isReturn;
    };

    const handleSaveRecurrencePattern = (endDateInput?: any) => {
      dispatch(
        saveRecurrencePattern({
          recurrencePatternId: isAddingPattern ? 0 : journalDetails?.recurrencePattern?.recurrence_pattern_id,
          voucherId: Number(voucherId),
          startDate: startDateInput,
          months: Number(watch("months")),
          endDate: endDateInput ?? null,
          callback: async (response) => {
            if (response) {
              setIsRecurrencePatternOpen(false);
            }
          }
        })
      );
    };

    const performValidation = async () => {
      if (!isAddingPattern && (!firstJournalCheck || firstPostedCheck)) {
        const hasValidationErrors = validateDates();
        if (hasValidationErrors) {
          return;
        }

        const formattedEndDate = inputData?.end_date ? formatDateInYYYYMMDD(inputData.end_date) : undefined;
        const endDateInput = formattedEndDate ? new Date(formattedEndDate).toISOString().split(".")[0] : undefined;
        handleSaveRecurrencePattern(endDateInput);
      } else {
        dispatch(
          validateJournalRecurrenceStartDate({
            startDate: formattedStartDate,
            callback: (response) => {
              if (!response) {
                setIsStartDateError(true);
                isReturn = true;
              }
              if (!isToday(startDate) && !isAfter(startDate, new Date())) {
                setIsStartDateError(true);
                isReturn = true;
              }
              if (noOfMonths === 0 || noOfMonths < 0 || noOfMonths > 12) {
                setIsMonthsError(true);
                isReturn = true;
              }

              const hasValidationErrors = validateDates();
              if (hasValidationErrors) {
                isReturn = true;
              }
              if (isReturn) {
                return;
              }

              const formattedEndDate = inputData?.end_date ? formatDateInYYYYMMDD(inputData.end_date) : undefined;
              const endDateInput = formattedEndDate
                ? new Date(formattedEndDate).toISOString().split(".")[0]
                : undefined;

              if (isAddingPattern) {
                const message = t("manualJournal.cashbookRecurrencePattern.saveRecurringSeries");
                jPaymentsValidation(message, startDateInput, endDateInput);
              } else {
                handleSaveRecurrencePattern(endDateInput);
              }
            }
          })
        );
      }
    };

    await performValidation();
  });

  return (
    <>
      <GridItem
        sm={4}
        md={4}
        lg={4}
        xl={2}
        xxl={2}
      >
        <FormLabel forId="txtStartDate">{t("manualJournal.startDate")}</FormLabel>
        <div className="recurr-pattern-txt">
          <InputDate
            id="txtStartDate"
            width="165px"
            autoFocus
            value={watch("start_date")}
            disabled={!isAddingPattern && (!firstJournalCheck || firstPostedCheck)}
            name={
              register("start_date", {
                required: true
              }).name
            }
            onBlur={(firstDate) => {
              if (firstDate.toString().trim().length) {
                const startDate = parse(firstDate, "yyyy-MM-dd", new Date());
                setSelectedStartDate(startDate);
                if (!isToday(startDate) && !isAfter(startDate, new Date())) {
                  setIsStartDateError(true);
                } else {
                  setIsStartDateError(false);
                }
                const formattedDate = formatDateInYYYYMMDD(firstDate);
                setValue("start_date", formattedDate);
              } else {
                setValue("start_date", "");
                setIsStartDateError(true);
              }
            }}
            onDateChange={(date, e) => register("start_date").onChange(e)}
            validationTextLevel={isStartDateError ? ValidationTextLevel.Error : undefined}
          />
          <DatePicker
            onChange={() => {}}
            customInput={<StartDateButton isAddingPattern={isAddingPattern} />}
            minDate={new Date()}
            showMonthDropdown
            showYearDropdown
            selected={selectedStartDate}
            onSelect={datepickerStartDateChangeHandler}
            dropdownMode="scroll"
            dateFormat={dateFormat.european}
            value={selectedStartDate ? selectedStartDate!.toLocaleDateString("en-GB").toString() : ""}
            scrollableYearDropdown
            yearDropdownItemNumber={datePicker.NumberofItemsInDropdown}
            className="start-date-picker"
            calendarStartDay={1}
          />
        </div>
      </GridItem>
      <GridItem
        sm={4}
        md={4}
        lg={4}
        xl={2}
        xxl={2}
      >
        <FormLabel forId="txtThenEvery">{t("manualJournal.thenEvery")}</FormLabel>
        <Grid>
          <GridItem
            sm={4}
            md={8}
            lg={6}
            xl={6}
          >
            <NumberInput
              id="numberOfMonths"
              name={register("months").name}
              inputRef={(e) => register("months").ref(e)}
              maxLength={2}
              decimals={0}
              defaultValue={getValues("months")}
              disabled={!isAddingPattern && (!firstJournalCheck || firstPostedCheck)}
              onChange={(e) => {
                setValue("months", e.target.value, { shouldDirty: true });
                if (e.target.value === "0" || e.target.value === "00") {
                  setIsMonthsError(true);
                } else {
                  setIsMonthsError(false);
                }
              }}
              onBlur={(e) => {
                if (
                  watch("months") === "0" ||
                  watch("months") === "00" ||
                  Number(watch("months")) < 0 ||
                  Number(watch("months")) > 12
                ) {
                  setIsMonthsError(true);
                } else {
                  setIsMonthsError(false);
                }
              }}
              validationTextLevel={isMonthsError ? ValidationTextLevel.Error : undefined}
              className="width100"
            />
          </GridItem>
          <GridItem
            sm={4}
            md={8}
            lg={6}
            xl={6}
            className="d-flex align-center mt-8 mb-8 pl-0"
          >
            <div className="d-flex">{t("manualJournal.months")}</div>
          </GridItem>
        </Grid>
      </GridItem>

      <GridItem
        sm={4}
        md={4}
        lg={4}
        xl={2}
        xxl={2}
      >
        <FormLabel forId="txtEndAfter">{t("manualJournal.endAfter")}</FormLabel>
        <div className="recurr-pattern-txt">
          <InputDate
            id="txtEndAfter"
            value={watch("end_date")}
            width="165px"
            autoFocus={!isAddingPattern && (!firstJournalCheck || firstPostedCheck)}
            name={register("end_date").name}
            inputRef={(e: any) => register("end_date").ref(e)}
            onBlur={(date) => {
              if (date.toString().trim().length) {
                const endDate = parse(date, "yyyy-MM-dd", new Date());
                setSelectedEndDate(endDate);
                if (!isToday(endDate) && !isAfter(endDate, new Date())) {
                  setIsEndDateError(true);
                } else {
                  setIsEndDateError(false);
                }
                const formattedDate = formatDateInYYYYMMDD(date);
                setValue("end_date", formattedDate);
              } else {
                setValue("end_date", "");
                setIsEndDateError(false);
              }
            }}
            onDateChange={(date, e) => register("end_date").onChange(e)}
            validationTextLevel={isEndDateError ? ValidationTextLevel.Error : undefined}
          />
          <DatePicker
            onChange={() => {}}
            customInput={<EndDateButton />}
            minDate={new Date()}
            openToDate={new Date()}
            showMonthDropdown
            showYearDropdown
            selected={selectedEndDate}
            onSelect={datepickerEndDateChangeHandler}
            dropdownMode="scroll"
            dateFormat={dateFormat.european}
            value={selectedEndDate ? selectedEndDate!.toLocaleDateString("en-GB").toString() : ""}
            scrollableYearDropdown
            yearDropdownItemNumber={datePicker.NumberofItemsInDropdown}
            calendarStartDay={1}
          />
        </div>
      </GridItem>
      <GridItem
        sm={4}
        md={4}
        lg={4}
        xl={3}
        className="d-flex align-center"
      >
        <div className="d-flex gap-8 mt-16">
          <Button
            id="btnCancel"
            size={ButtonSize.Small}
            color={ButtonColor.Secondary}
            onClick={() => {
              setIsRecurrencePatternOpen(false);
              dispatch(actions.setIsRecurrencePatterDirty(false));
            }}
          >
            {t("common.cancel")}
          </Button>
          <Button
            id="btnSave"
            size={ButtonSize.Small}
            color={ButtonColor.Primary}
            onClick={onSubmit}
          >
            {t("common.save")}
          </Button>
        </div>
      </GridItem>
    </>
  );
};
export default AddRecurrencePattern;
