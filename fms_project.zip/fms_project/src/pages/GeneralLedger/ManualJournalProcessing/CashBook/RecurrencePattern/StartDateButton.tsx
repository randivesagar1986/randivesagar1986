import { useAppSelector } from "@/store/store";
import { Button, ButtonColor, ButtonSize, Icon, IconSize, IconColor } from "@essnextgen/ui-kit";
import { forwardRef } from "react";

const StartDateButton = forwardRef(({ value, onClick, isAddingPattern }: any, ref: any) => {
  const { firstJournalCheck, firstPostedCheck } = useAppSelector((state) => state.recurrencePattern);

  return (
    <Button
      id="recurrencePatternStartDate"
      color={ButtonColor.Secondary}
      onClick={onClick}
      className="input-search-button essui-button-icon-only--small"
      size={ButtonSize.Small}
      disabled={!isAddingPattern && (!firstJournalCheck || firstPostedCheck)}
      ref={ref}
      aria-label="search"
    >
      <Icon
        size={IconSize.Medium}
        color={IconColor.Primary500}
        name="calendar"
      />
    </Button>
  );
});
export default StartDateButton;
