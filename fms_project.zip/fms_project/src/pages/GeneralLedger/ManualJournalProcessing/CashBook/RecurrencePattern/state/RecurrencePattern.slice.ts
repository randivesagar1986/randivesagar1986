import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { STATUS } from "@/types/UseStateType";
import axios from "axios";
import { fetchManualJournalDetails } from "@/pages/GeneralLedger/State/ManualJournalDetails.slice";

/* eslint-disable camelcase */
type TJPayments = {
  non_zero_line: boolean;
  correct_types: boolean;
  all_debits: boolean;
  one_bank: boolean;
};

type recurrencePattermState = {
  recurrencePatternId: number;
  error?: string;
  status?: STATUS;
  getJpaymentsStatus?: STATUS;
  firstJournalCheckStatus?: STATUS;
  firstPostedCheckStatus?: STATUS;
  jPaymentsDetails?: TJPayments;
  firstJournalCheck?: boolean;
  firstPostedCheck?: boolean;
  isRecurrencePatterDirty?: boolean;
};

const initialState: recurrencePattermState = {
  recurrencePatternId: 0,
  isRecurrencePatterDirty: false
};

type TSaveRecurrencePattern = {
  recurrencePatternId: number;
  voucherId: number;
  startDate: string;
  months: number;
  endDate: string | null;
};

/** Thunks */

export const validateJournalRecurrenceStartDate = createAsyncThunk(
  "recurrenceStartDateCheck/get",
  async ({ startDate, callback }: { startDate: string; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/Manual-Journal/manual-journal-recurrence-start-date-check`, {
      params: {
        startDate
      }
    });
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const saveRecurrencePattern = createAsyncThunk(
  "cashbook/saveRecurrencePattern",
  async (
    {
      recurrencePatternId,
      voucherId,
      startDate,
      months,
      endDate,
      callback
    }: TSaveRecurrencePattern & { callback?: (data: any) => void },
    thunkAPI
  ) => {
    const { dispatch } = thunkAPI;
    try {
      const { data }: { data: { [key: string]: any } } = await client.post(
        `${apiRoot}/Manual-Journal/manual-journal-recurrence-save`,
        {
          recurrencePatternId,
          voucherId,
          startDate,
          months,
          endDate
        }
      );
      await dispatch(fetchManualJournalDetails({ voucherId: String(voucherId), templateVoucherId: undefined }));
      if (callback) {
        callback(data);
      }
      return data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getJPayments = createAsyncThunk(
  "cashbook/jPayments",
  async ({ voucherId, callback }: { voucherId: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/Manual-Journal/manual-journal-Jpayments`, {
      params: {
        voucherId
      }
    });
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getFirstJournalCheck = createAsyncThunk(
  "cashbook/recurrence-first-journal-check",
  async ({ voucherId, callback }: { voucherId: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/Manual-Journal/manual-journal-recurrence-first-journal-check`, {
      params: {
        voucherId
      }
    });
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getFirstPostedCheck = createAsyncThunk(
  "cashbook/recurrence-first-posted-check",
  async ({ voucherId, callback }: { voucherId: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/Manual-Journal/manual-journal-recurrence-first-posted-check`, {
      params: {
        voucherId
      }
    });
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const deleteRecurrencePattern = createAsyncThunk(
  "cashbook/deleteRecurrencePattern",
  async ({ voucherId, callback }: { voucherId: number; callback?: (data: any) => void }, thunkAPI) => {
    try {
      // Make the axios API call
      const response = await axios.delete(`${apiRoot}/Manual-Journal/manual-journal-recurrence-delete`, {
        params: { voucherId }
      });
      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (error) {
      // Handle any errors that occur during the API call
      console.error("Failed to delete recurrence pattern", error);
      throw new Error("Failed to delete recurrence pattern");
    }
  }
);

/**
 * # Cash book Recurrence pattern Slice
 */
const slice = createSlice({
  extraReducers: (builder) => {
    builder
      .addCase(saveRecurrencePattern.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(saveRecurrencePattern.fulfilled, (state, action: PayloadAction<any>) => {
        state.recurrencePatternId = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(saveRecurrencePattern.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
    builder
      .addCase(getJPayments.pending, (state) => {
        state.getJpaymentsStatus = STATUS.LOADING;
      })
      .addCase(getJPayments.fulfilled, (state, action: PayloadAction<any>) => {
        state.jPaymentsDetails = action.payload;
        state.getJpaymentsStatus = STATUS.SUCCESS;
      })
      .addCase(getJPayments.rejected, (state, action: PayloadAction<any>) => {
        state.getJpaymentsStatus = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
    builder
      .addCase(getFirstJournalCheck.pending, (state) => {
        state.firstJournalCheckStatus = STATUS.LOADING;
      })
      .addCase(getFirstJournalCheck.fulfilled, (state, action: PayloadAction<any>) => {
        state.firstJournalCheck = action.payload;
        state.firstJournalCheckStatus = STATUS.SUCCESS;
      })
      .addCase(getFirstJournalCheck.rejected, (state, action: PayloadAction<any>) => {
        state.firstJournalCheckStatus = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
    builder
      .addCase(getFirstPostedCheck.pending, (state) => {
        state.firstPostedCheckStatus = STATUS.LOADING;
      })
      .addCase(getFirstPostedCheck.fulfilled, (state, action: PayloadAction<any>) => {
        state.firstPostedCheck = action.payload;
        state.firstPostedCheckStatus = STATUS.SUCCESS;
      })
      .addCase(getFirstPostedCheck.rejected, (state, action: PayloadAction<any>) => {
        state.firstPostedCheckStatus = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },

  initialState,
  name: "recurrencePattern",
  reducers: {
    resetToInitial: (state) => {
      state.recurrencePatternId = 0;
    },
    setIsRecurrencePatterDirty: (state, action: PayloadAction<boolean>) => {
      state.isRecurrencePatterDirty = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
