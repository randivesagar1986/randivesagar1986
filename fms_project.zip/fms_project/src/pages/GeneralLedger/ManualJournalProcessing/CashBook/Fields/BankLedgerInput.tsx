import React, { useEffect, useState } from "react";
import { GridItem, ISelectedItem, ValidationTextLevel } from "@essnextgen/ui-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import {
  getBankreconBankAccounts,
  actions as bankReconActions,
  getBankreconAccountNo
} from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import { KEYBOARD_STRING, specialCharacters, STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import Input, { onPendingType } from "@/components/Input/Input";
import { useDispatch } from "react-redux";
import { Controller, useFormContext } from "react-hook-form";
import { AppDispatch, useAppSelector } from "@/store/store";
import {
  fetchManualJournalDetails,
  mjDetailsActions,
  updateBank
} from "@/pages/GeneralLedger/State/ManualJournalDetails.slice";
import BankAccount from "../BankAccount/BankAccount";

const loaderConfig: loadingConfig = { isLoaderModal: true };
const BankLedgerInput = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { bankreconBankAccounts, bankStatus, selectedRow, filters } = useAppSelector(
    (state) => state.bankreconBankAccounts
  );
  const { data: mjDetails, updateBankStatus } = useAppSelector((state) => state.manualJournalDetails);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    setValue,
    watch,
    control,
    trigger,
    formState: { errors }
  } = useFormContext();
  const [isBankAccountModalOpen, setIsBankAccountModalOpen] = useState<boolean>(false);
  const searchItems = bankreconBankAccounts.map((b) => ({
    text: b.ledger_code,
    value: b.ledger_code
  }));
  const bankAccountClick = () => {
    setIsBankAccountModalOpen(true);
  };
  const setBankAccount = (bankAccountSelected: any) => {
    setValue("ledger_code", bankAccountSelected?.ledger_code, {
      shouldValidate: true
    });
    setValue("ledger_des", bankAccountSelected?.ledger_des);
    setValue("bank_account", bankAccountSelected?.bank_account);
    setValue("bank_sort_code", bankAccountSelected?.bank_sort_code);
    setValue("bank_id", bankAccountSelected?.bank_id);
  };

  useEffect(() => {
    if (selectedRow !== undefined) {
      setBankAccount(selectedRow);
    }
  }, [selectedRow]);

  useEffect(() => {
    if (bankStatus === STATUS.SUCCESS && watch("ledger_code") === undefined && bankreconBankAccounts.length > 0) {
      const row = bankreconBankAccounts?.find((s: any) => s.bank_id === mjDetails?.journalHeader?.bank_id);
      dispatch(bankReconActions.setSelectedRow(row));
      setValue("ledger_code", row?.ledger_code);
      setValue("ledger_des", row?.ledger_des);
      setValue("bank_account", row?.bank_account);
      setValue("bank_sort_code", row?.bank_sort_code);
      setValue("bank_id", row?.bank_id);
    }
  }, [bankreconBankAccounts, bankStatus]);

  const onBankAccountNoSelection = () => {
    dispatch(bankReconActions.setFilters({ ...filters, lookingFor: watch("ledger_code") }));
    setValue("ledger_code", "");
    setValue("ledger_des", "");
    setValue("bank_account", "");
    setValue("bank_id", 0);
    setIsBankAccountModalOpen(true);
  };

  const onBankAccountSelectedRow = async (row: any) => {
    if (mjDetails?.journalLines.length > 0) {
      await dispatch(
        updateBank({
          bankId: row?.bank_id,
          voucherId: mjDetails?.journalHeader?.voucher_id,
          lineItemsPresent: mjDetails?.journalLines.length > 0
        })
      );
    }
    if (row) {
      dispatch(bankReconActions.setSelectedRow(row));
      setValue("ledger_code", row?.ledger_code, {
        shouldValidate: true,
        shouldDirty: true
      });
      setValue("ledger_des", row?.ledger_des);
      setValue("bank_account", row?.bank_account);
      setValue("bank_sort_code", row?.bank_sort_code);
      setValue("bank_id", row?.bank_id);
    }
  };

  const onPending: onPendingType = (selectedItem, index) => {
    if (index === undefined) {
      setValue("bank_id", 0);
      dispatch(bankReconActions.selectBankAccountRow(undefined));
      dispatch(bankReconActions.resetSelectedRow());
      setValue("ledger_des", "");
      setValue("bank_account", "");
      setValue("bank_sort_code", "");
      // dispatch(bankReconActions.setFilters({ ...filters, lookingFor: "" }));
      return;
    }
    const bankAccount = bankreconBankAccounts?.at(index);
    if (bankAccount) {
      /* eslint-disable camelcase */
      const { ledger_des, bank_account, bank_sort_code } = bankAccount;
      setValue("ledger_des", ledger_des);
      setValue("bank_account", bank_account);
      setValue("bank_sort_code", bank_sort_code);
    }
  };

  const onBlurHandler = (e: any) => {
    if (e.target.value === "") {
      trigger("ledger_code");
    }
  };

  const onSelect = async (selectedItem: ISelectedItem | undefined) => {
    const bankAccount = bankreconBankAccounts.filter((s) => s.ledger_code === selectedItem?.value)[0];
    if (selectedItem?.text) {
      setValue("ledger_code", bankAccount?.ledger_code, {
        shouldValidate: true
      });
      setValue("ledger_des", bankAccount?.ledger_des);
      setValue("bank_account", bankAccount?.bank_account);
      setValue("bank_sort_code", bankAccount?.bank_sort_code);
      setValue("bank_id", bankAccount?.bank_id);
      dispatch(bankReconActions.setSelectedRow(bankAccount));
    } else {
      dispatch(bankReconActions.setSelectedRow(undefined));
    }

    if (mjDetails?.journalLines.length > 0 && bankAccount) {
      await dispatch(
        updateBank({
          bankId: bankAccount?.bank_id,
          voucherId: mjDetails?.journalHeader?.voucher_id,
          lineItemsPresent: mjDetails?.journalLines.length > 0
        })
      );
    }
  };

  const button = (
    <>
      <Input
        disabled
        id="bank-ledger-description-input"
        value={watch("ledger_des")}
        className="read-only w-auto"
        searchBtnClick={bankAccountClick}
        readOnly={mjDetails?.journalHeader?.temp_no !== null || mjDetails?.journalHeader?.template === "T"}
      />
    </>
  );
  return (
    <>
      {bankStatus === STATUS.LOADING || updateBankStatus === STATUS.LOADING ? (
        <Loader loadingConfig={loaderConfig} />
      ) : null}
      <div>
        <Controller
          render={({ field }) => (
            <Input
              id="bank-ledger-code-input"
              labelText={t("manualJournal.bankLedgerCode")}
              inputWidth={110}
              searchable
              searchItems={searchItems}
              containerClassName="width-auto"
              disabled={mjDetails?.journalHeader?.temp_no !== null || mjDetails?.journalHeader?.template !== "F"}
              onSelect={onSelect}
              onPending={onPending}
              validationTextLevel={errors?.ledger_code ? ValidationTextLevel.Error : undefined}
              onNoSelection={onBankAccountNoSelection}
              button={mjDetails?.voucherJournal?.posted !== "T" ? button : undefined}
              isViewOnly={mjDetails?.voucherJournal?.posted === "T"}
              {...field}
              onBlur={onBlurHandler}
            />
          )}
          control={control}
          name="ledger_code"
        />
      </div>

      <BankAccount
        isOpen={isBankAccountModalOpen}
        setOpen={setIsBankAccountModalOpen}
        onSelectedRow={onBankAccountSelectedRow}
      />
    </>
  );
};

BankLedgerInput.defaultProps = {
  SelectedBankId: undefined
};

export default BankLedgerInput;
