import { Dispatch, SetStateAction, useState, FC, useEffect } from "react";
import { GridItem, ISelectedItem, ValidationTextLevel } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { useFormContext } from "react-hook-form";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import Input from "@/components/Input/Input";
import { AppDispatch, useAppSelector } from "@/store/store";
import SelectPeriodModal from "../../../ManualJournalDetailsPage/SelectPeriodModal/SelectPeriodModal";
import { mjPeriodssActions } from "../../../State/ManualJournalPeriods.slice";

type onPendingType = ((selectedItem?: ISelectedItem, index?: number, flag?: boolean) => void) | undefined;
export enum periodsType {
  NORMAL = "NORMAL",
  REVERSAL = "REVERSAL"
}

const PeriodInput = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [id, setId] = useState<periodsType>(periodsType.NORMAL);
  const {
    setValue,
    getValues,
    clearErrors,
    formState: { errors }
  } = useFormContext();
  const periods = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.periods);
  const status = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.status);
  const { isOpenModal: isOpen } = useAppSelector((state) => state.manualJournalPeriods);
  const periodRow = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.selectedRow);
  const data = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.data);
  const searchItems = periods.map((period) => ({
    value: String(period.description),
    text: String(period.period_no)
  }));

  const periodOnClickHandler = () => {
    dispatch(mjPeriodssActions.setIsOpenModal(true));
    setId(periodsType.NORMAL);
  };

  const onPending: onPendingType = (_, index) => {
    if (index !== undefined) {
      setValue("period_no", periods.at(index!)?.period_no, {
        shouldDirty: true
      });
      setValue("period_description", periods.at(index!)?.description, {
        shouldDirty: true
      });
      dispatch(mjPeriodssActions.setSelectedRow(periods.at(index!)));
    } else {
      setValue("period_no", "", { shouldDirty: true });
      setValue("period_description", "", { shouldDirty: true });
      dispatch(mjPeriodssActions.setSelectedRow(undefined));
    }
  };

  const button = (
    <>
      <Input
        disabled
        id="period-description-input"
        inputWidth={60}
        value={periodRow?.description ?? ""}
        className="read-only w-auto"
        searchBtnClick={periodOnClickHandler}
        readOnly={data?.journalHeader?.temp_no !== null || data?.journalHeader?.template === "T"}
      />
    </>
  );

  return (
    <>
      <Input
        id="period-no-input"
        labelText={t("manualJournalPage.period")}
        inputWidth={45}
        searchable
        searchItems={searchItems}
        containerClassName="width-auto"
        value={String(periodRow?.period_no || "")}
        onBlur={() => (getValues("period_no") > 0 ? clearErrors("period_no") : null)}
        disabled={data?.journalHeader?.temp_no !== null || data?.journalHeader?.template !== "F"}
        onPending={onPending}
        onNoSelection={periodOnClickHandler}
        button={button}
        validationTextLevel={errors.period_no ? ValidationTextLevel.Error : undefined}
      />

      {isOpen && (
        <SelectPeriodModal
          isOpen={isOpen}
          setOpen={(flag) => {
            dispatch(mjPeriodssActions.setIsOpenModal(flag));
          }}
          id={id}
          isEnableSequence
        />
      )}
    </>
  );
};

export default PeriodInput;
