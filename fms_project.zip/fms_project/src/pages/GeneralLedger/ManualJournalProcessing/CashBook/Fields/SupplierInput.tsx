import { useEffect, FC } from "react";
import { ISelectedItem, ValidationTextLevel } from "@essnextgen/ui-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import Input from "@/components/Input/Input";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useFormContext, Controller } from "react-hook-form";
import { fetchSuppliersWithPagination, supplierActions } from "@/pages/PurchaseOrder/state/Suppliers.slice";
import POSupplierPagination from "@/shared/components/SuppliersModal/POSupplierPagination";
import { KeyValueType } from "@/components/GridTableNew/GridTableNew";

type SupplierType = {
  setIsSuppliersModal: (value: boolean) => void;
  isSuppliersModal: boolean;
  voucherType: string;
};

const SupplierInput: FC<SupplierType> = ({ voucherType, isSuppliersModal, setIsSuppliersModal }) => {
  const {
    selectedSupplier,
    suppliersListPagination,
    filterState: supplierFilterState
  } = useAppSelector((state) => state.suppliers);
  const { data: mjDetails } = useAppSelector((state) => state.manualJournalDetails);
  const dispatch = useDispatch<AppDispatch>();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    setValue,
    watch,
    formState: { errors, isDirty },
    control
  } = useFormContext();

  const openSupplierModal = () => {
    if (voucherType === "CB") {
      setIsSuppliersModal(true);
    }
  };

  useEffect(() => {
    if (voucherType === "CB" && mjDetails?.voucherJournal?.posted === "T") {
      setTimeout(() => {
        const button = document.querySelector(".input-container .essui-button--secondary") as HTMLElement;
        if (button) {
          button.focus();
        }
      }, 500);
    }
  }, []);

  useEffect(() => {
    if (selectedSupplier !== undefined) {
      setValue("client_name", selectedSupplier?.name, {
        shouldValidate: true,
        shouldDirty: mjDetails?.journalHeader?.client_id !== selectedSupplier?.client_id || isDirty ? true : undefined
      });
      setValue("client_id", selectedSupplier?.client_id);
    }
  }, [selectedSupplier, mjDetails]);

  const onSelectHandler = (selectedItem?: ISelectedItem) => {
    if (selectedItem?.value) {
      const supplier = suppliersListPagination.data.filter((s) => s.client_id === selectedItem?.value)?.at(0);
      setValue("client_name", supplier?.name, {
        shouldValidate: true,
        shouldDirty: true
      });
      setValue("client_id", selectedItem.value);
      dispatch(supplierActions.setSelectedRow(supplier));
    }
  };

  return (
    <>
      <Controller
        render={({ field }) => (
          <Input
            id="cashbook-supplier"
            labelText={t("manualJournal.supplier")}
            disabled={voucherType === "VR" || (voucherType === "CB" && mjDetails?.voucherJournal?.posted === "T")}
            searchable
            getSearchItem={async (searchString) => {
              let result;
              if (searchString !== undefined) {
                await dispatch(
                  fetchSuppliersWithPagination({
                    ...supplierFilterState,
                    lookingFor: searchString || "",
                    callback(data, selectedRow) {
                      result = {
                        row: { text: selectedRow?.name, value: selectedRow?.client_id } as ISelectedItem,
                        data
                      };
                    }
                  })
                );
              }
              return result;
            }}
            onSelect={onSelectHandler}
            onPending={(selectedItem, index) => {
              if (index === undefined) {
                setValue("client_name", "");
                setValue("client_id", "", {
                  shouldValidate: true,
                  shouldDirty: true
                });
                dispatch(supplierActions.resetSelectedRow());
              }
            }}
            onNoSelection={() => {
              openSupplierModal();
            }}
            searchBtnClick={async () => {
              openSupplierModal();
            }}
            onClear={() => {
              dispatch(
                fetchSuppliersWithPagination({
                  ...supplierFilterState,
                  pageNumber: 1,
                  lookingFor: "",
                  callback(data, selectedRow) {
                    dispatch(supplierActions.setSelectedRowUndefined());
                  }
                })
              );
            }}
            validationTextLevel={errors.client_name ? ValidationTextLevel.Error : undefined}
            {...field}
            buttonDisabled={voucherType === "VR"}
          />
        )}
        control={control}
        name="client_name"
      />
      {mjDetails?.journalHeader?.voucher_type === "CB" ? (
        <POSupplierPagination
          supplierDetailsData={
            isSuppliersModal
              ? suppliersListPagination.data.find((s) => s.client_id === suppliersListPagination?.highLightId)
              : undefined
          }
          isOpen={isSuppliersModal}
          setOpen={setIsSuppliersModal}
          viewDetailsAction={mjDetails?.journalHeader?.temp_no !== null}
          headerTitle={
            mjDetails?.journalHeader?.temp_no !== null ? t("supplier.supplierDetails") : t("supplier.supplierBrowse")
          }
          isPoSuppiler={false}
          autoFocusSecondaryBtn={mjDetails?.journalHeader?.temp_no !== null}
          onApiCallback={(data, selectRow) => {
            if (mjDetails?.journalHeader?.client_id === null) {
              // When initially it's null
              dispatch(supplierActions.setSelectedRowUndefined());
              return;
            }
            if (data?.length !== 0) {
              setValue("client_name", selectRow?.name);
              setValue("client_id", selectRow?.client_id);
              if (mjDetails?.journalHeader?.voucher_type !== "VR") {
                dispatch(supplierActions.setSelectedRow(selectRow));
              }
            }
          }}
        />
      ) : null}
    </>
  );
};

export default SupplierInput;
