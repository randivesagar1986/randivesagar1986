import { TColumnDef } from "@/components/GridTable/GridTable";
import { BANKRECON_SEQUENCE_TYPE, STATUS, JOURNAL_SEQUENCE_TYPE, KEYBOARD_STRING } from "@/types/UseStateType";

import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import {
  FormLabel,
  Grid,
  GridItem,
  RadioButton,
  RadioLabelPosition,
  TextInput,
  TextInputSize
} from "@essnextgen/ui-kit";
import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import useDebounce from "@/hooks/useDebounce";
import { actions as bankReconActions } from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import findNearest from "@/utils/nearestSearch";
import { sortByKey } from "@/utils/getDataSource";
import columnDef from "./columnDef";

type TBankAccountFilterProps = {
  setSelectRow: Dispatch<any>;
};

const BankAccountFilter = ({ setSelectRow }: TBankAccountFilterProps) => {
  const { bankStatus, filters, bankreconBankAccounts } = useAppSelector(
    ({ bankreconBankAccounts }) => bankreconBankAccounts
  );
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [lookingFor, setLookingFor] = useState<string>("");
  const debouncedValue = useDebounce(lookingFor, 500);
  const [sequenceValue, setSequenceValue] = useState<string>(filters?.sequenceValue!);
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const dispatch = useDispatch<AppDispatch>();

  useEffect(() => {
    const { field } = columnDef.filter((col) => !!col.sequence)[0];
    handleSequenceChange(field, 0);
  }, []);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setLookingFor(value.toUpperCase());
  };

  useEffect(() => {
    const lookingFor = filters?.lookingFor || "";
    setLookingFor(lookingFor);
  }, [filters?.lookingFor]);

  useEffect(() => {
    if (debouncedValue !== "" && bankreconBankAccounts && bankreconBankAccounts.length) {
      let found;
      found = [...bankreconBankAccounts]
        .filter((element) =>
          debouncedValue ? element[sequenceValue]?.toString()?.toUpperCase()?.startsWith(debouncedValue!) : false
        )
        .at(0);

      if (found && found !== undefined) {
        setSelectRow(found);
      }

      if (found === undefined) {
        found = findNearest(
          [...bankreconBankAccounts],
          [{ fieldName: sequenceValue, searchValue: debouncedValue }],
          true
        );
        setSelectRow(found);
      }
      const element = document.getElementById(
        `rowIndex-manualJournalBankAccountGrid-${bankreconBankAccounts.indexOf(found!)}`
      );
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [debouncedValue]);

  const handleSequenceChange = (value: React.SetStateAction<string>, sequenceIndex: number) => {
    columnDef.map((col, index) => {
      if (col.field === value) {
        const temp = columns[0];
        columns[0] = columns[index];
        columns[index] = temp;
      }
      return col;
    });

    setColumn([...columnDef]);
    setSequenceValue(value);
    dispatch(bankReconActions.setColumnDef(columns));
    const sortedBankAccountList = sortByKey(bankreconBankAccounts, String(value));
    dispatch(bankReconActions.setSortedData(sortedBankAccountList));
  };

  const handleSequenceFieldKeyDown = async (e: React.KeyboardEvent) => {
    const isArrowKey =
      e.key === KEYBOARD_STRING.ArrowDown ||
      e.key === KEYBOARD_STRING.ArrowUp ||
      e.key === KEYBOARD_STRING.ArrowLeft ||
      e.key === KEYBOARD_STRING.ArrowRight;

    if (isArrowKey) {
      e.preventDefault();
      e.stopPropagation();

      const nextSequenceValue =
        sequenceValue === BANKRECON_SEQUENCE_TYPE.CODE
          ? BANKRECON_SEQUENCE_TYPE.DESCRIPTION
          : BANKRECON_SEQUENCE_TYPE.CODE;
      const index = nextSequenceValue === BANKRECON_SEQUENCE_TYPE.DESCRIPTION ? 1 : 0;

      handleSequenceChange(String(nextSequenceValue), index);
      setLookingFor("");
    }
  };

  return (
    <>
      <Grid
        className="custom-table"
        align="center"
        justify="flex-start"
      >
        <GridItem
          sm={12}
          md={4}
          xl={4}
        >
          <div className="essui-global-typography-default-h2 mr-l-4">
            <FormLabel forId="looking-for">{t("common.lookingFor")}</FormLabel>
            <div className="looking-for">
              <TextInput
                id="looking-for"
                value={lookingFor}
                onChange={handleLookingForChange}
                size={TextInputSize.Medium}
                readOnly={bankStatus === STATUS.LOADING}
                autoComplete={false}
              />
            </div>
          </div>
        </GridItem>

        <GridItem
          sm={12}
          md={4}
          xl={5}
        >
          <div className="essui-global-typography-default-h2">
            <FormLabel>{t("purchaseOrder.sequence")}</FormLabel>
            <div
              className="essui-textinput sequence"
              onKeyDown={handleSequenceFieldKeyDown}
            >
              {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
                const sequenceId = `sequence=${index + 1}`;
                return (
                  <RadioButton
                    label={column.sequenceName ? column.sequenceName : column.headerName}
                    labelPosition={RadioLabelPosition.Right}
                    value={column.field}
                    onChange={() => {
                      handleSequenceChange(column.field, index);
                      setLookingFor("");
                    }}
                    isSelected={sequenceValue === column.field}
                    key={sequenceId}
                    name="sequenceColumn"
                  />
                );
              })}
            </div>
          </div>
        </GridItem>
      </Grid>
    </>
  );
};

export default BankAccountFilter;
