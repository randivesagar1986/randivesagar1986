import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import GridTableNew, { RowType } from "@/components/GridTableNew/GridTableNew";
import { actions as bankReconActions } from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import { useFormContext } from "react-hook-form";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { STATUS } from "@/types/UseStateType";
import { AppDispatch, useAppSelector } from "@/store/store";
import BankAccountFilter from "./Grid/BankAccountFilter";

type TBankAccountProp = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  onSelectedRow?: (row?: RowType) => void;
};

const BankAccount = ({ setOpen, isOpen, onSelectedRow }: TBankAccountProp) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const [selectRow, setSelectRow] = useState<any>();
  const { bankStatus, columnDef, selectedBankAccount, selectedRow, filters } = useAppSelector(
    ({ bankreconBankAccounts }) => bankreconBankAccounts
  );
  const { bankreconBankAccounts } = useAppSelector((state) => state.bankreconBankAccounts);
  const closeHandler = () => {
    dispatch(bankReconActions.setSelectedRow(undefined));
    dispatch(bankReconActions.resetSelectedBankAccountRow());
    setSelectRow(undefined);
    setOpen(false);
  };

  const rowSelectionHandler = () => {
    if (onSelectedRow) onSelectedRow(selectRow);
    dispatch(bankReconActions.setSelectedRow(selectRow));
    setOpen(false);
  };

  useEffect(() => {
    if (isOpen && selectedRow === undefined) {
      setSelectRow(bankreconBankAccounts[0]);
    } else {
      setSelectRow(selectedRow);
    }
  }, [isOpen]);

  const handleOnEnterPress = () => {
    if (onSelectedRow) onSelectedRow(selectRow);
    dispatch(bankReconActions.setSelectedRow(selectRow));
    setOpen(false);
  };

  const primaryButton = (
    <Button
      size={ButtonSize.Small}
      onClick={rowSelectionHandler}
    >
      {t("common.select")}
    </Button>
  );

  const secondaryButton = (
    <Button
      size={ButtonSize.Small}
      color={ButtonColor.Secondary}
      onClick={closeHandler}
    >
      {t("common.cancel")}
    </Button>
  );

  const tertiaryButton = (
    <HelpButton
      identifier="testIdentifier"
      labelName={t("common.help")}
    />
  );

  return (
    <Modalv2
      header={t("manualJournal.bankAccountTitle")}
      isOpen={isOpen}
      primaryButton={primaryButton}
      secondaryButton={secondaryButton}
      tertiaryButton={tertiaryButton}
      onClose={closeHandler}
      focusSelectBtnDef={false}
    >
      <GridTableNew
        dataTestId="manualJournalBankAccountGrid"
        isScrollable
        enableScrollIntoView
        selectedRow={selectRow}
        dataSource={bankreconBankAccounts}
        isLoading={bankStatus === STATUS.LOADING}
        columnDef={columnDef}
        selectedRowHandler={(row) => setSelectRow(row)}
        filters={<BankAccountFilter setSelectRow={setSelectRow} />}
        onEnterKeyPress={handleOnEnterPress}
      />
    </Modalv2>
  );
};

BankAccount.defaultProps = {
  onSelectedRow: undefined
};

export default BankAccount;
