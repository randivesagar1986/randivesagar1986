import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

export const bankAccount: TColumnDef = [
  {
    headerName: "Code",
    field: "ledger_code",
    sequence: true,
    val: 0
  },
  {
    headerName: "Description",
    field: "ledger_des",
    sequence: true,
    val: 1
  }
];

export default bankAccount;
