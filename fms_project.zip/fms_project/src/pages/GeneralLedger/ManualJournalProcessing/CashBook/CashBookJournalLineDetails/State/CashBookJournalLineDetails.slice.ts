import { KeyValueType, RowType } from "@/components/GridTableNew/GridTableNew";
import { apiRoot } from "@/config";
import { RootState } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { createSlice, PayloadAction, createAsyncThunk, current } from "@reduxjs/toolkit";
import axios from "axios";
import { client } from "@/shared/config";

// Define the initial state interface
export type JournalDetailsType = {
  journalHeader?: KeyValueType;
  journalLines: KeyValueType[];
  voucherJournal?: KeyValueType;
  [key: string]: any;
};
type initialStateType = {
  data: JournalDetailsType;
  selectedManualJournalDetails: KeyValueType;
  getSelectedJournalLineDetailsAPIStatus: STATUS;
  status: STATUS;
  error: string | null;
  selectedRow?: RowType;
  selectedRowVat?: RowType;
  balance?: string;
  isSaveAPIRequired?: boolean;
};

// Define the initial state
const initialState: initialStateType = {
  data: {
    journalHeader: undefined,
    journalLines: [],
    voucherJournal: undefined
  },
  selectedManualJournalDetails: {},
  getSelectedJournalLineDetailsAPIStatus: STATUS.IDLE,
  error: null,
  status: STATUS.IDLE,
  isSaveAPIRequired: false
};

// Create an async thunk function to update the CashBook details
export const postCashBookDetails = createAsyncThunk(
  "cashBookDetail/post",
  async ({
    /* eslint-disable camelcase */
    voucher_id,
    voucher_line_id,
    ledger_id,
    cost_id,
    vat_id,
    debit,
    credit,
    narrative,
    vat_amount,
    fund_id,
    isEdited,
    isVatEdit,
    callback
  }: {
    voucher_id: number;
    voucher_line_id: number;
    ledger_id: number;
    cost_id: number;
    vat_id: number;
    debit: number;
    credit: number;
    narrative: string;
    vat_amount: number;
    fund_id: number;
    isEdited?: boolean;
    isVatEdit?: boolean;
    callback?: (data: any) => void;
  }) => {
    const response = await axios.post(
      `${apiRoot}/Manual-Journal/manual-journal-cash-book-line-save?voucherId=${voucher_id}`,
      {
        voucher_id,
        voucher_line_id,
        ledger_id,
        cost_id,
        vat_id,
        debit,
        credit,
        narrative,
        vat_amount,
        fund_id,
        isEdited,
        isVatEdit
      }
    );

    if (callback) callback(response.data);

    return response.data;
  }
);

// Create an async thunk function to Get Vat Rate and Recoverable deatils based on vat Id
export const getVatRateRecoverableDeatils = createAsyncThunk(
  "manualJournalVATCodes/get",
  async ({ vatId, callback }: { vatId: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/Manual-Journal/manual-journal-vat-rate-recoverable?vatId=${vatId}`);
    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);
export const getSelectedJournalLineDetails = createAsyncThunk(
  "/manual-journal/manual-journal-line-edit",
  async ({ voucherLineId, callback }: { voucherLineId: number; callback?: (data: any) => void }) => {
    const response = await client.get(
      `${apiRoot}/Manual-Journal/manual-journal-line-edit?voucherLineId=${voucherLineId}`
    );
    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

// Add the async thunk function to the reducers
const slice = createSlice({
  name: "manualJournalLinesDetails",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(postCashBookDetails.fulfilled, (state, action) => {
      // Handle the successful API response and update the state accordingly
      state.data = action.payload as any;
      state.status = STATUS.SUCCESS;
      state.error = null;
    });
    builder.addCase(postCashBookDetails.pending, (state) => {
      // Handle the pending state while the API call is in progress
      state.status = STATUS.LOADING;
      state.error = null;
    });
    builder.addCase(postCashBookDetails.rejected, (state, action) => {
      // Handle any errors that occur during the API call
      state.status = STATUS.FAILED;
      state.error = action.error.message || null;
    });
    builder.addCase(getSelectedJournalLineDetails.fulfilled, (state, action) => {
      // Handle the successful API response and update the state accordingly
      state.selectedManualJournalDetails = action.payload as any;
      state.getSelectedJournalLineDetailsAPIStatus = STATUS.SUCCESS;
    });
    builder.addCase(getSelectedJournalLineDetails.pending, (state) => {
      // Handle the pending state while the API call is in progress
      state.getSelectedJournalLineDetailsAPIStatus = STATUS.LOADING;
    });
    builder.addCase(getSelectedJournalLineDetails.rejected, (state, action) => {
      // Handle any errors that occur during the API call
      state.getSelectedJournalLineDetailsAPIStatus = STATUS.FAILED;
    });
  },
  reducers: {
    // Define your actions and their corresponding reducers here
    setSelectedRow: (state, action: PayloadAction<RowType | undefined>) => {
      state.selectedRow = action.payload;
    },
    setSelectedRowVat: (state, action: PayloadAction<RowType | undefined>) => {
      state.selectedRowVat = action.payload;
    },
    addJournalLine: (state, action: PayloadAction<any>) => {
      state.data.journalLines.push(action.payload);
      state.selectedRow = action.payload;
    },
    resetDetails: (state) => {
      state.data = initialState.data;
    },
    addJournalDetails: (state, action: PayloadAction<JournalDetailsType>) => {
      state.data = {
        ...action.payload
      };
    },
    setBalance: (state, action: PayloadAction<any>) => {
      state.balance = action.payload;
    },
    setSelectedManualJournalDetails: (state, action: PayloadAction<any>) => {
      state.selectedManualJournalDetails = action.payload;
    },
    setIsSaveAPIRequired: (state, action: PayloadAction<any>) => {
      state.isSaveAPIRequired = action.payload;
    }
  }
});

// Export the actions and reducer
export const { actions, reducer } = slice;
export default reducer;
