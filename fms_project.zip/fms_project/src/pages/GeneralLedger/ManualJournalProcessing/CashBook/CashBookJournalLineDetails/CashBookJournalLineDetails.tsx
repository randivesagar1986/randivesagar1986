import {
  Button,
  ButtonColor,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  RadioButton,
  RadioLabelPosition,
  ValidationTextLevel,
  Tooltip,
  NotificationStatus
} from "@essnextgen/ui-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import { ArrowDown, ArrowUp } from "@carbon/icons-react";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import "./Style.scss";
import CashBookJournalLedgerCodesModal from "@/shared/components/JournalLedgerCodesModal/JournalLedgerCodesModal";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import UseStateType, {
  JOURNAL_PAYMENT_TYPE,
  JOURNAL_AMOUNT_TYPE,
  specialCharacters,
  STATUS,
  METHOD
} from "@/types/UseStateType";
import React, { useEffect, useState } from "react";
import { Controller, FormProvider, useForm } from "react-hook-form";
import CashBookJournalFundsModal from "@/shared/components/JournalFunCodeModal/JournalFunCodeModal";
import CashBookJournalCostCentresModal from "@/shared/components/JournalCostCenterModal/JournalCostCenterModal";
import CashBookJournalVATModal from "@/shared/components/CashbookJournalVatCodeModal/CashBookJournalVATModal";
import { AppDispatch, useAppSelector } from "@/store/store";
import { actions as cashBookJournalLedgerActions } from "@/shared/components/JournalLedgerCodesModal/state/JournalLedgerCodes.slice";
import { actions as cashBookJournalFundsActions } from "@/shared/components/JournalFunCodeModal/state/JournalFunCode.slice";
import {
  getjournalCostCentersDebitCredit,
  actions as journalCostActions
} from "@/shared/components/JournalCostCenterModal/state/JournalCostCenters.slice";
import {
  getLinkedVatCode,
  actions as journalVatActions
} from "@/shared/components/CashbookJournalVatCodeModal/state/CashBookJournalVAT.slice";
import { useDispatch } from "react-redux";
import { usNumberFormat } from "@/utils/getDataSource";
import NumberInput from "@/components/NumberInput/NumberInput";
import { useHistory, useParams } from "react-router-dom";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { KeyValueType } from "@/components/GridTableNew/GridTableNew";
import { fetchManualJournalDetails, mjDetailsActions } from "@/pages/GeneralLedger/State/ManualJournalDetails.slice";
import InputNumberMask from "@/components/Input/InputNumberMask";
import { supplierActions } from "@/pages/PurchaseOrder/state/Suppliers.slice";
import { checkGlLedgerType } from "@/pages/GeneralLedgerSetup/utils";
import {
  actions as cbJLDActions,
  postCashBookDetails,
  getVatRateRecoverableDeatils,
  getSelectedJournalLineDetails
} from "./State/CashBookJournalLineDetails.slice";

/* eslint-disable camelcase */
type FormData = {
  cost_code: string;
  cost_des: string;
  ledger_code: string;
  ledger_des: string;
  ledger_id: string;
  fund_code: string;
  fund_id: string;
  fund_des: string;
  vat_code: string;
  vat_id: string;
  vat_des: string;
  cost_budget: string;
  combination: string;
  part_no: string;
  author_name: string;
  item_des: string;
  quantity: string;
  amount: string;
  discount: string;
  lineTotal: string;
  contract_no: string;
  cost_id: string;
  fullLC: string;
  fullCC: string;
  part_contains: string;
  is_changed: boolean;
  amount_payment_type: string;
  unit: string;
  narrative: string;
  vat_amount: string;
  amt_type: string;
};

const loaderConfig: loadingConfig = { isLoaderModal: false };
const CashBookJournalLineDetails = () => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;
  const [isOpenLedgerCodesModal, setIsOpenLedgerCodesModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isOpenFundsCodesModal, setIsOpenFundsCodesModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isOpenCostCentresCodesModal, setIsOpenCostCentresCodesModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isOpenVATCodesModal, setIsOpenVATCodesModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isShowArrowDown, setIsShowArrowDown] = useState<boolean>(false);
  const [isCreditDebitAPIReq, setIsCreditDebitAPIReq] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");
  const [isOpenAlert, setIsOpenAlert] = useState<boolean>(false);
  const [alertType, setAlertType] = useState<NotificationStatus>(NotificationStatus.ERROR);
  const [resolve, setResolve] = useState<(value: unknown) => void>();
  const [isVal, setIsVal] = useState<boolean>();
  const { voucherId } = useParams<{ voucherId: string }>();
  const { alert } = useAppSelector((state) => state.ui);
  const [vateRate, setVateRate] = useState<string>("");
  const [vateRecoverable, setVateRecoverable] = useState<string>("");
  const [vateRecoverableRes, setVateRecoverableRes] = useState<any>();
  const [ledgerType, setLedgerType] = useState<string>("");
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [callVatCodeUseEffect, setCallVatCodeUseEffect] = useState<boolean>(true);
  const [netAmountV, setNetAmountV] = useState<number | undefined>();
  const [vatAmountV, setVatAmountV] = useState<number | undefined>();
  const [vatAmountS, setVatAmountS] = useState<number | undefined>();
  const [grossAmountS, setGrossAmountS] = useState<number | undefined>();
  const [grossAmountV, setGrossAmountV] = useState<number | undefined>();
  const [recoverableWarn, setRecoverableWarn] = useState<string>("");
  const { status, selectedManualJournalDetails } = useAppSelector((state) => state.cashbookJournalLinesDetails);
  const { status: mjDetailStatus, data: manualJournalData } = useAppSelector((state) => state.manualJournalDetails);
  const inputNumRef = React.useRef<HTMLInputElement>(null);
  const { voucherLineId } = useParams<{ voucherLineId: string }>();
  const {
    selectedJournalCostCentre,
    journalCostCenters,
    status: journalCostCentreStatus,
    balanceData
  } = useAppSelector((state) => state.journalCostCentre);

  const {
    journalLedgerCodes,
    selectedJournalLedgerCode,
    status: journalLedgerCodeStatus,
    isLoading,
    isLedgerType
  } = useAppSelector((state) => state.journalLedgerCode);

  const {
    journalFundCodes,
    selectedJournalFundCode,
    status: journalFundCodeStatus
  } = useAppSelector((state) => state.journalFundCode);

  const {
    vatCodeList,
    selectedRowVatCode,
    linkedVatCode,
    status: vatCodeCodeStatus
  } = useAppSelector((state) => state.cashBookJournalVAT);

  const formMethods = useForm<FormData>({
    mode: "all",
    defaultValues: {
      cost_budget: "0.00",
      combination: "0.00",
      quantity: "0",
      amount: "0.000",
      discount: "0.00",
      lineTotal: "0.00",
      item_des: "",
      part_no: "",
      author_name: "",
      contract_no: "",
      cost_des: "",
      ledger_des: "",
      fund_des: "",
      vat_des: "",
      part_contains: "",
      is_changed: false,
      amount_payment_type: JOURNAL_PAYMENT_TYPE.DEBIT,
      unit: "",
      vat_amount: "0.00",
      amt_type: JOURNAL_AMOUNT_TYPE.NET
    }
  });

  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    watch,
    reset,
    clearErrors,
    getFieldState,
    formState: { errors, isDirty },
    getValues,
    setError
  } = formMethods;

  const { control } = formMethods;

  const ledgerCodeClick = () => {
    setIsCreditDebitAPIReq(true);
    setIsOpenLedgerCodesModal(true);
  };

  const FundsCodeClick = () => {
    setIsCreditDebitAPIReq(true);
    setIsOpenFundsCodesModal(true);
  };

  const CostCentresCodeClick = () => {
    setIsCreditDebitAPIReq(true);
    setIsOpenCostCentresCodesModal(true);
  };
  const VATCodeClick = () => {
    setIsCreditDebitAPIReq(true);
    setIsOpenVATCodesModal(true);
  };

  // eslint-disable-next-line
  useEffect(() => {
    const unblock = history.block((location, action) => {
      if (location.pathname !== history.location.pathname) {
        dispatch(journalCostActions.reset());
        dispatch(cashBookJournalLedgerActions.reset());
        dispatch(cashBookJournalFundsActions.reset());
        dispatch(journalVatActions.reset());
        dispatch(supplierActions.resetStatus());
        dispatch(supplierActions.resetSupplierList());
        dispatch(mjDetailsActions.resetJournalDetails());
        location.state = {
          isDirty: (location.state as any)?.isDirty,
          manualJournalList: (location.state as any)?.manualJournalList,
          isSoftSaveEnable: historyState?.isSoftSaveEnable,
          from: "journalLines"
        };
      }
    });
    if (voucherLineId) dispatch(getSelectedJournalLineDetails({ voucherLineId: Number(voucherLineId) }));
    return () => {
      unblock();
      resrtAndClose();
      dispatch(fetchManualJournalDetails({ voucherId, templateVoucherId: undefined }));
      dispatch(cbJLDActions.setSelectedManualJournalDetails({}));
    };
  }, []);

  useEffect(() => {
    if (voucherLineId && !isCreditDebitAPIReq) {
      if (Object.keys(selectedManualJournalDetails).length > 0) {
        reset({
          narrative: selectedManualJournalDetails?.narrative || "",
          cost_budget: usNumberFormat(selectedManualJournalDetails?.cost_centre_balance) || "0.00",
          combination: usNumberFormat(selectedManualJournalDetails?.combination_balance) || "0.00",
          vat_amount: selectedManualJournalDetails?.credit || selectedManualJournalDetails?.debit || "0.00",
          fund_code: selectedManualJournalDetails?.fund_code || specialCharacters.BLANKVALUE,
          fund_des: selectedManualJournalDetails?.fund_des || specialCharacters.BLANKVALUE,
          fund_id: selectedManualJournalDetails?.fund_id || specialCharacters.BLANKVALUE,
          ledger_code: selectedManualJournalDetails?.ledger_code || specialCharacters.BLANKVALUE,
          ledger_des: selectedManualJournalDetails?.ledger_des || specialCharacters.BLANKVALUE,
          ledger_id: selectedManualJournalDetails?.ledger_id || specialCharacters.BLANKVALUE,
          cost_code: selectedManualJournalDetails?.cost_code || specialCharacters.BLANKVALUE,
          cost_des: selectedManualJournalDetails?.cost_des || specialCharacters.BLANKVALUE,
          cost_id: selectedManualJournalDetails?.cost_id || specialCharacters.BLANKVALUE,
          vat_code: selectedManualJournalDetails?.vat_code || specialCharacters.BLANKVALUE,
          vat_des: selectedManualJournalDetails?.vat_rate_des || specialCharacters.BLANKVALUE,
          vat_id: selectedManualJournalDetails?.vat_id || specialCharacters.BLANKVALUE,
          amount_payment_type: selectedManualJournalDetails?.debit
            ? JOURNAL_PAYMENT_TYPE.DEBIT
            : JOURNAL_PAYMENT_TYPE.CREDIT,
          amt_type: selectedManualJournalDetails?.amt_type || JOURNAL_AMOUNT_TYPE.NET
        });
      }
    }
  }, [selectedManualJournalDetails]);

  useEffect(() => {
    if (voucherLineId && selectedManualJournalDetails && Object.keys(selectedManualJournalDetails).length > 0) {
      const journalLedgerCode = journalLedgerCodes
        ?.filter((s) => s.code === selectedManualJournalDetails?.ledger_code)
        .at(0);
      if (journalLedgerCode && !selectedJournalLedgerCode) {
        dispatch(cashBookJournalLedgerActions.selectRowLedgerCode(journalLedgerCode));
      }
    }
  }, [journalLedgerCodes, selectedManualJournalDetails]);

  useEffect(() => {
    if (voucherLineId && selectedManualJournalDetails && Object.keys(selectedManualJournalDetails).length > 0) {
      const fundCode = journalFundCodes?.filter((s) => s.code === selectedManualJournalDetails?.fund_code).at(0);
      if (fundCode && !selectedJournalFundCode) dispatch(cashBookJournalFundsActions.selectRowFundCode(fundCode));
    }
  }, [journalFundCodes, selectedManualJournalDetails]);

  useEffect(() => {
    if (voucherLineId && selectedManualJournalDetails && Object.keys(selectedManualJournalDetails).length > 0) {
      const vatCode = vatCodeList?.filter((s) => s.vat_code === selectedManualJournalDetails?.vat_code).at(0);
      if (vatCode && callVatCodeUseEffect) {
        setCallVatCodeUseEffect(false);
        dispatch(journalVatActions.selectRowVatCode(vatCode));
      }
    }
  }, [vatCodeList, selectedManualJournalDetails]);

  useEffect(() => {
    if (selectedRowVatCode?.vat_id) {
      dispatch(
        getVatRateRecoverableDeatils({
          vatId: selectedRowVatCode?.vat_id,
          callback: (res) => {
            if (res) {
              setVateRate(res.rate);
              setVateRecoverable(res.recoverable);
              setVateRecoverableRes(res);
            }
          }
        })
      );
    }
  }, [selectedRowVatCode]);

  const okFocus = (notificationType: any, message: string) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        notificationType: notificationType || NotificationStatus.HIGHLIGHT,
        title: t("common.simsFMSModule"),
        message: message ?? "",
        className: "primary-focus",
        callback: () => {
          if (resolve) resolve(isVal);
        }
      })
    );
  };
  const validateLine = () => {
    let valid = true;
    let isOpen = false;
    if (!watch("ledger_code")) {
      valid = false;
      isOpen = true;
      const message = t("common.invalidData");
      okFocus(NotificationStatus.WARNING, message);
    } else if (
      historyState?.mode !== METHOD.EDIT &&
      historyState?.selectedBankAccount?.leddef_id === selectedJournalLedgerCode?.id
    ) {
      valid = false;
      isOpen = true;
      const message = t("common.ledgerCodeError");
      okFocus(NotificationStatus.HIGHLIGHT, message);
      setError("ledger_code", { type: "manual", message });
    }
    return new Promise<boolean>((resolve, rejects) => {
      if (valid) {
        if (!isOpen) {
          resolve(true);
        } else {
          setResolve((prev: any) => resolve);
          setIsVal(true);
        }
      } else {
        setResolve((prev: any) => resolve);
        setIsVal(valid);
      }
    });
  };

  const saveJournalLine = async (payload: KeyValueType) => {
    dispatch(cbJLDActions.setSelectedManualJournalDetails({}));
    await dispatch(postCashBookDetails(payload as any));
  };

  const resrtAndClose = async () => {
    reset({
      narrative: "",
      cost_budget: "0.00",
      combination: "0.00",
      vat_amount: "0.00",
      fund_code: specialCharacters.BLANKVALUE,
      fund_des: specialCharacters.BLANKVALUE,
      ledger_code: specialCharacters.BLANKVALUE,
      ledger_des: specialCharacters.BLANKVALUE,
      cost_code: specialCharacters.BLANKVALUE,
      cost_des: specialCharacters.BLANKVALUE,
      vat_code: specialCharacters.BLANKVALUE,
      amount_payment_type: JOURNAL_PAYMENT_TYPE.DEBIT,
      amt_type: JOURNAL_AMOUNT_TYPE.NET
    });
    setIsShowArrowDown(false);
    dispatch(journalCostActions.reset());
    dispatch(cashBookJournalLedgerActions.reset());
    dispatch(cashBookJournalFundsActions.reset());
    dispatch(journalVatActions.reset());
    setValue("amount_payment_type", JOURNAL_PAYMENT_TYPE.DEBIT);
    history.replace(history.location, {
      ...historyState
    });
  };

  const updateAndNextLine = handleSubmit(
    async (data) => {
      dispatch(cbJLDActions.setIsSaveAPIRequired(true));
      let costId;
      let vatId;
      if (journalCostCenters.length > 0) {
        costId = journalCostCenters.filter((s) => s.code === data.cost_code).at(0)?.id;
      }
      if (vatCodeList.length > 0) {
        vatId = vatCodeList.filter((s) => s.vat_code === data.vat_code).at(0)?.id;
      }
      const isValid = await validateLine();
      let netAmount: string | number;
      let vatAmount: number;
      let grossAmount;
      let recoverableWarn;
      let submitModal = false;
      /* eslint-disable react/jsx-pascal-case */
      if (isValid) {
        if (vateRecoverable === "T") {
          if (watch("amt_type") === "Net") {
            netAmount = data.vat_amount;
            vatAmount = (Number(data?.vat_amount) / 100) * Number(vateRate);
            submitModal = false;
          } else {
            netAmount = (100 * Number(data?.vat_amount)) / (100 + Number(vateRate));
            vatAmount = (netAmount / 100) * Number(vateRate);
            recoverableWarn = `You have entered a GROSS amount of ${usNumberFormat(
              Number(data.vat_amount)
            )} against a Ledger code which is linked to the recoverable VAT code ${
              selectedRowVatCode?.vat_code
            }. The line will be entered into the system with a NET amount of ${usNumberFormat(
              netAmount
            )} and the VAT of ${usNumberFormat(vatAmount)} will be accounted for.`;
            submitModal = true;
            setIsOpen(true);
          }
        } else if (watch("amt_type") === "Net" && vateRecoverableRes !== undefined) {
          netAmount = Number(data?.vat_amount);
          vatAmount = (netAmount / 100) * Number(vateRate);
          grossAmount = ((100 / Number(vateRate)) * netAmount) / 100;
          recoverableWarn = `You have entered a NET amount of ${usNumberFormat(
            netAmount
          )} against a Ledger code linked to the non-recoverable VAT code ${
            selectedRowVatCode?.vat_code
          }. The line will be entered into the system with a GROSS amount of ${usNumberFormat(
            grossAmount
          )} and the VAT of ${usNumberFormat(vatAmount)} will be noted as memo only.`;
          submitModal = true;
          setIsOpen(true);
        } else {
          netAmount = (100 * Number(data?.vat_amount)) / (100 + Number(vateRate));
          vatAmount = (netAmount / 100) * Number(vateRate);
          submitModal = false;
        }

        if (vateRecoverableRes === undefined) {
          submitModal = false;
        }
        const payload = {
          voucher_id: voucherId,
          voucher_line_id: selectedManualJournalDetails?.voucher_line_id ?? 0,
          ledger_id: selectedJournalLedgerCode?.id,
          fund_id: isLedgerType ? selectedJournalFundCode?.id : undefined,
          cost_id: isLedgerType ? costId : undefined,
          ledger_code: data.ledger_code,
          ledger_des: data.ledger_des,
          fund_code: isLedgerType ? data.fund_code : specialCharacters.BLANKVALUE,
          cost_code: isLedgerType ? data.cost_code : specialCharacters.BLANKVALUE,
          cost_des: isLedgerType ? data.cost_des : specialCharacters.BLANKVALUE,
          vat_code: isLedgerType ? data.vat_code : specialCharacters.BLANKVALUE,
          vat_id: selectedRowVatCode ? selectedRowVatCode?.vat_id : vatId,
          debit: data.amount_payment_type === "D" ? Number(data.vat_amount) : 0,
          credit: data.amount_payment_type === "C" ? Number(data.vat_amount) : 0,
          narrative: data.narrative,
          vat_amount: vatAmount,
          isEdited: !!Object.keys(selectedManualJournalDetails).length
        };

        if (submitModal && vateRecoverableRes !== undefined) {
          setTimeout(() => {
            const foucusButton = document.querySelector(
              ".essui-overlay-container .essui-button--primary"
            ) as HTMLElement;
            if (foucusButton) {
              foucusButton.focus();
            }
          }, 10);

          dispatch(
            uiActions.alertPopup({
              enable: true,
              type: MODAL_TYPE.ALERT,
              title: t("common.simsFMSModule"),
              notificationType: NotificationStatus?.WARNING,
              message: recoverableWarn,
              className: "primary-focus",
              callback: async () => {
                await saveJournalLine(payload);
                resrtAndClose();
              }
            })
          );
        } else {
          await saveJournalLine(payload);
          resrtAndClose();
          document.getElementById("txtJournalLedgerCode")?.focus();
          history.replace({
            ...history.location,
            state: {
              ...historyState,
              isDirty: true
            }
          });
        }
      }
    },
    (error) => {
      const message = t("common.invalidData");
      okFocus(NotificationStatus.HIGHLIGHT, message);
    }
  );
  const updateClose = handleSubmit(
    async (dataVal) => {
      dispatch(cbJLDActions.setIsSaveAPIRequired(true));
      const isValid = await validateLine();
      let netAmount: string | number;
      let vatAmount: number;
      let grossAmount;
      let recoverableWarn;
      let submitModal = false;
      if (isValid) {
        if (vateRecoverable === "T") {
          if (watch("amt_type") === "Net") {
            netAmount = dataVal.vat_amount;
            vatAmount = (Number(dataVal?.vat_amount) / 100) * Number(vateRate);
            submitModal = false;
          } else {
            netAmount = (100 * Number(dataVal?.vat_amount)) / (100 + Number(vateRate));
            vatAmount = (netAmount / 100) * Number(vateRate);
            recoverableWarn = `You have entered a GROSS amount of ${usNumberFormat(
              Number(dataVal.vat_amount)
            )} against a Ledger code which is linked to the recoverable VAT code ${
              selectedRowVatCode?.vat_code
            }. The line will be entered into the system with a NET amount of ${usNumberFormat(
              netAmount
            )} and the VAT of ${usNumberFormat(vatAmount)} will be accounted for.`;
            submitModal = true;
            setIsOpen(true);
          }
        } else if (watch("amt_type") === "Net" && vateRecoverableRes !== undefined) {
          netAmount = Number(dataVal?.vat_amount);
          vatAmount = (netAmount / 100) * Number(vateRate);
          grossAmount = ((100 + Number(vateRate)) * netAmount) / 100;
          recoverableWarn = `You have entered a NET amount of ${usNumberFormat(
            netAmount
          )} against a Ledger code linked to the non-recoverable VAT code ${
            selectedRowVatCode?.vat_code
          }. The line will be entered into the system with a GROSS amount of ${usNumberFormat(
            grossAmount
          )} and the VAT of ${usNumberFormat(vatAmount)} will be noted as memo only.`;
          submitModal = true;
          setIsOpen(true);
        } else {
          netAmount = (100 * Number(dataVal?.vat_amount)) / (100 + Number(vateRate));
          vatAmount = (netAmount / 100) * Number(vateRate);
          submitModal = false;
        }
        let payload: any;
        if (voucherLineId && selectedManualJournalDetails) {
          let costId;
          let fundId;
          let ledgerId;
          let vatId;
          if (journalCostCenters.length > 0) {
            costId = journalCostCenters.filter((s) => s.code === dataVal.cost_code).at(0)?.id;
          }
          if (journalFundCodes.length > 0) {
            fundId = journalFundCodes.filter((s) => s.code === dataVal.fund_code).at(0)?.id;
          }
          if (journalLedgerCodes.length > 0) {
            ledgerId = journalLedgerCodes.filter((s) => s.code === dataVal.ledger_code).at(0)?.id;
          }
          if (vatCodeList.length > 0) {
            vatId = vatCodeList.filter((s) => s.vat_code === dataVal.vat_code).at(0)?.id;
          }
          payload = {
            voucher_id: Number(voucherId),
            voucher_line_id: selectedManualJournalDetails?.voucher_line_id ?? 0,
            ledger_id: selectedJournalLedgerCode ? selectedJournalLedgerCode?.id : ledgerId,
            cost_id: selectedJournalCostCentre ? selectedJournalCostCentre?.id : costId,
            vat_id: selectedRowVatCode ? selectedRowVatCode?.vat_id : vatId,
            debit: dataVal.amount_payment_type === "D" ? netAmount : 0,
            credit: dataVal.amount_payment_type === "C" ? netAmount : 0,
            narrative: dataVal?.narrative,
            vat_amount: vatAmount,
            fund_id: selectedJournalFundCode ? selectedJournalFundCode?.id : fundId,
            isEdited: !!Object.keys(selectedManualJournalDetails).length
          };
        } else {
          let costId;
          if (journalCostCenters.length > 0) {
            costId = journalCostCenters.filter((s) => s.code === dataVal.cost_code).at(0)?.id;
          }
          payload = {
            voucher_id: Number(voucherId),
            voucher_line_id: selectedManualJournalDetails?.voucher_line_id ?? 0,
            ledger_id: Number(selectedJournalLedgerCode?.id),
            cost_id: isLedgerType ? costId : undefined,
            vat_id: isLedgerType ? Number(selectedRowVatCode?.vat_id) : undefined,
            debit: dataVal.amount_payment_type === "D" ? netAmount : 0,
            credit: dataVal.amount_payment_type === "C" ? netAmount : 0,
            narrative: dataVal?.narrative,
            vat_amount: vatAmount,
            fund_id: isLedgerType ? Number(selectedJournalFundCode?.id) : undefined,
            isEdited: !!Object.keys(selectedManualJournalDetails).length
          };
        }
        if (vateRecoverableRes === undefined) {
          submitModal = false;
        }

        if (submitModal && vateRecoverableRes !== undefined) {
          setTimeout(() => {
            const foucusButton = document.querySelector(
              ".essui-overlay-container .essui-button--primary"
            ) as HTMLElement;
            if (foucusButton) {
              foucusButton.focus();
            }
          }, 100);
          dispatch(
            uiActions.alertPopup({
              enable: true,
              type: MODAL_TYPE.ALERT,
              title: t("common.simsFMSModule"),
              notificationType: NotificationStatus?.WARNING,
              message: recoverableWarn,
              className: "recoverable-warning",
              callback: async () => {
                await saveJournalLine(payload);
                history.push({
                  pathname: `/general-ledger/manual-journal-list/edit/${voucherId}`,
                  state: { ...historyState, isDirty: true, from: "journalLines" }
                });
              }
            })
          );
        } else {
          await saveJournalLine(payload);
          history.push({
            pathname: `/general-ledger/manual-journal-list/edit/${voucherId}`,
            state: { ...historyState, isDirty: true, from: "journalLines" }
          });
        }
      }
    },
    (error) => {
      const message = t("common.invalidData");
      okFocus(NotificationStatus.HIGHLIGHT, message);
    }
  );

  useEffect(() => {
    dispatch(
      getjournalCostCentersDebitCredit({
        leddefId: selectedJournalLedgerCode ? selectedJournalLedgerCode?.id : undefined,
        callback: (res) => {
          if (res) {
            setLedgerType(res.LedgerType);
            if (isCreditDebitAPIReq && res?.DebitCredit !== null) {
              setValue(
                "amount_payment_type",
                res?.DebitCredit === "C" ? JOURNAL_PAYMENT_TYPE.CREDIT : JOURNAL_PAYMENT_TYPE.DEBIT
              );
            }
            if (historyState.selectedBankAccount?.leddef_id === selectedJournalLedgerCode?.id) {
              setMessage(t("common.ledgerCodeError"));
            }
          }
        }
      })
    );
  }, [selectedJournalLedgerCode]);

  // manually checking isFormDirty or not, coz, on edit page, isDirty is always true .
  const isInitialStateMaintain = () => {
    const initialStateValue = historyState?.selectedBankAccount;
    let isAmountChanged = false;
    if (initialStateValue?.credit || initialStateValue?.debit) {
      if (initialStateValue?.credit) {
        isAmountChanged =
          Number(getValues("vat_amount")) !== initialStateValue?.credit || getValues("amount_payment_type") !== "C";
      }
      if (initialStateValue?.debit) {
        isAmountChanged =
          Number(getValues("vat_amount")) !== initialStateValue?.debit || getValues("amount_payment_type") !== "D";
      }
    } else {
      isAmountChanged = Number(getValues("vat_amount")) > 0;
    }
    return (
      (initialStateValue?.ledger_code
        ? getValues("ledger_code") !== initialStateValue?.ledger_code
        : getValues("ledger_code") !== "") ||
      (initialStateValue?.cost_code
        ? getValues("cost_code") !== initialStateValue?.cost_code
        : getValues("cost_code") !== "") ||
      (initialStateValue?.fund_code
        ? getValues("fund_code") !== initialStateValue?.fund_code
        : getValues("fund_code") !== "") ||
      (initialStateValue?.vat_code
        ? getValues("vat_code") !== initialStateValue?.vat_code
        : getValues("vat_code") !== "") ||
      getValues("narrative") !== initialStateValue?.narrative ||
      isAmountChanged
    );
  };

  return (
    <>
      {status === STATUS.LOADING || mjDetailStatus === STATUS.LOADING ? <Loader loadingConfig={loaderConfig} /> : null}
      <FormProvider {...formMethods}>
        <Layout
          pageTitle={t("manualJournalPage.journalLineDetails")}
          className="cashbook__journal--line"
        >
          <Grid
            dataTestId="test-id"
            className="row-gap-16 mb-8"
          >
            {(journalCostCentreStatus === STATUS.LOADING ||
              journalLedgerCodeStatus === STATUS.LOADING ||
              journalFundCodeStatus === STATUS.LOADING) &&
            isLoading === false ? (
              <Loader loadingConfig={loaderConfig} />
            ) : null}

            <GridItem
              sm={4}
              md={12}
              lg={5}
              xl={5}
              xxl={5}
            >
              <FormLabel
                className="mb-5"
                forId="txtJournalLedgerCode"
              >
                {t("manualJournal.ledgerCode")}
              </FormLabel>
              <Grid className="set__table--hegiht">
                <GridItem className="pr-8">
                  <Input
                    id="txtJournalLedgerCode"
                    autoFocus
                    isLabel={false}
                    inputWidth={156}
                    maxLength={100}
                    value={watch("ledger_code")}
                    searchable
                    searchItems={journalLedgerCodes.map((b) => ({
                      text: b.code,
                      value: b.code
                    }))}
                    inputRef={(e) => register("ledger_code").ref(e)}
                    name={
                      register("ledger_code", {
                        required: true,
                        validate: (value) => true
                      }).name
                    }
                    onChange={(e) => {
                      setValue("ledger_code", e.target.value);
                      setValue("ledger_des", e.target.value ? getValues("ledger_des") : specialCharacters.BLANKVALUE);
                      register("ledger_code").onChange(e);
                    }}
                    onBlur={(e: any) => {
                      register("ledger_code").onBlur(e);
                      if (e.target.value === "") {
                        setValue("fund_code", specialCharacters.BLANKVALUE);
                        setValue("fund_des", specialCharacters.BLANKVALUE);
                        trigger("ledger_code");
                      }
                    }}
                    onSelect={(selectedItem) => {
                      const journalLedgerCode = journalLedgerCodes.filter((s) => s.code === selectedItem?.value).at(0);
                      setValue(
                        "ledger_des",
                        journalLedgerCodes.length === 1 || (selectedItem?.text && getValues("ledger_code") !== "")
                          ? journalLedgerCode?.description
                          : specialCharacters.BLANKVALUE
                      );
                      setValue("ledger_code", selectedItem?.text ? selectedItem.text! : specialCharacters.BLANKVALUE);
                      setValue("ledger_id", journalLedgerCode?.id);
                      dispatch(cashBookJournalLedgerActions.selectRowLedgerCode(journalLedgerCode));
                    }}
                    onPending={(selectedItem) => {
                      const journalLedgerCode = journalLedgerCodes.filter((s) => s.code === selectedItem?.value).at(0);
                      setValue("ledger_des", journalLedgerCode?.description);
                      if (journalLedgerCode) {
                        dispatch(
                          getjournalCostCentersDebitCredit({
                            leddefId: journalLedgerCode ? journalLedgerCode?.id : undefined,
                            callback: (resp) => {
                              if (resp) {
                                const isLedgerCodeType = checkGlLedgerType({ value: resp.LedgerType } as any);
                                dispatch(cashBookJournalLedgerActions.setIsLedgerType(isLedgerCodeType));
                                dispatch(
                                  getLinkedVatCode({
                                    leddefId: journalLedgerCode ? journalLedgerCode?.id : undefined,
                                    callback: (res) => {
                                      if (res) {
                                        setLedgerType(resp.LedgerType);
                                        setValue("vat_code", res.vat_code);
                                        setValue("vat_des", res.vat_rate_des);
                                      }
                                    }
                                  })
                                );
                              }
                            }
                          })
                        );
                      } else {
                        dispatch(cashBookJournalLedgerActions.selectRowLedgerCode(journalLedgerCode));
                        setValue("cost_code", specialCharacters.BLANKVALUE);
                        setValue("cost_des", specialCharacters.BLANKVALUE);
                        setLedgerType("");
                        setValue("vat_code", specialCharacters.BLANKVALUE);
                        setValue("vat_des", specialCharacters.BLANKVALUE);
                        setValue("cost_budget", "0.00");
                        setValue("combination", "0.00");
                      }
                    }}
                    onNoSelection={() => setIsOpenLedgerCodesModal(true)}
                    validationTextLevel={errors.ledger_code ? ValidationTextLevel.Error : undefined}
                  />
                </GridItem>
                <GridItem className="pl-0 sequence-row">
                  <Tooltip content={watch("ledger_des")}>
                    <div className="essui-textinput essui-textinput--medium read-only width-360 playback word-wrap">
                      {watch("ledger_des")}
                    </div>
                  </Tooltip>
                  <div className="pt-8">
                    <Button
                      id="btnJournalLedgerCode"
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      onClick={ledgerCodeClick}
                      aria-label="search"
                      className="essui-button-icon-only--small"
                    >
                      <Icon
                        color={IconColor.Primary500}
                        size={IconSize.Medium}
                        name="search"
                      />
                    </Button>
                  </div>
                </GridItem>
              </Grid>
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={5}
              xl={5}
              xxl={5}
            >
              <div>
                <FormLabel
                  className="mb-5"
                  forId="txtVatCode"
                >
                  {t("manualJournal.vatCode")}
                </FormLabel>

                <Grid>
                  <GridItem className="pr-8">
                    <Input
                      id="txtJournalVatCentre"
                      autoFocus
                      inputWidth={156}
                      isLabel={false}
                      maxLength={100}
                      value={watch("vat_code")}
                      searchable
                      disabled={!(ledgerType === "IN" || ledgerType === "EX" || ledgerType === "AF")}
                      searchItems={
                        vatCodeList
                          ? vatCodeList.map((b) => ({
                              text: b.vat_code,
                              value: b.vat_code
                            }))
                          : []
                      }
                      inputRef={(e) => register("vat_code").ref(e)}
                      name={
                        register("vat_code", {
                          required:
                            !(!isLedgerType || watch("ledger_code") === "") &&
                            (ledgerType === "IN" || ledgerType === "EX" || ledgerType === "AF")
                        }).name
                      }
                      onChange={(e) => {
                        setValue("vat_code", e.target.value);
                        setValue("vat_des", e.target.value ? getValues("vat_des") : specialCharacters.BLANKVALUE);
                      }}
                      onBlur={(e: any) => {
                        register("vat_code").onBlur(e);
                      }}
                      onSelect={(selectedItem) => {
                        const costCenter = vatCodeList.filter((s) => s.vat_code === selectedItem?.value).at(0);
                        setValue(
                          "vat_des",
                          vatCodeList.length === 1 || (selectedItem?.text && getValues("vat_code") !== "")
                            ? costCenter?.vat_rate_des
                            : specialCharacters.BLANKVALUE
                        );
                        setValue("vat_code", selectedItem?.text ? selectedItem.text! : specialCharacters.BLANKVALUE);
                        dispatch(journalVatActions.selectRowVatCode(costCenter));
                      }}
                      onPending={(selectedItem) => {
                        const costCenter = vatCodeList.filter((s) => s.vat_code === selectedItem?.value).at(0);
                        setValue("vat_des", costCenter?.vat_rate_des);
                        if (costCenter === undefined) {
                          setValue("vat_code", specialCharacters.BLANKVALUE, { shouldDirty: true });
                          setValue("vat_des", specialCharacters.BLANKVALUE);
                          dispatch(journalVatActions.selectRowVatCode(undefined));
                        }
                      }}
                      onNoSelection={() => setIsOpenVATCodesModal(true)}
                      validationTextLevel={errors.vat_code ? ValidationTextLevel.Error : undefined}
                    />
                  </GridItem>

                  <GridItem className="pl-0 sequence-row">
                    <Tooltip content={getValues("vat_des")}>
                      <div
                        className={`${
                          !isLedgerType ? "disabled-input word-wrap" : null
                        } read-only essui-textinput essui-textinput--medium width-360 playback word-wrap`}
                      >
                        {watch("vat_des")}
                      </div>
                    </Tooltip>
                    <div className="pt-8">
                      <Button
                        id="btnJournalFundCode"
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        onClick={VATCodeClick}
                        className={`essui-button-icon-only--small btnclass ${
                          !(ledgerType === "IN" || ledgerType === "EX" || ledgerType === "AF") ? "disabled" : null
                        }`}
                        disabled={!(ledgerType === "IN" || ledgerType === "EX" || ledgerType === "AF")}
                        aria-label="search"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </div>
                  </GridItem>
                </Grid>
              </div>
            </GridItem>
          </Grid>

          <Grid className="row-gap-16">
            <GridItem
              sm={5}
              md={12}
              lg={5}
              xl={5}
              xxl={5}
            >
              <FormLabel
                className="mb-5"
                forId="txtJournalFundCode"
              >
                {t("manualJournal.fundCode")}
              </FormLabel>
              <Grid>
                <GridItem className="pr-8">
                  <Input
                    id="txtJournalFundCode"
                    autoFocus
                    isLabel={false}
                    inputWidth={156}
                    maxLength={100}
                    value={watch("fund_code")}
                    searchable
                    disabled={!isLedgerType || watch("ledger_code") === ""}
                    searchItems={journalFundCodes.map((b) => ({
                      text: b.code,
                      value: b.code
                    }))}
                    inputRef={(e) => register("fund_code").ref(e)}
                    name={
                      register("fund_code", {
                        required: !(!isLedgerType || watch("ledger_code") === "")
                      }).name
                    }
                    onChange={(e) => {
                      setValue("fund_code", e.target.value);
                      setValue("fund_des", e.target.value ? getValues("fund_des") : specialCharacters.BLANKVALUE);
                    }}
                    onBlur={(e: any) => {
                      register("fund_code").onBlur(e);
                    }}
                    onSelect={(selectedItem) => {
                      const fundCode = journalFundCodes.filter((s) => s.code === selectedItem?.value).at(0);
                      setValue(
                        "fund_des",
                        journalFundCodes.length === 1 || (selectedItem?.text && getValues("fund_code") !== "")
                          ? fundCode?.description
                          : specialCharacters.BLANKVALUE
                      );
                      setValue("fund_code", selectedItem?.text ? selectedItem.text! : specialCharacters.BLANKVALUE);
                      dispatch(cashBookJournalFundsActions.selectRowFundCode(fundCode));
                    }}
                    onPending={(selectedItem) => {
                      const fundCode = journalFundCodes.filter((s) => s.code === selectedItem?.value).at(0);
                      if (fundCode === undefined) {
                        dispatch(cashBookJournalFundsActions.selectRowFundCode(undefined));
                      }
                    }}
                    onNoSelection={() => setIsOpenFundsCodesModal(true)}
                    validationTextLevel={errors.fund_code ? ValidationTextLevel.Error : undefined}
                  />
                </GridItem>
                <GridItem className="pl-0 sequence-row">
                  <Tooltip content={getValues("fund_des")}>
                    <div
                      className={`${
                        !isLedgerType ? "disabled-input word-wrap" : null
                      } read-only essui-textinput essui-textinput--medium width-360 playback word-wrap`}
                    >
                      {watch("fund_des")}
                    </div>
                  </Tooltip>
                  <div className="pt-8">
                    <Button
                      id="btnJournalFundCode"
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      onClick={FundsCodeClick}
                      className={`essui-button-icon-only--small btnclass ${
                        !isLedgerType || watch("ledger_code") === "" ? "disabled" : null
                      }`}
                      disabled={!isLedgerType || watch("ledger_code") === ""}
                      aria-label="search"
                    >
                      <Icon
                        color={IconColor.Primary500}
                        size={IconSize.Medium}
                        name="search"
                      />
                    </Button>
                  </div>
                </GridItem>
              </Grid>
            </GridItem>
            <GridItem
              sm={5}
              md={12}
              lg={5}
              xl={5}
              xxl={5}
            >
              <FormLabel
                className="mb-5"
                forId="txtJournalCostCentre"
              >
                {t("manualJournal.costCentre")}
              </FormLabel>
              <Grid>
                <GridItem className="pr-8">
                  <Input
                    id="txtJournalCostCentre"
                    autoFocus
                    inputWidth={156}
                    isLabel={false}
                    maxLength={100}
                    value={watch("cost_code")}
                    searchable
                    disabled={!isLedgerType || watch("ledger_code") === ""}
                    searchItems={journalCostCenters.map((b) => ({
                      text: b.code,
                      value: b.code
                    }))}
                    inputRef={(e) => register("cost_code").ref(e)}
                    name={
                      register("cost_code", {
                        required: !(!isLedgerType || watch("ledger_code") === "")
                      }).name
                    }
                    onChange={(e) => {
                      setValue("cost_code", e.target.value);
                      setValue("cost_des", e.target.value ? getValues("cost_des") : specialCharacters.BLANKVALUE);
                    }}
                    onBlur={(e: any) => {
                      register("cost_code").onBlur(e);
                    }}
                    onSelect={(selectedItem) => {
                      const costCenter = journalCostCenters.filter((s) => s.code === selectedItem?.value).at(0);
                      setValue(
                        "cost_des",
                        journalCostCenters.length === 1 || (selectedItem?.text && getValues("cost_code") !== "")
                          ? costCenter?.description
                          : specialCharacters.BLANKVALUE
                      );
                      setValue("cost_code", selectedItem?.text ? selectedItem.text! : specialCharacters.BLANKVALUE);
                      dispatch(journalCostActions.selectRowCostCentre(costCenter));
                    }}
                    onPending={(selectedItem) => {
                      const costCenter = journalCostCenters.filter((s) => s.code === selectedItem?.value).at(0);
                      setValue("cost_des", costCenter?.description);
                      if (costCenter === undefined) {
                        dispatch(journalCostActions.selectRowCostCentre(undefined));
                        setValue("cost_budget", "0.00");
                        setValue("combination", "0.00");
                      }
                    }}
                    onNoSelection={() => setIsOpenCostCentresCodesModal(true)}
                    validationTextLevel={errors.cost_code ? ValidationTextLevel.Error : undefined}
                    onKeyDown={(e) => {
                      if (e.key === "Tab") {
                        if (journalFundCodes.length === 1 && watch("fund_code") === "") {
                          setValue("fund_code", journalFundCodes[0].code, { shouldValidate: true });
                          setValue("fund_des", journalFundCodes[0].description);
                          dispatch(cashBookJournalFundsActions.selectRowFundCode(journalFundCodes[0]));
                        }
                      }
                    }}
                  />
                </GridItem>
                <GridItem className="pl-0 sequence-row">
                  <Tooltip content={getValues("cost_des")}>
                    <div
                      className={`${
                        !isLedgerType ? "disabled-input word-wrap" : null
                      } read-only essui-textinput essui-textinput--medium width-360 playback word-wrap`}
                    >
                      {watch("cost_des")}
                    </div>
                  </Tooltip>
                  <div className="pt-8">
                    <Button
                      id="btnJournalCostCenter"
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      onClick={CostCentresCodeClick}
                      aria-label="search"
                      className={`essui-button-icon-only--small btnclass ${
                        !isLedgerType || watch("ledger_code") === "" ? "disabled" : null
                      }`}
                      disabled={!isLedgerType || watch("ledger_code") === ""}
                    >
                      <Icon
                        color={IconColor.Primary500}
                        size={IconSize.Medium}
                        name="search"
                      />
                    </Button>
                  </div>
                </GridItem>
              </Grid>
            </GridItem>
          </Grid>

          <Divider />

          <Grid className="row-gap-16 mt-10">
            <GridItem
              sm={5}
              md={8}
              lg={12}
              xl={5}
              xxl={5}
            >
              <div>
                <FormLabel
                  forId="txtJournalAmount"
                  className="mb-5"
                >
                  {t("manualJournal.amount")}
                </FormLabel>
                <InputNumberMask
                  beforeDecimalMaxLength={10} // Max length of the number before the decimal point
                  beforeDecimalCursorIndex={13}
                  afterDecimalCursorIndex={14}
                  className="essui-textinput essui-textinput--medium w-100 custom-placeholder"
                  placeholder="0.00"
                  getInputRef={inputNumRef}
                  value={getValues("vat_amount") || "0.00"}
                  decimalSeparator="."
                  decimalScale={2}
                  fixedDecimalScale
                  thousandSeparator
                  validationTextLevel={errors.vat_amount ? ValidationTextLevel.Error : undefined}
                  name={
                    register("vat_amount", {
                      validate: (value) => {
                        let isValid = (parseFloat(value) || 0) >= 0.0 && (parseFloat(value) || 0) < 100000000000.0;
                        if (isValid && getValues("quantity")) {
                          isValid =
                            (parseInt(getValues("quantity"), 10) || 0) * (parseFloat(value) || 0) < 100000000000.0;
                        }
                        return isValid;
                      }
                    }).name
                  }
                  onValueChange={(inputVal) => {
                    const { formattedValue, value, floatValue } = inputVal;
                    if (value === "") {
                      const zeroValue = "0.00";
                      setValue("vat_amount", zeroValue);
                    } else {
                      setValue("vat_amount", value, { shouldDirty: true });
                    }
                    trigger("vat_amount");
                  }}
                />
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={12}
              xl={4}
              xxl={4}
              className="d-flex"
            >
              <div className="d-flex row-gap-16 debit__radio--btn">
                <div className="">
                  <FormLabel className="mb-5">&nbsp;</FormLabel>
                  <div className="d-flex">
                    <div className="essui-textinput sequence radio__btn--spacing mr-16">
                      <RadioButton
                        label={t("manualJournalPage.net")}
                        labelPosition={RadioLabelPosition.Right}
                        value={JOURNAL_AMOUNT_TYPE.NET}
                        name="amt_type"
                        onChange={(e) => {
                          setValue("amt_type", e.target.value, { shouldDirty: true });
                        }}
                        isSelected={watch("amt_type") === JOURNAL_AMOUNT_TYPE.NET}
                      />
                      <RadioButton
                        label={t("manualJournalPage.gross")}
                        labelPosition={RadioLabelPosition.Right}
                        value={JOURNAL_AMOUNT_TYPE.GROSS}
                        name="amt_type"
                        onChange={(e) => {
                          setValue("amt_type", e.target.value, { shouldDirty: true });
                        }}
                        isSelected={watch("amt_type") === JOURNAL_AMOUNT_TYPE.GROSS}
                      />
                    </div>
                  </div>
                </div>
                <div className="">
                  <FormLabel className="mb-5">{t("manualJournal.debitCredit")}</FormLabel>
                  <div className="d-flex">
                    <div className="essui-textinput sequence radio__btn--spacing mr-8">
                      <RadioButton
                        label={t("manualJournalPage.debit")}
                        labelPosition={RadioLabelPosition.Right}
                        value={JOURNAL_PAYMENT_TYPE.DEBIT}
                        name="amount_payment_type"
                        onChange={(e) => {
                          setValue("amount_payment_type", e.target.value, { shouldDirty: true });
                          if (selectedJournalLedgerCode !== undefined) {
                            if (isShowArrowDown) {
                              setIsShowArrowDown(false);
                            } else {
                              setIsShowArrowDown(true);
                            }
                          }
                        }}
                        disabled={
                          manualJournalData &&
                          manualJournalData?.recurrencePattern &&
                          manualJournalData?.recurrencePattern.recurrence_pattern_id !== 0
                        }
                        isSelected={watch("amount_payment_type") === JOURNAL_PAYMENT_TYPE.DEBIT}
                      />
                      <RadioButton
                        label={t("manualJournalPage.credit")}
                        labelPosition={RadioLabelPosition.Right}
                        value={JOURNAL_PAYMENT_TYPE.CREDIT}
                        name="amount_payment_type"
                        onChange={(e) => {
                          setValue("amount_payment_type", e.target.value, { shouldDirty: true });
                          if (selectedJournalLedgerCode !== undefined) {
                            if (isShowArrowDown) {
                              setIsShowArrowDown(false);
                            } else {
                              setIsShowArrowDown(true);
                            }
                          }
                        }}
                        disabled={
                          manualJournalData &&
                          manualJournalData?.recurrencePattern &&
                          manualJournalData?.recurrencePattern.recurrence_pattern_id !== 0
                        }
                        isSelected={watch("amount_payment_type") === JOURNAL_PAYMENT_TYPE.CREDIT}
                      />
                    </div>
                    <div className="d-flex align-center">
                      {isShowArrowDown ? <ArrowDown size={32} /> : <ArrowUp size={32} />}
                    </div>
                  </div>
                </div>
              </div>
            </GridItem>

            <GridItem
              sm={4}
              md={10}
              lg={12}
              xl={10}
              xxl={10}
            >
              <div className="narrative__spacing">
                <Controller
                  render={({ field }) => (
                    <Input
                      id="narrative-input"
                      labelText={t("manualJournalPage.narrative")}
                      maxLength={60}
                      {...field}
                    />
                  )}
                  name="narrative"
                  control={control}
                />
              </div>
            </GridItem>
          </Grid>

          <Divider />

          <Grid className="bottom-section mt-10">
            <GridItem
              sm={2}
              md={4}
              lg={2}
              xl={3}
            >
              <div>
                <div className="essui-form-label mb-5">{t("manualJournal.costCentre")}</div> {}
                <div className={parseFloat(getValues("cost_budget")) < 0 ? "playback-error" : ""}>
                  {watch("cost_budget") ? watch("cost_budget") : "0.00"}
                </div>
              </div>
            </GridItem>
            <GridItem
              sm={2}
              md={4}
              lg={2}
              xl={3}
            >
              <div>
                <div className="essui-form-label mb-5">{t("manualJournal.combination")}</div>
                <div className={parseFloat(getValues("combination")) < 0 ? "playback-error" : ""}>
                  {watch("combination") ? watch("combination") : "0.00"}
                </div>
              </div>
            </GridItem>
          </Grid>

          <Grid
            justify="space-between"
            className="mt-8 flex-rev"
          >
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="rightbtn">
                <Button
                  id="btnJournalUpdateClose"
                  size={ButtonSize.Small}
                  color={ButtonColor.Primary}
                  onClick={async () => {
                    await updateClose();
                  }}
                >
                  {t("manualJournal.updateClose")}
                </Button>
                {!voucherLineId && (
                  <Button
                    size={ButtonSize.Small}
                    id="btnJournalUpdateNextLine"
                    color={ButtonColor.Secondary}
                    onClick={async () => {
                      await updateAndNextLine();
                    }}
                  >
                    {t("manualJournal.updateNextLine")}
                  </Button>
                )}
                <Button
                  size={ButtonSize.Small}
                  id="btnJournalCancel"
                  color={ButtonColor.Secondary}
                  onClick={() => {
                    const isAddurl = history?.location?.pathname?.includes("add");
                    if ((isAddurl && isDirty) || (!isAddurl && isInitialStateMaintain())) {
                      dispatch(
                        uiActions.confirmPopup({
                          enable: true,
                          message: t("alertMessage.keepChangesMsg"),
                          title: t("common.simsFMSModule"),
                          type: MODAL_TYPE.CONFIRMV2,
                          yesCallback: async () => {
                            await updateClose();
                          },
                          noCallback: () => {
                            history.push({
                              pathname: `/general-ledger/manual-journal-list/edit/${voucherId}`,
                              state: { ...historyState, from: "journalLines" }
                            });
                          },
                          isCancelBtnEnable: true
                        })
                      );
                    } else {
                      history.push({
                        pathname: `/general-ledger/manual-journal-list/edit/${voucherId}`,
                        state: { ...historyState, from: "journalLines" }
                      });
                    }
                  }}
                >
                  {t("common.cancel")}
                </Button>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <HelpButton
                identifier="testIdentifier"
                labelName="Help"
              />
            </GridItem>
          </Grid>
        </Layout>
        <CashBookJournalLedgerCodesModal
          selectedRow={selectedManualJournalDetails}
          isOpen={isOpenLedgerCodesModal}
          setOpen={setIsOpenLedgerCodesModal}
        />
        <CashBookJournalFundsModal
          isOpen={isOpenFundsCodesModal}
          setOpen={setIsOpenFundsCodesModal}
        />
        <CashBookJournalCostCentresModal
          isOpen={isOpenCostCentresCodesModal}
          setOpen={setIsOpenCostCentresCodesModal}
        />
        <CashBookJournalVATModal
          isOpen={isOpenVATCodesModal}
          setOpen={setIsOpenVATCodesModal}
        />

        <AlertModal
          isOpen={isOpenAlert}
          setOpen={setIsOpenAlert}
          title={t("alertMessage.title")}
          notificationType={alertType}
          message={message}
          callback={() => {
            if (resolve) resolve(isVal);
            setIsOpenAlert(false);
          }}
        />
      </FormProvider>
    </>
  );
};

export default CashBookJournalLineDetails;
