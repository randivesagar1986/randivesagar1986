import Input from "@/components/Input/Input";
import InputNumberMask from "@/components/Input/InputNumberMask";
import Layout from "@/components/Layout/Layout";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Button, ButtonColor, ButtonSize, FormLabel, Grid, GridItem } from "@essnextgen/ui-kit";
import React, { useEffect, useState } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useHistory, useParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import { getLedgerCodes } from "@/pages/ManualJournalProcessing/VatTranferJournalLineDetails/VatTransferLedgerCode/state/VatTransferLedgerCode.slice";
import { voucherTypeMapping } from "@/pages/GeneralLedgerSetup/utils";
import { fetchManualJournalDetails } from "@/pages/GeneralLedger/State/ManualJournalDetails.slice";
import {
  actions as cbJLDActions,
  postCashBookDetails
} from "@/pages/GeneralLedger/ManualJournalProcessing/CashBook/CashBookJournalLineDetails/State/CashBookJournalLineDetails.slice";
import { useAppContext } from "@/routes/Routes.utils";
import { uiActions } from "@/store/state/ui.slice";

const CashBookVATJournalLinePage = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const inputNumRef = React.useRef<HTMLInputElement>(null);
  const selectedRow = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.selectedRow);
  const { status, ledgerCodeDetails, selectedLeadgerCode } = useAppSelector((state) => state.vatTransferLedgerCode);
  const history = useHistory();
  const { setPromise } = useAppContext();
  const { voucherId, voucherLineId } = useParams<{ voucherId: string; voucherLineId: string }>();
  const historyState = history.location.state as any;
  const mappedVoucherType = voucherTypeMapping[historyState?.voucherType];
  const dispatch = useDispatch<AppDispatch>();

  const [amount, setAmount] = useState<string>("0.00");
  const [narrative, setNarrative] = useState<string>("");
  const [initialAmount, setInitialAmount] = useState<string>("");

  useEffect(() => {
    if (historyState.selectedRow) {
      setAmount(historyState.selectedRow.credit ? historyState.selectedRow.credit : historyState.selectedRow.debit);
      setInitialAmount(
        historyState.selectedRow.credit ? historyState.selectedRow.credit : historyState.selectedRow.debit
      );
      setNarrative(historyState.selectedRow.narrative);
    }
  }, [historyState]);

  useEffect(() => {
    dispatch(
      getLedgerCodes({
        sequence: 0,
        journalType: 4
      })
    );
    const timer = setTimeout(() => {
      inputNumRef.current?.focus();
    }, 10);
    return () => {
      clearTimeout(timer);
      dispatch(fetchManualJournalDetails({ voucherId, templateVoucherId: undefined }));
    };
  }, []);

  const redirectToMJPage = (isDirtyFlag: boolean) => {
    history.push({
      pathname: `/general-ledger/manual-journal-list/edit/${voucherId}`,
      state: { ...historyState, isDirty: isDirtyFlag }
    });
  };

  const updateClose = async () => {
    if (initialAmount !== amount || historyState.selectedRow?.narrative !== narrative) {
      dispatch(cbJLDActions.setIsSaveAPIRequired(true));
      const journalLedgerCode = ledgerCodeDetails
        ?.filter((s) => s.code === historyState.selectedRow?.ledger_code)
        .at(0);
      if (!journalLedgerCode) return;
      const journalLinePayload = {
        voucher_id: voucherId,
        voucher_line_id: Number(voucherLineId),
        ledger_id: journalLedgerCode.id,
        ledger_code: journalLedgerCode.code,
        ledger_des: journalLedgerCode.description,
        debit: historyState.selectedRow?.debit > 0 ? Number(amount) : 0,
        credit: historyState.selectedRow?.credit > 0 ? Number(amount) : 0,
        narrative,
        vat_amount: 0,
        isEdited: true,
        isVatEdit: true
      };
      if (!(journalLinePayload.debit || journalLinePayload.credit)) journalLinePayload.debit = Number(amount);
      await dispatch(postCashBookDetails(journalLinePayload as any));
      dispatch(cbJLDActions.setSelectedManualJournalDetails(undefined));
      dispatch(cbJLDActions.setSelectedRow(undefined));
      dispatch(cbJLDActions.setSelectedRowVat(undefined));
      redirectToMJPage(true);
    } else {
      redirectToMJPage(true);
    }
  };

  const onCancelHandler = async () => {
    const result = await setPromise((resolve: any) => checkSaveChanges(resolve));
    if (result !== undefined) {
      if (result === false) {
        redirectToMJPage(false);
      } else if (result === true) {
        updateClose();
      }
    }
  };

  const checkSaveChanges = (resolve?: any) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: "invalidData",
        className: "delete-alert",
        callback: () => {
          if (resolve) resolve(true);
        }
      })
    );

    setTimeout(() => {
      const focusButton = document.querySelector(".essui-overlay-container .essui-button--primary") as HTMLElement;
      if (focusButton) {
        focusButton.focus();
      }
    }, 10);
  };

  return (
    <Layout
      pageTitle={t("manualJournalPage.journalLineDetails")}
      className="var__transfer--journal set__table--hegiht"
    >
      <Grid
        dataTestId="test-id"
        className="row-gap-16"
      >
        <GridItem
          sm={4}
          md={4}
          lg={4}
          xl={4}
          xxl={4}
        >
          <div>
            <FormLabel
              forId="txtAmount"
              className="mb-5"
            >
              {t("manualJournal.amount")}
            </FormLabel>
            <InputNumberMask
              beforeDecimalMaxLength={10} // Max length of the number before the decimal point
              beforeDecimalCursorIndex={13}
              afterDecimalCursorIndex={14}
              className="essui-textinput essui-textinput--medium w-100 custom-placeholder"
              placeholder="0.00"
              getInputRef={inputNumRef}
              value={amount}
              decimalSeparator="."
              decimalScale={2}
              fixedDecimalScale
              thousandSeparator
              name="amount"
              onValueChange={(inputVal) => {
                const { formattedValue, value, floatValue } = inputVal;
                if (value === "") {
                  setAmount("0.00");
                } else {
                  setAmount(value);
                }
              }}
            />
          </div>
        </GridItem>
        <GridItem
          sm={4}
          md={8}
          lg={11}
          xl={11}
          xxl={11}
        >
          <div className="narrative__spacing mr-0-responsive">
            <FormLabel
              forId="txtNarrative"
              className="mb-5"
            >
              {t("manualJournalPage.narrative")}
            </FormLabel>
            <Input
              searchable
              id="txtNarrative"
              maxLength={60}
              name="narrative"
              value={narrative}
              onChange={(e) => setNarrative(e.target.value)}
            />
          </div>
        </GridItem>
      </Grid>
      <Grid
        justify="space-between"
        className="mt-8 flex-rev"
      >
        <GridItem
          sm={4}
          md={4}
          lg={6}
          xl={6}
        >
          <div className="rightbtn">
            <Button
              id="btnUpdateClose"
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
              onClick={async () => {
                updateClose();
              }}
            >
              {t("manualJournal.updateClose")}
            </Button>
            <Button
              id="manual-journal-btn-cancel"
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
              onClick={async () => {
                onCancelHandler();
              }}
            >
              {t("common.cancel")}
            </Button>
          </div>
        </GridItem>
        <GridItem
          sm={4}
          md={4}
          lg={6}
          xl={6}
        >
          <HelpButton
            identifier="testIdentifier"
            labelName="Help"
          />
        </GridItem>
      </Grid>
    </Layout>
  );
};

export default CashBookVATJournalLinePage;
