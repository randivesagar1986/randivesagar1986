import GridTableNew, { RowType } from "@/components/GridTableNew/GridTableNew";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import React, { useEffect, useState } from "react";
import { useForm, useFormContext } from "react-hook-form";
import { useDispatch } from "react-redux";
import BodyUtil from "@/shared/utils/NoScroll";
import { useHistory } from "react-router-dom";
import { localRoutes } from "@/utils/constants";
import { getVatPeriods, vatPeriodAction } from "../../State/VatManualJournalPeriods.slice";
import VatSelectPeriodsFilters from "./Grid/VatSelectPeriodsFilters";
import { fetchPeriods, mjPeriodssActions } from "../../State/ManualJournalPeriods.slice";

type PropsType = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
};

const VatSelectPeriodModal = ({ setOpen, isOpen }: PropsType) => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const { vatPeriods, status, selectedRowVat, filters, columnDef } = useAppSelector(
    (state) => state.vatManualJournalPeriods
  );
  const history = useHistory();
  const {
    location: { pathname }
  } = history;
  const { setValue } = useFormContext();
  const [row, setRow] = useState<any>(selectedRowVat);

  const closeHandler = () => {
    setOpen(false);
    dispatch(mjPeriodssActions.setFilters({ lookingFor: "" }));
  };

  useEffect(
    () => () => {
      BodyUtil.NoScroll.remove();
    },
    []
  );

  useEffect(() => {
    const { field } = columnDef.filter((col) => !!col.sequence)[0];
    dispatch(mjPeriodssActions.setFilters({ ...filters, sequenceValue: field }));
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) {
      dispatch(fetchPeriods({ sequence: Number(filters?.sequenceIndex) }));
    }
  }, [isOpen, filters?.sequenceIndex]);

  const selectHandler = () => {
    dispatch(mjPeriodssActions.setSelectedRow(row));
    setValue("period_no", row.period_no);
    setValue("period_description", row.description);
    closeHandler();
  };

  useEffect(() => {
    if (
      pathname.includes(localRoutes.manualtJournalProcessing.manualJournalContra) ||
      pathname.includes(localRoutes.manualtJournalProcessing.manualJournalEdit)
    ) {
      setRow(selectedRowVat);
    }
  }, [selectedRowVat]);

  const tertiaryButton = (
    <HelpButton
      identifier="testIdentifier"
      labelName={t("common.help")}
    />
  );

  const secondaryButton = (
    <Button
      size={ButtonSize.Small}
      color={ButtonColor.Secondary}
      id="cancel-periods-button"
      onClick={closeHandler}
    >
      {t("common.cancel")}
    </Button>
  );

  const primaryButton = (
    <Button
      size={ButtonSize.Small}
      id="select-periods-button"
      onClick={() => {
        selectHandler();
        setOpen(false);
      }}
    >
      {t("common.select")}
    </Button>
  );

  return (
    <Modalv2
      header={t("manualJournalPage.selectPeriod")}
      isOpen={isOpen}
      primaryButton={primaryButton}
      secondaryButton={secondaryButton}
      tertiaryButton={tertiaryButton}
      onClose={closeHandler}
    >
      <div>
        <GridTableNew
          dataTestId="vatSelectPeriodsGrid"
          filters={<VatSelectPeriodsFilters setSelectRow={setRow} />}
          isScrollable
          enableScrollIntoView
          dataSource={vatPeriods}
          selectedRow={row}
          isLoading={status === STATUS.LOADING}
          columnDef={columnDef}
          selectedRowHandler={(row) => setRow(row as any)}
          onEnterKeyPress={() => {
            selectHandler();
            setOpen(false);
            dispatch(mjPeriodssActions.setFilters({ lookingFor: "" }));
          }}
        />
      </div>
    </Modalv2>
  );
};

export default VatSelectPeriodModal;
