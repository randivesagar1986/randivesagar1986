import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const vatSelectPeriodColumnDef: TColumnDef = [
  {
    headerName: "Code",
    field: "period_no",
    columnWidth: 20,
    sequence: true
  },
  {
    headerName: "Description",
    field: "description",
    sequence: true
  }
];

export default vatSelectPeriodColumnDef;
