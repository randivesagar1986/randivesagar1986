import React, { useState, useEffect, SyntheticEvent, useMemo } from "react";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import {
  Grid,
  GridItem,
  FormLabel,
  Button,
  ButtonColor,
  ButtonSize,
  Icon,
  IconColor,
  IconSize,
  Divider,
  Dropdown,
  DropdownItem,
  TextInputSize,
  ISelectedItem,
  Tag,
  TagSize,
  TagColor,
  NotificationStatus,
  Notification,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import { useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import { AppDispatch, useAppSelector } from "@/store/store";
import { localRoutes } from "@/utils/constants";
import { specialCharacters, STATUS, getCurrentFinancialYear, LEDGER_BALANCE, JOURNALTYPE } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Controller, FormProvider, useForm } from "react-hook-form";
import { usNumberFormat } from "@/utils/getDataSource";
import ManualJournalPageToolbar, {
  BalanceType,
  JournalEditorMode
} from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalPageToolbar";
import ManualJournalToolbar from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalToolbar";
import { actions as mjTypeActions } from "@/pages/ManualJournalProcessing/SelectManualJournalType/JournalType/ManualJournalTypeStatus.slice";
import {
  actions as mjActions,
  postJournalData
} from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalTypeList/state/ManualJournal.slice";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { voucherTypeMapping } from "@/pages/GeneralLedgerSetup/utils";
import { canDo } from "@/store/state/userAccessRights.slice";
import SelectPeriodModal from "./SelectPeriodModal/SelectPeriodModal";
import CustomCell from "./Grid/CustomCell";
import {
  copyAllTypeJournal,
  fetchManualJournalDetails,
  mjDetailsActions,
  rollbackJournalDetails,
  saveJournalDetails
} from "../State/ManualJournalDetails.slice";
import ManualJournalFilters from "./Grid/ManualJournalFilters";
import manualJournalColumnDef from "./Grid/manualJournalColumnDef";
import { mjPeriodssActions } from "../State/ManualJournalPeriods.slice";
import { mjFinancialYearActions } from "../State/ManualJournalFinancialYears.slice";
import "./ManualJournalDetailsPage.style.scss";
import "./style.scss";
import viewManualJournalColumnDef from "./Grid/viewVatTransferColumnDef";

export enum periodsType {
  NORMAL = "NORMAL",
  REVERSAL = "REVERSAL"
}

const loaderConfig: loadingConfig = {};
const ManualJournalDetailsPage = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [narrative, setNarrative] = useState<string>("");
  const [id, setId] = useState<periodsType>();

  const status = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.status);
  const pStatus = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.status);
  const { filterState, selectedRow: mjSelectedRow } = useAppSelector((state) => state.manualJournal);
  const { voucherId } = useParams<{ voucherId: string }>();
  const [isUndoModalOpen, setIsUndoModalOpen] = useState<boolean>(false);
  const data = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.data);
  const journalLinesData = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.data.journalLines);
  const isDeleteJournalFlag = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.isDeleteJournalFlag);
  const selectedRow = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.selectedRow);
  const periodRow = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.selectedRow);
  const periods = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.periods);
  const isOpen = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.isOpenModal);
  const closingPeriods = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.closingPeriods);
  const reversalPeriodRow = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.reversalPeriodRow);
  const filteredReversalPeriods = useAppSelector(
    ({ manualJournalPeriods }) => manualJournalPeriods.filteredReversalPeriods
  );
  const mappedVoucherType = voucherTypeMapping[data?.journalHeader?.voucher_type];
  const postStatus = useAppSelector(({ manualJournal }) => manualJournal.postStatus);
  const printStatus = useAppSelector(({ manualJournal }) => manualJournal.printStatus);
  const financialYearDetails = useAppSelector(({ manualJournal }) => manualJournal.financialYearDetails);
  const isPostJournalValidation = useAppSelector(({ manualJournal }) => manualJournal.isPostJournalValidation);
  const { selectedView: templateView } = useAppSelector((state) => state.manualJournalType);
  const [title, setTitle] = useState<string>();
  const [isFinYearEnabled, setIsFinYearEnabled] = useState<boolean>(false);
  const {
    data: financialYears,
    selectedView,
    selectedView: revFinYearSelected
  } = useAppSelector((state) => state.manualJournalFinancialYears);
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const canDelete = canDo(userAccessRights, { action: "Delete", module: "Manual Journals" });
  const canPost = canDo(userAccessRights, { action: "Post", module: "Manual Journals" });

  const difference = Math.abs(
    (data?.journalLines ?? []).reduce((acc: any, curr: any) => {
      if (curr?.isDeleted) {
        return acc;
      }
      return acc + Number(curr?.debit) - Number(curr?.credit);
    }, 0)
  );
  const formattedDifference = usNumberFormat(difference);
  const credit = (data?.journalLines ?? []).reduce((acc: any, curr: any) => {
    if (curr?.isDeleted) {
      return acc;
    }
    return acc + Number(curr?.credit);
  }, 0);
  const debit = (data?.journalLines ?? []).reduce((acc: any, curr: any) => {
    if (curr?.isDeleted) {
      return acc;
    }
    return acc + Number(curr?.debit);
  }, 0);
  const getBalance = () => {
    let balance;

    if (data?.journalLines?.length > 0 && formattedDifference !== "0.00") {
      balance = formattedDifference;
    } else if (credit !== 0 && debit !== 0 && credit === debit) {
      balance = t("manualJournalPage.balanced");
    } else if (data?.journalLines?.length === 0) {
      balance = specialCharacters.HYPHEN;
    } else {
      balance = t("manualJournalPage.noValues");
    }
    dispatch(mjDetailsActions.setBalance(balance));
    return balance;
  };
  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;

  const getReversePeriodId = () => revFinYearSelected?.value;
  const formMethods = useForm({
    defaultValues: {
      narrative: "",
      period_no: "",
      period_description: "",
      reversal_period_no: "",
      reversal_description: "",
      reversal_year: ""
    },
    values: {
      narrative: data?.journalHeader?.narrative,
      period_no: data?.journalHeader?.period,
      period_description: "",
      reversal_period_no: data?.journalHeader?.reverse_period_no,
      reversal_description: "",
      reversal_year: data?.reversalYear,
      year: data?.year,
      reverse_year_id: getReversePeriodId()
    }
  });

  const {
    control,
    register,
    handleSubmit,
    setValue,
    trigger,
    getValues,
    watch,
    formState: { errors, isDirty },
    reset
  } = formMethods;

  const getTagElement = () => (
    <div className="heading-tag journal-header">
      {(historyState?.isShowNarrative === undefined || historyState?.isShowNarrative) && narrative && (
        <Tag
          text={narrative}
          size={TagSize.Large}
          color={TagColor.Highlight}
        />
      )}
    </div>
  );

  const getDisplayValue = (code: any, description: any) => {
    if (code || description) {
      return `${code || ""} ${description || ""}`;
    }
    return specialCharacters.HYPHEN;
  };

  const periodOnClickHandler = () => {
    dispatch(mjPeriodssActions.setIsOpenModal(true));
    setId(periodsType.NORMAL);
  };

  useEffect(() => {
    if (pStatus === STATUS.SUCCESS && status === STATUS.SUCCESS) {
      if (data?.journalHeader?.template === "F") {
        if (data?.journalHeader?.voucher_type === "CL") {
          setValue("period_no", closingPeriods[0]?.period_no);
          setValue("period_description", closingPeriods[0]?.description);
          dispatch(mjPeriodssActions.setSelectedRow(closingPeriods[0]));
          if (data?.journalHeader?.reverse === "T") {
            const reversalPeriod = periods.find(
              (period) => period.period_no === data?.journalHeader?.reverse_period_no
            );
            setValue("reversal_period_no", reversalPeriod?.period_no ?? periods[0]?.period_no);
            setValue("reversal_description", reversalPeriod?.description ?? periods[0]?.description);
            dispatch(mjPeriodssActions.setReversalPeriodRow(reversalPeriod ?? periods[0]));
          }
        } else if (data?.journalHeader?.voucher_type === "OP") {
          setValue("period_no", "");
          setValue("period_description", "");
        } else {
          const normalPeriod = periods.find((period) => period.period_no === data?.journalHeader?.period);
          dispatch(mjPeriodssActions.setSelectedRow(normalPeriod));
          setValue("period_no", normalPeriod?.period_no);
          setValue("period_description", String(normalPeriod?.description || ""));
          const reversalPeriods = periods.filter((p) => p.period_no > normalPeriod?.period_no!);
          dispatch(mjPeriodssActions.setReversalPeriods(reversalPeriods));
          if (data?.journalHeader?.reverse === "T") {
            const reversalPeriod = periods.find(
              (period) => period.period_no === data?.journalHeader?.reverse_period_no
            );
            setValue("reversal_period_no", reversalPeriod?.period_no ?? reversalPeriods[0]?.period_no);
            setValue("reversal_description", reversalPeriod?.description ?? reversalPeriods[0]?.description);
            dispatch(mjPeriodssActions.setReversalPeriodRow(reversalPeriod ?? reversalPeriods[0]));
          }
        }
        let yearToReverse = data?.reversalYear ?? data?.year;

        if (data?.journalHeader?.voucher_type === "CL") {
          yearToReverse = String(Number(data?.year) + 1);
        }

        const newYear = (financialYears || []).find((year) => year.year_des === yearToReverse);
        dispatch(
          mjFinancialYearActions.setSelectedView({
            text: newYear?.year_des,
            value: newYear?.year_id
          })
        );
      }

      if (templateView.value !== "") {
        setValue("narrative", data?.journalHeader?.narrative, {
          shouldDirty: true
        });
        dispatch(
          mjTypeActions.setManualJournalTypeView({
            text: "",
            value: ""
          })
        );
      }

      if (data?.journalHeader?.reverse === "T") {
        if (data?.journalHeader?.voucher_type === "CL") {
          setTitle(t("manualJournal.yearEndAdjustmentReversing"));
        } else {
          setTitle(t("manualJournalPage.reversingJournal"));
        }
      } else if (data?.journalHeader?.voucher_type === "NL" && data?.journalHeader?.template === "T") {
        setTitle(t("manualJournalPage.standardTemplate"));
      } else if (data?.journalHeader?.voucher_type === "VT") {
        setTitle(t("manualJournalPage.vatTransfer"));
      } else if (data?.journalHeader?.voucher_type === "CL") {
        setTitle(t("manualJournal.yearEndAdjustment"));
      } else if (data?.journalHeader?.voucher_type === "OP") {
        setTitle(t("manualJournal.openingBalance"));
      } else if (data?.journalHeader?.voucher_type === "AM") {
        setTitle(t("manualJournalPage.assetManagement"));
      } else {
        setTitle(t("manualJournalPage.normalTemplate"));
      }

      if (isPostJournalValidation) {
        setTimeout(() => {
          postJournal();
          dispatch(mjActions.setIsPostJournalValidation(false));
        }, 500);
      }
    }
  }, [status]);

  useEffect(() => {
    const reversalPeriods = periods.filter((p) => p.period_no > periodRow?.period_no!);
    // dispatch(mjPeriodssActions.setReversalPeriods(reversalPeriods));
    if (
      data?.journalHeader?.reverse === "T" &&
      periodRow &&
      data?.journalHeader?.voucher_type !== "CL" &&
      reversalPeriods.indexOf(reversalPeriodRow!) === -1
    ) {
      const reversalPeriod = periods.at(periods.indexOf(periodRow) + 1);
      dispatch(mjPeriodssActions.setReversalPeriodRow(reversalPeriod));
      setValue("reversal_period_no", reversalPeriod?.period_no);
      setValue("reversal_description", String(reversalPeriod?.description));
    }
  }, [periodRow]);

  useEffect(() => {
    if (data?.journalHeader?.reverse === "T" && data?.journalHeader?.reverse_period_no) {
      const reversalPeriod = periods.find((period) => period.period_no === data?.journalHeader?.reverse_period_no);
      setValue("reversal_period_no", reversalPeriod?.period_no);
      setValue("reversal_description", String(reversalPeriod?.description));
      dispatch(mjPeriodssActions.setReversalPeriodRow(reversalPeriod));
    }
  }, [status]);

  useEffect(() => {
    if (watch("narrative") !== "") {
      setNarrative(watch("narrative"));
    } else {
      setNarrative("");
    }
  }, []);

  useEffect(() => {
    if (financialYears?.length) {
      const selectedFinancialYear = financialYears.find(
        (f) => f?.sequence === Number(getCurrentFinancialYear() ?? "0") + 1
      );
      const isDisabled = !(
        selectedFinancialYear?.year_des !== "" &&
        selectedFinancialYear?.year_state === "S" &&
        selectedFinancialYear?.lowest_gl < selectedFinancialYear?.no_periods
      );
      setIsFinYearEnabled(isDisabled);
    }
  }, [financialYears]);

  const handleKeyDown = (e: any) => {
    if (e.key === "Escape" && (isDirty || historyState?.isDirty || isDeleteJournalFlag)) {
      e.preventDefault();
      setIsUndoModalOpen(true);
    }
  };

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleKeyDown]);

  const onSubmit = async (isRedirect?: boolean) => {
    let isError = false;
    const payload = getValues();
    history.location.state = {
      ...(history.location?.state as any),
      isDirty: false
    };
    dispatch(mjDetailsActions.setIsJournalLineDirty(false));
    dispatch(mjDetailsActions.setSelectedRow(undefined));
    const result = await dispatch(saveJournalDetails({ data: payload }));
    if (result?.type !== "manualJournalDetails/save/fulfilled") {
      isError = true;
    }
    dispatch(mjDetailsActions.setDeleteJournalFlag(false));

    if (!isError) {
      history.replace({
        ...history.location,
        state: {
          ...historyState,
          isDirty: false
        }
      });
      reset();
    }

    if (!isRedirect) {
      await dispatch(
        fetchManualJournalDetails({
          voucherId,
          templateVoucherId: templateView?.value
        })
      );
    }

    return isError;
  };

  const postJournal = handleSubmit(
    (response) => {
      dispatch(
        postJournalData({
          voucherId,
          callback: async (data) => {
            if (data?.messageCode === "LRM20") {
              dispatch(
                uiActions.alertPopup({
                  enable: true,
                  type: MODAL_TYPE?.ALERT,
                  message: t("manualJournal.invalidLine"),
                  title: t("common.simsFMSModule"),
                  notificationType: NotificationStatus?.WARNING
                })
              );
            } else if (data?.messageCode?.includes("LR")) {
              dispatch(
                uiActions.alertPopup({
                  enable: true,
                  type: MODAL_TYPE?.ALERT,
                  message: data?.message,
                  title: t("common.simsFMSModule"),
                  notificationType: NotificationStatus?.ERROR
                })
              );
            } else {
              reset();
              dispatch(
                mjActions.setFilters({
                  ...filterState,
                  includePosted: true
                })
              );
              dispatch(
                fetchManualJournalDetails({
                  voucherId,
                  templateVoucherId: templateView?.value
                })
              );
            }
          }
        })
      );
    },
    (error) => {
      dispatch(
        uiActions.alertPopup({
          enable: true,
          type: MODAL_TYPE?.ALERT,
          message: t("common.invalidData"),
          title: t("common.simsFMSModule"),
          notificationType: NotificationStatus?.HIGHLIGHT
        })
      );
    }
  );

  const onUndoClick = () => {
    if (isDirty || historyState?.isDirty || isDeleteJournalFlag) {
      setIsUndoModalOpen(true);
    } else {
      setIsUndoModalOpen(false);
    }
  };
  const onUndoChange = async () => {
    dispatch(mjDetailsActions.setDeleteJournalFlag(false));
    if (isDeleteJournalFlag) {
      await dispatch(fetchManualJournalDetails({ voucherId, templateVoucherId: templateView?.value }));
    }
    if (isDirty || historyState?.isDirty) {
      if (!data?.journalLines) {
        setValue("narrative", "");
        dispatch(mjDetailsActions.setJournalLines(undefined));
      } else {
        await dispatch(fetchManualJournalDetails({ voucherId, templateVoucherId: templateView?.value }));
        history.replace({
          ...history.location,
          state: {
            ...historyState,
            isDirty: false
          }
        });
      }
    }
  };

  const clearHistoryState = () => {
    history.replace({ ...history.location, state: undefined });
  };

  const copyJournalData = async () => {
    let period;
    if (
      mjSelectedRow?.voucher_type === JOURNALTYPE.OPENING_BALANCE ||
      mjSelectedRow?.voucher_type === JOURNALTYPE.JW_CL
    ) {
      if (mjSelectedRow?.voucher_type === JOURNALTYPE.OPENING_BALANCE) {
        period = 0;
      } else {
        period = 13;
      }
    }
    await dispatch(
      copyAllTypeJournal({
        voucherId,
        period,
        callback: async (res: any) => {
          if (res) {
            dispatch(mjActions.setManualJournalView({ ...filterState, includeSeries: false }));
            clearHistoryState();
            history.push(`${localRoutes.manualtJournalProcessing.manualJournalEdit}/${res?.data}`, {
              ...(history.location.state as any)
            });
          }
        }
      })
    );
  };

  const isEnabledPostBtn = useMemo(() => {
    const isPosted = data?.voucherJournal?.posted !== "T";
    const isTemplate = data?.journalHeader?.template === "F";
    const balance = getBalance();
    const isBalanced = balance === BalanceType.Balanced;
    return (
      isPosted &&
      isTemplate &&
      isBalanced &&
      (financialYearDetails?.year_state === "S" || financialYearDetails?.year_state === "P") &&
      JournalEditorMode.jvExternalPayment !== data?.journalHeader?.voucher_type &&
      JournalEditorMode.jvAssetManagement !== data?.journalHeader?.voucher_type &&
      canPost
    );
  }, [canPost, financialYearDetails, data]);

  const deleteEnableHandler = () => {
    if (voucherId) {
      return (
        (data?.voucherJournal?.posted === "T" && data?.voucherJournal?.balanced === LEDGER_BALANCE.BALANCED) ||
        canDelete === false
      );
    }
    return canDelete === false;
  };

  return (
    <>
      {(pStatus === STATUS.LOADING && status === STATUS.LOADING) ||
      printStatus === STATUS.LOADING ||
      postStatus === STATUS.LOADING ? (
        <Loader loadingConfig={loaderConfig} />
      ) : (
        <FormProvider {...formMethods}>
          <Layout
            className="manual-journal-details"
            pageTitle={title}
            isSubTitle={getTagElement()}
            rightContent={
              <ManualJournalToolbar
                onSubmit={onSubmit}
                onFinalSubmit={onSubmit}
                isDirty={isDirty}
                disableHandler={deleteEnableHandler}
                onUndoClick={onUndoClick}
              />
            }
            toolbar={
              <ManualJournalPageToolbar
                isDirty={isDirty}
                isEnabledPostBtn={isEnabledPostBtn}
                postJournal={postJournal}
                contraJournal={() => {
                  dispatch(mjDetailsActions.setContraYear(data?.year));
                  history.push(`/general-ledger/manual-journal-list/edit/${voucherId}/contra/${voucherId}`);
                }}
                copyJournal={() => copyJournalData()}
                onSubmit={onSubmit}
              />
            }
            dataTestId="manaalJournalDetails-page"
          >
            <Grid className="row-gap-16">
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
              >
                <div>
                  <div className="essui-form-label">{t("manualJournalPage.year")}</div>
                  <div className="height__equal--input">{data?.year}</div>
                </div>
              </GridItem>
              {data.voucherJournal?.posted === "T" ? (
                <GridItem
                  sm={4}
                  md={2}
                  lg={2}
                  xl={2}
                >
                  <div>
                    <Grid>
                      <GridItem>
                        <div>
                          <div className="essui-form-label">{t("manualJournalPage.period")}</div>
                          <div className="height__equal--input">
                            {data.journalHeader?.period} {periodRow?.description ?? ""}
                          </div>
                        </div>
                      </GridItem>
                    </Grid>
                  </div>
                </GridItem>
              ) : (
                <GridItem
                  sm={4}
                  md={2}
                  lg={2}
                  xl={2}
                >
                  <div>
                    <Grid>
                      <GridItem>
                        <Controller
                          render={({ field }) => (
                            <Input
                              id="period-no-input"
                              labelText={t("manualJournalPage.period")}
                              inputWidth={45}
                              searchable
                              searchItems={(data?.journalHeader?.reverse === "T" ? periods.slice(0, -1) : periods).map(
                                (period) => ({
                                  value: String(period.description),
                                  text: String(period.period_no)
                                })
                              )}
                              disabled={
                                data?.journalHeader?.temp_no !== null ||
                                data?.journalHeader?.template !== "F" ||
                                data?.journalHeader?.voucher_type === "OP" ||
                                data?.journalHeader?.posted === "T"
                              }
                              onPending={(selectedItem, index) => {
                                if (index !== undefined) {
                                  setValue("period_no", periods.at(index!)?.period_no, { shouldDirty: true });
                                  setValue("period_description", String(periods.at(index!)?.description || ""), {
                                    shouldDirty: true
                                  });
                                  trigger();
                                  dispatch(mjPeriodssActions.setSelectedRow(periods.at(index!)));
                                } else {
                                  setValue("period_no", "", { shouldDirty: true });
                                  setValue("period_description", "", {
                                    shouldDirty: true
                                  });
                                  dispatch(mjPeriodssActions.setSelectedRow(undefined));
                                }
                              }}
                              onNoSelection={() => {
                                setId(periodsType.NORMAL);
                                setValue("period_no", "");
                                dispatch(mjPeriodssActions.setIsOpenModal(true));
                              }}
                              isViewOnly={
                                data?.journalHeader?.temp_no !== null || data?.voucherJournal?.voucher_type === "CL"
                              }
                              searchBtnClick={
                                data?.journalHeader?.temp_no !== null || data?.voucherJournal?.voucher_type === "CL"
                                  ? undefined
                                  : periodOnClickHandler
                              }
                              buttonDisabled={
                                data?.journalHeader?.temp_no !== null ||
                                data?.journalHeader?.template === "T" ||
                                data?.journalHeader?.voucher_type === "OP"
                              }
                              containerClassName={data?.voucherJournal?.posted === "T" ? "view-mode" : undefined}
                              validationTextLevel={errors.period_no ? ValidationTextLevel.Error : undefined}
                              button={
                                <>
                                  <Input
                                    id="period-description-input"
                                    inputWidth={55}
                                    value={periodRow?.description ?? ""}
                                    className="read-only"
                                    isViewOnly={
                                      (data?.voucherJournal?.posted === "F" || data?.voucherJournal?.reverse === "T") &&
                                      data?.voucherJournal?.voucher_type === "CL"
                                    }
                                    disabled
                                    readOnly
                                  />
                                </>
                              }
                              {...field}
                            />
                          )}
                          rules={{
                            required: data?.journalHeader?.voucher_type !== "OP"
                          }}
                          name="period_no"
                          control={control}
                        />
                      </GridItem>
                    </Grid>
                  </div>
                </GridItem>
              )}
              {data?.journalHeader?.temp_no ? (
                <GridItem
                  sm={4}
                  md={2}
                  lg={2}
                  xl={2}
                >
                  <div>
                    <div className="essui-form-label">{t("manualJournalPage.number")}</div>
                    <div className="height__equal--input">{data?.journalHeader?.temp_no}</div>
                  </div>
                </GridItem>
              ) : null}

              <GridItem
                sm={4}
                md={data?.journalHeader?.temp_no !== null ? 6 : 8}
                lg={data?.journalHeader?.temp_no !== null ? 6 : 8}
                xl={data?.journalHeader?.temp_no !== null ? 6 : 8}
              >
                <div>
                  <Controller
                    render={({ field }) => (
                      <Input
                        autoFocus
                        id="narrative-input"
                        labelText={t("manualJournalPage.narrative")}
                        maxLength={60}
                        isViewOnly={data?.journalHeader?.temp_no !== null}
                        validationTextLevel={errors.narrative ? ValidationTextLevel.Error : undefined}
                        {...field}
                      />
                    )}
                    rules={{
                      required: true
                    }}
                    name="narrative"
                    control={control}
                  />
                </div>
              </GridItem>
              {data?.contra_no && data?.journalHeader?.reverse !== "T" ? (
                <GridItem
                  sm={4}
                  md={2}
                  lg={2}
                  xl={2}
                >
                  <div>
                    <div className="essui-form-label">{t("manualJournalPage.contraNo")}</div>
                    <div className="height__equal--input">
                      {data?.contra_no ? data?.contra_no : specialCharacters.HYPHEN}
                    </div>
                  </div>
                </GridItem>
              ) : null}

              {data?.journalHeader?.reverse === "T" && data?.voucherJournal?.posted !== "T" ? (
                <>
                  <GridItem
                    sm={4}
                    md={2}
                    lg={2}
                    xl={2}
                  >
                    <div>
                      <FormLabel forId="reversal-year-dropdown">{t("manualJournalPage.reversalYear")}</FormLabel>
                      <Dropdown
                        id="reversal-year-dropdown"
                        className="manual-journal-details__dropdown"
                        size={TextInputSize.Medium}
                        searchable
                        selectedItem={selectedView}
                        isScrollbarVisible
                        onSelect={(e: React.SyntheticEvent, item: ISelectedItem) =>
                          dispatch(mjFinancialYearActions.setSelectedView(item))
                        }
                        scrollbarHeight={Number(data?.journalLines || 0) <= 3 ? 120 : undefined}
                        disabled={
                          data?.journalHeader?.temp_no !== null ||
                          isFinYearEnabled ||
                          data?.journalHeader?.voucher_type === "CL"
                        }
                      >
                        {(financialYears || []).map((view: { [key: string]: string }, i: any) => {
                          const id = `dropdown-${i}`;
                          return (
                            <DropdownItem
                              key={id}
                              id={id}
                              text={view.year_des}
                              value={view.year_id}
                            >
                              {view.year_des}
                            </DropdownItem>
                          );
                        })}
                      </Dropdown>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={2}
                    lg={2}
                    xl={2}
                  >
                    <div>
                      <Grid>
                        <GridItem>
                          <Controller
                            render={({ field }) => (
                              <Input
                                id="reversal-period-no-input"
                                searchable
                                searchItems={periods.map((period) => ({
                                  value: String(period.description),
                                  text: String(period.period_no)
                                }))}
                                labelText={t("manualJournalPage.period")}
                                inputWidth={45}
                                disabled={data?.journalHeader?.temp_no !== null}
                                onNoSelection={() => {
                                  setId(periodsType.REVERSAL);
                                  dispatch(mjPeriodssActions.setIsOpenModal(true));
                                }}
                                onPending={(selectedItem, index) => {
                                  if (index !== undefined) {
                                    setValue("reversal_period_no", periods.at(index!)?.period_no, {
                                      shouldDirty: true
                                    });
                                    setValue("reversal_description", String(periods.at(index!)?.description || ""), {
                                      shouldDirty: true
                                    });
                                    dispatch(mjPeriodssActions.setReversalPeriodRow(periods.at(index!)));
                                  } else {
                                    setValue("reversal_period_no", "", { shouldDirty: true });
                                    setValue("reversal_description", "", {
                                      shouldDirty: true
                                    });
                                    dispatch(mjPeriodssActions.setReversalPeriodRow(undefined));
                                  }
                                }}
                                searchBtnClick={() => {
                                  setId(periodsType.REVERSAL);
                                  dispatch(mjPeriodssActions.setIsOpenModal(true));
                                }}
                                buttonDisabled={data?.journalHeader?.temp_no !== null}
                                validationTextLevel={errors.reversal_period_no ? ValidationTextLevel.Error : undefined}
                                button={
                                  <>
                                    <Input
                                      readOnly
                                      disabled
                                      id="reversal-period-description-input"
                                      searchable={false}
                                      inputWidth={55}
                                      value={reversalPeriodRow?.description || ""}
                                      className="read-only"
                                    />
                                  </>
                                }
                                {...field}
                              />
                            )}
                            rules={{
                              required: data?.journalHeader?.reverse === "T"
                            }}
                            name="reversal_period_no"
                            control={control}
                          />
                        </GridItem>
                      </Grid>
                    </div>
                  </GridItem>
                </>
              ) : null}
              {data?.journalHeader?.reverse === "T" && data?.voucherJournal?.posted === "T" ? (
                <>
                  <GridItem
                    sm={4}
                    md={2}
                    lg={2}
                    xl={2}
                  >
                    <div>
                      <FormLabel forId="reversal-year">{t("manualJournalPage.reversalYear")}</FormLabel>
                      <div className="height__equal--input">{data?.reversalYear}</div>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={2}
                    lg={2}
                    xl={2}
                  >
                    {data?.journalHeader?.voucher_type === "CL" && data?.voucherJournal?.status === "C" ? (
                      <div>
                        <Grid>
                          <GridItem>
                            <Controller
                              render={({ field }) => (
                                <Input
                                  id="reversal-period-no-input"
                                  searchable
                                  searchItems={periods.map((period) => ({
                                    value: String(period.description),
                                    text: String(period.period_no)
                                  }))}
                                  labelText={t("manualJournalPage.period")}
                                  inputWidth={45}
                                  onNoSelection={() => {
                                    setId(periodsType.REVERSAL);
                                    dispatch(mjPeriodssActions.setIsOpenModal(true));
                                  }}
                                  isViewOnly={
                                    data?.journalHeader?.temp_no !== null || data?.journalHeader?.voucher_type === "CL"
                                  }
                                  onPending={(selectedItem, index) => {
                                    if (index !== undefined) {
                                      setValue("reversal_period_no", periods.at(index!)?.period_no, {
                                        shouldDirty: true
                                      });
                                      setValue("reversal_description", String(periods.at(index!)?.description || ""), {
                                        shouldDirty: true
                                      });
                                      dispatch(mjPeriodssActions.setReversalPeriodRow(periods.at(index!)));
                                    } else {
                                      setValue("reversal_period_no", "", { shouldDirty: true });
                                      setValue("reversal_description", "", {
                                        shouldDirty: true
                                      });
                                      dispatch(mjPeriodssActions.setReversalPeriodRow(undefined));
                                    }
                                  }}
                                  searchBtnClick={
                                    data?.journalHeader?.temp_no !== null ||
                                    (data?.journalHeader?.voucher_type === "CL" && data?.voucherJournal?.status === "C")
                                      ? undefined
                                      : () => {
                                          setId(periodsType.REVERSAL);
                                          dispatch(mjPeriodssActions.setIsOpenModal(true));
                                        }
                                  }
                                  containerClassName={data?.voucherJournal?.posted === "T" ? "view-mode" : undefined}
                                  buttonDisabled={data?.journalHeader?.temp_no !== null}
                                  button={
                                    <>
                                      <Input
                                        readOnly
                                        disabled
                                        id="reversal-period-description-input"
                                        searchable={false}
                                        inputWidth={55}
                                        isViewOnly={
                                          data?.journalHeader?.temp_no !== null ||
                                          (data?.journalHeader?.voucher_type === "CL" &&
                                            data?.voucherJournal?.status === "C")
                                        }
                                        value={reversalPeriodRow?.description || ""}
                                        className="read-only"
                                      />
                                    </>
                                  }
                                  {...field}
                                />
                              )}
                              name="reversal_period_no"
                              control={control}
                            />
                          </GridItem>
                        </Grid>
                      </div>
                    ) : (
                      <div>
                        <FormLabel forId="reversal-year">{t("manualJournalPage.period")}</FormLabel>
                        <div className="height__equal--input">
                          {getDisplayValue(reversalPeriodRow?.period_no, reversalPeriodRow?.description)}
                        </div>
                      </div>
                    )}
                  </GridItem>
                  {data?.contra_no ? (
                    <GridItem
                      sm={4}
                      md={2}
                      lg={2}
                      xl={2}
                    >
                      <div>
                        <div className="essui-form-label">{t("manualJournalPage.contraNo")}</div>
                        <div className="height__equal--input">
                          {data?.contra_no ? data?.contra_no : specialCharacters.HYPHEN}
                        </div>
                      </div>
                    </GridItem>
                  ) : null}
                </>
              ) : null}
            </Grid>
          </Layout>

          <Layout
            isBreadcrumbRequired={false}
            type="transparent"
            className="manual-journal-details__grid"
          >
            <GridTableNew
              id="journalLinesGrid"
              dataTestId="journalLinesGrid"
              customCell={CustomCell}
              filters={<ManualJournalFilters />}
              columnDef={data?.voucherJournal?.posted === "T" ? viewManualJournalColumnDef : manualJournalColumnDef}
              dataSource={journalLinesData ? journalLinesData.filter((item: any) => !item?.isDeleted) : []}
              isLoading={false}
              selectedRow={selectedRow}
              isScrollable
              enableScrollIntoView
              isAutoFocusInitially={data.voucherJournal?.posted === "T"}
              selectedRowHandler={(row) => {
                dispatch(mjDetailsActions.setSelectedRow(row));
              }}
              useDeepSearch
            />
          </Layout>

          <Layout isBreadcrumbRequired={false}>
            <div className="container">
              <Grid className="row-gap-16">
                <GridItem
                  lg={12}
                  md={12}
                  sm={4}
                  xl={12}
                  xxl={12}
                >
                  <div>
                    <div className="essui-form-label mb-5">{t("manualJournalPage.narrative")}</div>
                    <div>{selectedRow?.narrative ? selectedRow?.narrative : specialCharacters.HYPHEN}</div>
                  </div>
                </GridItem>
              </Grid>
              <div className="mb-16 mt-16">
                <Divider />
              </div>
              <Grid className="row-gap-16">
                <GridItem
                  lg={3}
                  md={3}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div>
                    <div className="essui-form-label mb-5">{t("manualJournalPage.balance")}</div>
                    <div>{getBalance()}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={3}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div>
                    <div className="essui-form-label mb-5">{t("manualJournalPage.totalDebits")}</div>
                    <div>{usNumberFormat(debit ?? specialCharacters.zero)}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={3}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div>
                    <div className="essui-form-label mb-5">{t("manualJournalPage.totalCredits")}</div>
                    <div>{usNumberFormat(credit ?? specialCharacters.zero)}</div>
                  </div>
                </GridItem>
              </Grid>
            </div>
            {isOpen && (
              <SelectPeriodModal
                isOpen={isOpen}
                setOpen={(flag) => {
                  dispatch(mjPeriodssActions.setIsOpenModal(flag));
                  if (!flag) {
                    setId(undefined);
                  }
                }}
                id={id}
                isReversal={data?.journalHeader?.reverse === "T"}
                voucherType={data?.journalHeader?.voucher_type}
                isEnableSequence={data?.journalHeader?.voucher_type === "VT"}
              />
            )}
          </Layout>

          <ConfirmModal
            className="delete-alert"
            isOpen={isUndoModalOpen}
            setOpen={setIsUndoModalOpen}
            title={t("alertMessage.title")}
            message={t("alertMessage.undoAlert.message")}
            confirm={() => {
              onUndoChange();
            }}
            autoFocusPrimaryBtn
          />
        </FormProvider>
      )}
    </>
  );
};

export default ManualJournalDetailsPage;
