import { useEffect } from "react";
import { useHistory, useParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { JournalEditorMode } from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalPageToolbar";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import { STATUS, getCurrentFinancialYear } from "@/types/UseStateType";
import { PageNotFound } from "@essnextgen/ui-error-pages-kit";
import { mjActions } from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalTypeList/state/ManualJournal.slice";
import { fetchUserAccessRights, Screen } from "@/store/state/userAccessRights.slice";
import ManualJournalDetailsPage from "./ManualJournalDetailsPage";
import { fetchManualJournalDetails, JournalDetailsType, mjDetailsActions } from "../State/ManualJournalDetails.slice";
import CashBook from "../ManualJournalProcessing/CashBook/CashBook";
import { fetchPeriods, getManualJournalClosingPeriods } from "../State/ManualJournalPeriods.slice";
import { fetchManualJournalFinancialYear } from "../State/ManualJournalFinancialYears.slice";

const loaderConfig: loadingConfig = {};
const CommonManualJournalDetails = () => {
  const { voucherId } = useParams<{ voucherId: string }>();
  const dispatch = useDispatch<AppDispatch>();
  const { data, copyJournalId } = useAppSelector((state) => state.manualJournalDetails);
  const { selectedView: templateView } = useAppSelector((state) => state.manualJournalType);
  const status = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.status);
  const pStatus = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.status);
  const periods = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.periods);
  const { isOpenModal } = useAppSelector((state) => state.manualJournalPeriods);
  const { status: saveRecurrenceStatus } = useAppSelector((state) => state.recurrencePattern);
  const { status: fyStatus } = useAppSelector((state) => state.manualJournalFinancialYears);
  const history = useHistory();
  const historyState = history.location.state as any;

  const getDetails = async () => {
    if (!periods?.length) {
      await dispatch(fetchPeriods());
      await dispatch(fetchManualJournalFinancialYear());
      await dispatch(getManualJournalClosingPeriods(getCurrentFinancialYear()));
    }
    dispatch(mjDetailsActions.addJournalDetails(historyState.mjDetail));
  };
  useEffect(() => {
    if (!data.journalHeader && !historyState?.mjDetail) {
      dispatch(
        fetchManualJournalDetails({
          voucherId,
          templateVoucherId: templateView?.value,
          callback: () => {
            dispatch(mjDetailsActions.setSelectedRow((data as JournalDetailsType).journalLines.at(0)));
          }
        })
      );
    }
    if (historyState?.mjDetail) {
      getDetails();
    }
  }, []);

  useEffect(() => {
    if (copyJournalId) {
      dispatch(fetchManualJournalDetails({ voucherId: copyJournalId, templateVoucherId: templateView?.value }));
      dispatch(mjDetailsActions.resetCopyJournalId());
      dispatch(mjActions.setFilters({ highlightVoucherId: copyJournalId }));
    }
  }, [copyJournalId]);

  const getPage = () => {
    switch (data?.journalHeader?.voucher_type) {
      case JournalEditorMode.jvCashBook:
      case JournalEditorMode.jvVATReimbursement:
        return <CashBook voucherType={data?.journalHeader?.voucher_type} />;

      case JournalEditorMode.jvNormal:
      case JournalEditorMode.jvVATTransfer:
      case JournalEditorMode.jvClosingBalance:
      case JournalEditorMode.jvOpeningBalance:
      case JournalEditorMode.jvAssetManagement:
        return <ManualJournalDetailsPage />;

      default:
        return <PageNotFound />;
    }
  };

  return (
    <>
      {(pStatus === STATUS.LOADING && !isOpenModal) ||
      status === STATUS.LOADING ||
      fyStatus === STATUS.LOADING ||
      saveRecurrenceStatus === STATUS.LOADING ? (
        <Loader loadingConfig={loaderConfig} />
      ) : (
        data?.journalHeader?.voucher_type && getPage()
      )}
    </>
  );
};

export default CommonManualJournalDetails;
