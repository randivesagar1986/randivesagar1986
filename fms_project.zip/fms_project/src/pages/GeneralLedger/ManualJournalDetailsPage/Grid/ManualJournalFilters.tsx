import { useAppSelector } from "@/store/store";
import { JOURNALTYPE } from "@/types/UseStateType";
import { AddLarge } from "@carbon/icons-react";
import { canDo } from "@/store/state/userAccessRights.slice";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Grid, GridItem, Button, ButtonSize, NotificationStatus, FormLabel, ButtonColor } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useFormContext } from "react-hook-form";
import { KeyValueType } from "@/components/GridTableNew/GridTableNew";
import { mjDetailsActions } from "../../State/ManualJournalDetails.slice";

const ManualJournalFilters = (onSubmit: any) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { formState } = useFormContext();
  const dispatch = useDispatch();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { data } = useAppSelector((state) => state.manualJournalDetails);
  const { getValues } = useFormContext();
  const { selectedRow } = useAppSelector((state) => state.manualJournal);

  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const mCanDefineTempl = canDo(userAccessRights, { action: "Define templates", module: "Manual Journals" });
  const mCanAddNormal = canDo(userAccessRights, { module: "Manual Journals", action: "Add normal" });
  const mCanAddOpeningBal = canDo(userAccessRights, { module: "Manual Journals", action: "Add opening balance" });
  const mCanAddCashbook = mCanAddNormal;
  const mCanAddVATReimbursement = mCanAddNormal;
  const mCanAddVATTransfer = mCanAddNormal;
  const mCanAddClosingBal = mCanAddNormal;
  const isAddBtnEnable =
    mCanAddNormal ||
    mCanAddOpeningBal ||
    mCanAddCashbook ||
    mCanDefineTempl ||
    mCanAddVATReimbursement ||
    mCanAddVATTransfer;

  const goToJournalLine = (journalType: string, payload: KeyValueType) => {
    switch (journalType) {
      case JOURNALTYPE.NORMAL:
        history.push({
          pathname: `${history.location.pathname}/journal-line/add`,
          state: {
            ...historyState,
            voucherType: data?.journalHeader?.voucher_type,
            isShowNarrative: true,
            mjDetail: payload,
            isDirty: formState.isDirty
          }
        });
        break;
      case JOURNALTYPE.VAT_TRANSFER:
        history.push({
          pathname: `${history.location.pathname}/vat-transfer-journal-line/add`,
          state: {
            ...historyState,
            voucherType: data?.journalHeader?.voucher_type,
            isShowNarrative: true,
            mjDetail: payload,
            isDirty: formState.isDirty
          }
        });
        break;
      default:
        history.push({
          pathname: `${history.location.pathname}/journal-line/add`,
          state: {
            ...historyState,
            voucherType: data?.journalHeader?.voucher_type,
            isShowNarrative: true,
            mjDetail: payload,
            isDirty: formState.isDirty
          }
        });
    }
  };

  return (
    <Grid justify="space-between">
      <GridItem>
        <h2 className="essui-global-typography-default-subtitle">{t("manualJournalPage.journalLines")}</h2>
      </GridItem>
      <GridItem>
        <Button
          // className="essui-button essui-button--utility essui-button--small br-0"
          className="br-0"
          id="manual-journal-addNewLine"
          dataTestId="manual-journal-addNewLine"
          size={ButtonSize.Small}
          color={ButtonColor.Utility}
          title={t("purchaseOrder.addNewLine")}
          aria-label={t("purchaseOrder.addNewLineAriaText")}
          onClick={() => {
            const values = getValues();
            const payload = {
              journalHeader: {
                ...data.journalHeader,
                period: values.period_no,
                reverse_period_no: values.reversal_period_no,
                narrative: values.narrative,
                year: values?.year
              },
              journalLines: data.journalLines,
              year: values.year
            };
            dispatch(mjDetailsActions.addJournalDetails(payload));
            dispatch(mjDetailsActions.setDeletedJournalLines(data.journalLines.length));
            goToJournalLine(data?.journalHeader?.voucher_type, payload);
          }}
          disabled={data?.journalHeader?.temp_no !== null || selectedRow?.posted === "T" || !isAddBtnEnable}
        >
          <AddLarge
            size="18"
            // color="black"
          />
        </Button>
      </GridItem>
    </Grid>
  );
};

export default ManualJournalFilters;
