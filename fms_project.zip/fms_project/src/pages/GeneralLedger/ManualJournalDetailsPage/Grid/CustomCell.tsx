import GridRowActions, { OptionsType } from "@/components/GridRowActions/GridRowActions";
import { cellRendererType } from "@/components/GridTableNew/GridTableNew";
import { usNumberFormat } from "@/utils/getDataSource";
import { Icon, IconSize, ISelectedItem } from "@essnextgen/ui-kit";
import React, { ReactNode, SyntheticEvent, useState } from "react";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { canDo } from "@/store/state/userAccessRights.slice";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { JOURNALTYPE } from "@/types/UseStateType";
import { useFormContext } from "react-hook-form";
import { mjDetailsActions } from "../../State/ManualJournalDetails.slice";

type clickHandlerType = (e: SyntheticEvent, selectedItem: ISelectedItem) => void;

const CustomCell: React.FC<cellRendererType> = ({ field, row }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { data } = useAppSelector((state) => state.manualJournalDetails);
  const selectedRow = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.selectedRow);
  const history = useHistory();
  const historyState = history.location.state as any;
  const { getValues } = useFormContext();
  const dispatch = useDispatch();
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const mCanDefineTempl = canDo(userAccessRights, { action: "Define templates", module: "Manual Journals" });
  const mCanAddNormal = canDo(userAccessRights, { module: "Manual Journals", action: "Add normal" });
  const mCanAddOpeningBal = canDo(userAccessRights, { module: "Manual Journals", action: "Add opening balance" });
  const mCanAddCashbook = mCanAddNormal;
  const mCanAddVATReimbursement = mCanAddNormal;
  const mCanAddVATTransfer = mCanAddNormal;
  const isAddBtnEnable =
    mCanAddNormal ||
    mCanAddOpeningBal ||
    mCanAddCashbook ||
    mCanDefineTempl ||
    mCanAddVATReimbursement ||
    mCanAddVATTransfer;
  const onDeleteJournalLines = (val: any, voucherId: any) => {
    if (val) {
      const journalLinePayload = data.journalLines.map((record) => {
        if (record.voucher_line_id === val) {
          return {
            ...record,
            isDeleted: true
          };
        }
        return record;
      });
      dispatch(mjDetailsActions.setJournalLines(journalLinePayload));
      const updatedSelectedRow = journalLinePayload.filter((record) => !record.isDeleted);
      dispatch(mjDetailsActions.setSelectedRow(updatedSelectedRow[updatedSelectedRow.length - 1]));
      dispatch(mjDetailsActions.setDeleteJournalFlag(true));
    } else if (val === 0) {
      const journalLinePayload = data.journalLines.filter((record) => record.temp_id !== selectedRow?.temp_id);
      dispatch(mjDetailsActions.setJournalLines(journalLinePayload));
      dispatch(mjDetailsActions.setSelectedRow(journalLinePayload[journalLinePayload.length - 1]));
      dispatch(mjDetailsActions.setDeleteJournalFlag(true));
    }
  };
  const options = [
    {
      text: "editLine",
      value: "editLine",
      disabled: data?.journalHeader?.temp_no !== null || (!isAddBtnEnable && data?.voucherJournal?.posted === "F"),
      children: <RowAction optionName={t("manualJournalPage.editLine")} />
    },
    {
      text: "deleteLine",
      value: "deleteLine",
      disabled: data?.journalHeader?.temp_no !== null || (!isAddBtnEnable && data?.voucherJournal?.posted === "F"),
      children: <RowAction optionName={t("manualJournalPage.deleteLine")} />
    }
  ];

  const getCurrentJLData = (journalType?: string) => {
    const values = getValues();
    const payload = {
      journalHeader: {
        ...data.journalHeader,
        period: values.period_no,
        reverse_period_no: values.reversal_period_no,
        narrative: values.narrative,
        year: values?.year
      },
      journalLines: data.journalLines,
      year: values.year
    };
    dispatch(mjDetailsActions.addJournalDetails(payload));
    dispatch(mjDetailsActions.setDeletedJournalLines(data.journalLines.length));
    if (journalType === JOURNALTYPE.OPENING_BALANCE) {
      history.push({
        pathname: `/general-ledger/manual-journal-list/edit/${row?.voucher_id}/opening-balance-journal-line/edit/${row?.voucher_line_id}`,
        state: { ...historyState, voucherType: data?.journalHeader?.voucher_type, mjDetail: payload, selectedRow }
      });
    }
    if (journalType === JOURNALTYPE.VAT_TRANSFER) {
      history.push({
        pathname: `/general-ledger/manual-journal-list/edit/${row?.voucher_id}/vat-transfer-journal-line/edit/${row?.voucher_line_id}`,
        state: {
          ...historyState,
          voucherType: data?.journalHeader?.voucher_type,
          mjDetail: payload,
          selectedRow
        }
      });
    }
    if (journalType === JOURNALTYPE.NORMAL) {
      history.push({
        pathname: `/general-ledger/manual-journal-list/edit/${row?.voucher_id}/normal-journal-line/edit/${row?.voucher_line_id}`,
        state: { ...historyState, voucherType: data?.journalHeader?.voucher_type, mjDetail: payload, selectedRow }
      });
    }
    if (journalType === JOURNALTYPE.JW_CL) {
      history.push({
        pathname: `/general-ledger/manual-journal-list/edit/${row?.voucher_id}/journal-line/edit/${row?.voucher_line_id}`,
        state: { ...historyState, voucherType: data?.journalHeader?.voucher_type, mjDetail: payload, selectedRow }
      });
    }
  };
  const orderLineActionHandler: clickHandlerType = async (e, selectedItem) => {
    switch (selectedItem.value) {
      case "editLine":
        if (
          data?.journalHeader?.voucher_type === JOURNALTYPE.NORMAL ||
          data?.journalHeader?.voucher_type === JOURNALTYPE.VAT_TRANSFER ||
          data?.journalHeader?.voucher_type === JOURNALTYPE.JW_CL ||
          data?.journalHeader?.voucher_type === JOURNALTYPE.OPENING_BALANCE
        ) {
          getCurrentJLData(data?.journalHeader?.voucher_type);
        }

        break;
      case "deleteLine":
        onDeleteJournalLines(row?.voucher_line_id, row?.voucher_id);
        break;
      default:
        break;
    }
  };

  const getContent = () => {
    switch (field) {
      case "debit":
        return <>{usNumberFormat(row?.debit)}</>;
      case "credit":
        return <>{usNumberFormat(row?.credit)}</>;
      case "actions":
        return (
          <GridRowActions
            name={
              <Icon
                size={IconSize.Medium}
                name="overflow-menu--horizontal"
              />
            }
            options={options}
            onClick={orderLineActionHandler}
            selectedRow={row}
          />
        );
      default:
        return null;
    }
  };
  return getContent();
};

export default CustomCell;

type OptionProps = {
  iconName?: string;
  optionName: string;
  children?: ReactNode;
};
const RowAction = ({ iconName, optionName, children }: OptionProps) => (
  <div className="option">
    {iconName ? (
      <Icon
        size={IconSize.Medium}
        name={iconName}
      />
    ) : (
      children
    )}
    {optionName}
  </div>
);

RowAction.defaultProps = {
  iconName: undefined,
  children: undefined
};
