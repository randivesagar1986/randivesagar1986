/**
 * @fileoverview Unit test for ManualJournalFilters component.
 *
 * This test verifies that clicking the plus button in the ManualJournalFilters component
 * navigates to the correct page for adding a new journal line.
 *
 * - Mocks the `useFormContext` hook from `react-hook-form` to provide necessary form state and values.
 * - Configures a mock Redux store with initial state for `manualJournalDetails` and `manualJournal`.
 * - Uses `createMemoryHistory` to manage navigation history.
 * - Renders the `ManualJournalFilters` component within the necessary providers (`Provider` for Redux and `Router` for routing).
 * - Simulates a button click and asserts that the navigation occurs to the expected path.
 *  * - To run this test use the command : npx jest ManualJournalFilters.test.tsx ---config ./config/jest/jest.config.js
 * - To run all the test cases use: npm test or npx jest ---config ./config/jest/jest.config.js
 */
import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { createMemoryHistory } from "history";
import { Router } from "react-router-dom";
import { Provider } from "react-redux";
import configureStore from "redux-mock-store";
import { useFormContext } from "react-hook-form";
import { JOURNALTYPE } from "@/types/UseStateType";
import ManualJournalFilters from "../ManualJournalFilters";

// Mock the useFormContext hook
jest.mock("react-hook-form", () => ({
  ...jest.requireActual("react-hook-form"),
  useFormContext: () => ({
    formState: { isDirty: false }, // Mock formState as required
    getValues: () => ({
      period_no: "1",
      reversal_period_no: null,
      narrative: "",
      year: "2024"
    })
  })
}));

const mockStore = configureStore([]);
const store = mockStore({
  manualJournalDetails: {
    data: {
      journalHeader: {
        auto_post: "F",
        bank_id: null,
        bank_reference: null,
        client_id: null,
        contra_journal_id: null,
        contra_nrv_journal_id: null,
        cost_id: null,
        ledger_id: null,
        narrative: "",
        next_year_voucher_id: null,
        nrv_journal_id: null,
        orig_journal_id: null,
        period: 1,
        posting_application: null,
        posting_date: null,
        previous_year_voucher_id: null,
        recurrence_pattern_id: null,
        reverse: "F",
        reverse_period_no: null,
        reverse_year_id: null,
        sequence_in_pattern: null,
        system_date: "2024-09-10T00:00:00",
        temp_no: null,
        template: "F",
        user_id: null,
        voucher_date: "2024-09-10T00:00:00",
        voucher_id: 5694,
        voucher_no: "#05694",
        voucher_type: JOURNALTYPE.NORMAL,
        year: "2024",
        year_id: 27
      },
      journalLines: []
    }
  },
  manualJournal: { selectedRow: { posted: "F" } }
});

const history = createMemoryHistory();
history.push("/UI/general-ledger/manual-journal-list/edit/5694"); // Set initial path

test("should navigate to the correct page when the plus button is clicked", () => {
  render(
    <Provider store={store}>
      <Router history={history}>
        <ManualJournalFilters />
      </Router>
    </Provider>
  );

  // Find the button using data-testid
  const addButton = screen.getByTestId("manual-journal-addNewLine");

  // Simulate button click
  fireEvent.click(addButton);

  // Assert that the correct navigation occurred
  expect(history.location.pathname).toBe("/UI/general-ledger/manual-journal-list/edit/5694/journal-line/add");
});
