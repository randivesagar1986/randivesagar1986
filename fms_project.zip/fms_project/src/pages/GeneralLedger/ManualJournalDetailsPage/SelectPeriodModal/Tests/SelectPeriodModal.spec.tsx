import React from "react";
import { render } from "@testing-library/react";
import { BrowserRouter as Router } from "react-router-dom";
import { Provider } from "react-redux";
import { FormProvider, useForm } from "react-hook-form";
import { setupStore } from "@/store/store";
import SelectPeriodModal from "../SelectPeriodModal";

const mockSetOpen = jest.fn();
type RenderComponentWrapperProps = {
  isOpen?: boolean;
};

const RenderComponentWrapper: React.FC<RenderComponentWrapperProps> = ({ isOpen = true }) => {
  const methods = useForm();
  const store = setupStore();
  return (
    <Provider store={store}>
      <Router>
        <FormProvider {...methods}>
          <SelectPeriodModal
            setOpen={mockSetOpen}
            isOpen={isOpen}
          />
        </FormProvider>
      </Router>
    </Provider>
  );
};

RenderComponentWrapper.defaultProps = {
  isOpen: true
};

const renderComponent = (isOpen = true) => render(<RenderComponentWrapper isOpen={isOpen} />);

describe("SelectPeriodModal Component", () => {
  it("renders the modal correctly with buttons and grid", () => {
    const { getByText } = renderComponent();
    expect(getByText(/Please wait/i)).toBeInTheDocument();
  });
});

it("clicking on 'Cancel' button closes the modal", () => {
  const { getByText } = renderComponent();
  const cancelButton = getByText(/common.cancel/i);
  cancelButton.click();
  expect(mockSetOpen).toHaveBeenCalledWith(false);
});

it("clicking on 'Select' button triggers select handler and closes the modal", () => {
  const { getByText } = renderComponent();
  const selectButton = getByText(/common.select/i);
  selectButton.click();
  expect(mockSetOpen).toHaveBeenCalledWith(false);
});
