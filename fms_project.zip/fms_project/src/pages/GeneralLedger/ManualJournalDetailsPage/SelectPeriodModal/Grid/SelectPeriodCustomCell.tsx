import { cellRendererType } from "@/components/GridTable/GridTable";

const SelectPeriodCustomCell = ({ field, row }: cellRendererType) => {
  const getContent = () => {
    switch (field) {
      case "start_date":
        return (
          <>
            {new Intl.DateTimeFormat("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })
              .format(new Date(row?.start_date))
              .replace("Sept", "Sep")}
          </>
        );
      default: {
        return <div />;
      }
    }
  };
  return getContent();
};

export default SelectPeriodCustomCell;
