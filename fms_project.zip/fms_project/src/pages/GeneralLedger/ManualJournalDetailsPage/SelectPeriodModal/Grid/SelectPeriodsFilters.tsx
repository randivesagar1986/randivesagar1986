import { RowType } from "@/components/GridTableNew/GridTableNew";
import useDebounce from "@/hooks/useDebounce";
import useNearestSearch from "@/hooks/useNearestSearch";
import { PeriodRowType } from "@/pages/GeneralLedger/State/ManualJournalPeriods.slice";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Grid, GridItem, FormLabel, TextInput, TextInputSize } from "@essnextgen/ui-kit";
import React, { useState } from "react";
import { useDispatch } from "react-redux";

type SelectPeriodsFiltersProps = {
  // Add any props you need here
  setSelectRow: React.Dispatch<React.SetStateAction<PeriodRowType | undefined>>;
  selectRow: PeriodRowType | undefined;
};

const SelectPeriodsFilters: React.FC<SelectPeriodsFiltersProps> = ({ setSelectRow, selectRow }) => {
  const [lookingFor, setLookingFor] = useState<string | undefined>("");
  const { periods, selectedRow, status } = useAppSelector((state) => state.manualJournalPeriods);
  const debouncedValue = useDebounce(lookingFor!, 600);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  useNearestSearch({
    key: "period_no",
    value: debouncedValue,
    rows: periods,
    dataTestId: "selectPeriodsGrid",
    selectRow: setSelectRow as React.Dispatch<React.SetStateAction<RowType | undefined>>
  });

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setLookingFor(value.toUpperCase());
  };

  return (
    <Grid
      className="custom-table"
      align="center"
    >
      <GridItem
        sm={12}
        md={4}
        xl={4}
      >
        <div className="essui-global-typography-default-h2">
          <FormLabel forId="looking-for">{t("purchaseOrder.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              autoFocus
              onKeyDown={(event) => {
                // eslint-disable-next-line
                if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                  event.preventDefault();
                }
              }}
              id="looking-for-input"
              value={lookingFor}
              onChange={(e) => handleLookingForChange(e)}
              size={TextInputSize.Medium}
              readOnly={status === STATUS.LOADING}
            />
          </div>
        </div>
      </GridItem>
    </Grid>
  );
};

export default SelectPeriodsFilters;
