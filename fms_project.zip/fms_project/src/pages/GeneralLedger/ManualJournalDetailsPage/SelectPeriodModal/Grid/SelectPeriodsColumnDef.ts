import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const selectPeriodColumnDef: TColumnDef = [
  {
    headerName: "Period",
    field: "period_no"
  },
  {
    headerName: "Description",
    field: "description"
  },
  {
    headerName: "Start Date",
    field: "start_date",
    cellRenderer: "GridCellLink"
  }
];

export default selectPeriodColumnDef;
