import { RowType, TColumnDef } from "@/components/GridTableNew/GridTableNew";
import useDebounce from "@/hooks/useDebounce";
import useNearestSearch from "@/hooks/useNearestSearch";
import { AppDispatch, useAppSelector } from "@/store/store";
import { JOURNAL_PERIOD_TYPE, KEYBOARD_STRING, STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import {
  Grid,
  GridItem,
  FormLabel,
  TextInput,
  TextInputSize,
  RadioButton,
  RadioLabelPosition
} from "@essnextgen/ui-kit";
import React, { Dispatch, useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { fetchPeriods, mjPeriodssActions } from "@/pages/GeneralLedger/State/ManualJournalPeriods.slice";
import columnDef from "../../VatSelectPeriodModal/Grid/VatSelectPeriodsColumnDef";

const SelectPeriodFiltersWithSequence = ({
  setSelectRow,
  isOpen
}: {
  setSelectRow: Dispatch<any>;
  isOpen: Boolean;
}) => {
  const [lookingFor, setLookingFor] = useState<string | undefined>("");
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const dispatch = useDispatch<AppDispatch>();
  const { periods, selectedRow, status, filters } = useAppSelector((state) => state.manualJournalPeriods);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const debouncedValue = useDebounce(lookingFor!, 300);
  const inputRef: React.Ref<HTMLInputElement> = useRef(null);

  useEffect(() => {
    if (debouncedValue !== "" && periods && periods?.length) {
      const found = [...(periods as any)]
        .filter((element) =>
          debouncedValue
            ? element[filters?.sequenceValue!].toString()?.toUpperCase()?.startsWith(debouncedValue!)
            : false
        )
        .at(0);

      if (found && found !== undefined) setSelectRow(found);

      const element = document.getElementById(`rowIndex-selectPeriodsGrid-${periods.indexOf(found!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [debouncedValue]);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
    const { value } = e.target;
    setLookingFor(value.toUpperCase());
  };

  const handleSequenceChange = async (value?: string, index?: any) => {
    columnDef.map((col, index) => {
      if (col.field === value) {
        const temp = columns[0];
        columns[0] = columns[index];
        columns[index] = temp;
      }
      return col;
    });
    setColumn([...columnDef]);
    dispatch(mjPeriodssActions.setColumnDef(columns));
  };

  useEffect(() => {
    handleSequenceChange(filters?.sequenceValue);
  }, [filters?.sequenceValue]);

  const handleSequenceFieldKeyDown = async (e: React.KeyboardEvent) => {
    const isArrowKey =
      e.key === KEYBOARD_STRING.ArrowDown ||
      e.key === KEYBOARD_STRING.ArrowUp ||
      e.key === KEYBOARD_STRING.ArrowLeft ||
      e.key === KEYBOARD_STRING.ArrowRight;

    if (isArrowKey) {
      e.preventDefault();

      const nextSequenceValue =
        filters?.sequenceValue === JOURNAL_PERIOD_TYPE.CODE
          ? JOURNAL_PERIOD_TYPE.DESCRIPTION
          : JOURNAL_PERIOD_TYPE.CODE;
      const index = nextSequenceValue === JOURNAL_PERIOD_TYPE.DESCRIPTION ? 1 : 0;

      dispatch(
        mjPeriodssActions.setFilters({
          sequenceValue: String(nextSequenceValue),
          sequenceIndex: String(index),
          lookingFor: ""
        })
      );
    }
  };

  return (
    <Grid
      className="custom-table"
      align="center"
    >
      <GridItem
        sm={12}
        md={4}
        xl={4}
      >
        <div className="essui-global-typography-default-h2">
          <FormLabel forId="txtLookingFor">{t("purchaseOrder.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              autoFocus
              onKeyDown={(event) => {
                // eslint-disable-next-line
                if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                  event.preventDefault();
                }
              }}
              id="txtLookingFor"
              value={filters?.lookingFor}
              onChange={(e) => handleLookingForChange(e)}
              size={TextInputSize.Medium}
              readOnly={status === STATUS.LOADING}
            />
          </div>
        </div>
      </GridItem>
      <GridItem
        sm={5}
        md={5}
        xl={5}
      >
        <div className="essui-global-typography-default-h2">
          <FormLabel>{t("purchaseOrder.sequence")}</FormLabel>
          <div
            className="essui-textinput sequence"
            onKeyDown={handleSequenceFieldKeyDown}
          >
            {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
              const sequenceId = `sequence=${index + 1}`;
              return (
                <RadioButton
                  label={column.sequenceName ? column.sequenceName : column.headerName}
                  labelPosition={RadioLabelPosition.Right}
                  value={column.field}
                  onChange={() => {
                    dispatch(
                      mjPeriodssActions.setFilters({
                        sequenceValue: String(column.field),
                        sequenceIndex: String(index),
                        lookingFor: ""
                      })
                    );
                  }}
                  isSelected={filters?.sequenceValue === column.field}
                  key={sequenceId}
                  id="periodSequence"
                  name="sequenceColumn"
                />
              );
            })}
          </div>
        </div>
      </GridItem>
    </Grid>
  );
};

export default SelectPeriodFiltersWithSequence;
