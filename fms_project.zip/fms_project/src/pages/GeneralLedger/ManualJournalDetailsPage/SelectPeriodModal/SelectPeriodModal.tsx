import GridTableNew, { RowType } from "@/components/GridTableNew/GridTableNew";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { AppDispatch, useAppSelector } from "@/store/store";
import { getCurrentFinancialYear, SEQUENCE_NAME, STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import React, { useEffect, useMemo, useState } from "react";
import { useFormContext } from "react-hook-form";
import { useDispatch } from "react-redux";
import BodyUtil from "@/shared/utils/NoScroll";
import { useHistory, useParams } from "react-router-dom";
import { localRoutes } from "@/utils/constants";
import SelectPeriodsColumnDef from "./Grid/SelectPeriodsColumnDef";
import {
  fetchContraPeriods,
  fetchPeriods,
  mjPeriodssActions,
  PeriodRowType
} from "../../State/ManualJournalPeriods.slice";
import SelectPeriodsFilters from "./Grid/SelectPeriodsFilters";
import SelectPeriodCustomCell from "./Grid/SelectPeriodCustomCell";
import { periodsType } from "../ManualJournalDetailsPage";
import SelectPeriodFiltersWithSequence from "./Grid/SelectPeriodFiltersWithSequence";

type Period = {
  period: number;
  description: string;
  startDate: string;
};

type PropsType = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  id?: periodsType;
  isReversal?: boolean;
  voucherType?: string;
  isEnableSequence?: boolean;
  period?: number;
};

const SelectPeriodModal = ({ setOpen, isOpen, id, isReversal, voucherType, isEnableSequence, period }: PropsType) => {
  const history = useHistory();
  const {
    location: { pathname }
  } = history;
  const { voucherId } = useParams<{ voucherId: string }>();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { selectedView: revFinYearSelected } = useAppSelector((state) => state.manualJournalFinancialYears);
  const dispatch = useDispatch<AppDispatch>();
  const { periods, status, selectedRow, reversalPeriodRow, filters, columnDef } = useAppSelector(
    (state) => state.manualJournalPeriods
  );
  const [isRowSelectionEnabled, setIsRowSelectionEnabled] = useState<boolean>(false);
  const { setValue } = useFormContext();
  const [row, setRow] = useState<PeriodRowType | undefined>(
    id === periodsType.NORMAL ? selectedRow : reversalPeriodRow
  );
  const dataSource = useMemo(() => {
    const source =
      id === periodsType.REVERSAL && selectedRow && voucherType !== "CL"
        ? periods.filter((p) => p.period_no > selectedRow?.period_no!)
        : [...periods];

    if (id !== periodsType.REVERSAL && isReversal) {
      source.pop(); // Remove the last period in case of reversal so that it should till feb
    }

    return source;
  }, [id, periods, selectedRow, isReversal]);

  const closeHandler = () => {
    setOpen(false);
    const { field } = columnDef.filter((col) => !!col.sequence)[0];
    dispatch(mjPeriodssActions.setFilters({ ...filters, lookingFor: "", sequenceValue: field }));
  };

  useEffect(
    () => () => {
      BodyUtil.NoScroll.remove();
      const { field } = columnDef.filter((col) => !!col.sequence)[0];
      dispatch(mjPeriodssActions.setFilters({ ...filters, lookingFor: "", sequenceValue: field, sequenceIndex: "0" }));
    },
    []
  );

  useEffect(() => {
    if (isOpen) {
      if (revFinYearSelected && voucherType === "CL") {
        dispatch(fetchPeriods({ sequence: filters?.sequenceIndex, yearId: revFinYearSelected.value }));
      } else if (
        pathname.includes(localRoutes.manualtJournalProcessing.manualJournalContra) ||
        pathname.includes(`general-ledger/manual-journal-list/edit/${voucherId}/contra/${voucherId}`)
      ) {
        dispatch(fetchContraPeriods({ period, yearId: Number(getCurrentFinancialYear()) }));
      } else {
        dispatch(fetchPeriods({ sequence: filters?.sequenceIndex }));
      }
    }
  }, [filters?.sequenceIndex, isOpen]);

  const selectHandler = () => {
    if (id === periodsType.NORMAL) {
      setValue("period_no", row?.period_no, { shouldDirty: true, shouldValidate: true });
      dispatch(mjPeriodssActions.setSelectedRow(row));
    } else {
      setValue("reversal_period_no", row?.period_no, { shouldDirty: true, shouldValidate: true });
      dispatch(mjPeriodssActions.setReversalPeriodRow(row));
    }
    dispatch(mjPeriodssActions.resetFilters());
  };

  const tertiaryButton = (
    <HelpButton
      identifier="testIdentifier"
      labelName={t("common.help")}
    />
  );

  const secondaryButton = (
    <Button
      size={ButtonSize.Small}
      color={ButtonColor.Secondary}
      id="cancel-periods-button"
      onClick={closeHandler}
    >
      {t("common.cancel")}
    </Button>
  );

  const primaryButton = (
    <Button
      size={ButtonSize.Small}
      id="select-periods-button"
      onClick={() => {
        selectHandler();
        setOpen(false);
      }}
    >
      {t("common.select")}
    </Button>
  );

  return (
    <Modalv2
      header={
        id === periodsType.NORMAL ? t("manualJournalPage.selectPeriod") : t("manualJournalPage.selectReversalPeriod")
      }
      isOpen={isOpen}
      primaryButton={primaryButton}
      secondaryButton={secondaryButton}
      tertiaryButton={tertiaryButton}
      onClose={closeHandler}
      className="set__table--hegiht"
    >
      <div>
        <GridTableNew
          dataTestId="selectPeriodsGrid"
          filters={
            <>
              {isEnableSequence ? (
                <SelectPeriodFiltersWithSequence
                  setSelectRow={setRow}
                  isOpen={isOpen}
                />
              ) : (
                <SelectPeriodsFilters
                  selectRow={row}
                  setSelectRow={setRow}
                />
              )}
            </>
          }
          customCell={SelectPeriodCustomCell}
          isScrollable
          enableScrollIntoView
          dataSource={dataSource}
          selectedRow={row}
          isLoading={status === STATUS.LOADING}
          columnDef={isEnableSequence ? columnDef : SelectPeriodsColumnDef}
          selectedRowHandler={(row) => setRow(row as any)}
          onEnterKeyPress={() => {
            selectHandler();
            setOpen(false);
          }}
          isRowSelectOnArrowkey={isRowSelectionEnabled}
          onFocus={(e) => {
            if (e.target.id === SEQUENCE_NAME.PERIOD_SEQUENCE) {
              setIsRowSelectionEnabled(false);
            } else {
              setIsRowSelectionEnabled(true);
            }
          }}
        />
      </div>
    </Modalv2>
  );
};

SelectPeriodModal.defaultProps = {
  id: undefined,
  isReversal: false,
  voucherType: "",
  isEnableSequence: undefined,
  period: undefined
};

export default SelectPeriodModal;
