import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import useDebounce from "@/hooks/useDebounce";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { actions as chequeActions } from "../state/ChequeProcessing.slice";

const useChequeSearchModalFilter = () => {
  const { searchFilters } = useAppSelector((state) => state.newChequeProcessingList);

  const dispatch = useDispatch<AppDispatch>();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [value, setValue] = useState<string>("");
  const debouncedValue = useDebounce(value, 600);

  useEffect(() => {
    if (debouncedValue) {
      dispatch(
        chequeActions.setSearchFilters({
          ...searchFilters,
          lookingFor: value,
          highLightedChequeNumber: undefined
        })
      );
      setValue("");
    }
  }, [debouncedValue]);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value !== "") {
      setValue(e.target.value.toUpperCase());
    } else {
      setValue("");
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      document.getElementById("searchCheque-lookingFor")?.focus();
    }, 10);
    return () => clearTimeout(timer);
  }, []);

  return {
    searchFilters,
    handleLookingForChange,
    t
  };
};

export default useChequeSearchModalFilter;
