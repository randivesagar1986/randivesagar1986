import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { IPaginationProps } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { actions as chequeActions, searchChequeNumber } from "../state/ChequeProcessing.slice";

type ChequeSearchPopupHooksProps = {
  setOpen: (isOpen: boolean) => void;
  isOpen: boolean;
};

const useChequeSearchModal = ({ setOpen, isOpen }: ChequeSearchPopupHooksProps) => {
  const dispatch = useDispatch<AppDispatch>();
  const { searchFilters, searchChequeList, searchStatus } = useAppSelector(
    (state) => state.newChequeProcessingList || {}
  );
  const { currentPage, totalPages } = useAppSelector(
    ({ newChequeProcessingList }) => newChequeProcessingList?.searchChequeList
  );

  const [selectedRow, setSelectedRow] = useState<any>();

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];
  const closeHandler = () => {
    if (selectedRow?.cheque_run_number) {
      dispatch(chequeActions?.setFindChequeNumber(true));
      dispatch(
        chequeActions.setFilters({
          sequenceValue: "payment_run_number",
          lookingFor: selectedRow?.cheque_run_number,
          sequence: 1,
          applyFilterChange: true
        })
      );
    }
    setSelectedRow(undefined);
    setOpen(false);
  };

  const handleSelectedRowChange = (row: any) => {
    setSelectedRow(row);
  };

  useEffect(() => {
    if (isOpen) {
      dispatch(
        chequeActions.setSearchFilters({
          ...searchFilters,
          pageNumber: 1,
          lookingFor: ""
        })
      );
    }
  }, [isOpen]);

  const getDataSource = () => searchChequeList.cheques;

  const onChangeHandler: onChangeType = (e, page) => {
    dispatch(
      chequeActions.setSearchFilters({
        ...searchFilters,
        pageNumber: page,
        lookingFor: ""
      })
    );
  };

  useEffect(() => {
    if (isOpen) {
      dispatch(
        searchChequeNumber({
          ...searchFilters,
          callback: (data, row) => {
            setSelectedRow(row);
          }
        })
      );
    }
  }, [searchFilters]);

  const onEnterKeyPress = (event: any) => {
    if (event.target.id === "" || event.target.id === "searchCheque-lookingFor") {
      return;
    }
    closeHandler();
  };

  return {
    t,
    searchChequeList,
    closeHandler,
    selectedRow,
    handleSelectedRowChange,
    totalPages,
    currentPage,
    onChangeHandler,
    setSelectedRow,
    getDataSource,
    searchStatus,
    onEnterKeyPress
  };
};

export default useChequeSearchModal;
