import Layout from "@/components/Layout/Layout";
import "./Style.scss";
import { STATUS } from "@/types/UseStateType";
import { Button, ButtonColor, ButtonSize, FormLabel, Icon, IconColor, Pagination } from "@essnextgen/ui-kit";
import GridTableNew, { cellRendererType } from "@/components/GridTableNew/GridTableNew";
import { Link, useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { fetchUserAccessRights, Screen } from "@/store/state/userAccessRights.slice";
import ChequeProcessingFilters from "./Grid/ChequeProcessingFilters";
import useChequeList from "./useChequeProcessingList";
import ChequeProcessingPageToolbar from "../ChequeProcessingPageToolBar";
import ChequeProcessingToolBar from "./ChequeProcessingToolBar/ChequeProcessingToolBar";
import { actions as cpAction, getChequeProcessingList } from "../state/ChequeProcessing.slice";
import { actions as sumAction } from "../state/SummaryOfCheques.slice";
import ChequeSearchModal from "./Grid/ChequeSearchModal";

const ChequeProcessingList = () => {
  const [isChequeSearchModalOpen, setIsChequeSearchModalOpen] = useState<boolean>(false);
  const { isFindCheque } = useAppSelector((state) => state.newChequeProcessingList);
  const {
    t,
    data,
    totalPages,
    currentPage,
    cpColumnDef,
    bank,
    account,
    status,
    user,
    noOfCheques,
    noReconciled,
    noSpoiled,
    selectedRowHandler,
    chequeStatus,
    selectPrevRecord,
    selectNextRecord,
    onChangeHandler,
    selectedRow,
    filterState,
    isFocus,
    clearTableFooter
  } = useChequeList();

  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();

  const handleDetailViewClick = (row: any) => {
    const paymentRunNumber = row.payment_run_number.toString().padStart(6, "0");
    localStorage.setItem("selectedPaymentRunNumber", paymentRunNumber);
    dispatch(cpAction.setSelectedRow(row));
    history.push(
      `/accounts-payable/cheque-processing/cheque-processing-detail/${row?.payment_run_id ? row?.payment_run_id : "0"}`
    );
  };

  const CustomCell = ({ field, row }: cellRendererType) => {
    const getContent = () => {
      if (field === "run_date") {
        return (
          <>
            {new Intl.DateTimeFormat("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })
              .format(new Date(row?.run_date))
              .replace("Sept", "Sep")}
          </>
        );
      }
      if (field === "payment_run_number") {
        return <>{row?.payment_run_number.toString().padStart(6, "0")}</>;
      }
      if (field === "narrative") {
        return <>{row?.narrative.trim() ? row?.narrative.trim() : "-"}</>;
      }
      if (field === "detailLink") {
        return (
          <>
            <Button
              className=" grid-actions__button m-auto"
              size={ButtonSize.Small}
              color={ButtonColor.Tertiary}
              onClick={() => handleDetailViewClick(row)}
            >
              <Icon
                color={IconColor.Primary500}
                name="chevron--right"
              />
            </Button>
          </>
        );
      }
      return null;
    };
    return getContent();
  };

  useEffect(() => {
    if (filterState?.applyFilterChange) {
      if (filterState?.lookingFor) {
        dispatch(
          getChequeProcessingList({
            ...filterState,
            callback: (resData) => showHighlightedRecord(resData)
          })
        );
        if (isFindCheque === true) {
          dispatch(
            cpAction.setFilters({
              lookingFor: ""
            })
          );
        }
        dispatch(sumAction.resetPDFData());
      }
    }
  }, [filterState?.lookingFor]);

  useEffect(() => {
    dispatch(cpAction.setFilters({ highlightId: undefined }));
    dispatch(
      getChequeProcessingList({
        ...filterState,
        callback: (resData) => showHighlightedRecord(resData)
      })
    );
  }, [filterState?.orderBy]);

  const showHighlightedRecord = (resData: any) => {
    const row = resData.data.find((row: { [key: string]: any }) => row?.payment_run_id === resData?.highLightId);
    if (!row) {
      dispatch(cpAction.setSelectedRow(resData.data[0]));
    } else {
      dispatch(cpAction.setSelectedRow(row));
    }
  };

  useEffect(() => {
    if (filterState?.status === "P") {
      clearTableFooter();
    }
  }, [filterState]);

  useEffect(() => {
    sessionStorage.removeItem("chequeProcessing");
    dispatch(fetchUserAccessRights(Screen.ChequeProcessing));
  }, []);

  return (
    <>
      <Layout
        pageTitle={t("chequeProcessing.chequeProcessing")}
        className="cheque-processing cheque-processing__list"
        rightContent={
          <ChequeProcessingToolBar
            goToPrevRecord={selectPrevRecord}
            goToNextRecord={selectNextRecord}
          />
        }
        toolbar={<ChequeProcessingPageToolbar />}
        type="transparent"
      >
        <GridTableNew
          dataTestId="chequeProcessingList"
          filters={<ChequeProcessingFilters />}
          dataSource={data || []}
          isLoading={chequeStatus === STATUS.LOADING}
          columnDef={cpColumnDef}
          customCell={CustomCell}
          selectedRow={selectedRow}
          selectedRowHandler={selectedRowHandler}
          onEnterKeyPress={(e) => {
            if (!e.target.className.includes("cheque-processing-detail-link")) return;
            handleDetailViewClick(selectedRow);
          }}
          footer={
            <>
              <div className="button-right">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Primary}
                  onClick={() => setIsChequeSearchModalOpen(true)}
                >
                  {t("chequeProcessing.findChequeNo")}
                </Button>
                <Pagination
                  count={totalPages}
                  page={currentPage}
                  onChange={(e, page) => {
                    onChangeHandler(page);
                  }}
                />
              </div>
            </>
          }
        />
      </Layout>

      <Layout isBreadcrumbRequired={false}>
        <div className="footer-controls">
          <div className="row">
            <div className="controls">
              <FormLabel>{t("chequeProcessing.bank")}</FormLabel>
              <div>{bank || t("chequeProcessing.bankAccount")}</div>
            </div>
            <div className="controls">
              <FormLabel>{t("chequeProcessing.account")}</FormLabel>
              <div>{account}</div>
            </div>
            <div className="controls">
              <FormLabel>{t("chequeProcessing.status")}</FormLabel>
              <div>{status}</div>
            </div>
          </div>
          <div className="row">
            <div className="controls">
              <FormLabel>{t("chequeProcessing.noOfCheques")}</FormLabel>
              <div>{noOfCheques}</div>
            </div>
            <div className="controls">
              <FormLabel>{t("chequeProcessing.noReconciled")}</FormLabel>
              <div>{noReconciled}</div>
            </div>
            <div className="controls">
              <FormLabel>{t("chequeProcessing.noSpoiled")}</FormLabel>
              <div>{noSpoiled}</div>
            </div>
            <div className="controls">
              <FormLabel>{t("chequeProcessing.user")}</FormLabel>
              <div>{user}</div>
            </div>
          </div>
        </div>
      </Layout>
      <ChequeSearchModal
        isOpen={isChequeSearchModalOpen}
        setOpen={setIsChequeSearchModalOpen}
      />
    </>
  );
};

export default ChequeProcessingList;
