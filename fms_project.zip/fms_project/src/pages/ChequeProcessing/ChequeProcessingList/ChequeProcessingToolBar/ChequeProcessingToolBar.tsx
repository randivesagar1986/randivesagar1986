import {
  AddLarge,
  ArrowDown,
  ArrowUp,
  Subtract,
  Save,
  /* eslint-disable camelcase */
  Thumbnail_2,
  Undo
} from "@carbon/icons-react";
import { ButtonSize, NotificationStatus } from "@essnextgen/ui-kit";
import Toolbar, { ToolbarType } from "@/components/Toolbar/Toolbar";
import { toolBarTitle } from "@/utils/constants";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import useChequeDetail from "../useChequeProcessingDetail";
import { useChequeProcessingToolBar } from "./useChequeProcessingToolBar";
import { actions as cpActions } from "../../state/ChequeProcessing.slice";

type TChequeProcessingToolbarProps = {
  onSubmit?: () => void;
  goToPrevRecord?: () => void;
  goToNextRecord?: () => void;
};

const ChequeProcessingToolbar = ({ onSubmit, goToPrevRecord, goToNextRecord }: TChequeProcessingToolbarProps) => {
  const { t, goToAdd, isAlertModalOpen, setIsAlertModalOpen, chequePaymentRun } = useChequeProcessingToolBar();

  const history = useHistory();
  const historyState = history.location.state as any;

  const dispatch = useDispatch<AppDispatch>();

  const { selectedRow } = useAppSelector((state) => state.newChequeProcessingList);

  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const addAccess = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.ChequeProcessing,
    action: ACCESS_RIGHTS_ACTION.Add
  });
  const cancelAccess = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.ChequeProcessing,
    action: ACCESS_RIGHTS_ACTION.Cancel
  });

  const buttons: ToolbarType[] = [
    {
      title: toolBarTitle.focusMode,
      /* eslint-disable react/jsx-pascal-case */
      element: <Thumbnail_2 size={18} />,
      size: ButtonSize.Small,
      onClick: async () => {
        if (history.location.pathname.includes("/cheque-processing-detail")) {
          dispatch(cpActions.setFocus());
          history.push("/accounts-payable/cheque-processing");
        } else {
          history.push(`/accounts-payable/cheque-processing/cheque-processing-detail/${selectedRow?.payment_run_id}`);
        }
      }
    },
    {
      title: toolBarTitle.previousRecord,
      element: <ArrowUp size={18} />,
      size: ButtonSize.Small,
      onClick: () => {
        if (goToPrevRecord) goToPrevRecord();
      }
    },
    {
      title: toolBarTitle.nextRecord,
      element: <ArrowDown size={18} />,
      size: ButtonSize.Small,
      onClick: (e) => {
        if (goToNextRecord) goToNextRecord();
      }
    },
    {
      title: toolBarTitle.addRecord,
      element: <AddLarge size={18} />,
      onClick: goToAdd,
      size: ButtonSize.Small,
      disabled: !addAccess
    },
    {
      title: toolBarTitle.saveRecord,
      element: <Save size={18} />,
      onClick: onSubmit,
      size: ButtonSize.Small,
      disabled: !(addAccess || cancelAccess)
    },
    {
      title: toolBarTitle.undoRecord,
      element: <Undo size={18} />,
      size: ButtonSize.Small,
      disabled: !(addAccess || cancelAccess)
    }
  ];

  return (
    <>
      <AlertModal
        title={t("alertMessage.title")}
        isOpen={isAlertModalOpen}
        setOpen={setIsAlertModalOpen}
        message={t("chequeProcessing.chequeRunAlert", {
          paymentRunNumber: chequePaymentRun[0]
        })}
        notificationType={NotificationStatus.HIGHLIGHT}
      />
      <Toolbar buttons={buttons} />
    </>
  );
};

ChequeProcessingToolbar.defaultProps = {
  onSubmit: undefined,
  goToPrevRecord: undefined,
  goToNextRecord: undefined
};

export default ChequeProcessingToolbar;
