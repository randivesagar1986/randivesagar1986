import { renderHook, act } from "@testing-library/react-hooks";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import useDebounce from "@/hooks/useDebounce";
import React from "react";
import useChequeSearchModalFilter from "../useChequeSearchModalFilters";
import { actions as chequeActions } from "../../state/ChequeProcessing.slice";

// Mock dependencies
jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("@/hooks/useDebounce");

describe("useChequeSearchModalFilter", () => {
  const mockDispatch = jest.fn();

  beforeEach(() => {
    jest.useFakeTimers();
    (useDebounce as jest.Mock).mockImplementation((value) => value);

    jest.spyOn(document, "getElementById").mockImplementation((id) => {
      if (id === "searchCheque-lookingFor") {
        return {
          focus: jest.fn()
        } as unknown as HTMLElement;
      }
      return null;
    });

    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => {
      if (selector.name === "newChequeProcessingList") {
        return {
          searchFilters: {
            pageNumber: 1,
            pageSize: 5,
            lookingFor: "",
            highLightedChequeNumber: 0
          }
        };
      }
      return {};
    });
    jest.spyOn(global, "clearTimeout");
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.useRealTimers();
  });

  it("should set focus on the 'searchCheque-lookingFor' element after a delay", () => {
    renderHook(() => useChequeSearchModalFilter());

    jest.advanceTimersByTime(10);
  });

  it("should clear the timeout on unmount", () => {
    const { unmount } = renderHook(() => useChequeSearchModalFilter());

    unmount();

    expect(clearTimeout).toHaveBeenCalled();
  });

  it("should dispatch setSearchFilters and reset value when debouncedValue changes", () => {
    const { result, rerender } = renderHook(() => useChequeSearchModalFilter());

    act(() => {
      result.current.handleLookingForChange({
        target: { value: "test" }
      } as React.ChangeEvent<HTMLInputElement>);
    });

    (useDebounce as jest.Mock).mockReturnValue("TEST");
    rerender();

    expect(mockDispatch).toHaveBeenCalledWith(
      chequeActions.setSearchFilters(
        expect.objectContaining({
          lookingFor: "TEST",
          highLightedChequeNumber: undefined
        })
      )
    );

    expect(result.current.handleLookingForChange).toBeDefined();
  });

  it("should initialize with correct default values", () => {
    const { result } = renderHook(() => useChequeSearchModalFilter());
    expect(result.current.t).toBeDefined();
  });

  it("should dispatch uppercase value when handleLookingForChange is called with a non-empty input", () => {
    const { result } = renderHook(() => useChequeSearchModalFilter());

    act(() => {
      result.current.handleLookingForChange({
        target: { value: "test" }
      } as React.ChangeEvent<HTMLInputElement>);
    });

    expect(mockDispatch).toHaveBeenCalledWith(
      chequeActions.setSearchFilters(
        expect.objectContaining({
          lookingFor: "TEST",
          highLightedChequeNumber: undefined
        })
      )
    );
  });

  it("should clear search filters when handleLookingForChange is called with an empty input", () => {
    const { result } = renderHook(() => useChequeSearchModalFilter());

    act(() => {
      result.current.handleLookingForChange({
        target: { value: "" }
      } as React.ChangeEvent<HTMLInputElement>);
    });
  });
});
