import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import { STATUS } from "@/types/UseStateType";
import ChequeSearchPopup from "../Grid/ChequeSearchModal";
import useChequeSearchModal from "../useChequeSearchModal";

// Mock dependencies
jest.mock("../useChequeSearchModal");
jest.mock("@/shared/components/CommonGridModal/CommonGridModal", () => ({
  __esModule: true,
  default: ({ headerTitle, modalFooter, children }: any) => (
    <div data-testid="CommonGridModal">
      <h1>{headerTitle}</h1>
      {children}
      {modalFooter}
    </div>
  )
}));

describe("ChequeSearchPopup Component", () => {
  const mockSetOpen = jest.fn();
  const mockGetDataSource = jest.fn();
  const mockOnEnterKeyPress = jest.fn();
  const mockOnChangeHandler = jest.fn();
  const mockSetSelectedRow = jest.fn();
  const t = (key: string) => {
    switch (key) {
      case "chequeProcessing.findChequeNo":
        return "Find Cheque Number";
      case "common.ok":
        return "OK";
      default:
        return key;
    }
  };

  const mockChequeSearchPopupProps = {
    setOpen: mockSetOpen,
    isOpen: true
  };

  beforeEach(() => {
    (useChequeSearchModal as jest.Mock).mockReturnValue({
      t,
      searchStatus: STATUS.IDLE,
      selectedRow: null,
      closeHandler: () => mockSetOpen(false),
      currentPage: 1,
      totalPages: 5,
      onChangeHandler: mockOnChangeHandler,
      setSelectedRow: mockSetSelectedRow,
      getDataSource: mockGetDataSource,
      onEnterKeyPress: mockOnEnterKeyPress
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("renders the modal with correct title and button", () => {
    render(
      <ChequeSearchPopup
        isOpen
        setOpen={mockSetOpen}
      />
    );

    expect(screen.getByText("Find Cheque Number")).toBeInTheDocument();

    expect(screen.getByRole("button", { name: "OK" })).toBeInTheDocument();
  });

  test("calls closeHandler when OK button is clicked", () => {
    render(
      <ChequeSearchPopup
        isOpen
        setOpen={mockSetOpen}
      />
    );

    fireEvent.click(screen.getByText("OK"));

    expect(mockSetOpen).toHaveBeenCalledWith(false);
  });

  test("calls setOpen with false when the modal is closed", () => {
    render(
      <ChequeSearchPopup
        isOpen
        setOpen={mockSetOpen}
      />
    );

    const { closeHandler } = useChequeSearchModal(mockChequeSearchPopupProps);
    closeHandler();

    expect(mockSetOpen).toHaveBeenCalledWith(false);
  });
});
