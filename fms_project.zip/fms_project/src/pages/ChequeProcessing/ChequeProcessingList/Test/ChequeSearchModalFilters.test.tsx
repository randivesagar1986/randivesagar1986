import { render, screen, fireEvent } from "@testing-library/react";
import ChequeSearchModalFilters from "../Grid/ChequeSearchModalFilters";
import useChequeSearchModalFilter from "../useChequeSearchModalFilters";

jest.mock("../useChequeSearchModalFilters");

describe("ChequeSearchModalFilters", () => {
  const mockHandleLookingForChange = jest.fn();

  beforeEach(() => {
    (useChequeSearchModalFilter as jest.Mock).mockReturnValue({
      searchFilters: { lookingFor: "" },
      handleLookingForChange: mockHandleLookingForChange,
      t: (key: string) => key
    });
  });

  it("should render without crashing", () => {
    render(<ChequeSearchModalFilters />);
    expect(screen.getByLabelText("common.lookingFor")).toBeInTheDocument();
  });

  it("should render the input field", () => {
    render(<ChequeSearchModalFilters />);
    expect(screen.getByRole("textbox", { name: "common.lookingFor" })).toBeInTheDocument();
  });

  it("should call handleLookingForChange on input change", () => {
    render(<ChequeSearchModalFilters />);
    const input = screen.getByRole("textbox", { name: "common.lookingFor" });

    fireEvent.change(input, { target: { value: "TEST" } });
  });

  it("should bind the input value to searchFilters.lookingFor", () => {
    (useChequeSearchModalFilter as jest.Mock).mockReturnValue({
      searchFilters: { lookingFor: "TEST" },
      handleLookingForChange: mockHandleLookingForChange,
      t: (key: string) => key
    });

    render(<ChequeSearchModalFilters />);
    const input = screen.getByRole("textbox", { name: "common.lookingFor" });

    expect(input).toHaveValue("TEST");
  });

  it("should prevent non-alphanumeric characters from being input", () => {
    render(<ChequeSearchModalFilters />);
    const input = screen.getByRole("textbox", { name: "common.lookingFor" });

    fireEvent.keyDown(input, { key: "!", code: "Digit1" });

    expect(input).toHaveValue("");
    fireEvent.keyDown(input, { key: "A", code: "KeyA" });
    fireEvent.change(input, { target: { value: "A" } });

    expect(input).toHaveValue("A");
  });
});
