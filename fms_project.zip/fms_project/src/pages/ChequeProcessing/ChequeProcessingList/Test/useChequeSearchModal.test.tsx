import { renderHook, act } from "@testing-library/react-hooks";
import { useDispatch } from "react-redux";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { actions as chequeActions } from "../../state/ChequeProcessing.slice";
import useChequeSearchModal from "../useChequeSearchModal";

// Mocking external dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));
jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("@/pages/ChequeProcessing/state/ChequeProcessing.slice", () => ({
  actions: {
    setFindChequeNumber: jest.fn(),
    setFilters: jest.fn(),
    setSearchFilters: jest.fn()
  },
  searchChequeNumber: jest.fn()
}));

describe("useChequeSearchModal", () => {
  const setOpenMock = jest.fn();
  const mockDispatch = jest.fn();

  beforeEach(() => {
    jest.useFakeTimers();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useTranslation as jest.Mock).mockReturnValue({ t: (key: string) => key });
    (useAppSelector as jest.Mock).mockImplementation((selector) => {
      if (selector.name === "newChequeProcessingList") {
        return {
          searchStatus: "idle",
          selectedRow: null,
          searchFilters: {
            pageNumber: 1,
            pageSize: 5,
            lookingFor: "",
            highLightedChequeNumber: 0
          },
          filterState: {
            pageNumber: "1",
            pageSize: "10",
            orderBy: 1,
            sequence: 0,
            status: "A",
            skip: "",
            lookingFor: "",
            highlightId: 0,
            applyFilterChange: true,
            sequenceValue: 0
          },
          isFindCheque: false,
          searchChequeList: {
            cheques: [],
            currentPage: 1,
            pageSize: 5,
            totalPages: 0,
            totalCount: ""
          }
        };
      }
      return {};
    });
  });

  afterEach(() => {
    jest.useRealTimers();
    jest.clearAllMocks();
  });

  it("should initialize with correct values", () => {
    const { result } = renderHook(() => useChequeSearchModal({ setOpen: setOpenMock, isOpen: false }));

    expect(result.current.t).toBeDefined();
  });

  it("should close modal and reset selectedRow when closeHandler is called", () => {
    const { result } = renderHook(() => useChequeSearchModal({ setOpen: setOpenMock, isOpen: true }));

    act(() => {
      result.current.setSelectedRow(undefined);
      result.current.closeHandler();
    });

    expect(mockDispatch).not.toHaveBeenCalledWith(
      expect.objectContaining({ type: chequeActions.setFindChequeNumber.type })
    );
    expect(mockDispatch).not.toHaveBeenCalledWith(expect.objectContaining({ type: chequeActions.setFilters.type }));
    expect(setOpenMock).toHaveBeenCalledWith(false);
    expect(result.current.selectedRow).toBeUndefined();

    const validRow = { cheque_run_number: "123" };
    act(() => {
      result.current.setSelectedRow(validRow);
      result.current.closeHandler();
    });

    expect(mockDispatch).toHaveBeenCalledWith(chequeActions.setFindChequeNumber(true));
    expect(mockDispatch).toHaveBeenCalledWith(
      chequeActions.setFilters({
        sequenceValue: "payment_run_number",
        lookingFor: "123",
        sequence: 1,
        applyFilterChange: true
      })
    );
    expect(setOpenMock).toHaveBeenCalledWith(false);
    expect(result.current.selectedRow).toBeUndefined();
  });

  it("should call closeHandler directly when conditions are met", () => {
    const setOpenMock = jest.fn();
    const { result } = renderHook(() => useChequeSearchModal({ setOpen: setOpenMock, isOpen: true }));

    act(() => {
      result.current.setSelectedRow({ cheque_run_number: "123" });
    });

    act(() => {
      result.current.closeHandler();
    });

    expect(setOpenMock).toHaveBeenCalledWith(false);
    expect(result.current.selectedRow).toBeUndefined();
  });

  it("should call closeHandler on Enter key press if the target id is not 'searchCheque-lookingFor'", () => {
    const setOpenMock = jest.fn();
    const { result } = renderHook(() => useChequeSearchModal({ setOpen: setOpenMock, isOpen: true }));

    act(() => {
      result.current.setSelectedRow({ cheque_run_number: "123" });
    });

    const mockEvent = {
      key: "Enter",
      target: { id: "some-other-id" }
    } as any;

    act(() => {
      result.current.onEnterKeyPress(mockEvent);
    });
  });

  it("should not call closeHandler on Enter key press if the target id is 'searchCheque-lookingFor'", () => {
    const setOpenMock = jest.fn();
    const { result } = renderHook(() => useChequeSearchModal({ setOpen: setOpenMock, isOpen: true }));

    act(() => {
      result.current.setSelectedRow({ cheque_run_number: "123" });
    });

    const closeHandlerSpy = jest.spyOn(result.current, "closeHandler");

    const mockEvent = {
      key: "Enter",
      target: { id: "searchCheque-lookingFor" }
    } as any;

    act(() => {
      result.current.onEnterKeyPress(mockEvent);
    });

    expect(closeHandlerSpy).not.toHaveBeenCalled();
  });
});
