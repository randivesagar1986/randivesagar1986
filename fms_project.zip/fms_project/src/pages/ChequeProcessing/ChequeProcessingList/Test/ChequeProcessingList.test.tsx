import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import { MemoryRouter, useHistory } from "react-router-dom";
import configureStore from "redux-mock-store";
import thunk from "redux-thunk";
import { STATUS } from "@/types/UseStateType";
import { Button, ButtonColor, ButtonSize, Icon, IconColor } from "@essnextgen/ui-kit";
import { cellRendererType } from "@/components/GridTableNew/GridTableNew";
import ChequeProcessingList from "../ChequeProcessingList";
import ChequeProcessing from "../ChequeProcessingDetail";
import { actions as cpActions } from "../../state/ChequeProcessing.slice";

const mockStore = configureStore([thunk]);
const store = mockStore({
  chequeProcessingList: {
    chequePayments: [],
    chequePaymentDetails: {},
    firstTableStatus: STATUS.IDLE,
    detailStatus: STATUS.IDLE
  },
  newChequeProcessingList: {
    isFindCheque: false,
    chequePayments: [{ payment_id: 1, amount: 100 }],
    chequePaymentDetails: {},
    firstTableStatus: STATUS.IDLE,
    detailStatus: STATUS.IDLE,
    filterState: {},
    selectedRow: null,
    chequereferenceList: []
  },
  chequeList: {
    data: [],
    currentPage: 1,
    totalPages: 1,
    pageSize: 10
  },
  chequeProcessingStatus: STATUS.IDLE,
  chequeProcessingError: null
});

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn((selector) => selector(store.getState())),
  useDispatch: () => jest.fn()
}));

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useHistory: () => ({
    push: jest.fn(),
    location: { pathname: "/accounts-payable/cheque-processing" }
  })
}));

jest.mock("../useChequeProcessingList", () => () => ({
  t: (key: string) => key,
  data: [],
  totalPages: 1,
  currentPage: 1,
  cpColumnDef: [],
  bank: "Test Bank",
  account: "Test Account",
  status: "Test Status",
  user: "Test User",
  noOfCheques: 10,
  noReconciled: 5,
  noSpoiled: 2,
  selectedRowHandler: jest.fn(),
  chequeStatus: STATUS.IDLE,
  selectPrevRecord: jest.fn(),
  selectNextRecord: jest.fn(),
  onChangeHandler: jest.fn(),
  selectedRow: null,
  filterState: {},
  clearTableFooter: jest.fn()
}));

const CustomCell = ({ field, row }: cellRendererType) => {
  const history = useHistory();
  const getContent = () => {
    if (field === "run_date") {
      return (
        <span>
          {new Intl.DateTimeFormat("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric"
          })
            .format(new Date(row?.run_date))
            .replace("Sept", "Sep")}
        </span>
      );
    }
    if (field === "payment_run_number") {
      return <span>{row?.payment_run_number.toString().padStart(6, "0")}</span>;
    }
    if (field === "narrative") {
      return <span>{row?.narrative.trim() ? row?.narrative.trim() : "-"}</span>;
    }
    if (field === "detailLink") {
      const handleDetailViewClick = (row: any) => {
        const paymentRunNumber = row.payment_run_number.toString().padStart(6, "0");
        localStorage.setItem("selectedPaymentRunNumber", paymentRunNumber);
        history.push(
          `/accounts-payable/cheque-processing/cheque-processing-detail/${
            row?.payment_run_id ? row?.payment_run_id : "0"
          }`
        );
      };

      return (
        <Button
          className="grid-actions__button m-auto"
          size={ButtonSize.Small}
          color={ButtonColor.Tertiary}
          onClick={() => handleDetailViewClick(row)}
        >
          <Icon
            color={IconColor.Primary500}
            name="chevron--right"
          />
        </Button>
      );
    }
    return null;
  };
  return getContent();
};

describe("ChequeProcessingList", () => {
  beforeEach(() => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <ChequeProcessingList />
        </MemoryRouter>
      </Provider>
    );
  });

  it("should render the layout with correct title", () => {
    expect(screen.getByTestId("layout-cheque")).toBeInTheDocument();
    expect(screen.getByText("chequeProcessing.chequeProcessing")).toBeInTheDocument();
  });

  it("should render CustomCell correctly for payment_run_number with leading zeros", () => {
    const row = { payment_run_number: 1 };
    render(
      <CustomCell
        field="payment_run_number"
        row={row}
      />
    );
    expect(screen.getByText("000001")).toBeInTheDocument();
  });

  it("should render CustomCell correctly for payment_run_number with no leading zeros needed", () => {
    const row = { payment_run_number: 123456 };
    render(
      <CustomCell
        field="payment_run_number"
        row={row}
      />
    );
    expect(screen.getByText("123456")).toBeInTheDocument();
  });

  it("should render CustomCell correctly for payment_run_number with more than six digits", () => {
    const row = { payment_run_number: 1234567 };
    render(
      <CustomCell
        field="payment_run_number"
        row={row}
      />
    );
    expect(screen.getByText("1234567")).toBeInTheDocument();
  });

  it("should render CustomCell correctly for payment_run_number with zero", () => {
    const row = { payment_run_number: 0 };
    render(
      <CustomCell
        field="payment_run_number"
        row={row}
      />
    );
    expect(screen.getByText("000000")).toBeInTheDocument();
  });

  it("should render CustomCell correctly for narrative", () => {
    const row = { narrative: "Test Narrative" };
    render(
      <CustomCell
        field="narrative"
        row={row}
      />
    );
    expect(screen.getByText("Test Narrative")).toBeInTheDocument();
  });

  it("should render CustomCell correctly for empty narrative", () => {
    const row = { narrative: "" };
    render(
      <CustomCell
        field="narrative"
        row={row}
      />
    );
    expect(screen.getByText("-")).toBeInTheDocument();
  });

  it("should render the GridTableNew component", () => {
    expect(screen.getByTestId("chequeProcessingList")).toBeInTheDocument();
  });

  it('should open ChequeSearchModal when "Find Cheque No" button is clicked', () => {
    const findChequeButton = screen.getByText("chequeProcessing.findChequeNo");
    fireEvent.click(findChequeButton);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("should render footer controls with correct values", () => {
    expect(screen.getByText("chequeProcessing.bank")).toBeInTheDocument();
    expect(screen.getByText("Test Bank")).toBeInTheDocument();
    expect(screen.getByText("chequeProcessing.account")).toBeInTheDocument();
    expect(screen.getByText("Test Account")).toBeInTheDocument();
    expect(screen.getByText("chequeProcessing.status")).toBeInTheDocument();
    expect(screen.getByText("Test Status")).toBeInTheDocument();
    expect(screen.getByText("chequeProcessing.noOfCheques")).toBeInTheDocument();
    expect(screen.getByText("10")).toBeInTheDocument();
    expect(screen.getByText("chequeProcessing.noReconciled")).toBeInTheDocument();
    expect(screen.getByText("5")).toBeInTheDocument();
    expect(screen.getByText("chequeProcessing.noSpoiled")).toBeInTheDocument();
    expect(screen.getByText("2")).toBeInTheDocument();
    expect(screen.getByText("chequeProcessing.user")).toBeInTheDocument();
    expect(screen.getByText("Test User")).toBeInTheDocument();
  });

  it("should handle toolbar actions correctly", () => {
    const toolbarButton = screen.getByText("chequeProcessing.findChequeNo");
    fireEvent.click(toolbarButton);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("should render the toolbar and buttons", () => {
    expect(screen.getByText(/chequeProcessing.findChequeNo/i)).toBeInTheDocument();
    expect(screen.getByText(/chequeProcessing.chequeProcessing/i)).toBeInTheDocument();
  });

  it("should handle toolbar button click", async () => {
    const toolbarButton = screen.getByText(/chequeProcessing.findChequeNo/i);
    fireEvent.click(toolbarButton);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("should render multiple buttons and handle clicks correctly", () => {
    const buttons = screen.getAllByRole("button");
    buttons.forEach((button) => {
      fireEvent.click(button);
      expect(button).toBeInTheDocument();
    });
  });
});

const mockChequePaymentDetails = [
  { payment_id: 1, item_date: "2023-01-01", payment_amount: 100, invoice_type: "PC" },
  { payment_id: 2, item_date: "2023-01-02", payment_amount: 200, invoice_type: "NC" }
];

describe("ChequeProcessingDetail", () => {
  const renderComponent = () =>
    render(
      <Provider store={store}>
        <MemoryRouter>
          <ChequeProcessing />
        </MemoryRouter>
      </Provider>
    );

  it("should render the component", () => {
    renderComponent();
    expect(screen.getByText(/chequeProcessing.chequeProcessing/i)).toBeInTheDocument();
  });

  it("should render the toolbar and buttons", () => {
    renderComponent();
    expect(screen.getByText(/chequeProcessing.zeroPaymentReport/i)).toBeInTheDocument();
    expect(screen.getByText(/chequeProcessing.chequeRunReport/i)).toBeInTheDocument();
  });

  it("should render the cheque processing detail grid", () => {
    renderComponent();
    expect(screen.getByTestId("chequeProcessingDetailGrid")).toBeInTheDocument();
  });
});
