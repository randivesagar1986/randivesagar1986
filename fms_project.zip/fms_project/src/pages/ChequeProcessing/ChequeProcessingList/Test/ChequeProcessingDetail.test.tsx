import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import { MemoryRouter } from "react-router-dom";
import configureStore from "redux-mock-store";
import thunk from "redux-thunk";
import ChequeProcessing from "../ChequeProcessingDetail";

const mockStore = configureStore([thunk]);

const store = mockStore({
  chequeProcessingList: {
    cancelStatus: "",
    cancelError: null,
    cancelChequePayment: null,
    selectedRow: null
  },
  newChequeProcessingList: {
    selectedRow: null
  },
  summaryOfCheques: {
    pdfByteArrayData: null
  },
  userAccessRights: {}
});

describe("ChequeProcessingDetail", () => {
  const renderComponent = () =>
    render(
      <Provider store={store}>
        <MemoryRouter>
          <ChequeProcessing />
        </MemoryRouter>
      </Provider>
    );

  it("should render the component", () => {
    renderComponent();
    expect(screen.getByText(/chequeProcessing.chequeProcessing/i)).toBeInTheDocument();
  });

  it("should handle zero payment report click", async () => {
    renderComponent();
    const zeroPaymentReportButton = screen.getByText(
      (content, element) => element?.textContent === "chequeProcessing.zeroReportMsg1"
    );
    fireEvent.click(zeroPaymentReportButton);
    expect(screen.getByText(/invoiceNote.invoiceModalCancel/i)).toBeInTheDocument();
  });

  it("should handle print cheque", async () => {
    renderComponent();
    const printChequeButton = screen.getByText((content, element) => element?.textContent === "printCheque");
    fireEvent.click(printChequeButton);
    expect(screen.getByText(/charts-accounts-review-preview/i)).toBeInTheDocument();
  });

  it("should open and close alert modal", async () => {
    renderComponent();
    const alertButton = screen.getByText((content, element) => element?.textContent === "alertMessage.title");
    fireEvent.click(alertButton);
    expect(screen.getByText(/alertMessage.title/i)).toBeInTheDocument();
    const closeButton = screen.getByText((content, element) => element?.textContent === "common.cancel");
    fireEvent.click(closeButton);
    expect(screen.queryByText(/alertMessage.title/i)).not.toBeInTheDocument();
  });

  it("should render the toolbar and buttons", () => {
    renderComponent();
    expect(screen.getByText(/chequeProcessing.zeroPaymentReport/i)).toBeInTheDocument();
    expect(screen.getByText(/chequeProcessing.chequeRunReport/i)).toBeInTheDocument();
  });

  it("should handle zero payment report button click", async () => {
    renderComponent();
    const zeroPaymentReportButton = screen.getByText(/chequeProcessing.zeroPaymentReport/i);
    fireEvent.click(zeroPaymentReportButton);
    expect(screen.getByText(/invoiceNote.invoiceModalCancel/i)).toBeInTheDocument();
  });

  it("should handle cheque run report button click", async () => {
    renderComponent();
    const chequeRunReportButton = screen.getByText(/chequeProcessing.chequeRunReport/i);
    fireEvent.click(chequeRunReportButton);
    expect(screen.getByText(/charts-accounts-review-preview/i)).toBeInTheDocument();
  });

  it("should open and close commitment modal", async () => {
    renderComponent();
    const commitmentButton = screen.getByText(
      (content, element) => element?.textContent === "chequeProcessing.commitmentMessageTitle"
    );
    fireEvent.click(commitmentButton);
    expect(screen.getByText(/chequeProcessing.commitmentMessageTitle/i)).toBeInTheDocument();
    const closeButton = screen.getByText((content, element) => element?.textContent === "common.cancel");
    fireEvent.click(closeButton);
    expect(screen.queryByText(/chequeProcessing.commitmentMessageTitle/i)).not.toBeInTheDocument();
  });

  it("should render the payment details grid", () => {
    renderComponent();
    expect(screen.getByTestId("paymentDetailsGrid")).toBeInTheDocument();
  });

  it("should render the cheque processing detail grid", () => {
    renderComponent();
    expect(screen.getByTestId("chequeProcessingDetailGrid")).toBeInTheDocument();
  });

  it("should handle payment details grid row selection correctly", () => {
    renderComponent();
    const row = screen.getByTestId("paymentDetailsGrid-row-0");
    fireEvent.click(row);
    expect(row).toHaveClass("selected");
  });

  it("should handle payment details grid pagination correctly", () => {
    renderComponent();
    const pagination = screen.getByTestId("paymentDetailsGrid-pagination");
    fireEvent.click(pagination);
    expect(pagination).toHaveClass("changed");
  });

  it("should handle cheque processing detail grid row selection correctly", () => {
    renderComponent();
    const row = screen.getByTestId("chequeProcessingDetailGrid-row-0");
    fireEvent.click(row);
    expect(row).toHaveClass("selected");
  });

  it("should handle cheque processing detail grid pagination correctly", () => {
    renderComponent();
    const pagination = screen.getByTestId("chequeProcessingDetailGrid-pagination");
    fireEvent.click(pagination);
    expect(pagination).toHaveClass("changed");
  });

  it("should handle cheque processing detail grid toolbar actions correctly", () => {
    renderComponent();
    const toolbarButton = screen.getByText("chequeProcessing.findChequeNo");
    fireEvent.click(toolbarButton);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("should handle cheque processing detail grid filter changes correctly", () => {
    const dispatch = jest.fn();
    jest.mock("@/store/store", () => ({
      useAppSelector: jest.fn((selector) => selector(store.getState())),
      useDispatch: () => dispatch
    }));
    renderComponent();
    expect(dispatch).toHaveBeenCalledWith(expect.any(Function));
  });

  it("should handle cheque processing detail view navigation correctly", () => {
    renderComponent();
    const detailLink = screen.getByTestId("chequeProcessingDetailGrid-detail-link-0");
    fireEvent.click(detailLink);
    expect(detailLink).toHaveClass("clicked");
  });

  it("should handle cheque processing detail modal actions correctly", () => {
    renderComponent();
    const findChequeButton = screen.getByText("chequeProcessing.findChequeNo");
    fireEvent.click(findChequeButton);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });
});
