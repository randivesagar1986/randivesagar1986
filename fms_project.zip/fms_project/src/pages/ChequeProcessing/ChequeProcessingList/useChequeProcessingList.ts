import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { IPaginationProps } from "@essnextgen/ui-kit";
import { Sequence } from "@/utils/constants";
import { actions as cpAction, getChequeProcessingList } from "../state/ChequeProcessing.slice";
import { actions as cpStatusAction, getChequeProcessingStatus } from "../state/ChequeProcessingStatus.slice";
import { actions as ItPayment } from "../state/ItemsPayment.slice";
import { actions as cplAction } from "../state/CheckProcessingList.slice";
import { actions as sumAction } from "../state/SummaryOfCheques.slice";

const useChequeList = () => {
  const dispatch = useDispatch<AppDispatch>();
  const [bank, setBank] = useState<String>("Bank Account");
  const [account, setAccount] = useState<any>(0);
  const [status, setStatus] = useState<String>("");
  const [user, setUser] = useState<String>("");
  const [noOfCheques, setNoOfCheques] = useState<any>(0);
  const [noReconciled, setNoReconciled] = useState<any>(0);
  const [noSpoiled, setNoSpoiled] = useState<any>(0);

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];
  const dataTestId = "chequeProcessingList";
  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;
  const {
    columnDef: cpColumnDef,
    checkedRows,
    filterState,
    selectedRow,
    isFocus
  } = useAppSelector((state) => state.newChequeProcessingList);

  const { selectedView } = useAppSelector((state) => state.chequeView);

  const { data, currentPage, totalPages, pageSize } = useAppSelector(
    ({ newChequeProcessingList }) => newChequeProcessingList?.chequeList
  );

  const { status: chequeStatus } = useAppSelector((state) => state.newChequeProcessingList);

  const setContactData = (row: { [key: string]: any } | undefined) => {
    if (row) {
      setNoOfCheques(row.cheque_count ?? 0);
      setBank(row?.description ?? "-");
      setAccount(row?.bank_account ?? "-");
      setStatus(row?.status_desc ?? "-");
      setNoReconciled(row?.cheques_reconciled ?? 0);
      setNoSpoiled(row?.cheques_spoiled ?? 0);
      setUser(row?.user_code ?? "-");
    }
  };

  const selectedRowHandler = (row: { [key: string]: any } | undefined) => {
    setContactData(row);
    dispatch(cpAction.setSelectedRow(row));
  };

  const onChangeHandler = (page: any) => {
    dispatch(
      cpAction.setFilters({
        pageNumber: page,
        pageSize: String(pageSize),
        lookingFor: ""
      })
    );
    dispatch(
      getChequeProcessingList({
        ...filterState,
        pageNumber: page,
        pageSize: String(pageSize),
        lookingFor: "",
        callback: (data) => dispatch(cpAction.setSelectedRow(data.data?.at(0)))
      })
    );
    dispatch(sumAction.resetPDFData());
  };

  const onChangePrevRecord = (page: any) => {
    dispatch(
      cpAction.setFilters({
        pageNumber: page,
        pageSize: String(pageSize),
        lookingFor: ""
      })
    );
    dispatch(
      getChequeProcessingList({
        ...filterState,
        pageNumber: page,
        pageSize: String(pageSize),
        lookingFor: "",
        callback: (data) => dispatch(cpAction.setSelectedRow(data.data?.at(data.data?.length - 1)))
      })
    );
  };

  const selectPrevRecord = () => {
    if (selectedRow && data) {
      const indexNo = data.indexOf(selectedRow);
      document.getElementById(getIndex(dataTestId, indexNo === 0 ? indexNo : indexNo - 1))?.focus();
      if (indexNo > 0) {
        dispatch(cpAction.setSelectedRow(data[indexNo - 1]));
      } else if (currentPage > 1) {
        onChangePrevRecord(currentPage - 1);
      }
    }
  };
  const selectNextRecord = () => {
    if (selectedRow && data) {
      const indexNo = data.indexOf(selectedRow);
      document.getElementById(getIndex(dataTestId, indexNo < data.length - 1 ? indexNo + 1 : indexNo))?.focus();
      if (indexNo < 9 && indexNo < data.length - 1) {
        dispatch(cpAction.setSelectedRow(data[indexNo + 1]));
      } else if (currentPage < totalPages) {
        onChangeHandler(currentPage + 1);
      }
    }
  };

  useEffect(() => {
    dispatch(cplAction.setSelectedRow(undefined));
    dispatch(
      getChequeProcessingStatus({
        callback: (data) => {
          if (selectedView?.value === "A") {
            const item = {
              text: data[0]?.description,
              value: data[0]?.code
            };
            dispatch(cpStatusAction.setChequeProcessingView(item));
          }
        }
      })
    );
    dispatch(ItPayment.setCheckedPaymentItems([]));
    dispatch(ItPayment.unCheckAll());
    dispatch(
      ItPayment.setFilters({
        sequence: Sequence.SEQ
      })
    );
  }, []);

  const clearTableFooter = () => {
    setBank("");
    setAccount("");
    setStatus("");
    setUser("");
    setNoOfCheques("");
    setNoReconciled("");
    setNoSpoiled("");
  };

  return {
    t,
    data,
    cpColumnDef,
    checkedRows,
    currentPage,
    totalPages,
    selectedRowHandler,
    bank,
    account,
    status,
    user,
    noOfCheques,
    noReconciled,
    noSpoiled,
    chequeStatus,
    selectPrevRecord,
    selectNextRecord,
    onChangeHandler,
    filterState,
    selectedRow,
    isFocus,
    clearTableFooter
  };
};

export default useChequeList;
