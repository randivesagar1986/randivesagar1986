import "./ChequeStyle.scss";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Grid,
  GridItem,
  TableUtility,
  TableWrapper,
  FormLabel,
  TextInput,
  ValidationTextLevel,
  NotificationStatus,
  Tag,
  TagSize,
  TagColor
} from "@essnextgen/ui-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import { useHistory, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import Layout from "@/components/Layout/Layout";
import { getDate } from "@/utils/getDataSource";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { CHECK_PAYMENT_STATUS, STATUS, VIEW_CHEQUE_STATUS, specialCharacters } from "@/types/UseStateType";
import {
  chequeProcessingColumnDef,
  chequeProcessingDetailColumnDef,
  chequeDebitColumnDef,
  bacsColumnDef
} from "@/utils/constants";
import { getPurchaseOrderDocument } from "@/pages/PurchaseOrder/state/PurchaseOrderDetails.slice";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { freeze } from "@reduxjs/toolkit";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import { canDo, fetchUserAccessRights, Screen } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import {
  getChequeProcessingData,
  getChequeProcessingDetailData,
  getChequeNewPrintDocument,
  getChequePrintDocument,
  getZeroChequePrintDocument,
  getChequeZeroPDFConfirmRun,
  getCancelChequeProcessing,
  actions as cplAction
} from "../state/CheckProcessingList.slice";
import { actions as cpAction } from "../state/ChequeProcessing.slice";
import useChequeDetail from "./useChequeProcessingDetail";
import ChequeProcessingPageToolbar from "../ChequeProcessingPageToolBar";
import ChequeProcessingToolBar from "./ChequeProcessingToolBar/ChequeProcessingToolBar";
import { getChequePaymentRun } from "../state/ChequePaymentRun.slice";
import CustomCell from "./Grid/CustomCell";

const loaderConfig: loadingConfig = {};
const ChequeProcessing = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;

  const {
    t,
    redirectToViewPage,
    selectedRowHandler,
    selectPrevRecord,
    selectNextRecord,
    PaymentRunNumber,
    setPaymentRunNumber,
    chequePayments,
    cancelledOn,
    cheque,
    printedDate,
    detailStatus,
    chequePaymentDetails,
    firstTableStatus,
    zeroPayReport,
    setDisableZeroPayReport,
    enableCancel,
    checkRunReport,
    paymentRunId,
    isYesClicked,
    setIsYesClicked
  } = useChequeDetail();

  const {
    cancelStatus: cancelchequeStatus,
    cancelError,
    cancelChequePayment,
    selectedRow: paymentRow
  } = useAppSelector((state) => state.chequeProcessingList);
  const { selectedRow: chqProListSelectedRow } = useAppSelector((state) => state.chequeProcessingList);
  const { selectedRow } = useAppSelector((state) => state.newChequeProcessingList);
  const { pdfByteArrayData } = useAppSelector((state) => state.summaryOfCheques);
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const addAccess = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.ChequeProcessing,
    action: ACCESS_RIGHTS_ACTION.Add
  });
  const [loading, setLoading] = useState(false);
  const [reasonValidateError, setReasonValidateError] = useState<boolean>(false);
  const [PaymentIdState, setPaymentIdState] = useState<any>("");
  const [PaymentIdStatus, setPaymentIdStatus] = useState<any>("");
  const [PaymentIdType, setPaymentIdType] = useState<any>("");
  const [iszeropdfclick, setiszeropdfclick] = useState(false);
  const [iszeropdfclickTwo, setiszeropdfclickTwo] = useState(false);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState<boolean>(false);
  const [isCommitmentModalOpen, setIsCommitmentModalOpen] = useState<boolean>(false);
  const [commitmentMessage, setCommitmentMessage] = useState<string>("");
  const [isAlertModalOpen, setIsAlertModalOpen] = useState<boolean>(false);
  const [alertMessage, setAlertMessage] = useState<string>("");
  const [isValidatationAlert, setIsValidatationAlert] = useState<boolean>(false);
  const [alertType, setAlertType] = useState<NotificationStatus>(NotificationStatus.ERROR);
  // const [isZeroPayReportButtonEnabled, setisZeroPayReportButtonEnabled] = useState(false);
  // const [isZeroButtonDisabled, setIsZeroButtonDisabled] = useState(false);
  // const [isCommitmentMessageValid, setIsCommitmentMessageValid] = useState(true);
  const [pageTitle, setPageTitle] = useState<string>(t("chequeProcessing.chequeProcessing"));
  const [dynamicColumnDef, setDynamicColumnDef] = useState(chequeProcessingColumnDef);
  const [isHideToolbarAndBtns, setIsHideToolbarAndBtns] = useState<boolean>(false);
  const [isCheckPaymentPage, setIsCheckPaymentPage] = useState<boolean>(false);
  const [isDebitPaymentPage, setIsDebitPaymentPage] = useState<boolean>(false);
  const [isBacksPaymentPage, setIsBacksPaymentPage] = useState<boolean>(false);
  const { selectedRow: bankSelectedRow } = useAppSelector((state) => state.bankReconciliationStatement);

  const location = useLocation();

  useEffect(() => {
    sessionStorage.removeItem("chequeProcessing");
  }, []);

  useEffect(() => {
    const wordsToSearch = ["cheque-payment", "debit-payment", "bacs-payment"];
    const foundWord = wordsToSearch.find((word) => location.pathname.includes(word));

    if (foundWord) {
      switch (foundWord) {
        case "cheque-payment":
          setIsCheckPaymentPage(true);
          setDynamicColumnDef(chequeDebitColumnDef);
          setPageTitle(t("bankReconciliation.bankReconChequeViewPage"));
          break;
        case "debit-payment":
          setIsDebitPaymentPage(true);
          setDynamicColumnDef(chequeDebitColumnDef);
          setPageTitle(t("bankReconciliation.bankReconDebitViewPage"));
          break;
        case "bacs-payment":
          setIsBacksPaymentPage(true);
          setDynamicColumnDef(bacsColumnDef);
          setPageTitle(t("bankReconciliation.bankReconBacsViewPage"));
          break;
        default:
          break;
      }
      setIsHideToolbarAndBtns(true);
    } else {
      setIsHideToolbarAndBtns(false);
    }
  }, [location]);

  useEffect(() => {
    sessionStorage.removeItem("chequeProcessing");
    sessionStorage.removeItem("paymentRunId");
    if (sessionStorage.getItem("paymentRunNumber")) {
      setPaymentRunNumber(sessionStorage.getItem("paymentRunNumber"));
      sessionStorage.removeItem("paymentRunNumber");
    }
    ChequeProcessingDataDetails();
  }, [paymentRunId]);

  const ChequeProcessingDataDetails = () => {
    dispatch(cpAction.setFilters({ highlightId: Number(paymentRunId) }));
    if (paymentRunId) {
      dispatch(
        getChequeProcessingData({
          paymentRunId,
          callback: (data) => {
            const paymentId = data?.chequePayments?.at(0)?.payment_id;
            const paymentType = data?.chequePayments?.at(0)?.payment_type;
            const paymentStatus = data?.chequePayments?.at(0)?.payment_status;
            selectedRowHandler(data?.chequePayments?.at(0));
            setPaymentIdState(paymentId);
            setPaymentIdType(paymentType);
            setPaymentIdStatus(paymentStatus);
            if (paymentType === "Z" && paymentStatus === "F") {
              setDisableZeroPayReport(false);
            } else {
              setDisableZeroPayReport(true);
            }
            dispatch(getChequePaymentRun());
          }
        })
      );
    }
  };

  const [cancelId, setCancelid] = useState("");
  const [chequeNo, setChequeNo] = useState("");

  useEffect(() => {
    if (cancelChequePayment) {
      setChequeNo(cancelChequePayment?.cheque_number);
      setCancelid(cancelChequePayment?.payment_id);
      setIsCancelModalOpen(true);
      dispatch(cplAction.setCancelChequePayment(undefined));
    }
  }, [cancelChequePayment]);

  useEffect(() => {
    if (cancelchequeStatus === STATUS.FAILED && cancelError) {
      if (cancelError?.detail === "LR164") {
        setIsAlertModalOpen(true);
        setAlertType(NotificationStatus.WARNING);
        setAlertMessage(t("alertMessage.clearCommitmentAlert.message"));
        dispatch(cplAction.resetErrors());
      }
    }
  }, [cancelchequeStatus]);

  const DetailCustomCell = ({ field, row }: any) => {
    const numberFormatter = new Intl.NumberFormat("en-US", {
      style: "decimal",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    const getContent = () => {
      const negativeVal = Number(parseFloat(row?.payment_amount).toFixed(2));
      const positiveVal = negativeVal * -1;

      if (field === "action") {
        return (
          <>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Utility}
              onClick={() => redirectToViewPage(row)}
              className="small__white--btn"
            >
              View
            </Button>
          </>
        );
      }
      if (field === "item_date") {
        return <span>{getDate(row?.item_date)}</span>;
      }
      if (field === "payment_amount") {
        const formattedAmount =
          row?.invoice_type === "PC"
            ? numberFormatter.format(positiveVal)
            : numberFormatter.format(Number(parseFloat(row?.payment_amount).toFixed(2)));
        return <span>{formattedAmount}</span>;
      }
      return null;
    };
    return getContent();
  };

  interface MyResponseType {
    payload: string; // Adjust this type according to your actual response structure
    // Add other properties if necessary
  }

  const HandleZeroPaymentReport = async (paymentID: any, paymentRunID: any) => {
    setLoading(true);
    const res = await dispatch(getZeroChequePrintDocument({ paymentID, paymentRunID }));

    const pdfData = (res as unknown as MyResponseType).payload;
    try {
      const byteCharacters = atob(pdfData);
      const byteNumbers = new Array(byteCharacters.length);
      let i = 0;
      while (i < byteCharacters.length) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
        i += 1; // Use compound assignment instead of increment operator
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: "application/pdf" });
      const pdfUri = URL.createObjectURL(blob);
      if (pdfUri) {
        fetch(pdfUri)
          .then((response) => response.blob())
          .then((blob) => {
            // Create a link element
            const link = document.createElement("a");
            link.href = window.URL.createObjectURL(blob);
            link.download = `${PaymentRunNumber}.pdf`; // Set the download attribute with file extension
            link.click();
            // Revoke the Blob URL to free up memory
            window.URL.revokeObjectURL(link.href);
            setLoading(false);

            setTimeout(() => {
              ZeroPDFClickCallTwo();
            }, 7000);
          })
          .catch((error) => {
            setLoading(false);
            console.error("Error downloading file:", error);
          });
      }
    } catch (error) {
      console.error("Error decoding base64 string:", error);
      // Handle the error gracefully, e.g., set pdfUrl to null
    }
  };

  const HandlePrintCheque = async (
    runNo: any,
    runID: any,
    chequeRun: any,
    period: any,
    uniqueId: any,
    odbcHandle: any
  ) => {
    setLoading(true);
    const res = await dispatch(
      getChequeNewPrintDocument({
        runNumber: runNo,
        runId: runID,
        param1: chequeRun,
        period,
        uniqueId,
        odbcHandle
      })
    );
    const params = {
      runNumber: runNo,
      runId: runID,
      param1: chequeRun,
      period,
      uniqueId,
      odbcHandle
    };
    history.push({
      pathname: `/accounts-payable/cheque-processing/cheque-processing-detail/${paymentRunId}/charts-accounts-review-preview`,
      state: { ...params }
    });
  };

  const ZeroPDFClickCallTwo = () => {
    setiszeropdfclickTwo(true);
  };

  const getTagElement = () => (
    <div className="cheque-sub-title">
      <Tag
        text={PaymentRunNumber}
        size={TagSize.Large}
        color={TagColor.Highlight}
      />
    </div>
  );

  useEffect(() => {
    if (chequePayments?.length === 0) return;

    const selectedIndex = chequePayments.findIndex(
      (payment: any) => payment?.cheque_number === historyState?.bankStatementRow?.ref
    );
    if (selectedIndex !== -1) {
      dispatch(cplAction.setSelectedRow(chequePayments[selectedIndex]));
    }

    if (chequePaymentDetails?.length > 0) {
      setTimeout(() => {
        const element = document.getElementById(`rowIndex-chequeProcessingDetailGrid-${selectedIndex}`);
        element?.scrollIntoView({ behavior: "smooth", block: "center" });
        element?.focus();
      }, 800);
    }
  }, [chequePayments]);

  useEffect(() => {
    setTimeout(() => {
      const selectedIndex = chequePayments.findIndex(
        (payment: any) => payment?.cheque_number === historyState?.bankStatementRow?.ref
      );
      const element = document.getElementById(`rowIndex-chequeProcessingDetailGrid-${selectedIndex}`);
      element?.scrollIntoView({ behavior: "smooth", block: "center" });
      element?.focus();
    }, 200);
  }, [chequePaymentDetails?.length]);

  return (
    <>
      <Layout
        pageTitle={pageTitle}
        isSubTitle={!isHideToolbarAndBtns ? getTagElement() : ""}
        toolbar={!isHideToolbarAndBtns ? <ChequeProcessingPageToolbar /> : ""}
        className="cheque-processing cheque-processing__list"
        rightContent={
          !isHideToolbarAndBtns ? (
            <ChequeProcessingToolBar
              goToPrevRecord={selectPrevRecord}
              goToNextRecord={selectNextRecord}
            />
          ) : (
            ""
          )
        }
        type="transparent"
      >
        <GridTableNew
          dataTestId="chequeProcessingDetailGrid"
          isScrollable
          dataSource={chequePayments || []}
          isLoading={firstTableStatus === STATUS.LOADING}
          columnDef={dynamicColumnDef}
          customCell={CustomCell}
          selectedRow={chqProListSelectedRow}
          selectedRowHandler={selectedRowHandler}
          enableScrollIntoView
        />
      </Layout>
      {!isDebitPaymentPage && (
        <Layout
          isBreadcrumbRequired={false}
          className=""
        >
          {!isHideToolbarAndBtns && (
            <>
              <Grid>
                <GridItem
                  sm={12}
                  md={12}
                  lg={12}
                  xl={12}
                  className="grid-item"
                >
                  {loading ? (
                    <Loader loadingConfig={loaderConfig} />
                  ) : (
                    <div className="d-flex gap-8 justify-end">
                      <Button
                        className="button-sec"
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        disabled={!addAccess || (addAccess && zeroPayReport)}
                        onClick={() => HandleZeroPaymentReport(PaymentIdState, paymentRunId)}
                      >
                        {t("chequeProcessing.zeroPaymentReport")}
                      </Button>
                      <Button
                        className="button-sec"
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        disabled={!zeroPayReport}
                        onClick={() => HandlePrintCheque(PaymentRunNumber, paymentRunId, "Cheque Run", "12", null, 0)}
                      >
                        {t("chequeProcessing.chequeRunReport")}
                      </Button>
                    </div>
                  )}
                </GridItem>
              </Grid>
              <hr />
            </>
          )}

          {firstTableStatus === STATUS.SUCCESS && (
            <Grid>
              <GridItem
                sm={12}
                md={8}
                lg={8}
                xl={!isBacksPaymentPage ? 8 : 10}
              >
                {chqProListSelectedRow?.transfer_text && (
                  <p className="p-tag">{chqProListSelectedRow?.transfer_text}</p>
                )}
              </GridItem>
              <GridItem
                sm={12}
                md={4}
                lg={4}
                xl={!isBacksPaymentPage ? 4 : 2}
                className="grid-items"
              >
                <Grid className="justify__content--between">
                  <GridItem
                    sm={4}
                    md={4}
                    lg={8}
                    xl={8}
                  >
                    <div className="essui-form-label">
                      {!isHideToolbarAndBtns ? t("chequeProcessing.printed") : t("chequeProcessing.printedOn")}
                    </div>
                    {Object.keys(chequePayments).length > 0 &&
                    chequePayments[0]?.status_desc !== VIEW_CHEQUE_STATUS.NOT_PRINT ? (
                      <div className="mt-12">{getDate(printedDate)}</div>
                    ) : (
                      <div className="mt-12">-</div>
                    )}
                  </GridItem>
                  {!isBacksPaymentPage && (
                    <GridItem>
                      <div className="essui-form-label">{t("chequeProcessing.cancelledOn")}</div>
                      {paymentRow?.cancelled_on ? (
                        <div className="mt-12">{getDate(paymentRow?.cancelled_on)}</div>
                      ) : (
                        <div className="mt-12">-</div>
                      )}
                    </GridItem>
                  )}
                </Grid>
              </GridItem>
            </Grid>
          )}
        </Layout>
      )}

      <ConfirmModal
        isOpen={iszeropdfclick}
        setOpen={setiszeropdfclick}
        className="cancel-popup"
        title={t("invoiceNote.invoiceModalCancel")}
        message={t("chequeProcessing.zeroReportMsg1")}
        confirm={() => {
          if (paymentRunId) {
            HandleZeroPaymentReport(parseInt(PaymentIdState, 10), parseInt(paymentRunId, 10));
            setiszeropdfclick(false);
          }
        }}
      />

      <ConfirmModal
        isOpen={iszeropdfclickTwo}
        setOpen={setiszeropdfclickTwo}
        className="cancel-popup"
        title={t("invoiceNote.invoiceModalCancel")}
        message={t("chequeProcessing.zeroReportMsg2")}
        confirm={async () => {
          if (paymentRunId) {
            const response = await dispatch(getChequeZeroPDFConfirmRun(paymentRunId));
            setiszeropdfclickTwo(false);
            setDisableZeroPayReport(true);
            ChequeProcessingDataDetails();
          }
        }}
      />

      <ConfirmModal
        isOpen={isCancelModalOpen}
        setOpen={setIsCancelModalOpen}
        title={t("alertMessage.title")}
        message={t("chequeProcessing.cancelCheque", { chequeNo })}
        className="close-button-disabled"
        confirm={() => {
          dispatch(uiActions.alertPopup({ enable: false }));
          setIsCommitmentModalOpen(true);
        }}
      />

      <ConfirmModal
        isOpen={isCommitmentModalOpen}
        setOpen={setIsCommitmentModalOpen}
        title={t("chequeProcessing.commitmentMessageTitle")}
        isIconRequired={false}
        primaryBtnText={t("common.save")}
        tertiaryBtnText={t("common.cancel")}
        message={
          <>
            <div className="mr-l-4 mr-r-4">
              <FormLabel>{t("chequeProcessing.commitmentMsg")}</FormLabel>
              <TextInput
                inputWidth={800}
                maxLength={60}
                onChange={(e) => setCommitmentMessage(e.target.value.trim() as string)}
                validationTextLevel={reasonValidateError && !commitmentMessage ? ValidationTextLevel.Error : undefined}
              />
            </div>
          </>
        }
        confirm={() => {
          if (!commitmentMessage) {
            setIsCommitmentModalOpen(false);
            setAlertType(NotificationStatus.HIGHLIGHT);
            setIsAlertModalOpen(true);
            setAlertMessage(t("common.invalidData"));
            setIsValidatationAlert(true);
            setReasonValidateError(true);
          } else {
            setIsCommitmentModalOpen(false);
            setReasonValidateError(false);
            dispatch(
              getCancelChequeProcessing({
                paymentId: cancelId,
                reason: commitmentMessage,
                callback: () => {
                  ChequeProcessingDataDetails();
                  setCommitmentMessage("");
                }
              })
            );
          }
        }}
        callback={({ confirm }) => {
          if (!confirm) {
            setIsCommitmentModalOpen(false);
            setCommitmentMessage("");
            setReasonValidateError(false);
          }
        }}
      />

      <AlertModal
        isOpen={isAlertModalOpen}
        setOpen={setIsAlertModalOpen}
        title={t("alertMessage.title")}
        notificationType={alertType}
        message={alertMessage}
        callback={() => {
          if (isValidatationAlert) {
            setIsCommitmentModalOpen(true);
            setIsValidatationAlert(false);
          }
        }}
      />

      <Layout
        isBreadcrumbRequired={false}
        type="transparent"
        className="payment__detail--table"
      >
        <div className="third-grid-container">
          <TableWrapper>
            <TableUtility className="payment-details"> {t("chequeProcessing.paymentDetails")}</TableUtility>
            <GridTableNew
              isScrollable
              dataTestId="paymentDetailsGrid"
              dataSource={Object.keys(chequePayments).length > 0 ? chequePaymentDetails || [] : []}
              isLoading={detailStatus === STATUS.LOADING}
              columnDef={chequeProcessingDetailColumnDef}
              customCell={DetailCustomCell}
            />
          </TableWrapper>
        </div>
      </Layout>
    </>
  );
};

export default ChequeProcessing;
