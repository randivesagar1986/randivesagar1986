import { FormLabel, Grid, GridItem, TextInput, TextInputSize } from "@essnextgen/ui-kit";
import useChequeSearchModalFilter from "../useChequeSearchModalFilters";

const ChequeSearchModalFilters = () => {
  const { searchFilters, handleLookingForChange, t } = useChequeSearchModalFilter();

  return (
    <>
      <Grid
        className="custom-table"
        align="center"
        justify="space-between"
      >
        <GridItem xl={5}>
          <FormLabel forId="searchCheque-lookingFor">{t("common.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              onKeyDown={(event) => {
                // eslint-disable-next-line
                if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                  event.preventDefault();
                }
              }}
              id="searchCheque-lookingFor"
              value={searchFilters?.lookingFor}
              onChange={(e) => handleLookingForChange(e)}
              size={TextInputSize.Medium}
              autoComplete={false}
            />
          </div>
        </GridItem>
      </Grid>
    </>
  );
};

export default ChequeSearchModalFilters;
