import React from "react";
import CommonGridModal from "@/shared/components/CommonGridModal/CommonGridModal";
import { STATUS } from "@/types/UseStateType";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import ChequeSearchModalFilters from "./ChequeSearchModalFilters";
import { ChequeSearchColumnDef } from "./columnDef";
import useChequeSearchModal from "../useChequeSearchModal";

type ChequeSearchPopupProps = {
  isOpen: boolean;
  setOpen: (isOpen: boolean) => void;
};

const ChequeSearchPopup: React.FC<ChequeSearchPopupProps> = ({ isOpen, setOpen }) => {
  const {
    t,
    searchStatus,
    selectedRow,
    closeHandler,
    currentPage,
    totalPages,
    onChangeHandler,
    setSelectedRow,
    getDataSource,
    onEnterKeyPress
  } = useChequeSearchModal({ setOpen, isOpen });

  return (
    <CommonGridModal
      selectRow={selectedRow}
      setSelectRow={setSelectedRow}
      dataTestId="chequeTableId"
      id="chequeTableId"
      headerTitle={t("chequeProcessing.findChequeNo")}
      isOpen={isOpen}
      columnDef={ChequeSearchColumnDef}
      className="cheque-modal"
      modalFooter={
        <div className="modal-footer">
          <Button
            color={ButtonColor.Primary}
            size={ButtonSize.Small}
            onClick={closeHandler}
          >
            {t("common.ok")}
          </Button>
        </div>
      }
      onClose={() => {
        setOpen(false);
      }}
      getDataSource={getDataSource}
      setOpen={setOpen}
      onEnterKeyPress={onEnterKeyPress}
      gridFilters={<ChequeSearchModalFilters />}
      gridLoading={searchStatus === STATUS.LOADING}
      onChangeHandler={onChangeHandler}
      totalPages={totalPages}
      currentPage={currentPage}
    />
  );
};

export default ChequeSearchPopup;
