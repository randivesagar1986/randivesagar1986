import {
  Dropdown,
  DropdownItem,
  FormLabel,
  ISelectedItem,
  RadioButton,
  RadioLabelPosition,
  TextInputSize
} from "@essnextgen/ui-kit";
import React, { KeyboardEvent, useEffect, useState } from "react";
import { LookingFor } from "@/shared/components/LookingFor/LookingFor";
import { CHEQUE_PROCESSING_SEQ_NAME, KEYBOARD_STRING, STATUS } from "@/types/UseStateType";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import columnDef from "./columnDef";
import "react-datepicker/dist/react-datepicker.css";
import useChequeProcessingFilters from "./useChequeProcessingFilters";
import { actions } from "../../state/ChequeProcessing.slice";

const ChequeProcessingFilters = () => {
  const {
    t,
    status,
    onDescendingSort,
    onAscendingSort,
    onSequenceChange,
    lookingFor,
    lookingForChangehandler,
    lookingForCallback,
    chequeProcessingViews,
    selectedView,
    onViewSelection
  } = useChequeProcessingFilters();

  const { filterState } = useAppSelector((state) => state.newChequeProcessingList);

  const extraKey = ["Backspace", "Delete", "Tab"];

  const restrictAlphaSpecialChar = (e: KeyboardEvent<Element>) => {
    if (
      /^\d+$/.test(e.key) === false &&
      !extraKey.includes(e.key) &&
      filterState?.sequenceValue === "payment_run_number"
    ) {
      e.preventDefault();
    }
  };

  const handleSequenceKeyDown = (e: React.KeyboardEvent) => {
    if (
      e.key === KEYBOARD_STRING.ArrowRight ||
      e.key === KEYBOARD_STRING.ArrowDown ||
      e.key === KEYBOARD_STRING.ArrowLeft ||
      e.key === KEYBOARD_STRING.ArrowUp
    ) {
      e.preventDefault();
      const { nextSequenceValue, index } = (() => {
        if (filterState?.sequenceValue === CHEQUE_PROCESSING_SEQ_NAME.RUN_DATE) {
          return { nextSequenceValue: CHEQUE_PROCESSING_SEQ_NAME.PAYMENT_RUN_NUMBER, index: 1 };
        }
        return { nextSequenceValue: CHEQUE_PROCESSING_SEQ_NAME.RUN_DATE, index: 0 };
      })();
      onSequenceChange(nextSequenceValue, index);
    }
  };

  const handleSortKeyDown = (e: React.KeyboardEvent) => {
    if (
      e.key === KEYBOARD_STRING.ArrowRight ||
      e.key === KEYBOARD_STRING.ArrowDown ||
      e.key === KEYBOARD_STRING.ArrowLeft ||
      e.key === KEYBOARD_STRING.ArrowUp
    ) {
      e.preventDefault();
      if (filterState?.orderBy === 0) {
        onDescendingSort();
      } else {
        onAscendingSort();
      }
    }
  };

  return (
    <div className="cheque-processing-filters">
      <LookingFor
        initialValue={filterState?.lookingFor}
        callback={lookingForCallback}
        changeHandler={lookingForChangehandler}
        hasDatePicker
        disableDatePicker={filterState?.sequence !== 0}
        isInputReadOnly={status === STATUS.LOADING}
        restrictInput={restrictAlphaSpecialChar}
        className="essui-global-typography-default-h2 looking-for-container"
      />
      <div className="essui-global-typography-default-h2 sequence-container pos-rel">
        <FormLabel>{t("common.sequenceOrder")}</FormLabel>
        <div className="sequence">
          <div
            className="essui-textinput sequence-fields"
            onKeyDown={(e) => handleSequenceKeyDown(e)}
          >
            {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
              const sequenceId = `sequence=${index + 1}`;
              return (
                <RadioButton
                  label={column.sequenceName ? column.sequenceName : column.headerName}
                  labelPosition={RadioLabelPosition.Right}
                  value={column.field}
                  onChange={() => onSequenceChange(column.field, index)}
                  isSelected={filterState?.sequenceValue === column.field}
                  key={sequenceId}
                  name="sequenceName"
                />
              );
            })}
          </div>
          <div
            className="essui-textinput sequence-order"
            onKeyDown={(e) => handleSortKeyDown(e)}
          >
            <RadioButton
              label={t("common.ascending")}
              labelPosition={RadioLabelPosition.Right}
              value={0}
              onChange={onAscendingSort}
              isSelected={filterState?.orderBy === 0}
              name="sortName"
            />
            <RadioButton
              label={t("common.descending")}
              labelPosition={RadioLabelPosition.Right}
              value={1}
              onChange={onDescendingSort}
              isSelected={filterState?.orderBy === 1}
              name="sortName"
            />
          </div>
        </div>
      </div>
      <div className="view-filter">
        <FormLabel forId="view">{t("common.view")}</FormLabel>
        <Dropdown
          size={TextInputSize.Medium}
          searchable
          selectedItem={selectedView ?? undefined}
          isScrollbarVisible
          onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => onViewSelection(e, item)}
        >
          {(chequeProcessingViews || []).map((view: { [key: string]: string }, i: any) => {
            const id = `dropdown-${i}`;
            return (
              <DropdownItem
                key={id}
                id={id}
                text={view.description}
                value={view.code}
              >
                {view.description}
              </DropdownItem>
            );
          })}
        </Dropdown>
      </div>
    </div>
  );
};

export default ChequeProcessingFilters;
