import { AppDispatch, useAppSelector } from "@/store/store";
import { CHECK_PAYMENT_STATUS, specialCharacters } from "@/types/UseStateType";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import { useHistory } from "react-router-dom";
import { actions as cpActions } from "../../state/CheckProcessingList.slice";

const CustomCell = ({ field, row }: any) => {
  const dispatch = useDispatch<AppDispatch>();
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const cancelAccess = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.ChequeProcessing,
    action: ACCESS_RIGHTS_ACTION.Cancel
  });
  const history = useHistory();
  const historyState = history?.location?.state as any;
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const isCancelChequeRunDisabled = () => {
    if (!cancelAccess) {
      return true;
    }
    if (
      cancelAccess &&
      !(
        row?.payment_status === CHECK_PAYMENT_STATUS.PAYMENT_STATUS_ONE ||
        (row?.payment_type === CHECK_PAYMENT_STATUS.PAYMENT_TYPE &&
          row?.payment_status !== CHECK_PAYMENT_STATUS.PAYMENT_STATUS_TWO)
      )
    ) {
      return true;
    }
    return false;
  };

  const getContent = () => {
    if (field === "statement_no") {
      return (
        (historyState?.bankStatementRow?.ref === row?.cheque_number
          ? historyState?.selectedRowState?.statement_no
          : row?.statement_no) ?? specialCharacters.HYPHEN
      );
    }
    if (field === "action") {
      return (
        <>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            className="small__white--btn"
            onClick={() => dispatch(cpActions.setCancelChequePayment(row))}
            disabled={isCancelChequeRunDisabled()}
          >
            Cancel
          </Button>
        </>
      );
    }
    if (field === "amount") {
      const formattedAmount =
        row?.amount !== undefined && row?.amount !== null
          ? numberFormatter.format(row?.amount)
          : specialCharacters.zero;
      return <>{formattedAmount}</>;
    }
    return null;
  };
  return getContent();
};
export default CustomCell;
