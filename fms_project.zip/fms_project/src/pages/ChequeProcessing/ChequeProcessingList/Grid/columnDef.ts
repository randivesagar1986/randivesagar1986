import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const chequeProcessingDef: TColumnDef = [
  {
    headerName: "Run Date",
    field: "run_date",
    sequenceName: "Date",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "Run No.",
    field: "payment_run_number",
    sequenceName: "Run",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "Narrative",
    field: "narrative",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Cross Year",
    field: "transfer_code"
  },
  {
    headerName: "",
    field: "detailLink",
    cellRenderer: "GridCellLink",
    columnWidth: 5
  }
];

export const ChequeSearchColumnDef: TColumnDef = [
  {
    headerName: "Cheque No.",
    field: "cheque_number",
    align: "left"
  },
  {
    headerName: "Cheque Run No.",
    field: "cheque_run_number",
    align: "left"
  }
];

export default chequeProcessingDef;
