import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState, useRef } from "react";
import { useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import { FMSSessionStorage } from "@/utils/Storage";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { getSessionItem, setToSession, usNumberFormat } from "@/utils/getDataSource";
import { useClickAway } from "@/hooks/useClickAway";
import { actions as sidebarMenuActions } from "@/components/SidebarMenu/state/SidebarMenu.slice";
import {
  getChequeConfirmRun,
  getChequeZeroPayConfirm,
  getPayeeDetails,
  printPdfDocument,
  getChequeZeroRunReport,
  zeroPaymentFailure
} from "../state/SummaryOfCheques.slice";
import useChequeDetail from "../ChequeProcessingList/useChequeProcessingDetail";
import { getChequeProcessingData } from "../state/CheckProcessingList.slice";
import { CHEQUE_PROCESSING_CHEQUE_RUN, CHEQUE_PROCESSING_STORAGE_KEY } from "../constants";

const useSummaryOfCheques = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { status, chequePayeeDetails, pdfByteArrayData } = useAppSelector((state) => state.summaryOfCheques);
  const [gridData, setGridData] = useState<{ [key: string]: any }[]>([]);
  const [chequeRunDetails, setChequeRunDetails] = useState<{ [key: string]: any }>({});
  const { confirm } = useAppSelector((state) => state.ui);
  const { clientId, payeeId } = useParams<{ clientId: string; payeeId: string }>();
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState<boolean>(false);
  const [isPrintDisabled, setIsPrintDisabled] = useState<boolean>(false);
  const { setIsSidebarOpen } = sidebarMenuActions;

  const yesCallback = (target?: HTMLElement) => {
    onPrintBtnClicked();
  };

  const noCallback = (target: HTMLElement) => {
    setIsPrintDisabled(true);
    return true;
  };

  // Wrapper to handle noCallback with a parameter
  const noCallbackWrapper = (target: HTMLElement) => {
    noCallback(target); // Pass the event target to the actual noCallback function
  };

  const handleCancelCallback = () => {
    homeRef.current = null;
    menuRef.current = null;
  };

  const { menuRef, setHistoryRedirect, targetRef, reDispatchEvent, homeRef } = useClickAway({
    // common hook for click away functionality.
    isDirty: !isPrintDisabled && !clientId,
    yesCallback: (e: HTMLElement) => yesCallback(e),
    noCallback: noCallbackWrapper,
    cancelCallback: handleCancelCallback,
    popupTitle: t("common.simsFMSModule"),
    popupMessage: t("alertMessage.keepChangesMsg"),
    unblockCondition:
      history?.location?.pathname?.includes(
        "/accounts-payable/cheque-processing/add-cheque-run/items-for-payment/summary-of-cheques"
      ) &&
      !confirm?.enable &&
      !isConfirmModalOpen,
    isNonReturnYesCallback: true,
    excludePath: [
      "/accounts-payable/cheque-processing/add-cheque-run/items-for-payment/summary-of-cheques/charts-accounts-review-preview"
    ]
  });

  const clickAwayNavigation = () => {
    const paymentRunId = sessionStorage.getItem("paymentRunId");
    setIsPrintDisabled(true);
    console.log("targetRef", targetRef.current?.closest(".essui-header__menu"));
    console.log("menuRef", menuRef.current?.closest(".essui-header__menu"));
    console.log("homeRef", homeRef.current?.closest(".essui-header__menu"));
    if ((getSessionItem("redirectPath") || homeRef.current || menuRef.current) && !clientId) {
      if (homeRef.current) {
        history.push({
          pathname: "/",
          state: {
            redirect: true
          }
        });
        setHistoryRedirect(true);
      } else if (menuRef.current) {
        dispatch(setIsSidebarOpen(true));
        setHistoryRedirect(false);
        menuRef.current = null;
        return;
      } else {
        history.push({
          pathname: getSessionItem("redirectPath"),
          state: {
            redirect: true
          }
        });
        setHistoryRedirect(true);
        setToSession("redirectPath", "");
        return;
      }
      homeRef.current = null;
    } else {
      history.push({
        pathname: clientId
          ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/cheque-processing-detail/${paymentRunId}`
          : `/accounts-payable/cheque-processing/cheque-processing-detail/${paymentRunId}`,
        state: { redirect: true }
      });
    }
  };

  const onPrintBtnClicked = () => {
    setIsPrintDisabled(true);
    const zeroPaymentAmounts = gridData.every((row) => row?.amount === "0.00");
    if (zeroPaymentAmounts) {
      setIsConfirmModalOpen(true);
    } else {
      printDocument();
    }
  };

  const printDocument = () => {
    const sessionData = JSON.parse(sessionStorage.getItem("chequeProcessing")!) || [];
    dispatch(
      printPdfDocument({
        bankId: sessionData.bankId,
        narration: sessionData.narration,
        period: sessionData.period,
        uniqueId: sessionData.uniqueId,
        chequePrintData: gridData.map((row) => ({
          payeeName: row?.payee_name,
          chequeNo: row?.cheque_number,
          bookId: row?.book_id,
          amount: row?.amount,
          payeeId: 0,
          clientId: row?.client_id ?? 0
        })),
        callback: (resData) => {
          if (resData.pdfByte) {
            sessionStorage.setItem("paymentRunId", resData.paymentRunID);
            sessionStorage.setItem("paymentRunNumber", resData.paymentRunNumber?.toString().padStart(6, "0"));
            downloadDocument({
              pdfByte: resData.pdfByte,
              callback: () => {
                const zeroPaymentAmounts = gridData.every((row) => row?.amount === "0.00");
                if (zeroPaymentAmounts) {
                  confirmModalCheck();
                } else {
                  pdfPrintedModal({ pdfByte: resData.pdfByte });
                }
              }
            });
          }
        }
      })
    );
  };

  const zeroPaymentPrint = () => {
    const paymentRunId = sessionStorage.getItem("paymentRunId");
    const paymentRunNumber = sessionStorage.getItem("paymentRunNumber");
    dispatch(
      getChequeZeroRunReport({
        paymentRunId,
        callback: (resData) => {
          if (resData) {
            try {
              const byteCharacters = atob(resData);
              const byteNumbers = new Array(byteCharacters.length);
              let i = 0;
              while (i < byteCharacters.length) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
                i += 1; // Use compound assignment instead of increment operator
              }
              const byteArray = new Uint8Array(byteNumbers);
              const blob = new Blob([byteArray], { type: "application/pdf" });
              const pdfUri = URL.createObjectURL(blob);
              if (pdfUri) {
                fetch(pdfUri)
                  .then((response) => response.blob())
                  .then((blob) => {
                    // Create a link element
                    const link = document.createElement("a");
                    link.href = window.URL.createObjectURL(blob);
                    link.download = `${paymentRunNumber}.pdf`; // Set the download attribute with file extension
                    link.click();
                    // Revoke the Blob URL to free up memory
                    window.URL.revokeObjectURL(link.href);
                    dispatch(
                      getChequeZeroPayConfirm({
                        paymentRunId,
                        callback: zeroPaymentCheck
                      })
                    );
                  })
                  .catch((error) => {
                    console.error("Error downloading file:", error);
                  });
              }
            } catch (error) {
              console.error("Error decoding base64 string:", error);
              // Handle the error gracefully, e.g., set pdfUrl to null
            }
          }
        }
      })
    );
  };

  const downloadDocument = ({ pdfByte, callback }: { pdfByte: string; callback?: () => void }) => {
    const paymentRunNumber = sessionStorage.getItem("paymentRunNumber");
    try {
      const byteCharacters = atob(pdfByte);
      const byteNumbers = new Array(byteCharacters.length);
      let i = 0;
      while (i < byteCharacters.length) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
        i += 1; // Use compound assignment instead of increment operator
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: "application/pdf" });
      const pdfUri = URL.createObjectURL(blob);
      if (pdfUri) {
        fetch(pdfUri)
          .then((response) => response.blob())
          .then((blob) => {
            // Create a link element
            const link = document.createElement("a");
            link.href = window.URL.createObjectURL(blob);
            link.download = `${paymentRunNumber}.pdf`; // Set the download attribute with file extension
            link.click();
            // Revoke the Blob URL to free up memory
            window.URL.revokeObjectURL(link.href);
            if (callback) {
              setTimeout(() => {
                callback();
              }, 3000);
            }
          })
          .catch((error) => {
            console.error("Error downloading file:", error);
          });
      }
    } catch (error) {
      console.error("Error decoding base64 string:", error);
      // Handle the error gracefully, e.g., set pdfUrl to null
    }
  };

  const pdfPrintedModal = ({ pdfByte }: { pdfByte: string }) => {
    const paymentRunNumber = sessionStorage.getItem("paymentRunNumber");
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        type: MODAL_TYPE.CONFIRMV2,
        message: t("chequeProcessing.pdfPrintedAlert", {
          paymentRunNumber
        }),
        title: t("alertMessage.title"),
        yesButtonText: t("common.yes"),
        isCancelBtnEnable: true,
        yesCallback: () => {
          setTimeout(() => {
            confirmModalSuccess();
          }, 100);
        },
        noCallback: () => {
          downloadDocument({
            pdfByte,
            callback: () => {
              pdfPrintedModal({
                pdfByte
              });
            }
          });
        },
        cancelCallback: () => {
          const hasZeroPaymentAmount = gridData.some((row) => row?.amount === "0.00");
          if (hasZeroPaymentAmount) {
            setIsConfirmModalOpen(true);
          } else {
            const paymentRunId = sessionStorage.getItem("paymentRunId");
            history.push({
              pathname: clientId
                ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/cheque-processing-detail/${paymentRunId}`
                : `/accounts-payable/cheque-processing/cheque-processing-detail/${paymentRunId}`
            });
          }
        }
      })
    );
  };

  const zeroPaymentFailures = () => {
    const sessionData = JSON.parse(sessionStorage.getItem("chequeProcessing")!) || [];
    dispatch(
      zeroPaymentFailure({
        bankId: sessionData.bankId,
        narration: sessionData.narration,
        period: sessionData.period,
        uniqueId: sessionData.uniqueId,
        chequePrintData: gridData.map((row) => ({
          payeeName: row?.payee_name,
          chequeNo: row?.cheque_number,
          bookId: row?.book_id,
          amount: row?.amount,
          payeeId: 0,
          clientId: row?.client_id ?? 0
        })),
        callback: (resData) => {
          if (resData) {
            sessionStorage.setItem("paymentRunId", resData.paymentRunID);
            zeroPaymentCheck();
          }
        }
      })
    );
  };

  const confirmModalSuccess = () => {
    const paymentRunNumber = sessionStorage.getItem("paymentRunNumber");
    setIsPrintDisabled(false);
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        type: MODAL_TYPE.CONFIRMV2,
        message: t("alertMessage.printSuccessAlert.message", {
          paymentRunNumber
        }),
        title: t("alertMessage.title"),
        yesButtonText: t("common.yes"),
        isCancelBtnEnable: true,
        yesCallback: () => {
          const paymentRunId = sessionStorage.getItem("paymentRunId");
          const hasZeroPaymentAmount = gridData.some((row) => row?.amount === "0.00");
          if (hasZeroPaymentAmount) {
            setIsConfirmModalOpen(true);
            dispatch(
              getChequeConfirmRun({
                paymentRunId,
                callback: () => {
                  dispatch(getChequeProcessingData({ paymentRunId }));
                }
              })
            );
          } else {
            confirmModalCheck();
          }
        },
        noCallback: () => {
          const hasZeroPaymentAmount = gridData.some((row) => row?.amount === "0.00");
          if (hasZeroPaymentAmount) {
            setIsConfirmModalOpen(true);
          } else {
            const paymentRunId = sessionStorage.getItem("paymentRunId");
            const historyState = { paymentRunId };

            history.push({
              pathname: clientId
                ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/choose-spoiled-cheques`
                : "/accounts-payable/cheque-processing/choose-spoiled-cheques",
              state: { ...historyState }
            });
          }
        },
        cancelCallback: () => {
          const hasZeroPaymentAmount = gridData.some((row) => row?.amount === "0.00");
          if (hasZeroPaymentAmount) {
            setIsConfirmModalOpen(true);
          } else {
            const paymentRunId = sessionStorage.getItem("paymentRunId");
            history.push({
              pathname: clientId
                ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/cheque-processing-detail/${paymentRunId}`
                : `/accounts-payable/cheque-processing/cheque-processing-detail/${paymentRunId}`
            });
          }
        }
      })
    );
  };

  const zeroPaymentCheck = () => {
    clickAwayNavigation();
  };

  const confirmModalCheck = () => {
    setIsPrintDisabled(false);
    const paymentRunId = sessionStorage.getItem("paymentRunId");
    if (paymentRunId) {
      dispatch(
        getChequeConfirmRun({
          paymentRunId,
          callback: () => {
            dispatch(getChequeProcessingData({ paymentRunId }));
          }
        })
      );
      clickAwayNavigation();
    }
  };
  useEffect(() => {
    const storedData = FMSSessionStorage.getItem("chequeProcessing");

    if (storedData) {
      dispatch(getPayeeDetails({ uniqueId: storedData?.uniqueId }));
      setChequeRunDetails(storedData);
    }
  }, []);

  useEffect(() => {
    const chequeRunData = FMSSessionStorage.getItem(CHEQUE_PROCESSING_CHEQUE_RUN);
    const { tobeUsedChequeBooks, chequeList } = chequeRunData;

    if (chequePayeeDetails.length !== 0) {
      const clientIds = chequePayeeDetails.map((row) => row?.client_id);
      const uniqueClientIds = Array.from(new Set(clientIds));
      const newGridData: { [key: string]: any }[] = [];
      uniqueClientIds.forEach((clientId, index) => {
        const clientDetails = chequePayeeDetails.filter((row) => row.client_id === clientId);
        const totalAmount = clientDetails.reduce((sum, row) => sum + row.payment_amount, 0);
        const payeeName = clientDetails[0]?.payee_name;
        newGridData.push({
          client_id: clientId,
          payee_name: payeeName,
          amount: totalAmount
        });
      });

      const newGridDataSort = newGridData
        .sort((a, b) => {
          const diff1 = a?.payee_name ? a?.payee_name : a?.client_name;
          const diff2 = b?.payee_name ? b?.payee_name : b?.client_name;
          return diff1.localeCompare(diff2);
        })
        .map((row, index) => ({
          ...row,
          cheque_number: chequeList[index].chequeNumber,
          book_id: chequeList[index].bookId,
          amount: row?.amount ? usNumberFormat(row?.amount) : "0.00"
        }));
      setGridData(newGridDataSort);
    }
  }, [chequePayeeDetails]);

  const goToBack = () => {
    history.push({
      pathname: clientId
        ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/add-cheque-run/items-for-payment`
        : "/accounts-payable/cheque-processing/add-cheque-run/items-for-payment",
      state: { redirect: true }
    });
  };

  return {
    t,
    gridData,
    status,
    zeroPaymentPrint,
    zeroPaymentCheck,
    onPrintBtnClicked,
    isPrintDisabled,
    setIsPrintDisabled,
    goToBack,
    chequeRunDetails,
    isConfirmModalOpen,
    setIsConfirmModalOpen,
    confirmModalCheck,
    printDocument,
    zeroPaymentFailures
  };
};

export default useSummaryOfCheques;
