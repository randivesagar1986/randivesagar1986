import GridTableNew from "@/components/GridTableNew/GridTableNew";
import Layout from "@/components/Layout/Layout";
import { Button, ButtonColor, ButtonSize, Grid, GridItem, Icon, IconColor, IconSize } from "@essnextgen/ui-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import { STATUS } from "@/types/UseStateType";
import { AsyncThunkAction } from "@reduxjs/toolkit";
import { Dispatch, AnyAction } from "redux";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/store/store";
import { useState } from "react";
import { setToSession, usNumberFormat } from "@/utils/getDataSource";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { useHistory } from "react-router-dom";
import { getChequeNewPrintDocument, getChequePrintDocument } from "../state/CheckProcessingList.slice";
import useSummaryOfCheques from "./useSummaryOfCheques";
import summaryOfChequesDef from "./Grid/columnDef";

const loaderConfig: loadingConfig = {};
const SummaryOfCheques = () => {
  const {
    t,
    gridData,
    status,
    zeroPaymentPrint,
    zeroPaymentCheck,
    chequeRunDetails,
    goToBack,
    onPrintBtnClicked,
    isPrintDisabled,
    setIsPrintDisabled,
    isConfirmModalOpen,
    setIsConfirmModalOpen,
    confirmModalCheck,
    printDocument,
    zeroPaymentFailures
  } = useSummaryOfCheques();
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const [loading, setLoading] = useState(false);

  interface MyResponseType {
    payload: string; // Adjust this type according to your actual response structure
    // Add other properties if necessary
  }

  const PROPOSED_CHECK_RUN = "Proposed Cheque Run";

  const HandlePrintCheque = async (
    runNo: any,
    runID: any,
    chequeRun: any,
    period: any,
    uniqueId: any,
    odbcHandle: any
  ) => {
    setLoading(true);
    if (uniqueId) {
      const sessionData = JSON.parse(sessionStorage.getItem("chequeProcessing")!) || [];
      const res = await dispatch(
        getChequeNewPrintDocument({
          runNumber: runNo,
          runId: runID,
          param1: chequeRun,
          period,
          uniqueId,
          odbcHandle,
          bankId: sessionData?.bankId
        })
      );
      const params = {
        runNumber: runNo,
        runId: runID,
        param1: chequeRun,
        period,
        uniqueId,
        odbcHandle
      };
      history.push({
        pathname:
          "/accounts-payable/cheque-processing/add-cheque-run/items-for-payment/summary-of-cheques/charts-accounts-review-preview",
        state: { ...params }
      });
    }
  };

  const CustomCell = ({ field, row }: any) => {
    if (field === "cheque_number") {
      return <>{row?.amount === 0 || row?.amount === "0.00" ? "Zero Payment" : row?.cheque_number}</>;
    }
    return null;
  };
  return (
    <>
      <Layout
        className="Summary__of--cheques"
        pageTitle={t("chequeProcessing.summaryOfCheque")}
      >
        <Grid className="marginb15">
          <GridItem sm={4}>
            <div className="essui-global-typography-default-subtitle">{t("chequeProcessing.bankBalance")}</div>
          </GridItem>
        </Grid>

        <Grid
          dataTestId="test-id"
          className="row-gap-16"
        >
          <GridItem
            lg={4}
            md={4}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div>
              <div className="essui-form-label mb-5">{t("chequeProcessing.current")}</div>
              <div>{usNumberFormat(chequeRunDetails?.paymentDetails?.current)}</div>
            </div>
          </GridItem>
          <GridItem
            lg={4}
            md={4}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div>
              <div className="essui-form-label mb-5">{t("chequeProcessing.processing")}</div>
              <div>{usNumberFormat(chequeRunDetails?.paymentDetails?.taggedItems)}</div>
            </div>
          </GridItem>
          <GridItem
            lg={4}
            md={4}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div>
              <div className="essui-form-label mb-5">{t("chequeProcessing.new")}</div>
              <div>{usNumberFormat(chequeRunDetails?.paymentDetails?.new)}</div>
            </div>
          </GridItem>
        </Grid>
      </Layout>
      {loading ? (
        <Loader loadingConfig={loaderConfig} />
      ) : (
        <Layout
          isBreadcrumbRequired={false}
          type="transparent"
        >
          <GridTableNew
            columnDef={summaryOfChequesDef}
            customCell={CustomCell}
            dataSource={gridData}
            isLoading={status === STATUS.LOADING}
            footer={
              <div className="overflow-hidden">
                <Grid>
                  <GridItem
                    sm={6}
                    md={{
                      offset: 2,
                      span: 6
                    }}
                    lg={{
                      offset: 6,
                      span: 6
                    }}
                    xl={{
                      offset: 6,
                      span: 6
                    }}
                  >
                    <>
                      <div className="d-flex justify-end flex-wrap row-gap-8">
                        <Button
                          size={ButtonSize.Small}
                          color={ButtonColor.Secondary}
                          disabled={
                            chequeRunDetails?.paymentDetails?.taggedItems === 0 ||
                            chequeRunDetails?.paymentDetails?.taggedItems === 0.0 ||
                            chequeRunDetails?.paymentDetails?.taggedItems === 0.0
                          }
                          onClick={() =>
                            HandlePrintCheque(
                              null,
                              0,
                              PROPOSED_CHECK_RUN,
                              chequeRunDetails?.period,
                              chequeRunDetails?.uniqueId,
                              0
                            )
                          }
                        >
                          {t("chequeProcessing.chequeRunReport")}
                        </Button>
                      </div>
                    </>
                  </GridItem>
                </Grid>
              </div>
            }
          />
        </Layout>
      )}

      <Layout isBreadcrumbRequired={false}>
        <Grid
          className="margint10"
          justify="space-between"
        >
          <GridItem
            sm={5}
            md={5}
            lg={6}
            xl={6}
            className="grid-container-item save-cancel-button"
          >
            <div className="rightbtn">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={() => {
                  setToSession("redirectPath", "");
                  onPrintBtnClicked();
                }}
                disabled={isPrintDisabled}
              >
                {t("common.print")}
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={() => {
                  setToSession("redirectPath", "");
                  goToBack();
                }}
              >
                {t("common.back")}
              </Button>
            </div>
          </GridItem>

          <GridItem
            sm={3}
            md={1}
            lg={6}
            xl={6}
            className="grid-container-item"
          >
            <HelpButton
              identifier="help-btn-cheque"
              labelName={t("common.help")}
            />
          </GridItem>
        </Grid>
      </Layout>
      <ConfirmModal
        title={t("alertMessage.title")}
        isOpen={isConfirmModalOpen}
        setOpen={setIsConfirmModalOpen}
        message={t("chequeProcessing.zeroReportMsg1")}
        confirm={() => {
          const zeroPaymentAmounts = gridData.every((row) => row?.amount === "0.00");
          if (zeroPaymentAmounts) {
            printDocument();
          } else {
            zeroPaymentPrint();
          }
        }}
        callback={({ confirm }) => {
          if (!confirm) {
            const zeroPaymentAmounts = gridData.every((row) => row?.amount === "0.00");
            if (zeroPaymentAmounts) {
              zeroPaymentFailures();
            } else {
              zeroPaymentCheck();
            }
          }
        }}
      />
    </>
  );
};
export default SummaryOfCheques;
