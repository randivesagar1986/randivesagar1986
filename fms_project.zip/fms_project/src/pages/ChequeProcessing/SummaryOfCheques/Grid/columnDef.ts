import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const summaryOfChequesDef: TColumnDef = [
  {
    headerName: "Payee Name",
    field: "payee_name"
  },
  {
    headerName: "Cheque No.",
    field: "cheque_number",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Amount",
    field: "amount",
    align: "right"
  }
];

export default summaryOfChequesDef;
