import { useHistory } from "react-router-dom";
import { chequeButtonTitle } from "@/utils/constants";
import { WhitePaper } from "@carbon/icons-react";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { Button, ButtonColor, ButtonSize, Grid, GridItem } from "@essnextgen/ui-kit";
import { CHEQUE_RUN_STATUS, VIEW_CHEQUE_STATUS } from "@/types/UseStateType";
import { useEffect, useState } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { canDo } from "@/store/state/userAccessRights.slice";
import ACCESS_RIGHTS_MODULE from "@/types/accessRightModule";
import ACCESS_RIGHTS_ACTION from "@/types/accesRightActions";
import useChequeDetail from "./ChequeProcessingList/useChequeProcessingDetail";

import {
  getChequeProcessingDetailData,
  getConfirmChequeRunZeroPayment,
  getConfirmChequeRun,
  getChequeProcessingData,
  actions as checkPAction
} from "./state/CheckProcessingList.slice";
import { getChequePaymentRun } from "./state/ChequePaymentRun.slice";
import { actions as cpAction, getChequeProcessingList } from "./state/ChequeProcessing.slice";

const ChequeProcessingPageToolbar = () => {
  const { t, paymentRunId } = useChequeDetail();
  const dispatch = useDispatch<AppDispatch>();
  const { selectedRow: cpSelectedRow } = useAppSelector((state) => state.chequeProcessingList);
  const { selectedRow: cpListSelectedRow, filterState } = useAppSelector((state) => state.newChequeProcessingList);
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const addAccess = canDo(userAccessRights, {
    module: ACCESS_RIGHTS_MODULE.ChequeProcessing,
    action: ACCESS_RIGHTS_ACTION.Add
  });
  const currentRow = paymentRunId ? cpSelectedRow : cpListSelectedRow;
  const paymentRunNumber = currentRow?.payment_run_number;
  const history = useHistory();
  const historyState = { paymentRunId: currentRow?.payment_run_id };

  const isConfrimCheckRunDisabled = () => {
    if (!addAccess) {
      return true;
    }
    if (
      addAccess &&
      cpListSelectedRow?.status !== CHEQUE_RUN_STATUS.PENDING_CONFIRMATION &&
      cpSelectedRow?.status_desc !== VIEW_CHEQUE_STATUS.PRINTED_PENDING_CONFIRMATION
    ) {
      return true;
    }
    return false;
  };

  const showHighlightedRecord = (resData: any) => {
    const row = resData.data.find((row: { [key: string]: any }) => row?.payment_run_id === resData?.highLightId);
    if (!row) {
      dispatch(cpAction.setSelectedRow(resData.data[0]));
    } else {
      dispatch(cpAction.setSelectedRow(row));
    }
  };

  return (
    <>
      <Grid
        justify="flex-end"
        className="tools"
      >
        <GridItem>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            title={chequeButtonTitle.ConfirmCheque}
            disabled={isConfrimCheckRunDisabled()}
            onClick={() =>
              dispatch(
                uiActions.confirmPopup({
                  title: t("alertMessage.title"),
                  message: t("chequeProcessing.chequeRunModalTitle", { paymentRunNumber }),
                  yesCallback: () => {
                    if (currentRow?.cheque_number === "Zero Payment") {
                      dispatch(
                        getConfirmChequeRunZeroPayment({
                          paymentRunId: currentRow?.payment_run_id,
                          callback: () => {
                            dispatch(getChequeProcessingDetailData(currentRow?.paymentId));
                            dispatch(
                              getChequeProcessingData({
                                paymentRunId: currentRow?.payment_run_id,
                                callback: (data) => {
                                  checkPAction.setSelectedRow(data?.chequePayments?.at(0));
                                }
                              })
                            );
                            dispatch(getChequePaymentRun());
                            dispatch(
                              getChequeProcessingList({
                                ...filterState,
                                callback: (resData) => showHighlightedRecord(resData)
                              })
                            );
                          }
                        })
                      );
                    } else {
                      dispatch(
                        getConfirmChequeRun({
                          paymentRunId: currentRow?.payment_run_id,
                          callback: () => {
                            dispatch(getChequeProcessingDetailData(currentRow?.paymentId));
                            dispatch(
                              getChequeProcessingData({
                                paymentRunId: currentRow?.payment_run_id,
                                callback: (data) => {
                                  checkPAction.setSelectedRow(data?.chequePayments?.at(0));
                                }
                              })
                            );
                            dispatch(getChequePaymentRun());
                            dispatch(
                              getChequeProcessingList({
                                ...filterState,
                                callback: (resData) => showHighlightedRecord(resData)
                              })
                            );
                          }
                        })
                      );
                    }
                  },
                  isCancelBtnEnable: true,
                  noCallback: () => {
                    history.push({
                      pathname: "/accounts-payable/cheque-processing/choose-spoiled-cheques",
                      state: { ...historyState }
                    });
                  },
                  type: MODAL_TYPE.CONFIRMV2
                })
              )
            }
          >
            <WhitePaper size={22} />
          </Button>
        </GridItem>
      </Grid>
    </>
  );
};
export default ChequeProcessingPageToolbar;
