import { specialCharacters } from "@/types/UseStateType";
import { usNumberFormat } from "@/utils/getDataSource";

const CustomCell = ({ field, row }: any) => {
  const getContent = () => {
    const formatDate = (dateString: any) => {
      const [day, month, year] = dateString.split("/");
      const dateObj = new Date(`${year}-${month}-${day}`);
      const options: any = { day: "2-digit", month: "short", year: "numeric" };
      return dateObj.toLocaleDateString("en-GB", options).replace("Sept", "Sep");
    };

    if (field === "disp_pay_by") {
      return <span>{formatDate(row?.disp_pay_by)}</span>;
    }
    if (field === "amount") {
      return <span>{row?.payment_amount ? usNumberFormat(row?.payment_amount) : specialCharacters.HYPHEN}</span>;
    }

    return null;
  };
  return getContent();
};

export default CustomCell;
