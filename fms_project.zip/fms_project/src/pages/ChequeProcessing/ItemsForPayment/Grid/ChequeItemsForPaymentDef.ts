import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
/* eslint-disable import/prefer-default-export */
export const ChequeItemsForPaymentDef: TColumnDef = [
  {
    field: "checkbox",
    checkboxSelection: true,
    key: "unique_id"
  },
  {
    headerName: "Supplier Name",
    field: "client_name",
    align: "left",
    sequence: true
  },
  {
    headerName: "Code",
    field: "client_code",
    align: "left",
    sequence: true
  },
  {
    headerName: "Invoice / Credit Note",
    field: "invoice_num",
    align: "left",
    sequence: true
  },
  {
    headerName: "Pay By Date",
    field: "disp_pay_by",
    align: "left",
    sequence: true,
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Authorisation",
    field: "auth_by",
    align: "left"
  },
  {
    headerName: "Amount",
    field: "amount",
    align: "right",
    cellRenderer: "GridCellLink"
  }
];
