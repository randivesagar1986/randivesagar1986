import React, { useState, useEffect } from "react";
import { CheckBox, FormLabel, Grid, GridItem, RadioButton, RadioLabelPosition } from "@essnextgen/ui-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { Sequence } from "@/utils/constants";
import { KEYBOARD_STRING } from "@/types/UseStateType";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { actions as ItPayment } from "../../../state/ItemsPayment.slice";

/* eslint-disable import/prefer-default-export */
export const Filter = (props: any) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { filterState } = useAppSelector((state) => state.chequePaymentItems);
  const dispatch = useDispatch<AppDispatch>();

  const {
    sequence,
    showBACS,
    showSundry,
    onSequenceChange,
    onSelectBACSCheckbox,
    onSelectSundryInvCheckbox,
    displayBacsPayable,
    displaySundryInvoicesOnly,
    isSundryOnlyChecked
  } = props;

  const [arrowSequence, setArrowSequence] = useState<string>(sequence);

  useEffect(() => {
    const timer = setTimeout(() => {
      document.getElementById(arrowSequence)?.focus();
    }, 5);

    return () => clearTimeout(timer);
  }, [arrowSequence]);

  const handleSequenceFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey =
      e.key === KEYBOARD_STRING.ArrowDown ||
      e.key === KEYBOARD_STRING.ArrowUp ||
      e.key === KEYBOARD_STRING.ArrowLeft ||
      e.key === KEYBOARD_STRING.ArrowRight;

    const arrowKey: string = e.key;

    if (isArrowKey) {
      e.preventDefault();
      e.stopPropagation();
      let nextSequenceValue: string = "";

      if (sequence === Sequence.SEQ) {
        nextSequenceValue = arrowKey === "ArrowUp" || arrowKey === "ArrowLeft" ? Sequence.PAYDATE : Sequence.IDSEQ;
      } else if (sequence === Sequence.IDSEQ) {
        nextSequenceValue = arrowKey === "ArrowUp" || arrowKey === "ArrowLeft" ? Sequence.SEQ : Sequence.INVCR;
      } else if (sequence === Sequence.INVCR) {
        nextSequenceValue = arrowKey === "ArrowUp" || arrowKey === "ArrowLeft" ? Sequence.IDSEQ : Sequence.PAYDATE;
      } else if (sequence === Sequence.PAYDATE) {
        nextSequenceValue = arrowKey === "ArrowUp" || arrowKey === "ArrowLeft" ? Sequence.INVCR : Sequence.SEQ;
      }

      setArrowSequence(nextSequenceValue);
      dispatch(
        ItPayment.setFilters({
          ...filterState,
          sequence: nextSequenceValue
        })
      );
    }
  };

  return (
    <Grid className="row-gap-16">
      <GridItem>
        <div>
          <FormLabel>{t("chequeProcessing.sequence")}</FormLabel>
          <div className="sequence">
            <div
              className="essui-textinput sequence-fields flex-wrap row-gap-16"
              onKeyDown={handleSequenceFieldKeyDown}
            >
              <RadioButton
                label={t("chequeProcessing.supplier")}
                labelPosition={RadioLabelPosition.Right}
                value={Sequence.SEQ}
                isSelected={arrowSequence === Sequence.SEQ}
                onChange={onSequenceChange}
                name={arrowSequence}
                id={Sequence.SEQ}
              />
              <RadioButton
                label={t("chequeProcessing.idSupplier")}
                labelPosition={RadioLabelPosition.Right}
                value={Sequence.IDSEQ}
                isSelected={arrowSequence === Sequence.IDSEQ}
                onChange={onSequenceChange}
                name={arrowSequence}
                id={Sequence.IDSEQ}
              />
              <RadioButton
                label={t("chequeProcessing.invoiceCreditNoteNo")}
                labelPosition={RadioLabelPosition.Right}
                value={Sequence.INVCR}
                isSelected={arrowSequence === Sequence.INVCR}
                onChange={onSequenceChange}
                name={arrowSequence}
                id={Sequence.INVCR}
              />
              <RadioButton
                label={t("chequeProcessing.payByDate")}
                labelPosition={RadioLabelPosition.Right}
                value={Sequence.PAYDATE}
                isSelected={arrowSequence === Sequence.PAYDATE}
                onChange={onSequenceChange}
                name={arrowSequence}
                id={Sequence.PAYDATE}
              />
            </div>
          </div>
        </div>
      </GridItem>
      <GridItem>
        <div className="mt-32">
          <CheckBox
            label={t("chequeProcessing.showBACSEnabledSupplierTransactions")}
            value={showBACS}
            isSelected={showBACS}
            onChange={onSelectBACSCheckbox}
          />
        </div>
      </GridItem>
      <GridItem>
        {displaySundryInvoicesOnly && (
          <div className="mt-32">
            <CheckBox
              label={t("chequeProcessing.showSundryInvoicesOnly")}
              isSelected={isSundryOnlyChecked}
              value={showSundry}
              onChange={onSelectSundryInvCheckbox}
            />
          </div>
        )}
      </GridItem>
    </Grid>
  );
};
