import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider, useDispatch } from "react-redux";
import { BrowserRouter as Router, useParams } from "react-router-dom";
import { FormProvider } from "react-hook-form";
import configureStore from "redux-mock-store";
import { useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import ItemsForPayment from "../ItemsForPayment";
import useItemsForPayment from "../useItemsForPayment";

jest.mock("../useItemsForPayment");

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn().mockImplementation((selector) => selector(initialState))
}));

jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn()
}));

const mockStore = configureStore([]);

const initialState = {
  chequePaymentItems: {
    chequePaymentItem: [],
    status: STATUS.IDLE,
    selectedView: null,
    checkedPaymentItems: [],
    checkedRows: [],
    columnDef: [],
    displayBacsPayable: false,
    displaySundryInvoicesOnly: false,
    chequePaymentItemsPaginations: {
      totalCount: 0,
      totalPages: 1,
      currentPage: 1
    },
    chequePaymentItemsPaginationsStatus: STATUS.IDLE
  },
  userAccessRights: {
    isSupplierHavingAccess: true
  },
  chequeDetails: {
    defaultPeriod: ""
  },
  summaryOfCheques: {
    chequePayeeDetails: []
  },
  availableChequeBooks: {
    chequeBooks: []
  },
  filterState: {
    sequence: "",
    showBACS: false,
    showSundry: false
  }
};

const mockProps = {
  t: (key: string) => key,
  goToNext: jest.fn(),
  setIsTaggedOpen: jest.fn(),
  isTaggedOpen: false,
  isAlertModalOpen: false,
  setIsAlertModalOpen: jest.fn(),
  alertMessage: "",
  tagSubmitHandler: jest.fn(),
  onSelectCheckbox: jest.fn(),
  onRowSelection: jest.fn(),
  currentBalance: 1000,
  taggedBalance: 500,
  newBalance: 200,
  goBack: jest.fn(),
  paymentPeriod: "2024-10",
  orderNumber: "12345",
  orderNumberLabel: "Order Number",
  unTagAll: jest.fn(),
  sequence: "",
  showBACS: false,
  showSundry: false,
  onSequenceChange: jest.fn(),
  onSelectBACSCheckbox: jest.fn(),
  onSelectSundryInvCheckbox: jest.fn(),
  openKeepChangeModal: false,
  setOpenKeepChangeModal: jest.fn(),
  history: { push: jest.fn() },
  redirectUrl: "/redirect",
  isSundryOnlyChecked: false,
  onPageChangeHandler: jest.fn()
};

describe("ItemsForPayment ChequeProcessing", () => {
  let store: any = mockStore({});
  let mockDispatch: jest.Mock;

  beforeEach(() => {
    store = mockStore(initialState);

    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(initialState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
    (useItemsForPayment as jest.Mock).mockReturnValue(mockProps);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("renders the component", async () => {
    render(
      <Provider store={store}>
        <Router>
          <ItemsForPayment />
        </Router>
      </Provider>
    );
    await waitFor(() => {
      const element = screen.getByTestId("layoutItemsForPaymentTable");
      expect(element).toBeInTheDocument();
    });
  });

  test("displays the current balance correctly", () => {
    render(
      <Provider store={store}>
        <Router>
          <ItemsForPayment />
        </Router>
      </Provider>
    );
    expect(screen.getByText(/current/i)).toBeInTheDocument();
    expect(screen.getByText(/1,000.00/i)).toBeInTheDocument(); // Adjust based on your formatting
  });

  test("renders the correct number of rows in the table", async () => {
    const mockData = [{ disp_pay_by: "01/01/2024", payment_amount: 100 }];
    store = mockStore({
      ...initialState,
      chequePaymentItems: {
        ...initialState.chequePaymentItems,
        chequePaymentItem: mockData
      }
    });

    render(
      <Provider store={store}>
        <Router>
          <ItemsForPayment />
        </Router>
      </Provider>
    );

    const rows = await screen.findAllByRole("row");
    expect(rows.length).toBe(mockData.length + 1); // Including header row
  });

  test("disables 'Next' button if no rows are checked", () => {
    render(
      <Provider store={store}>
        <Router>
          <ItemsForPayment />
        </Router>
      </Provider>
    );
    const nextButton = screen.getByTestId("gotonext-btn-cheque");
    expect(nextButton).toBeDisabled();
  });

  test("renders hyphen when payment amount is not provided", async () => {
    const mockData = [{ disp_pay_by: "01/01/2024", payment_amount: null }];
    store = mockStore({
      ...initialState,
      chequePaymentItems: {
        ...initialState.chequePaymentItems,
        chequePaymentItem: mockData
      }
    });

    render(
      <Provider store={store}>
        <Router>
          <ItemsForPayment />
        </Router>
      </Provider>
    );

    // Check if the hyphen is displayed for missing amount
    expect(screen.getByText(/-/)).toBeInTheDocument();
  });

  test("renders nothing for unsupported field", async () => {
    const mockData = [{ disp_pay_by: "01/01/2024", payment_amount: 100 }];
    store = mockStore({
      ...initialState,
      chequePaymentItems: {
        ...initialState.chequePaymentItems,
        chequePaymentItem: mockData
      }
    });

    render(
      <Provider store={store}>
        <Router>
          <ItemsForPayment />
        </Router>
      </Provider>
    );

    // Assuming the component doesn't render anything for unsupported fields
    expect(screen.queryByText(/unsupported_field/i)).not.toBeInTheDocument();
  });

  test("renders formatted amount for amount field", async () => {
    const mockData = [{ disp_pay_by: "01/01/2024", payment_amount: 1234.56 }];
    store = mockStore({
      ...initialState,
      chequePaymentItems: {
        ...initialState.chequePaymentItems,
        chequePaymentItem: mockData
      }
    });

    render(
      <Provider store={store}>
        <Router>
          <ItemsForPayment />
        </Router>
      </Provider>
    );

    // Check if the formatted amount is displayed correctly
    expect(await screen.findByText("1,000.00")).toBeInTheDocument();
  });

  test("renders formatted date for disp_pay_by field", async () => {
    const mockData = [{ disp_pay_by: "01/01/2024", payment_amount: 100 }];
    store = mockStore({
      ...initialState,
      chequePaymentItems: {
        ...initialState.chequePaymentItems,
        chequePaymentItem: mockData
      }
    });

    render(
      <Provider store={store}>
        <Router>
          <ItemsForPayment />
        </Router>
      </Provider>
    );

    // Check if the formatted date is displayed correctly
    expect(await screen.findByText("01 Jan 2024")).toBeInTheDocument();
  });
});
