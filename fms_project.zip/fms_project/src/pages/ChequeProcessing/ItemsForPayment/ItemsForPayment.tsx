import { useDispatch } from "react-redux";

import GridTableNew from "@/components/GridTableNew/GridTableNew";
import Layout from "@/components/Layout/Layout";

import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  Dialog,
  DialogContent,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  NotificationStatus,
  Pagination
} from "@essnextgen/ui-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";

import { TagAll } from "@/shared/components/TagAll/TagAll";
import { usNumberFormat, getDate } from "@/utils/getDataSource";
import AlertModal from "@/shared/components/AlertModal/AlertModal";

import HelpButton from "@/components/OpenLinkButton/HelpButton";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { Filter } from "./Grid/Filter/Filter";

import useItemsForPayment from "./useItemsForPayment";
import CustomCell from "./Grid/CustomCell";

import "./Style.scss";

const ItemsForPayment = () => {
  const {
    chequePaymentItem,
    status,
    selectedView,
    checkedPaymentItems,
    checkedRows,
    columnDef,
    displayBacsPayable,
    displaySundryInvoicesOnly,
    chequePaymentItemsPaginations,
    chequePaymentItemsPaginationsStatus
  } = useAppSelector((state) => state.chequePaymentItems);

  const {
    t,
    goToNext,
    isTaggedOpen,
    setIsTaggedOpen,
    isAlertModalOpen,
    setIsAlertModalOpen,
    alertMessage,
    tagSubmitHandler,
    onSelectCheckbox,
    onRowSelection,
    currentBalance,
    taggedBalance,
    newBalance,
    goBack,
    paymentPeriod,
    orderNumber,
    orderNumberLabel,
    unTagAll,
    sequence,
    showBACS,
    showSundry,
    onSequenceChange,
    onSelectBACSCheckbox,
    onSelectSundryInvCheckbox,
    openKeepChangeModal,
    setOpenKeepChangeModal,
    history,
    redirectUrl,
    isSundryOnlyChecked,
    onPageChangeHandler,
    isPaymentItemsResponnse
  } = useItemsForPayment();

  const isUntagAllDisabled =
    chequePaymentItem.length === 0 || (checkedRows.length === 0 && isPaymentItemsResponnse.length === 0);

  return (
    <>
      <Layout
        className="items-for-payment"
        pageTitle={t("chequeProcessing.itemsForPayment")}
        isBreadcrumbRequired
      >
        <Grid
          container
          className="marginb15"
        >
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
            className="bankbalance-padding-left"
          >
            <div className="essui-global-typography-default-subtitle">{t("chequeProcessing.bankBalance")}</div>
          </GridItem>
        </Grid>
        <Grid className="row-gap-16">
          <GridItem
            sm={12}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">{t("chequeProcessing.current")}</div>
              <div className="mt-12 balance">{usNumberFormat(currentBalance)}</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">{t("chequeProcessing.taggedItems")}</div>
              <div className="mt-12">{usNumberFormat(taggedBalance)}</div>
            </div>
          </GridItem>
          <GridItem
            sm={12}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">{t("chequeProcessing.new")}</div>
              <div className="mt-12">{usNumberFormat(newBalance)}</div>
            </div>
          </GridItem>
        </Grid>
      </Layout>

      <Layout
        isBreadcrumbRequired={false}
        type="transparent"
        className="items-for-payment mt-8 pb-8"
        dataTestId="layoutItemsForPaymentTable"
      >
        <GridTableNew
          filters={
            <Filter
              sequence={sequence}
              showBACS={showBACS}
              showSundry={showSundry}
              displayBacsPayable={displayBacsPayable}
              displaySundryInvoicesOnly={displaySundryInvoicesOnly}
              isSundryOnlyChecked={isSundryOnlyChecked}
              onSequenceChange={onSequenceChange}
              onSelectBACSCheckbox={onSelectBACSCheckbox}
              onSelectSundryInvCheckbox={onSelectSundryInvCheckbox}
            />
          }
          dataSource={chequePaymentItem}
          isLoading={chequePaymentItemsPaginationsStatus === STATUS.LOADING}
          columnDef={columnDef}
          customCell={CustomCell}
          selectedRow={selectedView}
          checkedRows={checkedRows}
          checkedRowHandler={onSelectCheckbox}
          selectedRowHandler={onRowSelection}
          footer={
            chequePaymentItemsPaginations?.totalCount >= 5 ? (
              <Pagination
                count={chequePaymentItemsPaginations.totalPages}
                page={chequePaymentItemsPaginations.currentPage}
                onChange={onPageChangeHandler}
                className="fl-rt"
              />
            ) : null
          }
        />
      </Layout>

      <Layout
        isBreadcrumbRequired={false}
        className="items-for-payment layout mt-8 pb-8"
      >
        <Grid>
          <GridItem
            sm={4}
            md={2}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">{t("chequeProcessing.period")}</div>
              <div className="mt-12">{paymentPeriod}</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={2}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">{orderNumberLabel}</div>
              <div className="mt-12">{orderNumber}</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
            className="end-txt rsp-justify-start"
          >
            <FormLabel className="mr-bt8">{t("chequeProcessing.selection")}</FormLabel>
            <div className="selection">
              <div className="right-end">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  iconPosition={ButtonIconPosition.Left}
                  disabled={isUntagAllDisabled}
                  onClick={unTagAll}
                  dataTestId="unTagAll-btn"
                >
                  {t("tagUntag.unTagAll")}
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  iconPosition={ButtonIconPosition.Right}
                  disabled={chequePaymentItem.length === 0}
                  onClick={() => setIsTaggedOpen(true)}
                >
                  {t("tagUntag.tag")}
                </Button>
              </div>
            </div>
          </GridItem>
        </Grid>
        <Divider />
        <Grid
          className="margint10"
          justify="space-between"
        >
          <GridItem
            sm={5}
            md={4}
            lg={6}
            xl={6}
            className="grid-container-item save-cancel-button"
          >
            <div className="rightbtn">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
                onClick={goToNext}
                disabled={checkedRows.length === 0 && isPaymentItemsResponnse.length === 0}
                id="gotonext-btn-cheque"
                dataTestId="gotonext-btn-cheque"
              >
                {t("common.next")}
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={goBack}
                id="back-btn-cheque"
              >
                {t("common.back")}
              </Button>
              {/* <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                >
                  Cancel
                </Button> */}
            </div>
          </GridItem>

          <GridItem
            sm={3}
            md={4}
            lg={6}
            xl={6}
            className="grid-container-item"
          >
            <div>
              <HelpButton
                identifier="help-btn-cheque-itemsforpayment"
                labelName={t("common.help")}
              />
            </div>
          </GridItem>
        </Grid>
      </Layout>
      <Dialog
        title={t("chequeProcessing.chequeProcessingTagModalTitle")}
        className="invoice-note-tag modal__adjust--spacing"
        isOpen={isTaggedOpen}
        onClose={() => setIsTaggedOpen(false)}
      >
        <DialogContent className="overflow-hidden">
          <TagAll
            filters={["supplier", "date", "amount"]}
            onSubmit={tagSubmitHandler}
            onCancel={() => setIsTaggedOpen(false)}
            showAllSupplierSundry
            supplierModalHeaderTitle={t("supplier.supplierBrowse")}
            dateLabelByCheque
          />
        </DialogContent>
      </Dialog>
      <AlertModal
        isOpen={isAlertModalOpen}
        setOpen={setIsAlertModalOpen}
        title={t("alertMessage.title")}
        notificationType={NotificationStatus.HIGHLIGHT}
        message={alertMessage}
      />
      <ConfirmModal
        className="modal-width"
        isOpen={openKeepChangeModal}
        setOpen={setOpenKeepChangeModal}
        title={t("alertMessage.title")}
        message={t("common.keepChangesMsg")}
        confirm={() => {}}
        callback={({ confirm }) => {
          const historyState = {
            ...(history?.location?.state as any),
            checkedPaymentItems,
            moveToAddPage: true
          };
          if (!confirm) {
            history.push({
              pathname: redirectUrl,
              state: {
                ...historyState
              }
            });
          }
        }}
      />
    </>
  );
};
export default ItemsForPayment;
