import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const spoiledChequesDef: TColumnDef = [
  {
    headerName: "Cheque",
    field: "cheque_number"
  },
  {
    headerName: "Bank",
    field: "bank_des"
  },
  {
    headerName: "Account",
    field: "bank_account"
  },
  {
    headerName: "Amount",
    field: "amount",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Payee Name",
    field: "payee_name"
  }
];

export default spoiledChequesDef;
