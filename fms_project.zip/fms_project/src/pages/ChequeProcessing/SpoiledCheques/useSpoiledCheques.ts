import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useHistory, useParams } from "react-router-dom";
import { getSpoiledChequesDetails, saveChequeSpoil, actions as scActions } from "../state/SpoiledCheques.slice";
import useChequeDetail from "../ChequeProcessingList/useChequeProcessingDetail";
import { getChequeProcessingData } from "../state/CheckProcessingList.slice";
import { getChequeConfirmRun } from "../state/SummaryOfCheques.slice";

const useSpoiledCheques = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const { clientId, payeeId } = useParams<{ clientId: string; payeeId: string }>();
  const [isValueEmpty, setIsValueEmpty] = useState<boolean>(false);
  const [commitmentMessage, setCommitmentMessage] = useState<string>("");
  const [isSpoil, setIsSpoil] = useState<boolean>(false);
  const [isAlertMsg, setIsAlertMsg] = useState<boolean>(false);
  const historyState = history?.location?.state as any;
  const paymentRunId = historyState?.paymentRunId;
  const [isChequePrinted, setIsChequePrinted] = useState<boolean>(false);

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    chequePrintedStatus,
    printedChequesDetails,
    spoiledChequesDetails,
    printedChequesSelectedRow,
    spoiledChequesSelectedRow
  } = useAppSelector((state) => state.spoiledCheques);

  useEffect(() => {
    if (paymentRunId) {
      dispatch(
        getSpoiledChequesDetails({
          paymentRunId,
          callback: (data) => {
            dispatch(scActions.setPrintedChequesSelectedRow(data.at(0)));
          }
        })
      );
    }
  }, []);

  const selectedRowHandlerForPrint = (row: { [key: string]: any } | undefined) => {
    dispatch(scActions.setPrintedChequesSelectedRow(row));
  };

  const selectedRowHandlerForSpoiled = (row: { [key: string]: any } | undefined) => {
    dispatch(scActions.setSpoiledChequesSelectedRow(row));
  };

  const moveRecordToChequeSpoiled = () => {
    if (printedChequesDetails.length > 0) {
      const recordMoveToDown = { ...printedChequesSelectedRow };
      dispatch(scActions.removeFromChequesPrinted(recordMoveToDown));
      dispatch(scActions.setSpoiledCheques(recordMoveToDown));
      setIsSpoil(true);
    }
  };

  const removeRecordFromChequeSpoiled = () => {
    if (spoiledChequesDetails.length > 0) {
      const recordMoveToUp = { ...spoiledChequesSelectedRow };
      dispatch(scActions.removeFromChequesSpoiled(recordMoveToUp));
      dispatch(scActions.setChequesPrinted(recordMoveToUp));
    }
  };

  const moveAllRecordsToChequeSpoiled = () => {
    if (printedChequesDetails.length > 0) {
      dispatch(scActions.setAllChequesSpoiled(printedChequesDetails));
      dispatch(scActions.resetPrintedCheques());
      dispatch(scActions.resetPrintedChequesSelectedRow());
      dispatch(scActions.selectedLastRecordForSpoiled());
      setIsSpoil(true);
    }
  };

  const removeAllRecordsFromChequeSpoiled = () => {
    if (spoiledChequesDetails.length > 0) {
      dispatch(scActions.setAllChequesPrinted(spoiledChequesDetails));
      dispatch(scActions.resetSpoiledCheques());
      dispatch(scActions.resetSpoiledChequesSelectedRow());
      dispatch(scActions.selectedLastRecordForPrinted());
      setIsSpoil(false);
    }
  };

  const confirmChequesPrinted = () => {
    let payments: { paymentId: number }[] = [];
    payments = printedChequesDetails.map((detail) => ({ paymentId: detail.payment_id }));
    dispatch(
      saveChequeSpoil({
        chequeSpoil: {
          isSpoil,
          paymentRunId,
          reason: commitmentMessage,
          payment: payments
        }
      })
    );
    dispatch(scActions.resetPrintedCheques());
    dispatch(scActions.resetSpoiledCheques());
    setCommitmentMessage("");
    dispatch(
      getChequeConfirmRun({
        paymentRunId,
        callback: () => {
          dispatch(getChequeProcessingData({ paymentRunId }));
        }
      })
    );
    history.push({
      pathname: clientId
        ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/cheque-processing-detail/${paymentRunId}`
        : `/accounts-payable/cheque-processing/cheque-processing-detail/${paymentRunId}`
    });
  };

  const onSubmit = () => {
    if (spoiledChequesDetails.length > 0) {
      if (commitmentMessage?.replace(/\s/g, "")) {
        let payments: { paymentId: number }[] = [];
        payments = spoiledChequesDetails.map((detail) => ({ paymentId: detail.payment_id }));
        dispatch(
          saveChequeSpoil({
            chequeSpoil: {
              isSpoil,
              paymentRunId,
              reason: commitmentMessage,
              payment: payments
            }
          })
        );
        setCommitmentMessage("");
        dispatch(scActions.resetPrintedCheques());
        dispatch(scActions.resetSpoiledCheques());
        dispatch(getChequeProcessingData({ paymentRunId }));
        history.push({
          pathname: clientId
            ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/cheque-processing-detail/${paymentRunId}`
            : `/accounts-payable/cheque-processing/cheque-processing-detail/${paymentRunId}`
        });
      } else {
        setIsValueEmpty(true);
        setIsAlertMsg(true);
      }
    } else {
      setIsChequePrinted(true);
    }
  };

  const onCancel = () => {
    dispatch(scActions.resetPrintedCheques());
    dispatch(scActions.resetSpoiledCheques());
    history.push({
      pathname: clientId
        ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/cheque-processing-detail/${paymentRunId}`
        : `/accounts-payable/cheque-processing/cheque-processing-detail/${paymentRunId}`
    });
  };

  return {
    t,
    printedChequesSelectedRow,
    spoiledChequesSelectedRow,
    printedChequesDetails,
    spoiledChequesDetails,
    chequePrintedStatus,
    isValueEmpty,
    setIsValueEmpty,
    setCommitmentMessage,
    moveRecordToChequeSpoiled,
    removeRecordFromChequeSpoiled,
    moveAllRecordsToChequeSpoiled,
    removeAllRecordsFromChequeSpoiled,
    selectedRowHandlerForPrint,
    selectedRowHandlerForSpoiled,
    onSubmit,
    onCancel,
    isAlertMsg,
    setIsAlertMsg,
    isChequePrinted,
    setIsChequePrinted,
    confirmChequesPrinted
  };
};

export default useSpoiledCheques;
