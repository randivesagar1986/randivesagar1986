import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  NotificationStatus,
  TableUtility,
  TableWrapper
} from "@essnextgen/ui-kit";

import Layout from "@/components/Layout/Layout";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { STATUS } from "@/types/UseStateType";
import Input from "@/components/Input/Input";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import CustomCell from "./Grid/CustomCell";
import useSpoiledCheques from "./useSpoiledCheques";
import spoiledCheques from "./Grid/columnDef";
import "./Style.scss";

const SpoiledCheques = () => {
  const dispatch = useDispatch<AppDispatch>();
  const {
    t,
    chequePrintedStatus,
    printedChequesSelectedRow,
    spoiledChequesSelectedRow,
    printedChequesDetails,
    spoiledChequesDetails,
    setCommitmentMessage,
    setIsValueEmpty,
    isValueEmpty,
    moveRecordToChequeSpoiled,
    removeRecordFromChequeSpoiled,
    moveAllRecordsToChequeSpoiled,
    removeAllRecordsFromChequeSpoiled,
    selectedRowHandlerForPrint,
    selectedRowHandlerForSpoiled,
    onSubmit,
    onCancel,
    isAlertMsg,
    setIsAlertMsg,
    isChequePrinted,
    setIsChequePrinted,
    confirmChequesPrinted
  } = useSpoiledCheques();

  return (
    <>
      <div className="choose-spoiled-cheques-details-container">
        <Layout
          pageTitle={t("chequeProcessing.spoiledChequesTitle")}
          className="choose-spoiled-cheques-details"
        >
          <Grid />
          <TableWrapper>
            <TableUtility className="cheques-details"> {t("chequeProcessing.chequesPrinted")}</TableUtility>
            <GridTableNew
              dataSource={printedChequesDetails || []}
              isLoading={chequePrintedStatus === STATUS.LOADING}
              columnDef={spoiledCheques}
              customCell={CustomCell}
              selectedRow={printedChequesSelectedRow}
              selectedRowHandler={selectedRowHandlerForPrint}
            />
          </TableWrapper>
        </Layout>
        <Layout isBreadcrumbRequired={false}>
          <Grid>
            <GridItem
              sm={5}
              md={4}
              lg={{
                offset: 6,
                span: 6
              }}
              xl={{
                offset: 6,
                span: 6
              }}
            >
              <div className="d-flex justify-end">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="ml-4 mr-4"
                  iconName="arrow--down"
                  onClick={moveRecordToChequeSpoiled}
                >
                  {t("chequeProcessing.choose")}
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="ml-4 mr-4"
                  iconName="arrow--down"
                  onClick={moveAllRecordsToChequeSpoiled}
                >
                  {t("chequeProcessing.chooseAll")}
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="ml-4 mr-4"
                  iconName="arrow--up"
                  onClick={removeRecordFromChequeSpoiled}
                >
                  {t("chequeProcessing.remove")}
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="ml-4 mr-4"
                  iconName="arrow--up"
                  onClick={removeAllRecordsFromChequeSpoiled}
                >
                  {t("chequeProcessing.removeAll")}
                </Button>
              </div>
            </GridItem>
          </Grid>
        </Layout>
        <Layout isBreadcrumbRequired={false}>
          <TableWrapper>
            <TableUtility className="cheques-details"> {t("chequeProcessing.chequesSpoiled")}</TableUtility>
            <GridTableNew
              dataSource={spoiledChequesDetails || []}
              isLoading={false}
              columnDef={spoiledCheques}
              customCell={CustomCell}
              selectedRow={spoiledChequesSelectedRow}
              selectedRowHandler={selectedRowHandlerForSpoiled}
            />
          </TableWrapper>
        </Layout>
        <Layout isBreadcrumbRequired={false}>
          <Grid>
            <GridItem
              lg={6}
              xl={6}
            >
              <FormLabel forId="txtDescription">{t("chequeProcessing.descriptionPrintRunProblem")}</FormLabel>
              <Input
                searchable={false}
                autoComplete={false}
                id="txtDescription"
                maxLength={60}
                name="Description"
                className={isValueEmpty ? "value-empty w-100" : "w-100"}
                onChange={(e) => {
                  if (e.target.value.trim()) {
                    setIsValueEmpty(false);
                  } else {
                    setIsValueEmpty(true);
                  }
                  setCommitmentMessage(e.target.value.trim() as string);
                }}
              />
            </GridItem>
          </Grid>
          <Grid>
            <GridItem
              sm={3}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Tertiary}
                >
                  {t("common.help")}
                </Button>
              </div>
            </GridItem>
            <GridItem
              sm={5}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="d-flex justify-end">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="ml-4 mr-4"
                  onClick={onCancel}
                >
                  {t("common.cancel")}
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Primary}
                  className="ml-4"
                  onClick={onSubmit}
                >
                  {t("common.save")}
                </Button>
              </div>
            </GridItem>
          </Grid>
        </Layout>
      </div>

      <AlertModal
        isOpen={isAlertMsg}
        setOpen={setIsAlertMsg}
        message={t("common.invalidData")}
        title={t("common.simsFMSModule")}
        notificationType={NotificationStatus.HIGHLIGHT}
      />
      <ConfirmModal
        isOpen={isChequePrinted}
        setOpen={setIsChequePrinted}
        title={t("common.simsFMSModule")}
        message={t("chequeProcessing.chequeRunSuccessful")}
        confirm={() => {
          confirmChequesPrinted();
        }}
        callback={({ confirm }) => {
          if (!confirm) {
            setIsChequePrinted(false);
          }
        }}
      />
    </>
  );
};

export default SpoiledCheques;
