import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useHistory } from "react-router-dom";
import {
  ButtonColor,
  FormLabel,
  Button,
  ButtonSize,
  Grid,
  GridItem,
  IconColor,
  IconSize,
  Divider,
  TextInput,
  Icon,
  ValidationTextLevel,
  ISelectedItem,
  Notification,
  NotificationStatus
} from "@essnextgen/ui-kit";
import Layout from "@/components/Layout/Layout";
import Input from "@/components/Input/Input";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { Modalv2 } from "@/components/Modalv2/Modalv2";

import BankAccount from "@/shared/components/BankAccount/BankAccount";
import PostingPeriodModal from "@/shared/components/PostingPeriod/PostingPeriodModal";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { actions as bankActions } from "@/shared/components/BankAccount/state/BankAccount.slice";
import { chequeBooksColumnDef } from "./columnDef";
import { useAddChequeRun } from "./useAddChequeRun";

import "./Style.scss";

/* eslint-disable import/prefer-default-export */
const AddChequeRun = () => {
  const playmode = "essui-textinput essui-textinput--medium b-0 pl-0 playback";
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();

  const {
    bankAccounts,
    goToNext,
    cancelClicked,
    onBankAccountSelection,
    onBankAccountChange,
    getValues,
    setValue,
    register,
    errors,
    dispatch,
    isAlertModalOpen,
    setIsAlertModalOpen,
    message,
    showBankAccountModal,
    paymentPeriod,
    setShowBankAccountModal,
    onBankAccountSelectedRow,
    availableChequeBooks,
    tobeUsedChequeBooks,
    moveRecordsToRight,
    moveRecordsToLeft,
    availableChequeBookSelectedRowHandler,
    tobeUsedChequeBookSelectedRowHandler,
    availableChequeBookSelectedRow,
    tobeUsedChequeBookSelectedRow,
    showPostingPeriodModal,
    setShowPostingPeriodModal,
    onPostingPeriodSelectedRow,
    postingPeriodDetails,
    onPaymentPeriodSelection,
    onPaymentPeriodChange,
    onBankAccountNoSelection,
    onBankAccountBlur,
    onPaymentPeriodNoSelection,
    moveUp,
    moveDown,
    isDisabled,
    showEmptyChequeBookModal,
    setShowEmptyChequeBookModal,
    selectedBankAccount,
    onSelectRowDate,
    openKeepChangeModal,
    setOpenKeepChangeModal,
    validateNextChequeNumber
  } = useAddChequeRun();

  return (
    <>
      <Layout
        pageTitle={t("chequeProcessing.addChequeRun")}
        className="add-cheque-run"
        rightContent=""
        toolbar=""
        isBreadcrumbRequired
      >
        <Grid>
          <GridItem
            sm={12}
            md={3}
            xl={3}
          >
            <Input
              id="txtBankAccount"
              searchable
              searchItems={bankAccounts.map((s) => ({ text: s.ledger_des, value: s.ledger_des }))}
              onSelect={(selectedItem: ISelectedItem | undefined) => onBankAccountSelection(selectedItem)}
              labelText={t("chequeProcessing.selectBankAccount")}
              onNoSelection={onBankAccountNoSelection}
              value={getValues("bankAccount")}
              inputRef={(e) => register("bankAccount").ref(e)}
              name={register("bankAccount").name}
              onChange={onBankAccountChange}
              validationTextLevel={errors.bankAccount ? ValidationTextLevel.Error : undefined}
              onBlur={onBankAccountBlur}
              button={
                <>
                  <Button
                    color={ButtonColor.Secondary}
                    onClick={() => setShowBankAccountModal(true)}
                    size={ButtonSize.Small}
                    className="essui-button-icon-only--small"
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                </>
              }
            />
          </GridItem>
          <GridItem
            sm={12}
            md={2}
            xl={2}
          >
            <FormLabel>{t("chequeProcessing.accountNo")}</FormLabel>
            <div className={playmode}>{getValues("accountNo")}</div>
          </GridItem>
          <GridItem
            sm={12}
            md={2}
            xl={2}
          >
            <FormLabel>{t("chequeProcessing.sortCode")}</FormLabel>
            <div className={playmode}>{getValues("sortCode")}</div>
          </GridItem>
        </Grid>
        <Divider />
        <Grid className="mt-16">
          <GridItem>
            <FormLabel>
              <div className="essui-global-typography-default-h4">{t("chequeProcessing.selectChequeBookToPrint")}</div>
            </FormLabel>
          </GridItem>
        </Grid>
        <Grid className="mt-16">
          <GridItem lg={4}>
            <GridTableNew
              dataTestId="availableChequeBookGrid"
              filters={
                <div className="essui-global-typography-default-subtitle">
                  {t("chequeProcessing.availableChequeBook")}
                </div>
              }
              selectedRow={availableChequeBookSelectedRow}
              selectedRowHandler={availableChequeBookSelectedRowHandler}
              dataSource={availableChequeBooks}
              columnDef={chequeBooksColumnDef}
              isLoading={false}
              isScrollable
              enableScrollIntoView
            />
          </GridItem>
          <GridItem
            lg={1}
            className="select-cheque-btn"
          >
            <Button
              className="base-class table-btn"
              color={ButtonColor.Secondary}
              iconName="arrow--right"
              size={ButtonSize.Small}
              // disabled={!availableChequeBooks.length}
              onClick={moveRecordsToRight}
            />
            <Button
              className="base-class table-btn"
              color={ButtonColor.Secondary}
              iconName="arrow--left"
              size={ButtonSize.Small}
              // disabled={!tobeUsedChequeBooks.length}
              onClick={moveRecordsToLeft}
            />
          </GridItem>
          <GridItem
            lg={4}
            className="checkBookUsed"
          >
            <GridTableNew
              dataTestId="tobeUsedChequeBookGrid"
              filters={
                <div className="essui-global-typography-default-subtitle">
                  {t("chequeProcessing.selectChequeBookToBeUsed")}
                </div>
              }
              selectedRow={tobeUsedChequeBookSelectedRow}
              selectedRowHandler={tobeUsedChequeBookSelectedRowHandler}
              dataSource={tobeUsedChequeBooks}
              columnDef={chequeBooksColumnDef}
              isLoading={false}
              isScrollable
            />
            <FormLabel className="next-check-book-lbl">{t("chequeProcessing.nextChequeNo")}</FormLabel>
            <TextInput
              id="txtNextChequeNo"
              className="essui-textinput"
              value={getValues("nextChequeNumber")}
              onChange={(e) => {
                setValue("nextChequeNumber", e.target.value);
              }}
              inputRef={(e) => register("nextChequeNumber").ref(e)}
              name={
                register("nextChequeNumber", {
                  validate: (value) => {
                    if (
                      value < tobeUsedChequeBookSelectedRow?.next_no ||
                      value > tobeUsedChequeBookSelectedRow?.last_no
                    ) {
                      return false;
                    }
                    return true;
                  }
                }).name
              }
              onBlur={validateNextChequeNumber}
              maxLength={6}
              autoComplete={false}
              validationTextLevel={errors.nextChequeNumber ? ValidationTextLevel.Error : undefined}
            />
          </GridItem>
          <GridItem
            lg={1}
            className="select-cheque-btn"
          >
            <Button
              className="base-class table-btn"
              color={ButtonColor.Secondary}
              iconName="arrow--up"
              size={ButtonSize.Small}
              disabled={isDisabled}
              onClick={moveUp}
            />
            <Button
              className="base-class table-btn"
              color={ButtonColor.Secondary}
              iconName="arrow--down"
              size={ButtonSize.Small}
              disabled={isDisabled}
              onClick={moveDown}
            />
          </GridItem>
        </Grid>
        <Divider />
        <Grid className="mt-16">
          <GridItem
            sm={12}
            md={2}
            xl={2}
          >
            <Grid>
              <GridItem
                lg={12}
                className="add-cheque-run-period-field"
              >
                <Input
                  id="txtPaymentPeriod"
                  searchable
                  searchItems={postingPeriodDetails.map((p) => ({ text: p.code, value: p.description }))}
                  onSelect={(selectedItem: ISelectedItem | undefined) => onPaymentPeriodSelection(selectedItem)}
                  labelText={t("chequeProcessing.paymentPeriod")}
                  inputWidth={50}
                  onNoSelection={onPaymentPeriodNoSelection}
                  value={getValues("paymentPeriod")}
                  inputRef={(e) => register("paymentPeriod").ref(e)}
                  name={register("paymentPeriod").name}
                  onChange={onPaymentPeriodChange}
                  validationTextLevel={paymentPeriod ? ValidationTextLevel.Error : undefined}
                  button={
                    <>
                      <TextInput
                        id="txtPaymentDescription"
                        className="width55"
                        inputWidth={60}
                        value={getValues("paymentPeriod") === "" ? "" : getValues("paymentDescription")}
                        name={register("paymentDescription").name}
                        disabled
                      />
                      <Button
                        color={ButtonColor.Secondary}
                        onClick={() => setShowPostingPeriodModal(true)}
                        size={ButtonSize.Small}
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </>
                  }
                />
              </GridItem>
            </Grid>
          </GridItem>
          <GridItem
            sm={12}
            md={10}
            xl={10}
          >
            <FormLabel>{t("chequeProcessing.chequeRunNarrative")}</FormLabel>
            <TextInput
              id="txtNarrative"
              className="w-100"
              value={getValues("chequeRunNarrative")}
              inputRef={(e) => register("chequeRunNarrative").ref(e)}
              name={register("chequeRunNarrative").name}
              onChange={(e) => register("chequeRunNarrative").onChange(e)}
              maxLength={60}
              autoComplete={false}
            />
          </GridItem>
        </Grid>
        <Grid
          className="mt-16"
          justify="space-between"
        >
          <GridItem
            lg={10}
            // className="cheque-next-btn"
            className="cheque-next-btn grid-container-item save-cancel-button"
          >
            <div className="rightbtn">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
                className="button"
                disabled={!tobeUsedChequeBooks.length}
                onClick={goToNext}
                id="gotonext-btn-cheque"
              >
                {t("common.next")}
              </Button>
              {false && (
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="button"
                  onClick={cancelClicked}
                  id="cancel-btn-cheque"
                >
                  {t("common.cancel")}
                </Button>
              )}

              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                className="button"
                onClick={() => {}}
                disabled
                id="back-btn-cheque"
              >
                {t("common.back")}
              </Button>
            </div>
          </GridItem>

          <GridItem
            lg={2}
            className="grid-container-item"
          >
            <HelpButton
              identifier="help-btn-cheque-addchequerun"
              labelName={t("common.help")}
            />
          </GridItem>
          <Grid />
        </Grid>
      </Layout>
      <BankAccount
        isOpen={showBankAccountModal}
        setOpen={setShowBankAccountModal}
        onSelectedRow={onBankAccountSelectedRow}
      />
      <PostingPeriodModal
        isOpen={showPostingPeriodModal}
        setOpen={setShowPostingPeriodModal}
        selectedRow={onPostingPeriodSelectedRow}
        onSelectRowDate={onSelectRowDate}
      />
      <Modalv2
        header={t("alertMessage.title")}
        isOpen={showEmptyChequeBookModal}
        className="empty-cheque-book-popup"
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => setShowEmptyChequeBookModal(false)}
          >
            {t("common.ok")}
          </Button>
        }
      >
        <Notification
          actionElement={1}
          dataTestId="empty-cheque-book-warning"
          escapeExits
          id="empty-cheque-book-warning"
          hideCloseButton
          status={paymentPeriod ? NotificationStatus.HIGHLIGHT : NotificationStatus.ERROR}
          title={
            paymentPeriod ? t("supplierView.basicTab.basicPageValidationErrorMsg") : t("chequeProcessing.noChequeBook")
          }
          className="mb-18 confirm-modal-text"
        />
      </Modalv2>
      <AlertModal
        isOpen={isAlertModalOpen}
        setOpen={setIsAlertModalOpen}
        title={t("alertMessage.title")}
        notificationType={NotificationStatus.HIGHLIGHT}
        message={message}
      />
      <ConfirmModal
        className="modal-width"
        isOpen={openKeepChangeModal}
        setOpen={setOpenKeepChangeModal}
        title={t("alertMessage.title")}
        message={t("common.keepChangesMsg")}
        confirm={() => {}}
        callback={({ confirm }) => {
          if (!confirm) {
            dispatch(bankActions.selectBankAccountRow(undefined));
            history.push({
              pathname: "/accounts-payable/cheque-processing",
              state: {
                moveToListingPage: true
              }
            });
          }
        }}
      />
    </>
  );
};

export default AddChequeRun;
