import { TColumnDef } from "@/components/GridTable/GridTable";

/* eslint-disable import/prefer-default-export */
export const chequeBooksColumnDef: TColumnDef = [
  {
    headerName: "Start",
    field: "first_no",
    align: "left"
  },
  {
    headerName: "End",
    field: "last_no",
    align: "left"
  },
  {
    headerName: "Unused",
    field: "un_used",
    align: "left"
  }
];
