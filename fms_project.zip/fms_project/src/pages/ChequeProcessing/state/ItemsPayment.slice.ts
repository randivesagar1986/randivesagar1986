import { ISelectedItem } from "@essnextgen/ui-kit";
import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";

import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

import { STATUS } from "@/types/UseStateType";
import { Sequence } from "@/utils/constants";
import { findDifferencesByProperty } from "@/utils/getDataSource";
import { apiRoot, client } from "../../../config";
import { ChequeItemsForPaymentDef } from "../ItemsForPayment/Grid/ChequeItemsForPaymentDef";

export type TChequePaymentItems = {
  bankId: any;
  period: any;
  order: string;
  sundryType: string;
  bacsPayable: boolean;
  callback?: (response: any) => void;
};

export type TChequePaymentItemsPagination = {
  bankId: any;
  period: any;
  order: string;
  sundryType: string;
  bacsPayable: boolean;
  pageNumber: number;
  pageSize: number;
  callback?: (response: any) => void;
};

export type ChequePaymentItemsPaginationDataType = {
  data: [];
  highLightId?: number;
  highLightValue?: string;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;
};

type chequeProcessingState = {
  chequePaymentItem: { [key: string]: any }[];
  chequePaymentItemsPaginations: ChequePaymentItemsPaginationDataType;
  chequeBankDetails: number;
  checkedPaymentItems: { [key: string]: any }[];
  filterState: {
    sequence: string;
    showBACS: boolean;
    showSundry: string;
  };
  displayBacsPayable: boolean;
  displaySundryInvoicesOnly: boolean;
  // checkedRows: { [key: string]: any }[];
  unCheckedRows: { [key: string]: any }[];
  error: string | undefined;
  status?: STATUS;
  checkedRows: { [key: string]: any }[];
  selectedView: any;
  selectedCheckedView: number;
  currentBalance: number;
  taggedPaymentItems: Number[];
  columnDef: TColumnDef;
  chequePaymentItemsPaginationsStatus?: STATUS;
  chequePaymentItemsPaginationsError?: string | undefined;
};

export type ChequeProcessingPostTagData = {
  sundryInvoiceChecked: boolean;
  exclBACSSupplChecked: boolean;
  /* eslint-disable camelcase */
  supplierTag_TagAllChecked: boolean;
  supplierTag_SpecificChecked: boolean;
  supplierTag_Client_Id: string;
  supplierTag_Not_ClientChecked: boolean;
  amountTag_AllChecked: boolean;
  amountTag_GreaterChecked: boolean;
  amountTag_LessChecked: boolean;
  amount: number;
  payByTag_All_DateChecked: boolean;
  payByTag_Specific_DateChecked: boolean;
  payByTag_Not_DateChecked: boolean;
  payByTag_DateCode: string;
  payByTag_StartDateTag: string;
  payByTag_EndDateTag: string;
  bankId: number; // 53
  period: number; // 12
};

const initialState: chequeProcessingState = {
  chequePaymentItem: [],
  checkedPaymentItems: [],
  chequePaymentItemsPaginations: {
    data: [],
    currentPage: 1,
    totalPages: 1,
    pageSize: 5,
    totalCount: 0
  },
  taggedPaymentItems: [],
  filterState: {
    sequence: Sequence.SEQ,
    showBACS: true,
    showSundry: "F"
  },
  displayBacsPayable: true,
  displaySundryInvoicesOnly: true,
  checkedRows: [],
  unCheckedRows: [],
  selectedCheckedView: 0,
  chequeBankDetails: 0.0,
  selectedView: {
    text: "",
    value: ""
  },
  error: "",
  // checkedRows: [],
  currentBalance: 0,
  columnDef: ChequeItemsForPaymentDef
};

/** Thunks */

export const getTaggedSuppliers = createAsyncThunk(
  "Cheques/cheque-tag",
  async ({ reqData, callback }: { reqData: ChequeProcessingPostTagData; callback?: (data: any) => void }) => {
    const response = await client.post(`${apiRoot}/Cheques/cheque-tag`, {
      sundryInvoiceChecked: reqData.sundryInvoiceChecked,
      exclBACSSupplChecked: reqData.exclBACSSupplChecked,
      supplierTag_TagAllChecked: reqData.supplierTag_TagAllChecked,
      supplierTag_SpecificChecked: reqData.supplierTag_SpecificChecked,
      supplierTag_Client_Id: reqData.supplierTag_Client_Id,
      supplierTag_Not_ClientChecked: reqData.supplierTag_Not_ClientChecked,
      amountTag_AllChecked: reqData.amountTag_AllChecked,
      amountTag_GreaterChecked: reqData.amountTag_GreaterChecked,
      amountTag_LessChecked: reqData.amountTag_LessChecked,
      amount: reqData.amount,
      payByTag_All_DateChecked: reqData.payByTag_All_DateChecked,
      payByTag_Specific_DateChecked: reqData.payByTag_Specific_DateChecked,
      payByTag_Not_DateChecked: reqData.payByTag_Not_DateChecked,
      payByTag_DateCode: reqData.payByTag_DateCode,
      payByTag_StartDateTag: reqData.payByTag_StartDateTag,
      payByTag_EndDateTag: reqData.payByTag_EndDateTag,
      bankId: reqData.bankId,
      period: reqData.period
    });

    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getChequePaymentItems = createAsyncThunk(
  "Cheques/payment-items",
  async ({ bankId, period, order, sundryType, bacsPayable, callback }: TChequePaymentItems) => {
    const response = await client.post(`${apiRoot}/Cheques/payment-items`, {
      bankId,
      period,
      order,
      sundryType,
      bacsPayable
    });
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getChequePaymentItemsPagination = createAsyncThunk(
  "Cheques/payment-items-details",
  async ({
    bankId,
    period,
    order,
    sundryType,
    bacsPayable,
    pageNumber,
    pageSize,
    callback
  }: TChequePaymentItemsPagination) => {
    const response = await client.post(`${apiRoot}/Cheques/payment-items-details`, {
      pageNumber,
      pageSize,
      chequePaymentItemsQueryParams: {
        bankId,
        period,
        order,
        sundryType,
        bacsPayable
      }
    });
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getChequeGetDetails = createAsyncThunk("Cheques/get-details", async ({ bankId }: { bankId: string }) => {
  const response = await client.get(`${apiRoot}/Cheques/get-details`, {
    params: {
      bankId
    }
  });
  return response.data;
});

export const getChequeOptionsBrowse = createAsyncThunk("Cheques/cheque-options-browse", async () => {
  const response = await client.get(`${apiRoot}/Cheques/cheque-options-browse`);
  return response.data;
});

export const getChequeSundrySupplyStatus = createAsyncThunk("Cheques/cheque-sundry-supply-status", async () => {
  const response = await client.get(`${apiRoot}/Cheques/cheque-sundry-supply-status`);
  return response.data;
});

export const chequeOptionsUpdate = createAsyncThunk(
  "Cheques/cheque-options-update",
  async ({
    displayBacsPayable,
    displaySundryInvoicesOnly
  }: {
    displayBacsPayable: boolean;
    displaySundryInvoicesOnly: boolean;
  }) => {
    const response = await client.put(
      `${apiRoot}/Cheques/cheque-options-update?displayBacsPayable=${displayBacsPayable}&displaySundryInvoicesOnly=${displaySundryInvoicesOnly}`
    );
    return response.data;
  }
);

/**
 * # Cheque Processing Status Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    builder
      .addCase(getChequePaymentItems.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequePaymentItems.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequePaymentItem = action.payload;
        // eslint-disable-next-line
        state.status = STATUS.SUCCESS;
      })
      .addCase(getChequePaymentItems.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getChequePaymentItemsPagination.pending, (state) => {
        state.chequePaymentItemsPaginationsStatus = STATUS.LOADING;
        state.chequePaymentItemsPaginationsError = undefined;
      })
      .addCase(getChequePaymentItemsPagination.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequePaymentItemsPaginations = action.payload;
        state.chequePaymentItem = action.payload.data;
        state.chequePaymentItemsPaginationsStatus = STATUS.SUCCESS;
      })
      .addCase(getChequePaymentItemsPagination.rejected, (state) => {
        state.chequePaymentItemsPaginationsStatus = STATUS.FAILED;
      });
    builder
      .addCase(getChequeGetDetails.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeGetDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequeBankDetails = action.payload;
        state.currentBalance = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getChequeGetDetails.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getChequeOptionsBrowse.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeOptionsBrowse.fulfilled, (state, action: PayloadAction<any>) => {
        const response = action.payload;
        if (response) {
          state.filterState = {
            ...state.filterState,
            showBACS: response?.display_bacs_payable
          };
          state.displayBacsPayable = response?.display_bacs_payable;
        }
        state.status = STATUS.SUCCESS;
      })
      .addCase(getChequeOptionsBrowse.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getChequeSundrySupplyStatus.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeSundrySupplyStatus.fulfilled, (state, action: PayloadAction<any>) => {
        const response = action.payload;
        if (response) {
          state.filterState = {
            ...state.filterState
          };
          state.displaySundryInvoicesOnly = response?.sundry_invoice === "T";
        }
        state.status = STATUS.SUCCESS;
      })
      .addCase(getChequeSundrySupplyStatus.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  initialState,
  name: "chequePaymentItems",
  reducers: {
    setChequeProcessingView: (state, action: PayloadAction<any>) => {
      state.selectedView = action.payload;
    },
    updatePaymentItemsDataSourc: (state, action: PayloadAction<any>) => {
      state.chequePaymentItem = action.payload;
    },
    setFilters: (state, action: PayloadAction<any>) => {
      state.filterState = {
        ...state.filterState,
        ...action.payload
      };
    },
    handleCheckbox: (state, action: PayloadAction<any>) => {
      const rows = action.payload.val;
      if (rows.length) {
        state.selectedCheckedView = action.payload.val[0].amount;
        state.checkedPaymentItems = action.payload.val;
      }
      state.checkedRows = [...rows];
    },
    handleUncheckedRow: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const diff = findDifferencesByProperty(current(state.checkedRows), [...action.payload.row], "unique_id");
      state.unCheckedRows = [...current(state.unCheckedRows), ...diff];
    },
    setCheckedPaymentItems: (state, action: PayloadAction<any>) => {
      state.taggedPaymentItems = [...action.payload];
      const checkedRows = current(state.chequePaymentItem).filter((row) =>
        state.taggedPaymentItems?.includes(row.unique_id)
      );
      const combinedCheckedRows = [...current(state.checkedRows), ...checkedRows];
      const uniqueCheckedRows = Array.from(new Map(combinedCheckedRows.map((item) => [item.unique_id, item])).values());
      console.log("uniqueCheckedRows", uniqueCheckedRows);
      state.checkedRows = uniqueCheckedRows;
      state.checkedPaymentItems = uniqueCheckedRows;
    },
    clearCheckedInvoices: (state) => {
      state.taggedPaymentItems = [];
    },
    unCheckAll: (state) => {
      state.checkedRows = [];
    },
    clearUncheckedRows: (state) => {
      state.unCheckedRows = [];
    },
    checkFiltered: (state) => {
      if (state?.chequePaymentItem) {
        const checkedRows = state.chequePaymentItem.filter((row) =>
          current(state.taggedPaymentItems)?.includes(row.unique_id)
        );
        state.checkedRows = checkedRows;
      }
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setCheckedRows: (state, action: PayloadAction<any>) => {
      state.checkedRows = [...action.payload];
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
