import { createSlice, createAsyncThunk, PayloadAction, current, createAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { getDateInStringFormat } from "@/utils/constants";
import columnDef from "../ChequeProcessingList/Grid/columnDef";

export type ChequeProcessingListType = { [key: string]: any }[];

export type TCheques = {
  data: ChequeProcessingListType;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: string;
  lookingFor?: string | undefined;
  orderBy?: number;
  sequence?: number;
};

export type TfindCheque = {
  cheques: ChequeProcessingListType;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: string;
};

type TfindChecque = {
  chequeReferences: { [key: string]: any }[];
};
type TgetChequeDetail = {
  pageNumber?: string;
  pageSize?: string;
  view?: string;
  orderBy?: number;
  sequence?: number;
  status?: string;
  skip?: string;
  lookingFor?: string | undefined;
  highlightId?: number;
  sequenceValue?: string;
  applyFilterChange?: boolean;
};

type TChequePagination = {
  pageNumber?: number;
  pageSize?: number;
  lookingFor?: string | undefined;
  highLightedChequeNumber?: number;
};

type ChequeDetailStateType = {
  selectedRow?: { [key: string]: any };
  checkedRows: { [key: string]: any }[];
  columnDef: TColumnDef;
  filterState?: TgetChequeDetail;
  chequeList: TCheques;
  error: string | undefined;
  applyFilterChange?: boolean;
  status?: STATUS;
  searchStatus?: STATUS;
  pageStatus?: STATUS;
  isFocus?: boolean;
  isFindCheque?: boolean;
  chequereferenceList: TfindChecque;
  searchChequeList: TfindCheque;
  searchFilters: TChequePagination;
};

const initialState: ChequeDetailStateType = {
  chequereferenceList: {
    chequeReferences: []
  },
  selectedRow: undefined,
  checkedRows: [],
  filterState: {
    pageNumber: "1",
    pageSize: "10",
    orderBy: 1,
    sequence: 0,
    status: "A",
    skip: "",
    lookingFor: "",
    highlightId: 0,
    applyFilterChange: true,
    sequenceValue: columnDef.filter((col) => !!col.sequence)[0].field
  },
  searchFilters: {
    pageNumber: 1,
    pageSize: 5,
    lookingFor: "",
    highLightedChequeNumber: 0
  },
  isFindCheque: false,
  columnDef,
  chequeList: {
    data: [],
    currentPage: 1,
    totalCount: "",
    pageSize: 10,
    totalPages: 0,
    lookingFor: ""
  },
  searchChequeList: {
    cheques: [],
    currentPage: 1,
    pageSize: 5,
    totalPages: 0,
    totalCount: ""
  },
  error: "",
  isFocus: false
};

/** Thunks */
export const getChequeProcessingList = createAsyncThunk(
  "chequeProcessing/list",
  async (
    {
      pageSize,
      pageNumber,
      orderBy,
      sequence,
      status,
      skip,
      lookingFor,
      highlightId,
      callback
    }: TgetChequeDetail & { callback?: (response: any) => void },
    thunkAPI
  ) => {
    const { getState } = thunkAPI;
    const state: any = getState();
    const { filterState } = state.newChequeProcessingList;
    let newLookingFor = "";
    if (filterState?.sequenceValue === "run_date" && lookingFor !== "") {
      newLookingFor = getDateInStringFormat(new Date(lookingFor as string));
    } else {
      newLookingFor = lookingFor as string;
    }
    const response = await client.post(
      `${apiRoot}/Cheques?PageNumber=${pageNumber}&Skip=${skip}&PageSize=${pageSize}`,
      {
        orderBy: Number(orderBy),
        sequence,
        status,
        lookingFor: newLookingFor,
        paymentRunId: highlightId,
        pageNumber,
        pageSize
      }
    );
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const searchCheques = createAsyncThunk("cheques/search", async (term: string) => {
  const response = await client.get(`${apiRoot}/Cheques/FilterByCheque`);
  return response.data;
});

export const searchChequeNumber = createAsyncThunk(
  "cheques/searchChequeNumber",
  async (
    {
      pageNumber,
      pageSize,
      lookingFor,
      highLightedChequeNumber,
      callback
    }: TChequePagination & { callback?: (data: any, selectedRow?: any) => void },
    thunkAPI
  ) => {
    try {
      const { data }: { data: { [key: string]: any } } = await client.post(
        `${apiRoot}/Cheques/FilterByCheque-pagination`,
        {
          pageNumber,
          pageSize,
          lookingFor,
          highLightedChequeNumber: highLightedChequeNumber || undefined
        }
      );
      if (data) {
        const row = ((data?.cheques as { [key: string]: any }[]) || [])
          ?.filter((p) => p.cheque_number === data?.highLightValue)
          .at(0);
        if (callback) {
          callback(data, row);
        }
      }
      return data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

/**
 * # Cheque Processing Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  initialState,
  name: "newChequeProcessingList",
  extraReducers: (builder) => {
    /** Cheque Processing List */
    builder
      .addCase(getChequeProcessingList.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeProcessingList.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequeList = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getChequeProcessingList.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(searchChequeNumber.pending, (state) => {
        state.searchStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(searchChequeNumber.fulfilled, (state, action: PayloadAction<any>) => {
        state.searchChequeList = action.payload;
        state.searchStatus = STATUS.SUCCESS;
      })
      .addCase(searchChequeNumber.rejected, (state) => {
        state.searchStatus = STATUS.FAILED;
      });
  },
  reducers: {
    unCheckAll: (state) => {
      state.checkedRows = [];
    },
    checkAll: (state) => {
      const poList = current(state.chequeList?.data);
      state.checkedRows = [...poList];
    },
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedRow = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TgetChequeDetail>) => {
      state.filterState = {
        ...current(state.filterState),
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filterState = {
        ...initialState.filterState
      };
    },
    setSearchFilters: (state, action: PayloadAction<TChequePagination>) => {
      state.searchFilters = {
        ...current(state.searchFilters),
        ...action.payload
      };
    },
    resetSearchFilters: (state) => {
      state.searchFilters = {
        ...initialState.searchFilters
      };
    },
    setFocus: (state) => {
      state.isFocus = true;
    },
    resetFocus: (state) => {
      state.isFocus = false;
    },
    setFindChequeNumber: (state, action: PayloadAction<any>) => {
      state.isFindCheque = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
