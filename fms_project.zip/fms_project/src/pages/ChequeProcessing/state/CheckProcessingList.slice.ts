import { ISelectedItem } from "@essnextgen/ui-kit";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "../../../config";

const initialState: any = {
  chequePayments: [],
  chequePaymentDetails: [],
  selectedRow: null,
  error: "",
  firstTableStatus: STATUS,
  detailStatus: STATUS,
  cancelStatus: STATUS,
  cancelError: "",
  cancelChequePayment: undefined,
  confirmChequelStatus: STATUS,
  chequeNewRunPrintData: [],
  checkNewRunPrint: STATUS
};

export const getChequePrintDocument = createAsyncThunk(
  "Cheques/ChequesOrderDocument",
  async ({
    runNumber,
    runId,
    param1,
    period,
    uniqueId,
    odbcHandle
  }: {
    runNumber: string;
    runId: number;
    param1: string;
    period: string;
    uniqueId: string;
    odbcHandle: number;
  }) => {
    const response = await client.post(`${apiRoot}/document/cheque-run-print`, {
      runNumber,
      runId,
      param1,
      period,
      uniqueId,
      odbcHandle
    });
    return response.data;
  }
);

export const getChequeNewPrintDocument = createAsyncThunk(
  "Cheques/ChequesNewOrderDocument",
  async ({
    runNumber,
    runId,
    param1,
    period,
    uniqueId,
    odbcHandle,
    bankId,
    callback
  }: {
    runNumber: string;
    runId: number;
    param1: string;
    period: string;
    uniqueId: string;
    odbcHandle: number;
    bankId?: number;
    callback?: (data: any) => void;
  }) => {
    const response = await client.post(`${apiRoot}/document/cheque-run-new-print`, {
      runNumber,
      runId,
      param1,
      period,
      uniqueId,
      odbcHandle,
      bankId
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getChequePrintXml = createAsyncThunk(
  "document/cheque-run-new-print-xml",
  async ({
    runNumber,
    runId,
    param1,
    period,
    uniqueId,
    odbcHandle,
    bankId,
    callback
  }: {
    runNumber: string;
    runId: number;
    param1: string;
    period: string;
    uniqueId: string;
    odbcHandle: number;
    bankId?: number;
    callback?: (data: any) => void;
  }) => {
    const response = await client.post(`${apiRoot}/document/cheque-run-new-print-xml`, {
      runNumber,
      runId,
      param1,
      period,
      uniqueId,
      odbcHandle,
      bankId
    });
    const fileName = (response.headers["content-disposition"] as any)
      .split(";")
      .find((n: any) => n.includes("filename="))
      .replace("filename=", "")
      .trim()
      .replace(/['"]+/g, "");

    if (callback) {
      callback({ data: response.data, fileName });
    }
    return { data: response.data, fileName };
  }
);
export const getChequePrintCsv = createAsyncThunk(
  "document/cheque-run-new-print-csv",
  async ({
    runNumber,
    runId,
    param1,
    period,
    uniqueId,
    odbcHandle,
    bankId,
    callback
  }: {
    runNumber: string;
    runId: number;
    param1: string;
    period: string;
    uniqueId: string;
    odbcHandle: number;
    bankId?: number;
    callback?: (data: any) => void;
  }) => {
    const response = await client.post(`${apiRoot}/document/cheque-run-new-print-csv`, {
      runNumber,
      runId,
      param1,
      period,
      uniqueId,
      odbcHandle,
      bankId
    });
    const fileName = (response.headers["content-disposition"] as any)
      .split(";")
      .find((n: any) => n.includes("filename="))
      .replace("filename=", "")
      .trim()
      .replace(/['"]+/g, "");

    if (callback) {
      callback({ data: response.data, fileName });
    }
    return { data: response.data, fileName };
  }
);
/** Export document */
export const getZeroChequePrintDocument = createAsyncThunk(
  "Cheques/ChequesOrderDocument",
  async ({ paymentID, paymentRunID }: { paymentID: any; paymentRunID: any }) => {
    const response = await client.get(
      `${apiRoot}/document/cheque-zero-run-report?paymentId=${paymentID}&paymentRunId=${paymentRunID}`
    );
    return response.data;
  }
);

export const getChequeProcessingData = createAsyncThunk(
  "Cheques/Data",
  async ({ paymentRunId, callback }: { paymentRunId: any; callback?: (data: any) => void }, thunkAPI) => {
    const { dispatch } = thunkAPI;
    const response = await client.get(`${apiRoot}/Cheques/cheque-payment?paymentRunId=${paymentRunId}`);
    if (response.status === 200 && callback) {
      dispatch(actions.setSelectedRow((response.data as any)?.chequePayments?.at(0)));
      callback(response.data);
    }
    return response.data;
  }
);

export const getCancelChequeProcessing = createAsyncThunk(
  "Cheques/cancel",
  async ({ paymentId, reason, callback }: any) => {
    const response = await client.delete(`${apiRoot}/Cheques/cheque-cancel?paymentId=${paymentId}&reason=${reason}`);
    if (response.status === 200) {
      callback();
    }
    return response.data;
  }
);

export const getConfirmChequeRunZeroPayment = createAsyncThunk(
  "Cheques/ChequeRunZeroPayment",
  async ({ paymentRunId, callback }: any) => {
    const response = await client.get(`${apiRoot}/Cheques/zero-pay-confirm?paymentRunId=2631${paymentRunId}`);
    if (response.status === 200) {
      callback();
    }
    return response.data;
  }
);

export const getConfirmChequeRun = createAsyncThunk("Cheques/ChequeRun", async ({ paymentRunId, callback }: any) => {
  const response = await client.get(`${apiRoot}/Cheques/confirm-run?paymentRunId=${paymentRunId}`);
  if (response.status === 200) {
    callback();
  }
  return response.data;
});

export const getChequeZeroPDFConfirmRun = createAsyncThunk("Cheques/ZeroPDFData", async (paymentRunId: any) => {
  const response = await client.get(`${apiRoot}/Cheques/zero-pay-confirm?paymentRunId=${paymentRunId}`);
  return response.data;
});

export const getChequeProcessingDetailData = createAsyncThunk(
  "Cheques/DetailData",
  async ({ payemntId }: { payemntId: any }) => {
    const response = await client.get(`${apiRoot}/Cheques/cheque-payment-details?payemntId=${payemntId}`);
    return response.data;
  }
);

const slice = createSlice({
  extraReducers: (builder) => {
    builder
      .addCase(getChequeProcessingData.pending, (state) => {
        state.firstTableStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeProcessingData.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequePayments = action.payload.chequePayments;
        state.firstTableStatus = STATUS.SUCCESS;
      })
      .addCase(getChequeProcessingData.rejected, (state) => {
        state.firstTableStatus = STATUS.FAILED;
      });
    builder
      .addCase(getChequeProcessingDetailData.pending, (state) => {
        state.detailStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeProcessingDetailData.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequePaymentDetails = action.payload.chequePaymentDetails || [];
        state.detailStatus = STATUS.SUCCESS;
      })
      .addCase(getChequeProcessingDetailData.rejected, (state) => {
        state.detailStatus = STATUS.FAILED;
      });
    builder
      .addCase(getCancelChequeProcessing.pending, (state) => {
        state.cancelStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getCancelChequeProcessing.fulfilled, (state, action: PayloadAction<any>) => {
        state.cancelStatus = STATUS.SUCCESS;
      })
      .addCase(getCancelChequeProcessing.rejected, (state, action: PayloadAction<any>) => {
        state.cancelStatus = STATUS.FAILED;
        state.cancelError = action.payload?.error?.response?.data;
      });
    builder
      .addCase(getConfirmChequeRunZeroPayment.pending, (state) => {
        state.confirmChequelStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getConfirmChequeRunZeroPayment.fulfilled, (state, action: PayloadAction<any>) => {
        state.confirmChequelStatus = STATUS.SUCCESS;
      })
      .addCase(getConfirmChequeRunZeroPayment.rejected, (state, action: PayloadAction<any>) => {
        state.confirmChequelStatus = STATUS.FAILED;
        state.confirmChequelError = action.payload?.error?.response?.data;
      });
    builder
      .addCase(getConfirmChequeRun.pending, (state) => {
        state.confirmChequelStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getConfirmChequeRun.fulfilled, (state, action: PayloadAction<any>) => {
        state.confirmChequelStatus = STATUS.SUCCESS;
      })
      .addCase(getConfirmChequeRun.rejected, (state, action: PayloadAction<any>) => {
        state.confirmChequelStatus = STATUS.FAILED;
        state.confirmChequelError = action.payload?.error?.response?.data;
      });

    builder
      .addCase(getChequeNewPrintDocument.pending, (state) => {
        state.checkNewRunPrint = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeNewPrintDocument.fulfilled, (state, action: PayloadAction<any>) => {
        state.checkNewRunPrint = STATUS.SUCCESS;
        state.chequeNewRunPrintData = action?.payload;
      })
      .addCase(getChequeNewPrintDocument.rejected, (state, action: PayloadAction<any>) => {
        state.checkNewRunPrint = STATUS.FAILED;
      });
  },
  initialState,
  name: "chequeProcessingList",
  reducers: {
    setSelectedRow: (state, action: any) => {
      state.selectedRow = action.payload;
    },
    resetErrors: (state) => {
      state.cancelError = undefined;
    },
    setCancelChequePayment: (state, action: any) => {
      state.cancelChequePayment = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
