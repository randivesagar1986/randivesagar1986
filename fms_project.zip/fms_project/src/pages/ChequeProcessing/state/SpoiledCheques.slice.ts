import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";

export type TGetSpoiltDetailsParams = {
  paymentRunId: string | null;
  callback?: (response: any) => void;
};

export type TSpoiledChequesState = {
  error: string | undefined;
  chequePrintedStatus?: STATUS;
  printedChequesDetails: { [key: string]: any }[];
  spoiledChequesDetails: { [key: string]: any }[];
  printedChequesSelectedRow?: { [key: string]: any };
  spoiledChequesSelectedRow?: { [key: string]: any };
};

const initialState: TSpoiledChequesState = {
  error: "",
  printedChequesDetails: [],
  spoiledChequesDetails: []
};

/** Thunks */
export const getSpoiledChequesDetails = createAsyncThunk(
  "chequeProcessing/spoilt",
  async ({ paymentRunId, callback }: TGetSpoiltDetailsParams) => {
    const response = await client.get(`${apiRoot}/Cheques/spoilt?paymentRunId=${paymentRunId}`);
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const saveChequeSpoil = createAsyncThunk(
  "chequeProcessing/cheque-spoil",
  async ({ chequeSpoil, callback }: { chequeSpoil: { [key: string]: any }; callback?: any }) => {
    const response: any = await client.post(`${apiRoot}/Cheques/cheque-spoil`, chequeSpoil);
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

const slice = createSlice({
  initialState,
  name: "spoiledCheques",
  extraReducers: (builder) => {
    /** Cheque Processing List */
    builder
      .addCase(getSpoiledChequesDetails.pending, (state) => {
        state.chequePrintedStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getSpoiledChequesDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequePrintedStatus = STATUS.SUCCESS;
        state.printedChequesDetails = action.payload;
      })
      .addCase(getSpoiledChequesDetails.rejected, (state) => {
        state.chequePrintedStatus = STATUS.FAILED;
      });
  },
  reducers: {
    setPrintedChequesSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.printedChequesSelectedRow = action.payload;
    },
    setSpoiledChequesSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.spoiledChequesSelectedRow = action.payload;
    },
    resetPrintedChequesSelectedRow: (state) => {
      state.printedChequesSelectedRow = [];
    },
    resetSpoiledChequesSelectedRow: (state) => {
      state.spoiledChequesSelectedRow = [];
    },
    removeFromChequesPrinted: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const index = current(state.printedChequesDetails).findIndex(
        (row: { [key: string]: any }) => row.payment_id === action.payload.payment_id
      );
      if (index > -1) {
        state.printedChequesDetails.splice(index, 1);
        if (index < state.printedChequesDetails.length) {
          state.printedChequesSelectedRow = state.printedChequesDetails[index];
        } else if (state.printedChequesDetails.length > 0) {
          state.printedChequesSelectedRow = state.printedChequesDetails[state.printedChequesDetails.length - 1];
        } else {
          state.printedChequesSelectedRow = [];
        }
      }
    },
    removeFromChequesSpoiled: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const index = current(state.spoiledChequesDetails).findIndex(
        (row: { [key: string]: any }) => row.payment_id === action.payload.payment_id
      );
      if (index > -1) {
        state.spoiledChequesDetails.splice(index, 1);
        if (index < state.spoiledChequesDetails.length) {
          state.spoiledChequesSelectedRow = state.spoiledChequesDetails[index];
        } else if (state.spoiledChequesDetails.length > 0) {
          state.spoiledChequesSelectedRow = state.spoiledChequesDetails[state.spoiledChequesDetails.length - 1];
        } else {
          state.spoiledChequesSelectedRow = [];
        }
      }
    },
    setSpoiledCheques: (state, action: PayloadAction<{ [key: string]: any }>) => {
      state.spoiledChequesDetails.push(action.payload);
      state.spoiledChequesSelectedRow = action.payload;
    },
    setChequesPrinted: (state, action: PayloadAction<{ [key: string]: any }>) => {
      state.printedChequesDetails.push(action.payload);
      state.printedChequesSelectedRow = action.payload;
    },
    setAllChequesSpoiled: (state, action: PayloadAction<{ [key: string]: any }[]>) => {
      state.spoiledChequesDetails = [...state.spoiledChequesDetails, ...action.payload];
    },
    setAllChequesPrinted: (state, action: PayloadAction<{ [key: string]: any }[]>) => {
      state.printedChequesDetails = [...state.printedChequesDetails, ...action.payload];
    },
    selectedLastRecordForSpoiled: (state) => {
      const totalLength = state.spoiledChequesDetails.length;
      state.spoiledChequesSelectedRow = totalLength ? state.spoiledChequesDetails.at(totalLength - 1) : undefined;
    },
    selectedLastRecordForPrinted: (state) => {
      const totalLength = state.printedChequesDetails.length;
      state.printedChequesSelectedRow = totalLength ? state.printedChequesDetails.at(totalLength - 1) : undefined;
    },
    resetPrintedCheques: (state) => {
      state.printedChequesDetails = [];
    },
    resetSpoiledCheques: (state) => {
      state.spoiledChequesDetails = [];
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
