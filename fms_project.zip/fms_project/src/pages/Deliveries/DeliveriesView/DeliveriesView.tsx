import Input from "@/components/Input/Input";
import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  Orientation,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableUtility,
  TableWrapper,
  TextInput
} from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";

const DeliveriesView = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <>
      <Layout
        className="deliveries-view"
        pageTitle="View Deliveries"
      >
        <Grid
          container
          className="marginb15"
        >
          <GridItem
            sm={12}
            md={3}
            lg={3}
            xl={3}
            className="supplier-section"
          >
            <div>
              <FormLabel>Supplier</FormLabel>
              <Input
                className="readonly-input-box"
                button={
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    className="essui-button-icon-only--small"
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                }
                searchable
                value="British Gas"
              />
              <div>
                <div className="essui-global-typography-default-body">
                  Tower Point <br />
                  Enfield
                  <br />
                  London
                </div>
              </div>
            </div>
          </GridItem>

          <Divider orientation={Orientation.VERTICAL} />

          <GridItem
            sm={12}
            md={9}
            lg={9}
            xl={9}
          >
            <Grid container>
              <GridItem
                sm={12}
                md={4}
                lg={4}
                xl={4}
              >
                <div>
                  <FormLabel>Delivery Date</FormLabel>
                  <Input
                    button={
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="calendar"
                        />
                      </Button>
                    }
                    searchable
                    value="20/04/2024"
                  />
                  <div>
                    <div>
                      <FormLabel>Delivery Note Number</FormLabel>
                      <TextInput
                        className="width100"
                        value="123"
                      />
                    </div>
                  </div>
                </div>
              </GridItem>
              <GridItem
                sm={12}
                md={4}
                lg={4}
                xl={4}
              >
                <div>
                  <FormLabel>Delivery Note Date</FormLabel>
                  <Input
                    button={
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="calendar"
                        />
                      </Button>
                    }
                    searchable
                    value="20/04/2024"
                  />
                  <div>
                    <div>
                      <FormLabel>Order Number</FormLabel>
                      <Input
                        className="disable-input-box"
                        disabled
                        button={
                          <Button
                            className="essui-button-icon-only--small"
                            size={ButtonSize.Small}
                            color={ButtonColor.Secondary}
                            disabled
                          >
                            <Icon
                              color={IconColor.Neutral200}
                              size={IconSize.Medium}
                              name="search"
                            />
                          </Button>
                        }
                        searchable
                        value="BANK012116"
                      />
                    </div>
                  </div>
                </div>
              </GridItem>
              <GridItem
                sm={12}
                md={4}
                lg={4}
                xl={4}
              >
                <div>
                  <FormLabel>Delevery Note ID</FormLabel>
                  <TextInput
                    className="playmodetxt"
                    dataTestId="txtName"
                    value="000000003"
                  />
                </div>
              </GridItem>
              <GridItem
                sm={12}
                md={12}
                lg={12}
                xl={12}
              >
                <div>
                  <FormLabel>Invoice Notes</FormLabel>
                  <Input
                    className="readonly-input-box"
                    button={
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="edit--alt"
                        />
                      </Button>
                    }
                    searchable
                    value="Test Note"
                  />
                </div>
              </GridItem>
            </Grid>
          </GridItem>
        </Grid>
      </Layout>
      <section className="layout mt-8 pb-8">
        <div className="wrapper padding-0">
          <TableWrapper>
            <TableUtility>
              <CheckBox
                dataTestId="test-id"
                id="element-id-1"
                label={t("deliveries.hidefullydelivereditems")}
                // onChange={function noRefCheck(){}}
                value="1"
              />
            </TableUtility>
            <Table
              dataTestId="test-id"
              id="element-id"
            >
              <TableHead>
                <TableRow>
                  <TableCell header>Part Number</TableCell>
                  <TableCell header>Item Description</TableCell>
                  <TableCell header>Quantity Ordered</TableCell>

                  <TableCell header>Quantity Outstanding</TableCell>
                  <TableCell header>Quantity Delivered</TableCell>
                  <TableCell header />
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell>001</TableCell>
                  <TableCell>Test Description</TableCell>
                  <TableCell>250</TableCell>

                  <TableCell>50</TableCell>
                  <TableCell>20</TableCell>
                  <TableCell>
                    <div>
                      {" "}
                      <Button
                        className="m-auto grid-actions__button m-auto"
                        size={ButtonSize.Small}
                        color={ButtonColor.Utility}
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="overflow-menu--horizontal"
                        />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableWrapper>
        </div>
      </section>
    </>
  );
};
export default DeliveriesView;
