import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  FormLabel,
  Grid,
  GridItem,
  TextInput
} from "@essnextgen/ui-kit";

const EditDeliveryLineDetails = () => (
  <>
    <Layout pageTitle="Delivery Line Details">
      <Button
      // onClick={function noRefCheck(){}}
      >
        View Current Line
      </Button>
      <Dialog
        dataTestId="test-id"
        escapeExits
        id="element-id"
        // onClose={function noRefCheck(){}}
        returnFocusOnDeactivate
        title="Delivery Line Details"
      >
        <DialogContent>
          <Grid
            container
            className="marginb15"
          >
            <GridItem
              sm={12}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <FormLabel>Part Number</FormLabel>
                <TextInput
                  className="playmodetxt readonly-border-none"
                  dataTestId="txtName"
                  value="001"
                  readOnly
                />
              </div>
            </GridItem>
            <GridItem
              sm={12}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <FormLabel>Item Description</FormLabel>
                <TextInput
                  className="playmodetxt readonly-border-none"
                  dataTestId="txtName"
                  value="Test Description"
                  readOnly
                />
              </div>
            </GridItem>
          </Grid>
          <Grid
            container
            className="marginb15"
          >
            <GridItem
              sm={12}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <FormLabel>Quantity Ordered</FormLabel>
                <TextInput
                  className="playmodetxt readonly-border-none"
                  dataTestId="txtName"
                  value="250"
                  readOnly
                />
              </div>
            </GridItem>
            <GridItem
              sm={12}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <FormLabel>Quantity Outstanding</FormLabel>
                <TextInput
                  className="playmodetxt readonly-border-none"
                  dataTestId="txtName"
                  value="50"
                  readOnly
                />
              </div>
            </GridItem>
          </Grid>
          <Grid
            container
            className="marginb15"
          >
            <GridItem
              sm={12}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <FormLabel>Quantity Delivered</FormLabel>
                <TextInput
                  // className="playmodetxt"
                  dataTestId="txtName"
                  value="200"
                />
              </div>
            </GridItem>
          </Grid>
        </DialogContent>
        <DialogFooter>
          <Grid container>
            <GridItem
              sm={3}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Tertiary}
                >
                  Help
                </Button>
              </div>
            </GridItem>
            <GridItem
              sm={5}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="rightbtn">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Primary}
                >
                  Save
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                >
                  Cancel
                </Button>
              </div>
            </GridItem>
          </Grid>
        </DialogFooter>
      </Dialog>
    </Layout>
  </>
);
export default EditDeliveryLineDetails;
