import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import useDebounce from "@/hooks/useDebounce";
import findNearest from "@/utils/nearestSearch";
import { actions } from "../FundCode.slice";
import FundCodeModalFilters from "../FundCodeModalFilters";

jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("../FundCode.slice", () => ({
  actions: {
    setFilters: jest.fn()
  },
  getFundCodes: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("@essnextgen/ui-kit", () => ({
  FormLabel: jest.fn((props: any) => <div id="label">{props?.children}</div>),
  Grid: jest.fn((props: any) => <div>{props?.children}</div>),
  GridItem: jest.fn((props: any) => <div>{props?.children}</div>),
  TextInput: jest.fn((props: any) => (
    <input
      {...props}
      type="text"
    />
  )),
  TextInputSize: {
    Medium: "medium"
  }
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("@/hooks/useDebounce", () => jest.fn());
jest.mock("@/utils/nearestSearch", () => jest.fn());

describe("FundCodeModalFilters Component", () => {
  const mockDispatch = jest.fn();
  const mockSelectFundCode = jest.fn();

  const defaultProps = {
    selectFundCode: mockSelectFundCode
  };

  const mockState = {
    fundCode: {
      fundCodes: [],
      filters: {
        lookingFor: ""
      }
    }
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useDebounce as jest.Mock).mockReturnValue("");
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<FundCodeModalFilters {...defaultProps} />);
    screen.debug();
    expect(screen.getByText("common.lookingFor")).toBeInTheDocument();
    expect(screen.getByRole("textbox")).toBeInTheDocument();
  });

  it("should call dispatch with setFilters action when input value changes", () => {
    render(<FundCodeModalFilters {...defaultProps} />);
    fireEvent.change(screen.getByRole("textbox"), { target: { value: "test" } });
    expect(mockDispatch).toHaveBeenCalledWith(actions.setFilters({ lookingFor: "TEST" }));
  });

  it("should call selectFundCode and scroll into view when debouncedValue matches a fund code", () => {
    const mockFundCodes = [{ fund_code: "TEST1" }, { fund_code: "TEST2" }];
    (useAppSelector as jest.Mock).mockImplementation((selector) =>
      selector({
        fundCode: {
          fundCodes: mockFundCodes,
          filters: {
            lookingFor: "TEST"
          }
        }
      })
    );
    (useDebounce as jest.Mock).mockReturnValue("TEST");

    render(<FundCodeModalFilters {...defaultProps} />);
    expect(mockSelectFundCode).toHaveBeenCalledWith(mockFundCodes[0]);
  });
});
