import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import FundCodeModal from "../FundCodeModal";
import { useAppSelector } from "../../../../store/store";
import { actions } from "../FundCode.slice";

jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@essnextgen/ui-kit", () => ({
  Button: jest.fn((props: any) => (
    <button
      type="button"
      onClick={props?.onClick}
    >
      {props?.children}
    </button>
  )),
  ButtonColor: {
    Secondary: "secondary"
  },
  ButtonSize: {
    Small: "small"
  }
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("../../../../store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("@/components/Modalv2/Modalv2", () => ({
  Modalv2: jest.fn((props: any) => (
    <>
      <div {...props}>
        <h1>{props?.header && props?.header}</h1>
        {props?.children && props?.children?.props?.filters[0]}
        {props?.children && props?.children}
        <div>
          {props?.primaryButton}
          {props?.secondaryButton}
          {props?.tertiaryButton}
        </div>
      </div>
    </>
  ))
}));

jest.mock("@/components/GridTableNew/GridTableNew", () =>
  jest.fn((props) => (
    <>
      <div
        {...props}
        onKeyDown={(e: any) => props?.onEnterKeyPress(e)}
      >
        GridTableNew
      </div>
    </>
  ))
);

jest.mock("../FundCodeModalFilters", () =>
  jest.fn((props) => (
    <>
      <div>FundCodeModalFilters</div>
    </>
  ))
);

describe("FundCodeModal Component", () => {
  const mockDispatch = jest.fn();
  const mockSetOpen = jest.fn();

  const defaultProps = {
    setOpen: mockSetOpen,
    isOpen: true
  };

  const mockState = {
    fundCode: {
      status: "IDLE",
      fundCodes: [],
      columnDef: [],
      filters: {},
      selectedfundCode: null
    }
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<FundCodeModal {...defaultProps} />);
    expect(screen.getByText("purchaseOrder.fundBrowse")).toBeInTheDocument();
    expect(screen.getByText("common.select")).toBeInTheDocument();
    expect(screen.getByText("common.cancel")).toBeInTheDocument();
    expect(screen.getByText("common.help")).toBeInTheDocument();
  });

  it("should call setOpen with false when the cancel button is clicked", () => {
    render(<FundCodeModal {...defaultProps} />);
    fireEvent.click(screen.getByText("common.cancel"));
    expect(mockSetOpen).toHaveBeenCalledWith(false);
  });

  it("should call dispatch with selectRow action when the select button is clicked", () => {
    render(<FundCodeModal {...defaultProps} />);
    fireEvent.click(screen.getByText("common.select"));
    expect(mockDispatch).toHaveBeenCalledWith(actions.selectRow(undefined));
    expect(mockSetOpen).toHaveBeenCalledWith(false);
  });

  it("should call dispatch with resetFilters and getFundCodes actions when isOpen is true", () => {
    render(<FundCodeModal {...defaultProps} />);
    expect(mockDispatch).toHaveBeenCalledWith(actions.resetFilters());
    expect(mockDispatch).toHaveBeenCalledWith(expect.any(Function));
  });

  it("should call setOpen with false and dispatch selectRow action when Enter key is pressed", () => {
    render(<FundCodeModal {...defaultProps} />);
    fireEvent.keyDown(screen.getByText("GridTableNew"), { key: "Enter" });
    expect(mockDispatch).toHaveBeenCalledWith(actions.selectRow(undefined));
  });
});
