import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import findNearest from "@/utils/nearestSearch";
import useDebounce from "@/hooks/useDebounce";
import { FormLabel, Grid, GridItem, TextInput, TextInputSize } from "@essnextgen/ui-kit";
import { actions } from "./FundCode.slice";

interface FundCodeModalFiltersProps {
  selectFundCode: React.Dispatch<React.SetStateAction<{ [key: string]: any } | undefined>>;
}

const FundCodeModalFilters: React.FC<FundCodeModalFiltersProps> = ({ selectFundCode }) => {
  const { t } = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const { fundCodes, filters } = useAppSelector((state) => state.fundCode);
  const debouncedValue = useDebounce(filters?.lookingFor!, 600);

  useEffect(() => {
    if (debouncedValue && fundCodes.length) {
      let found =
        fundCodes.filter((element) => element.fund_code.toString().toUpperCase().startsWith(debouncedValue)).at(0) ??
        null;
      if (!found) {
        found = findNearest(
          [
            ...fundCodes.map((c) => {
              if (c.fund_code === null) {
                c.fund_code = "";
              }
              return c;
            })
          ],
          [{ fieldName: "fund_code", searchValue: debouncedValue }],
          true
        );
      }

      if (found) {
        selectFundCode(found);
        const element = document.getElementById(`rowIndex-fundCodesModal-${fundCodes.indexOf(found)}`);
        element?.scrollIntoView({ block: "center", behavior: "smooth" });
      }
    }
  }, [debouncedValue, fundCodes, selectFundCode]);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    dispatch(actions.setFilters({ lookingFor: e.target.value.toString().toUpperCase() }));
  };

  return (
    <Grid align="center">
      <GridItem xl={2}>
        <FormLabel forId="looking-for">{t("common.lookingFor")}</FormLabel>
        <TextInput
          id="looking-for"
          value={filters?.lookingFor}
          onChange={handleLookingForChange}
          size={TextInputSize.Medium}
          inputWidth={200}
        />
      </GridItem>
    </Grid>
  );
};

export default FundCodeModalFilters;
