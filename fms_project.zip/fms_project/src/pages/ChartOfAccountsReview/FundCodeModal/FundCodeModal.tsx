import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import GridTableNew, { RowType } from "@/components/GridTableNew/GridTableNew";
import { getCurrentFinancialYear } from "@/types/UseStateType";
import { AppDispatch, useAppSelector } from "../../../store/store";
import { getFundCodes, actions } from "./FundCode.slice";
import FundCodeModalFilters from "./FundCodeModalFilters";

interface FundCodeModalProps {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
}

const FundCodeModal: React.FC<FundCodeModalProps> = ({ setOpen, isOpen }) => {
  const { t } = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const [selectedRow, setSelectedRow] = useState<{ [key: string]: any } | undefined>();
  const { status, fundCodes, columnDef, filters, selectedfundCode } = useAppSelector((state) => state.fundCode);

  useEffect(() => {
    if (isOpen) {
      dispatch(actions.resetFilters());
      dispatch(getFundCodes({ financialYear: getCurrentFinancialYear() }));
    }
  }, [isOpen, dispatch]);

  const closeHandler = () => {
    setOpen(false);
    setSelectedRow(undefined);
  };

  const primaryButton = (
    <Button
      size={ButtonSize.Small}
      onClick={() => {
        dispatch(actions.selectRow(selectedRow));
        setOpen(false);
      }}
    >
      {t("common.select")}
    </Button>
  );

  const secondaryButton = (
    <Button
      size={ButtonSize.Small}
      color={ButtonColor.Secondary}
      onClick={closeHandler}
    >
      {t("common.cancel")}
    </Button>
  );

  const tertiaryButton = (
    <HelpButton
      identifier="testIdentifier"
      labelName={t("common.help")}
    />
  );

  return (
    <Modalv2
      header={t("purchaseOrder.fundBrowse")}
      isOpen={isOpen}
      primaryButton={primaryButton}
      secondaryButton={secondaryButton}
      tertiaryButton={tertiaryButton}
      onClose={closeHandler}
      className="set__table--hegiht"
      escapeExits
    >
      <GridTableNew
        dataTestId="fundCodesModal"
        id="fundCodesModal"
        filters={<FundCodeModalFilters selectFundCode={setSelectedRow} />}
        isScrollable
        enableScrollIntoView
        dataSource={fundCodes || []}
        selectedRow={selectedRow}
        isLoading={status === "LOADING"}
        columnDef={columnDef}
        selectedRowHandler={(row?: RowType | undefined) => {
          setSelectedRow(row);
        }}
        onEnterKeyPress={() => {
          setOpen(false);
          dispatch(actions.selectRow(selectedRow));
        }}
      />
    </Modalv2>
  );
};

export default FundCodeModal;
