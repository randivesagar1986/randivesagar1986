import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { client, apiRoot } from "@/config";
import { STATUS, getCurrentFinancialYear } from "@/types/UseStateType";
import { RowType, TColumnDef } from "@/components/GridTableNew/GridTableNew";
import columnDef from "../SidePanels/SelectPeriod/Grid/ColumnDef";

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
  pageNumber?: number;
  pageSize?: string;
  currentPage?: number;
  totalPages?: number;
};

export type TranDetailsType = {
  [key: string]: any;
}[];
export type TransactionDetailsType = {
  tranDetails: TranDetailsType;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: string;
};

type intialStateType = {
  periods: RowType[];
  error?: string;
  status?: STATUS;
  transactionDetails: TransactionDetailsType;
  selectedTransactionRow?: { [key: string]: any };
  transactionStatus?: STATUS;
  selectedPeriodFrom?: RowType;
  selectedPeriodTo?: RowType;
  columnDef: TColumnDef;
  filters?: TFilters;
  journalId?: number;
};

const initialState: intialStateType = {
  columnDef,
  transactionDetails: {
    tranDetails: [],
    currentPage: 1,
    totalPages: 0,
    pageSize: 10,
    totalCount: ""
  },
  periods: [],
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: undefined,
    pageNumber: 10,
    pageSize: "",
    currentPage: 1,
    totalPages: 10
  }
};

/** Thunks */
export const getFinancialPeriods = createAsyncThunk(
  "financialPeriod/get",
  async ({ status, callback }: { status: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/gl-acct-review/financial-period-from-to`, {
      params: { sequence: status, yearId: getCurrentFinancialYear() }
    });

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getTransactions = createAsyncThunk(
  "financialPeriod/getTransactions",
  async ({
    fromPeriodNo,
    toPeriodNo,
    costId,
    leddefId,
    fundId,
    PageNumber,
    PageSize,
    callback
  }: {
    fromPeriodNo?: string;
    toPeriodNo?: string;
    costId: number;
    leddefId: number;
    fundId: number;
    PageNumber: number;
    PageSize: number;
    callback?: (data?: any) => void;
  }) => {
    const response = await client.get(`${apiRoot}/gl-acct-review/acct-review-tran-lines-pagination`, {
      params: {
        PageNumber,
        PageSize,
        fromPeriodNo,
        toPeriodNo,
        costId,
        leddefId,
        fundId,
        yearId: getCurrentFinancialYear()
      }
    });

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * # Financial Perios Slice
 * This slice of state is responsible for storing purchase order details state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** getFinancialPeriods API cases */
    builder
      .addCase(getFinancialPeriods.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getFinancialPeriods.fulfilled, (state, action: PayloadAction<any>) => {
        state.periods = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getFinancialPeriods.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
    /** getTransactions API cases */
    builder
      .addCase(getTransactions.pending, (state) => {
        state.transactionStatus = STATUS.LOADING;
      })
      .addCase(getTransactions.fulfilled, (state, action: PayloadAction<any>) => {
        state.transactionDetails = action.payload;
        state.transactionStatus = STATUS.SUCCESS;
      })
      .addCase(getTransactions.rejected, (state, action: PayloadAction<any>) => {
        state.transactionStatus = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },
  initialState,
  name: "financialPeriods",
  reducers: {
    selectFrom: (state, action: PayloadAction<any>) => {
      state.selectedPeriodFrom = action.payload;
    },
    selectTo: (state, action: PayloadAction<any>) => {
      state.selectedPeriodTo = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (columnDef || [])?.filter((col) => !!col.sequence)?.at(0)?.field
      };
    },
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedTransactionRow = action.payload;
      state.journalId = action?.payload?.journal_id;
    },
    resetSelectedRow: (state) => {
      state.selectedTransactionRow = undefined;
    }
  }
});

export const { actions: financialPeriodActions, reducer } = slice;
export default reducer;
