import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { STATUS, getCurrentFinancialYear } from "@/types/UseStateType";
import { RootState } from "@/store/store";

type TacctReview = {
  costId?: number;
  leddefId?: number;
  fundId?: number;
  costValue?: string;
  leddefValue?: string;
  fundValue?: string;
  showAllPreYrMovement?: boolean;
  budget: number;
  commitment: any;
  invoiced: any;
  actual: any;
  total: number;
  remaining: any;
  yearId?: number;
};

type AcctReportType = {
  filterState?: TacctReview;
  selectedRow?: { [key: string]: any };
  costCentreBrowseStatus?: STATUS;
  pageStatus?: STATUS;
  viewStatus?: STATUS;
  pdfStatus?: STATUS;
  pdfData: string;
};

const initialState: AcctReportType = {
  filterState: {
    costId: 0,
    leddefId: 0,
    fundId: 0,
    costValue: "",
    leddefValue: "",
    fundValue: "",
    yearId: parseInt(getCurrentFinancialYear(), 10),
    showAllPreYrMovement: false,
    budget: 0,
    commitment: 0.0,
    invoiced: 0.0,
    actual: 0.0,
    total: 0,
    remaining: 0.0
  },
  pdfData: ""
};

/** Thunks */

export const acctReportPreviewPDF = createAsyncThunk(
  "document/acct-preview-pdf",
  async (
    {
      costId,
      leddefId,
      fundId,
      costValue,
      leddefValue,
      fundValue,
      yearId,
      showAllPreYrMovement,
      budget,
      commitment,
      invoiced,
      actual,
      total,
      remaining,
      callback
    }: TacctReview & { callback?: (data: any) => void },
    thunkAPI
  ) => {
    const { restrictedMenu } = thunkAPI.getState() as RootState;
    try {
      const response = await client.post(
        `${apiRoot}/document/acct-review-print-pdf`,
        {
          costId,
          leddefId,
          fundId,
          costValue,
          leddefValue,
          fundValue,
          yearId,
          showAllPreYrMovement,
          budget,
          commitment,
          invoiced,
          actual,
          total,
          remaining,
          restrictedUser: restrictedMenu?.restrictedUser?.restricted_user === "T"
        },
        { responseType: "blob" }
      );
      if (callback) {
        callback(response.data);
      }
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");
      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const acctReportPreviewXML = createAsyncThunk(
  "document/acct-report-preview-xml",
  async (
    {
      costId,
      leddefId,
      fundId,
      costValue,
      leddefValue,
      fundValue,
      yearId,
      showAllPreYrMovement,
      budget,
      commitment,
      invoiced,
      actual,
      total,
      remaining,
      callback
    }: TacctReview & { callback?: (data: any) => void },
    thunkAPI
  ) => {
    const { restrictedMenu } = thunkAPI.getState() as RootState;

    try {
      const response = await client.post(`${apiRoot}/document/acct-review-print-xml`, {
        costId,
        leddefId,
        fundId,
        costValue,
        leddefValue,
        fundValue,
        yearId,
        showAllPreYrMovement,
        budget,
        commitment,
        invoiced,
        actual,
        total,
        remaining,
        restrictedUser: restrictedMenu?.restrictedUser?.restricted_user === "T"
      });
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");

      if (callback) {
        callback(response.data);
      }

      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const acctReportPreviewCSV = createAsyncThunk(
  "document/acct-report-preview-csv",
  async (
    {
      costId,
      leddefId,
      fundId,
      costValue,
      leddefValue,
      fundValue,
      yearId,
      showAllPreYrMovement,
      budget,
      commitment,
      invoiced,
      actual,
      total,
      remaining,
      callback
    }: TacctReview & { callback?: (data: any) => void },
    thunkAPI
  ) => {
    const { restrictedMenu } = thunkAPI.getState() as RootState;
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-print-csv`, {
        costId,
        leddefId,
        fundId,
        costValue,
        leddefValue,
        fundValue,
        yearId,
        showAllPreYrMovement,
        budget,
        commitment,
        invoiced,
        actual,
        total,
        remaining,
        restrictedUser: restrictedMenu?.restrictedUser?.restricted_user === "T"
      });
      if (callback) {
        callback(response.data);
      }
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");

      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

/**
 * This slice of state is responsible for storing BRC details state
 */
const slice = createSlice({
  initialState,
  name: "chartOfAccountReportPreview",
  extraReducers(builder) {
    builder
      .addCase(acctReportPreviewPDF.pending, (state) => {
        state.pdfStatus = STATUS.LOADING;
      })
      .addCase(acctReportPreviewPDF.fulfilled, (state, action: PayloadAction<any>) => {
        state.pdfStatus = STATUS.SUCCESS;
        state.pdfData = action.payload;
      })
      .addCase(acctReportPreviewPDF.rejected, (state, action: PayloadAction<any>) => {
        state.pdfStatus = STATUS.FAILED;
      });
  },
  reducers: {}
});

export const { actions, reducer } = slice;
export default reducer;
