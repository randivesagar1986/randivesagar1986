import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { client, apiRoot } from "@/config";
import { STATUS } from "@/types/UseStateType";
import { RowType, TColumnDef } from "@/components/GridTableNew/GridTableNew";
import LedgerTypesColumnDef from "../LedgerBrowse/LedgerTypeModal/Grid/LedgerTypesColumnDef";

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};
type intialStateType = {
  ledgerTypes: RowType[];
  filters?: TFilters;
  error?: string;
  status?: STATUS;
  columnDef: TColumnDef;
  selectedLedgerType?: RowType;
};

const initialState: intialStateType = {
  columnDef: LedgerTypesColumnDef,
  ledgerTypes: [],
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: LedgerTypesColumnDef.filter((col) => !!col.sequence)?.at(0)?.field
  }
};

/** Thunks */
export const getLedgerTypes = createAsyncThunk(
  "ledgerTypes/get",
  async ({ costId, sequence, callback }: { costId?: string; sequence: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/gl-acct-review/acct-review-ledger-types`, {
      params: { sequence, costId }
    });

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * # Ledger Types Slice
 * This slice of state is responsible for storing ledger types list of details
 */
const slice = createSlice({
  extraReducers: (builder) => {
    builder
      .addCase(getLedgerTypes.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getLedgerTypes.fulfilled, (state, action: PayloadAction<any>) => {
        state.ledgerTypes = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getLedgerTypes.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },
  initialState,
  name: "ledgerTypes",
  reducers: {
    selectRow: (state, action: PayloadAction<any>) => {
      state.selectedLedgerType = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (LedgerTypesColumnDef || [])?.filter((col) => !!col.sequence)?.at(0)?.field
      };
    }
  }
});

export const { actions: ledgerTypeActions, reducer: ledgerTypesReducer } = slice;
export default ledgerTypesReducer;
