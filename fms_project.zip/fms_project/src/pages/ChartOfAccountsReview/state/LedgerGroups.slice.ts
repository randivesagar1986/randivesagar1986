import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { client, apiRoot } from "@/config";
import { STATUS } from "@/types/UseStateType";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import { ISelectedItem } from "@essnextgen/ui-kit";

type intialStateType = {
  ledgerGroups: RowType[];
  error?: string;
  selectedGroup: ISelectedItem;
  status?: STATUS;
};

const initialState: intialStateType = {
  ledgerGroups: [],
  selectedGroup: {
    text: "",
    value: ""
  }
};

/** Thunks */
export const getLedgerGroups = createAsyncThunk(
  "ledgerGroups/get",
  async ({ costId, callback }: { costId?: string; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/gl-acct-review/acct-review-ledger-groups`, { params: { costId } });

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * # Ledger Groups Slice
 * This slice of state is responsible for storing ledger groups list of details
 */
const slice = createSlice({
  extraReducers: (builder) => {
    builder
      .addCase(getLedgerGroups.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getLedgerGroups.fulfilled, (state, action: PayloadAction<any>) => {
        state.ledgerGroups = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getLedgerGroups.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },
  initialState,
  name: "ledgerGroups",
  reducers: {
    setGroup: (state, action: PayloadAction<ISelectedItem>) => {
      state.selectedGroup = action.payload;
    }
  }
});

export const { actions: ledgerGroupActions, reducer: ledgerGroupReducer } = slice;
export default ledgerGroupReducer;
