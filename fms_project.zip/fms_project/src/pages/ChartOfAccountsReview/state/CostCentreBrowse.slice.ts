import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { STATUS, getCurrentFinancialYear } from "@/types/UseStateType";
import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import { RootState } from "@/store/store";
import columnDef from "../CostCentreBrowse/Grid/columnDef";

export type CostCentreBrowseListType = { [key: string]: any }[];
export type TaggedValueType = { [key: string]: any };

export type CostCentreDetails = {
  tranDetails: CostCentreBrowseListType;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;
  highlightedCostId: number;
};

type TgetCostCentreBrowse = {
  pageNumber?: number;
  pageSize?: number;
  excludeZero?: boolean;
  lookingFor?: string | undefined;
  yearId?: number;
  index?: number;
  costId?: number;
  ledgerCode?: string;
};

type CostCentreBrowseStateType = {
  filterState?: TgetCostCentreBrowse;
  costCentresBrowseList: CostCentreDetails;
  selectedRow?: { [key: string]: any };
  conlumnDef: TColumnDef;
  costCentreBrowseStatus?: STATUS;
  pageStatus?: STATUS;
  viewStatus?: STATUS;
};

const initialState: CostCentreBrowseStateType = {
  filterState: {
    pageNumber: 1,
    pageSize: 10,
    excludeZero: false,
    lookingFor: "",
    yearId: parseInt(getCurrentFinancialYear(), 10),
    costId: 0,
    ledgerCode: ""
  },
  costCentresBrowseList: {
    tranDetails: [],
    currentPage: 1,
    totalCount: 0,
    pageSize: 10,
    totalPages: 0,
    highlightedCostId: 0
  },
  conlumnDef: columnDef
};

/** Thunks */

export const costCentreBrowseFilter = createAsyncThunk(
  "costCentreBrowse/filters",
  async (
    {
      pageNumber,
      pageSize,
      lookingFor,
      excludeZero,
      yearId,
      callback,
      index,
      costId,
      ledgerCode
    }: TgetCostCentreBrowse & { callback?: (data: any, selectedRow?: any) => void },
    thunkAPI
  ) => {
    try {
      const { dispatch } = thunkAPI;
      const { data }: { data: { [key: string]: any } } = await client.post(
        `${apiRoot}/gl-acct-review/acct-review-cc-browse`,
        {
          pageNumber,
          pageSize,
          lookingFor,
          excludeZero,
          yearId,
          costId,
          ledgerCode
        }
      );
      if (data) {
        const row = index
          ? ((data?.tranDetails as { [key: string]: any }[]) || []).at(index)
          : ((data?.tranDetails as { [key: string]: any }[]) || [])
              ?.filter((p) => p.cost_id === data?.highlightedCostId)
              .at(0);
        dispatch(ccBrowseActions.setSelectedRow(row));
        if (callback) {
          callback(data, row);
        }
      }

      return data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getCostCentresPDFData = createAsyncThunk(
  "costCentreBrowse/pdf",
  async (
    {
      payload
    }: {
      payload: {
        excludeZero: string;
        ledgerDescription: string;
        ledgerCode: string;
      };
    },
    thunkAPI
  ) => {
    const { restrictedMenu } = thunkAPI.getState() as RootState;
    try {
      const response = await client.post(
        `${apiRoot}/document/acct-review-cost-center-print-pdf`,
        {
          ...payload,
          restrictedUser: restrictedMenu?.restrictedUser?.restricted_user === "T"
        },
        {
          responseType: "blob"
        }
      );
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");
      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);
export const getCostCentresXMLData = createAsyncThunk(
  "costCentreBrowse/XML",
  async (
    {
      payload
    }: {
      payload: {
        excludeZero: string;
        ledgerDescription: string;
        ledgerCode: string;
      };
    },
    thunkAPI
  ) => {
    const { restrictedMenu } = thunkAPI.getState() as RootState;
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-cost-center-print-xml`, {
        ...payload,
        restrictedUser: restrictedMenu?.restrictedUser?.restricted_user === "T"
      });
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");

      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);
export const getCostCentresCsvData = createAsyncThunk(
  "costCentreBrowse/csv",
  async (
    {
      payload
    }: {
      payload: {
        excludeZero: string;
        ledgerDescription: string;
        ledgerCode: string;
      };
    },
    thunkAPI
  ) => {
    const { restrictedMenu } = thunkAPI.getState() as RootState;
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-cost-center-print-csv`, {
        ...payload,
        restrictedUser: restrictedMenu?.restrictedUser?.restricted_user === "T"
      });
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");
      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

/**
 * This slice of state is responsible for storing BRC details state
 */
const slice = createSlice({
  initialState,
  name: "chartOfAccountReviewList",
  extraReducers: (builder) => {
    /** BRC details state */
    builder
      .addCase(costCentreBrowseFilter.pending, (state) => {
        state.costCentreBrowseStatus = STATUS.LOADING;
      })
      .addCase(costCentreBrowseFilter.fulfilled, (state, action: PayloadAction<any>) => {
        state.costCentresBrowseList = action.payload;
        state.costCentreBrowseStatus = STATUS.SUCCESS;
      })
      .addCase(costCentreBrowseFilter.rejected, (state, action: PayloadAction<any>) => {
        state.costCentreBrowseStatus = STATUS.FAILED;
      });
  },
  reducers: {
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.conlumnDef = [...action.payload];
    },
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedRow = action.payload;
    },
    setFilters: (state, action: PayloadAction<TgetCostCentreBrowse>) => {
      state.filterState = {
        ...state.filterState,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filterState = {
        ...initialState.filterState
      };
    }
  }
});

export const { actions: ccBrowseActions, reducer } = slice;
export default reducer;
