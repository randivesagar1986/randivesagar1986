import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useFormContext } from "react-hook-form";
import { STATUS } from "@/types/UseStateType";
import { financialPeriodActions } from "../../../../state/financialPeriod.slice";
import PeriodsGrid from "../PeriodsGrid";

// Mock dependencies
jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("react-hook-form", () => ({
  useFormContext: jest.fn()
}));

jest.mock("../../../../state/financialPeriod.slice", () => ({
  financialPeriodActions: {
    resetFilters: jest.fn(),
    selectFrom: jest.fn(),
    selectTo: jest.fn()
  }
}));

jest.mock("@/components/GridTableNew/GridTableNew", () =>
  jest.fn((props) => (
    <div
      {...props}
      data-testid={props?.dataTestId}
    >
      <div>{props?.filters}</div>
      <div>{props?.actions}</div>
    </div>
  ))
);
jest.mock("../Filters", () => jest.fn((props) => <div {...props}>Filters</div>));
jest.mock("../FooterActions", () =>
  jest.fn((props) => (
    <div {...props}>
      <h1>FooterActions</h1>
      <div>
        <button
          type="button"
          onClick={props?.onSelect}
        >
          footer actions select
        </button>
        <button
          type="button"
          onClick={props?.onCancel}
        >
          footer actions cancel
        </button>
      </div>
    </div>
  ))
);
jest.mock("../CustomCell", () => jest.fn((props) => <div {...props}>CustomCell</div>));

describe("PeriodsGrid Component", () => {
  const mockDispatch = jest.fn();

  const mockState = {
    financialPeriods: {
      periods: [],
      status: STATUS.IDLE,
      columnDef: [],
      selectedPeriodFrom: { period_no: "1", description: "Period 1" },
      selectedPeriodTo: { period_no: "2", description: "Period 2" }
    }
  };

  const mockFormContext = {
    setValue: jest.fn()
  };

  const mockProps = {
    setIsOpen: jest.fn(),
    id: "selectFrom"
  };

  beforeEach(() => {
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useFormContext as jest.Mock).mockReturnValue(mockFormContext);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<PeriodsGrid {...mockProps} />);
    expect(screen.getByTestId("periodsGrid")).toBeInTheDocument();
    expect(screen.getByText("Filters")).toBeInTheDocument();
    expect(screen.getByText("FooterActions")).toBeInTheDocument();
  });

  it("should call resetFilters on mount and unmount", () => {
    const { unmount } = render(<PeriodsGrid {...mockProps} />);
    expect(mockDispatch).toHaveBeenCalledWith(financialPeriodActions.resetFilters());
    unmount();
    expect(mockDispatch).toHaveBeenCalledWith(financialPeriodActions.resetFilters());
  });

  it("should handle row selection and call selectFrom", () => {
    render(<PeriodsGrid {...mockProps} />);
    fireEvent.click(screen.getByRole("button", { name: "footer actions select" }));
    expect(mockDispatch).toHaveBeenCalledWith(
      financialPeriodActions.selectFrom(mockState.financialPeriods.selectedPeriodFrom)
    );
    expect(mockFormContext.setValue).toHaveBeenCalledWith(
      "from",
      mockState.financialPeriods.selectedPeriodFrom.period_no
    );
    expect(mockFormContext.setValue).toHaveBeenCalledWith(
      "fromDescription",
      mockState.financialPeriods.selectedPeriodFrom.description
    );
    expect(mockProps.setIsOpen).toHaveBeenCalledWith(false);
  });

  it("should handle row selection and call selectTo", () => {
    render(
      <PeriodsGrid
        {...mockProps}
        id="selectTo"
      />
    );
    fireEvent.click(screen.getByRole("button", { name: "footer actions select" }));
    expect(mockDispatch).toHaveBeenCalledWith(
      financialPeriodActions.selectTo(mockState.financialPeriods.selectedPeriodTo)
    );
    expect(mockFormContext.setValue).toHaveBeenCalledWith("to", mockState.financialPeriods.selectedPeriodTo.period_no);
    expect(mockFormContext.setValue).toHaveBeenCalledWith(
      "toDescription",
      mockState.financialPeriods.selectedPeriodTo.description
    );
    expect(mockProps.setIsOpen).toHaveBeenCalledWith(false);
  });

  it("should handle cancel action", () => {
    render(<PeriodsGrid {...mockProps} />);
    fireEvent.click(screen.getByRole("button", { name: "footer actions cancel" }));
    expect(mockProps.setIsOpen).toHaveBeenCalledWith(false);
  });
});
