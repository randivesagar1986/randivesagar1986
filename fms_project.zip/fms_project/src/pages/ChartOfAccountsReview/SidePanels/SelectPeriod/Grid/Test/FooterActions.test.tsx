import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import FooterActions from "../FooterActions";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@essnextgen/ui-kit", () => ({
  CheckBox: jest.fn((props: any) => (
    <input
      type="checkbox"
      id="checkBox"
      {...props}
    />
  )),
  Button: jest.fn((props: any) => (
    <button
      type="button"
      id="button"
      {...props}
    >
      {props?.children}
    </button>
  )),
  TextInput: jest.fn((props: any) => (
    <input
      data-testid={props?.dataTestId}
      type="text"
      id="textInput"
      {...props}
    />
  )),
  Grid: jest.fn((props: any) => (
    <div
      {...props}
      id="grid"
    >
      {props?.children}
    </div>
  )),
  GridItem: jest.fn((props: any) => (
    <div
      {...props}
      id="gridItem"
    >
      {props?.children}
    </div>
  )),
  FormLabel: jest.fn((props: any) => (
    <div
      {...props}
      id="label"
    >
      {props?.children}
    </div>
  )),
  ButtonSize: {
    Small: "small"
  },
  ButtonColor: {
    Primary: "primary",
    Secondary: "secondary"
  }
}));

jest.mock("@/components/OpenLinkButton/HelpButton", () =>
  jest.fn((props) => (
    <button
      type="button"
      {...props}
    >
      HelpButton
    </button>
  ))
);

describe("FooterActions Component", () => {
  const mockProps = {
    onSelect: jest.fn(),
    onCancel: jest.fn(),
    onHelp: jest.fn(),
    className: "test-class"
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<FooterActions {...mockProps} />);
    expect(screen.getByText("common.selectButton")).toBeInTheDocument();
    expect(screen.getByText("common.cancel")).toBeInTheDocument();
    expect(screen.getByText("HelpButton")).toBeInTheDocument();
  });

  it("should call onSelect when the select button is clicked", () => {
    render(<FooterActions {...mockProps} />);
    fireEvent.click(screen.getByText("common.selectButton"));
    expect(mockProps.onSelect).toHaveBeenCalled();
  });

  it("should call onCancel when the cancel button is clicked", () => {
    render(<FooterActions {...mockProps} />);
    fireEvent.click(screen.getByText("common.cancel"));
    expect(mockProps.onCancel).toHaveBeenCalled();
  });

  it("should render with the provided className", () => {
    const { container } = render(<FooterActions {...mockProps} />);
    expect(container.firstChild).toHaveClass("test-class");
  });

  it("should render HelpButton with the correct props", () => {
    render(<FooterActions {...mockProps} />);
    const helpButton = screen.getByText("HelpButton");
    expect(helpButton).toHaveAttribute("identifier", "help-button");
    expect(helpButton).toHaveAttribute("labelName", "common.help");
  });
});
