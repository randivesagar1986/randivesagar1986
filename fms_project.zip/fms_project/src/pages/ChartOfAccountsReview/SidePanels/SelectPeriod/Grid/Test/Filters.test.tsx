import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { STATUS } from "@/types/UseStateType";
import { financialPeriodActions } from "../../../../state/financialPeriod.slice";
import Filters from "../Filters";
import columnDef from "../ColumnDef";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("../../../../state/financialPeriod.slice", () => ({
  financialPeriodActions: {
    setFilters: jest.fn(),
    setColumnDef: jest.fn()
  }
}));

jest.mock("@/hooks/useDebounce", () => jest.fn((value) => value));
jest.mock("@/hooks/useNearestSearch", () => jest.fn());

jest.mock("@essnextgen/ui-kit", () => ({
  RadioButton: jest.fn((props: any) => (
    <input
      type="radio"
      id="radio"
      {...props}
    />
  )),
  CheckBox: jest.fn((props: any) => (
    <input
      type="checkbox"
      id="checkBox"
      {...props}
    />
  )),
  Button: jest.fn((props: any) => (
    <button
      type="button"
      id="button"
      {...props}
    >
      {props?.children}
    </button>
  )),
  TextInput: jest.fn((props: any) => (
    <input
      data-testid={props?.dataTestId}
      onKeyDown={props?.onKeyDown}
      type="text"
      id="textInput"
      {...props}
    />
  )),
  Grid: jest.fn((props: any) => (
    <div
      {...props}
      id="grid"
    >
      {props?.children}
    </div>
  )),
  GridItem: jest.fn((props: any) => (
    <div
      {...props}
      id="gridItem"
    >
      {props?.children}
    </div>
  )),
  FormLabel: jest.fn((props: any) => (
    <div
      {...props}
      id="label"
    >
      {props?.children}
    </div>
  )),
  TextInputSize: {
    Medium: "medium"
  },
  RadioLabelPosition: {
    Right: "right"
  }
}));

describe("Filters Component", () => {
  const mockDispatch = jest.fn();

  const mockState = {
    financialPeriods: {
      status: STATUS.IDLE,
      periods: [],
      filters: {
        lookingFor: "",
        sequenceValue: ""
      }
    }
  };

  const mockProps = {
    selectRow: jest.fn()
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<Filters {...mockProps} />);
    screen.debug();
    expect(screen.getByText("purchaseOrder.lookingFor")).toBeInTheDocument();
    expect(screen.getByText("purchaseOrder.sequence")).toBeInTheDocument();
  });

  it("should call setFilters when the input value changes", () => {
    render(<Filters {...mockProps} />);
    fireEvent.change(screen.getByRole("textbox"), { target: { value: "test" } });
    expect(mockDispatch).toHaveBeenCalledWith(financialPeriodActions.setFilters({ lookingFor: "TEST" }));
  });

  it("should prevent non-alphanumeric characters in the input", () => {
    render(<Filters {...mockProps} />);
    const input = screen.getByRole("textbox");
    fireEvent.keyDown(input, { key: "!" });
    expect(input).toHaveValue("");
  });

  it("should allow alphanumeric characters in the input", () => {
    render(<Filters {...mockProps} />);
    const input = screen.getByRole("textbox");
    fireEvent.keyDown(input, { key: "a" });
    fireEvent.change(input, { target: { value: "a" } });
  });

  it("should call setFilters and setColumnDef when the sequence is changed", () => {
    render(<Filters {...mockProps} />);
    const seqRadios = screen.getAllByRole("radio");
    fireEvent.click(seqRadios[0]);
    expect(mockDispatch).toHaveBeenCalledWith(
      financialPeriodActions.setFilters({
        lookingFor: "",
        sequenceValue: columnDef[0].field,
        sequenceIndex: "0"
      })
    );
    expect(mockDispatch).toHaveBeenCalledWith(financialPeriodActions.setColumnDef(expect.any(Array)));
  });
});
