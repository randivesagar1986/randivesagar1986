import React from "react";
import { render, screen } from "@testing-library/react";
import { cellRendererType } from "@/components/GridTable/GridTable";
import CustomCell from "../CustomCell";

describe("CustomCell Component", () => {
  it("should render the period_no when it is not zero", () => {
    const row = { period_no: 5 };
    render(
      <CustomCell
        field="period_no"
        row={row}
      />
    );
    expect(screen.getByText("5")).toBeInTheDocument();
  });

  it("should render zero when period_no is zero", () => {
    const row = { period_no: 0 };
    render(
      <CustomCell
        field="period_no"
        row={row}
      />
    );
    expect(screen.getByText("0")).toBeInTheDocument();
  });

  it("should render null when field is not period_no", () => {
    const row = { period_no: 5 };
    const { container } = render(
      <CustomCell
        field="other_field"
        row={row}
      />
    );
    expect(container).toBeEmptyDOMElement();
  });
});
