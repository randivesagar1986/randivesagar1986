import React, { FC, useEffect, useState } from "react";
import {
  Grid,
  GridItem,
  NotificationStatus,
  SidePanel,
  SidePanelContent,
  SidePanelFooter,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import "../../Style.scss";
import Input from "@/components/Input/Input";
import { AppDispatch, useAppSelector } from "@/store/store";
import { FormProvider, useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { useAppContext } from "@/routes/Routes.utils";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import { STATUS, specialCharacters } from "@/types/UseStateType";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useHistory } from "react-router-dom";
import BodyUtil from "@/shared/utils/NoScroll";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import InputButton from "./Grid/InputButton";
import { financialPeriodActions, getFinancialPeriods, getTransactions } from "../../state/financialPeriod.slice";
import FooterActions from "./Grid/FooterActions";
import PeriodsGrid from "./Grid/PeriodsGrid";

type FormDataType = { from?: string; fromDescription?: string; to?: string; toDescription?: string };
type PropsType = { enable: boolean; setEnable: (flag: boolean) => void; row?: RowType };

const SelectPeriodRangeModal: FC<PropsType> = ({ enable, setEnable, row }) => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { t: locale }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [id, setId] = useState<string>();
  const { periods, filters, status, transactionStatus } = useAppSelector((state) => state.financialPeriods);
  const searchItems = periods.map((p) => ({ text: p?.period_no, value: p?.period_no }));
  const selectedfundCode = useAppSelector((state) => state.fundCode.selectedfundCode);
  const formMethods = useForm<FormDataType>({
    defaultValues: {
      fromDescription: "",
      toDescription: ""
    }
  });
  const {
    setValue,
    watch,
    getValues,
    register,
    formState: { errors },
    handleSubmit,
    setError,
    clearErrors
  } = formMethods;
  const { from, to } = getValues();
  const isLoading = (transactionStatus === STATUS.LOADING || status === STATUS.LOADING) && !isOpen;

  const onClick = (id: string) => {
    setIsOpen(true);
    setId(id);
  };

  useEffect(() => {
    if (enable) dispatch(getFinancialPeriods({ status: Number(filters?.sequenceIndex) }));
  }, [filters?.sequenceIndex, enable]);

  useEffect(() => {
    if (!from && !to && status === STATUS.SUCCESS && periods.length) {
      const period = row ? periods.find((p) => p.period_no === row?.period_no) : periods?.at(0);
      dispatch(financialPeriodActions.selectFrom(period));
      dispatch(financialPeriodActions.selectTo(period));
      setValue("from", period?.period_no);
      setValue("to", period?.period_no);
      setValue("toDescription", period?.description);
      setValue("fromDescription", period?.description);
    }
  }, [status]);

  const invalidError = () => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE?.ALERT,
        message: locale("common.invalidData"),
        title: locale("common.simsFMSModule"),
        notificationType: NotificationStatus?.ERROR,
        className: "primary-focus",
        callback: () => {
          setTimeout(() => {
            BodyUtil.NoScroll.add();
          }, 60);
        }
      })
    );
  };

  const validatePeriod = () => {
    const from = watch("from")?.toString();
    const to = watch("to")?.toString();
    let isError = false;
    if (from && to && Number(from) > Number(to)) {
      setError("from", { type: "custom", message: "From should be less than to period" });
      isError = true;
    } else {
      clearErrors("from");
    }

    return isError;
  };

  const onSubmit = async () => {
    const isError = validatePeriod();

    if (isError) {
      invalidError();
    } else {
      const formSubmit = handleSubmit(
        async (data) => {
          // ToDo: Needs to cover submit action in next user story
          const result: any = await dispatch(
            getTransactions({
              fromPeriodNo: data.from,
              toPeriodNo: data.to,
              costId: historyState?.costCentreRecord?.cost_id,
              leddefId: historyState?.ledgerRecord?.leddef_id,
              fundId: selectedfundCode?.fund_id,
              PageNumber: 1,
              PageSize: 10
            })
          );
          const fromDate = `${data.from}`;
          const toDate = `${data.to}`;
          if (result.payload?.errorMessage?.message) {
            document.body.style.overflow = "hidden";
            dispatch(
              uiActions.alertPopup({
                enable: true,
                type: MODAL_TYPE?.ALERT,
                message: result.payload?.errorMessage?.message,
                title: locale("common.simsFMSModule"),
                notificationType: NotificationStatus?.ERROR,
                className: "primary-focus",
                callback: () => {
                  setTimeout(() => {
                    BodyUtil.NoScroll.add();
                    document.body.style.overflow = "";
                  }, 60);
                }
              })
            );
          } else {
            history.push({
              pathname: `/general-ledger/chart-accounts-review/transaction-period/from/${fromDate}/to/${toDate}`,
              state: {
                ...historyState,
                from: "transactionPeriod"
              }
            });
          }
        },
        (error) => {
          if (error) invalidError();
        }
      );

      await formSubmit();
    }
  };

  const handleKeyDown = (e: any) => {
    if (e.key === "Escape") {
      e.preventDefault();
      setEnable(false);
    }
  };

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleKeyDown]);

  const loaderConfig: loadingConfig = {};

  return (
    <FormProvider {...formMethods}>
      <SidePanel
        dataTestId="view-transaction"
        id="view-transaction"
        onClose={() => {
          setEnable(false);
        }}
        title={locale("bankReconciliation.viewTransaction")}
        isOpen={enable}
        className="period-range-panel"
        showConfirmDialog
      >
        <SidePanelContent>
          {isLoading ? (
            <Loader loadingConfig={loaderConfig} />
          ) : (
            <Grid>
              <GridItem
                sm={4}
                md={6}
                lg={12}
                xl={12}
                className="essui-global-typography-default-subtitle mb-8"
              >
                {locale(`bankReconciliation.${id ?? "selectPeriodRange"}`)}
              </GridItem>
              {!isOpen ? (
                <>
                  <GridItem
                    sm={12}
                    md={4}
                    lg={6}
                    xl={6}
                    className="input--width80"
                  >
                    <Input
                      id="from"
                      dataTestId="period-from"
                      labelText={locale("generalLedgerSetup.periodFrom")}
                      searchable
                      className="width160"
                      value={from}
                      searchItems={searchItems}
                      name={register("from", { required: true, validate: (value) => !validatePeriod() }).name}
                      onBlur={register("from").onBlur}
                      inputRef={register("from").ref}
                      onNoSelection={() => {
                        setId("selectFrom");
                        setIsOpen(true);
                        setValue("from", specialCharacters.BLANKVALUE);
                        setValue("fromDescription", specialCharacters.BLANKVALUE);
                      }}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                        const { value } = e.target;
                        setValue(
                          "from",
                          value !== specialCharacters.BLANKVALUE ? value : specialCharacters.BLANKVALUE,
                          { shouldValidate: true }
                        );
                        setValue(
                          "fromDescription",
                          value !== specialCharacters.BLANKVALUE
                            ? periods?.at(Number(value))?.description
                            : specialCharacters.BLANKVALUE,
                          {
                            shouldValidate: true
                          }
                        );
                        dispatch(
                          financialPeriodActions.selectFrom(
                            value !== specialCharacters.BLANKVALUE ? periods?.at(Number(value)) : undefined
                          )
                        );
                      }}
                      button={
                        <InputButton
                          value={watch("fromDescription")}
                          onClick={() => onClick("selectFrom")}
                        />
                      }
                      validationTextLevel={errors.from ? ValidationTextLevel.Error : undefined}
                    />
                  </GridItem>
                  <GridItem
                    sm={12}
                    md={4}
                    lg={6}
                    xl={6}
                    className="input--width80"
                  >
                    <Input
                      id="to"
                      dataTestId="period-to"
                      labelText={locale("generalLedgerSetup.periodTo")}
                      searchable
                      value={to}
                      searchItems={searchItems}
                      name={register("to", { required: true }).name}
                      onBlur={register("to").onBlur}
                      inputRef={register("to").ref}
                      onNoSelection={() => {
                        setId("selectTo");
                        setIsOpen(true);
                        setValue("to", specialCharacters.BLANKVALUE);
                        setValue("toDescription", specialCharacters.BLANKVALUE);
                      }}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                        const { value } = e.target;
                        setValue("to", value !== specialCharacters.BLANKVALUE ? value : specialCharacters.BLANKVALUE);
                        setValue(
                          "toDescription",
                          value !== specialCharacters.BLANKVALUE
                            ? periods?.at(Number(value))?.description
                            : specialCharacters.BLANKVALUE
                        );
                        dispatch(
                          financialPeriodActions.selectTo(
                            value !== specialCharacters.BLANKVALUE ? periods?.at(Number(value)) : undefined
                          )
                        );
                      }}
                      validationTextLevel={errors.to ? ValidationTextLevel.Error : undefined}
                      button={
                        <InputButton
                          value={watch("toDescription")}
                          onClick={() => onClick("selectTo")}
                        />
                      }
                    />
                  </GridItem>
                </>
              ) : (
                <GridItem xl>
                  <PeriodsGrid
                    id={id}
                    setIsOpen={(value) => {
                      setIsOpen(value);
                      if (!value) {
                        setId(undefined);
                        validatePeriod();
                      }
                    }}
                  />
                </GridItem>
              )}
            </Grid>
          )}
        </SidePanelContent>
        {!isOpen && !isLoading && (
          <SidePanelFooter>
            <FooterActions
              className="period-range-panel__footer-actions flex-rev"
              onSelect={async () => {
                await onSubmit();
              }}
              onCancel={() => setEnable(false)}
            />
          </SidePanelFooter>
        )}
      </SidePanel>
    </FormProvider>
  );
};

SelectPeriodRangeModal.defaultProps = {
  row: undefined
};

export default SelectPeriodRangeModal;
