import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { uiActions, MODAL_TYPE } from "@/store/state/ui.slice";
import { STATUS, specialCharacters } from "@/types/UseStateType";
import { useHistory } from "react-router-dom";
import { financialPeriodActions, getFinancialPeriods, getTransactions } from "../../../state/financialPeriod.slice";
import SelectPeriodRangeModal from "../SelectPeriodRangeModal";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("@essnextgen/ui-kit", () => ({
  CheckBox: jest.fn((props: any) => (
    <input
      type="checkbox"
      id="checkBox"
      {...props}
    />
  )),
  RadioButton: jest.fn((props: any) => (
    <input
      type="radio"
      id="radio"
      {...props}
    />
  )),
  TextInput: jest.fn((props: any) => (
    <input
      data-testid={props?.dataTestId}
      type="text"
      id="textInput"
      {...props}
    />
  )),
  Grid: jest.fn((props: any) => (
    <div
      {...props}
      id="grid"
    >
      {props?.children}
    </div>
  )),
  GridItem: jest.fn((props: any) => (
    <div
      {...props}
      id="gridItem"
    >
      {props?.children}
    </div>
  )),
  FormLabel: jest.fn((props: any) => (
    <div
      {...props}
      id="label"
    >
      {props?.children}
    </div>
  )),
  SidePanel: jest.fn((props: any) => (
    <div
      {...props}
      id="sidePanel"
      data-testid={props?.dataTestId}
    >
      {props?.children}
    </div>
  )),
  SidePanelContent: jest.fn((props: any) => (
    <div
      {...props}
      id="sidePanelContent"
    >
      {props?.children}
    </div>
  )),
  SidePanelFooter: jest.fn((props: any) => (
    <div
      {...props}
      id="sidePanelFooter"
    >
      {props?.children}
    </div>
  )),
  RadioLabelPosition: {
    Right: "right"
  },
  TextInputSize: {
    Medium: "medium"
  },
  NotificationStatus: {
    ERROR: "error"
  },
  ValidationTextLevel: {
    ERROR: "error"
  }
}));

jest.mock("../../../state/financialPeriod.slice", () => ({
  financialPeriodActions: {
    selectFrom: jest.fn(),
    selectTo: jest.fn()
  },
  getFinancialPeriods: jest.fn(),
  getTransactions: jest.fn()
}));

jest.mock("@/store/state/ui.slice", () => ({
  uiActions: {
    alertPopup: jest.fn()
  },
  MODAL_TYPE: {
    ALERT: "ALERT"
  }
}));

jest.mock("@/components/Input/Input", () =>
  jest.fn((props) => (
    <input
      data-testid={props?.dataTestId}
      {...props}
    />
  ))
);
jest.mock("@/components/Loader/Loader", () => jest.fn((props) => <div {...props}>Loader</div>));
jest.mock("../Grid/InputButton", () =>
  jest.fn((props) => (
    <button
      type="button"
      {...props}
    >
      InputButton
    </button>
  ))
);
jest.mock("../Grid/FooterActions", () =>
  jest.fn((props) => (
    <div
      {...props}
      onSelect={props?.onSelect}
    >
      FooterActions
    </div>
  ))
);
jest.mock("../Grid/PeriodsGrid", () => jest.fn((props) => <div {...props}>PeriodsGrid</div>));

describe("SelectPeriodRangeModal Component", () => {
  const mockDispatch = jest.fn();
  const mockHistory = {
    push: jest.fn(),
    location: {
      state: {}
    }
  };

  const mockState = {
    financialPeriods: {
      periods: [],
      filters: {},
      status: STATUS.IDLE,
      transactionStatus: STATUS.IDLE
    },
    fundCode: {
      selectedfundCode: null
    }
  };

  const mockProps = {
    enable: true,
    setEnable: jest.fn(),
    row: undefined
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<SelectPeriodRangeModal {...mockProps} />);
    screen.debug();
    expect(screen.getByTestId("view-transaction")).toBeInTheDocument();
    expect(screen.getByTestId("period-from")).toBeInTheDocument();
    expect(screen.getByTestId("period-to")).toBeInTheDocument();
  });

  it("should call setEnable and dispatch alertPopup when invalid data is submitted", async () => {
    render(<SelectPeriodRangeModal {...mockProps} />);
    fireEvent.click(screen.getByText("FooterActions"));
    await waitFor(() => {
      expect(mockDispatch).toHaveBeenCalledWith(
        uiActions.alertPopup({
          enable: true,
          type: MODAL_TYPE.ALERT,
          message: "common.invalidData",
          title: "common.simsFMSModule",
          className: "primary-focus",
          callback: expect.any(Function)
        })
      );
    });
  });

  it("should call getFinancialPeriods when enable is true", () => {
    render(<SelectPeriodRangeModal {...mockProps} />);
    expect(mockDispatch).toHaveBeenCalledWith(getFinancialPeriods({ status: NaN }));
  });

  it("should call selectFrom and selectTo when periods are loaded", () => {
    const mockPeriods = [{ period_no: "1", description: "Period 1" }];
    (useAppSelector as jest.Mock).mockImplementation((selector) =>
      selector({
        ...mockState,
        financialPeriods: {
          ...mockState.financialPeriods,
          periods: mockPeriods,
          status: STATUS.SUCCESS
        }
      })
    );

    render(<SelectPeriodRangeModal {...mockProps} />);
    expect(mockDispatch).toHaveBeenCalledWith(financialPeriodActions.selectFrom(mockPeriods[0]));
    expect(mockDispatch).toHaveBeenCalledWith(financialPeriodActions.selectTo(mockPeriods[0]));
  });

  it("should call getTransactions and navigate to transaction period page on submit", async () => {
    const mockPeriods = [{ period_no: "1", description: "Period 1" }];
    (useAppSelector as jest.Mock).mockImplementation((selector) =>
      selector({
        ...mockState,
        financialPeriods: {
          ...mockState.financialPeriods,
          periods: mockPeriods,
          status: STATUS.SUCCESS
        }
      })
    );

    render(<SelectPeriodRangeModal {...mockProps} />);
    fireEvent.change(screen.getByTestId("period-from"), { target: { value: "1" } });
    fireEvent.change(screen.getByTestId("period-to"), { target: { value: "1" } });
    fireEvent.click(screen.getByText("FooterActions"));

    await waitFor(() => {
      expect(mockDispatch).toHaveBeenCalledWith(
        getTransactions({
          fromPeriodNo: "1",
          toPeriodNo: "1",
          costId: expect.any(Number),
          leddefId: expect.any(Number),
          fundId: expect.any(Number),
          PageNumber: 1,
          PageSize: 10
        })
      );
    });
  });

  it("should handle keydown event and close the modal on Escape key press", () => {
    render(<SelectPeriodRangeModal {...mockProps} />);
    fireEvent.keyDown(window, { key: "Escape" });
    expect(mockProps.setEnable).toHaveBeenCalledWith(false);
  });

  it("should render Loader when isLoading is true", () => {
    (useAppSelector as jest.Mock).mockImplementation((selector) =>
      selector({
        ...mockState,
        financialPeriods: {
          ...mockState.financialPeriods,
          transactionStatus: STATUS.LOADING
        }
      })
    );

    render(<SelectPeriodRangeModal {...mockProps} />);
    expect(screen.getByText("Loader")).toBeInTheDocument();
  });
});
