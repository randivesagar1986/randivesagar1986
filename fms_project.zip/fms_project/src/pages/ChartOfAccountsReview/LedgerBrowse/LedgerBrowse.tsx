import Layout from "@/components/Layout/Layout";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import "./LedgerBrowse.style.scss";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { IPaginationProps, Pagination } from "@essnextgen/ui-kit";
import { useHistory } from "react-router-dom";
import { useAppContext } from "@/routes/Routes.utils";
import { ledgerGrpAction } from "@/pages/GeneralLedgerSetup/State/LedgerGroupsList.slice";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import LedgerBrowseColumnDef from "./Grid/LedgerBrowseColumnDef";
import LedgerBrowseFilters from "./Grid/LedgerBrowserFilters";
import { getLedgerGroups, ledgerGroupActions } from "../state/LedgerGroups.slice";
import { getLedgerTypes, ledgerTypeActions } from "../state/LedgerTypes.slice";
import LedgerBrowseFooter from "./Grid/LedgerBrowseFooter";
import LedgerTypeModal from "./LedgerTypeModal/LedgerTypeModal";
import { getLedgers, ledgersActions } from "../state/Ledgers.slice";
import CustomCell from "./Grid/CustomCell";

type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];

const LedgerBrowse = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { t: locale }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [isDisabled, setIsDisabled] = useState(false);
  const history = useHistory();
  const historyState = history.location.state as any;
  const {
    ledgerBrowse: { ledgers, selectedLedger, filterState, status: ledgerStatus },
    ledgerGroups: { status: groupsStatus },
    ledgerTypes: { ledgerTypes, filters, status: typesStatus }
  } = useAppSelector((state) => state);

  const unblock = history.block((location, action) => {
    if (!location.pathname.includes("ledger-browse") || location.pathname.includes("/preview")) {
      const locationState = location?.state as any;
      location.state = {
        ...locationState,
        excludeBalanceSheetAccounts: filterState.excludeBalanceSheetAccounts,
        excludeNonZeroValues: filterState.excludeNonZeroValues
      };

      if (!location.pathname.includes("/preview")) {
        dispatch(ledgersActions.resetFilters());
        dispatch(ledgerTypeActions.selectRow(undefined));
        dispatch(ledgerGroupActions.setGroup({ text: "", value: "" }));
      }
    }
  });

  useEffect(() => {
    dispatch(
      getLedgerGroups({
        costId: historyState?.costCentreRecord?.cost_id,
        callback: (data) => {
          if (data.length === 1) {
            dispatch(
              ledgerGroupActions.setGroup({
                text: data.at(0).group_des,
                value: data.at(0).group_id
              })
            );
            setIsDisabled(true);
          }
        }
      })
    );

    return () => {
      unblock();
    };
  }, []);

  useEffect(() => {
    dispatch(
      getLedgerTypes({
        sequence: Number(filters?.sequenceIndex),
        costId: historyState?.costCentreRecord?.cost_id,
        callback: (data) => {
          if (data.length === 1) {
            dispatch(ledgerTypeActions.selectRow(data.at(0)));
            setIsDisabled(true);
          }
        }
      })
    );
  }, [filters?.sequenceIndex]);

  useEffect(() => {
    dispatch(
      getLedgers({
        filterState: {
          ...filterState,
          costId: historyState?.costCentreRecord?.cost_id
        }
      })
    );
  }, [filterState]);

  const onChangeHandler: onChangeType = (e, page) => {
    dispatch(
      ledgersActions.setFilters({
        ...filterState,
        pageNumber: page,
        pageSize: ledgers?.pageSize,
        lookingFor: "",
        highLightedRecord: ""
      })
    );
  };

  const isLoading =
    ledgerStatus !== STATUS.SUCCESS ||
    groupsStatus !== STATUS.SUCCESS ||
    (typesStatus !== STATUS.SUCCESS && ledgerTypes.length === 0);

  useEffect(() => {
    const element = document.getElementById(`rowIndex-ledgerGrid-${ledgers?.ledgerCodes?.indexOf(selectedLedger)}`);
    const elementId = element?.getAttribute("id");

    if (elementId) {
      document.getElementById(elementId)?.addEventListener("keyup", (event) => {
        event.preventDefault();
        if (event.keyCode === 13) {
          dispatch(ledgersActions.resetFilters());
          history.push(
            {
              pathname: "/general-ledger/chart-accounts-review"
            },
            { ...historyState, ledgerRecord: selectedLedger }
          );
        }
      });
    }
  }, [selectedLedger]);

  useEffect(() => {
    const element = document.getElementById(`rowIndex-ledgerGrid-${ledgers?.ledgerCodes?.indexOf(selectedLedger)}`);
    const elementId = element?.getAttribute("id");

    if (elementId) {
      document.getElementById(elementId)?.addEventListener("keyup", (event) => {
        event.preventDefault();
        if (event.keyCode === 13) {
          dispatch(ledgersActions.resetFilters());
          history.push(
            {
              pathname: "/general-ledger/chart-accounts-review"
            },
            { ...historyState, ledgerRecord: selectedLedger }
          );
        }
      });
    }
  }, [selectedLedger]);

  return (
    <>
      <Layout
        pageTitle={locale("ledgerBrowse.ledgerBrowseTitle")}
        className="ledgers-browse"
        type="transparent"
        dataTestId="ledgerGridLayout"
      >
        <GridTableNew
          id="ledgerGrid"
          dataTestId="ledgerGridTable"
          customCell={CustomCell}
          filters={
            <LedgerBrowseFilters
              isOpen={setIsOpen}
              setIsDisabled={setIsDisabled}
              isDisabled={isDisabled}
            />
          }
          columnDef={LedgerBrowseColumnDef}
          dataSource={ledgers?.ledgerCodes || []}
          selectedRow={selectedLedger}
          isLoading={isLoading}
          selectedRowHandler={(row) => {
            dispatch(ledgersActions.selectRow(row));
          }}
          // onEnterKeyPress={() => {
          //   dispatch(ledgersActions.resetFilters());
          //   history.push(
          //     {
          //       pathname: "/general-ledger/chart-accounts-review"
          //     },
          //     { ...historyState, ledgerRecord: selectedLedger }
          //   );
          // }}
          footer={
            <Pagination
              className="ml-auto"
              count={ledgers?.totalPages}
              page={ledgers?.currentPage}
              onChange={onChangeHandler}
            />
          }
        />
      </Layout>
      <LedgerBrowseFooter />
      <LedgerTypeModal
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        setIsDisabled={setIsDisabled}
      />
    </>
  );
};

export default LedgerBrowse;
