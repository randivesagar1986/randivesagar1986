import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { ledgerTypeActions } from "../../../state/LedgerTypes.slice";
import { ledgersActions } from "../../../state/Ledgers.slice";
import LedgerTypeModal from "../LedgerTypeModal";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("../../../state/LedgerTypes.slice", () => ({
  ledgerTypeActions: {
    selectRow: jest.fn(),
    resetFilters: jest.fn()
  }
}));

jest.mock("../../../state/Ledgers.slice", () => ({
  ledgersActions: {
    setFilters: jest.fn()
  }
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("@/components/GridTableNew/GridTableNew", () =>
  jest.fn((props) => (
    <div {...props}>
      <h1>GridTableNew</h1>
      <div>{props?.filters}</div>
      <div onClick={props?.selectedRowHandler}>row</div>
    </div>
  ))
);
jest.mock("../Grid/LedgerTypeFilters", () => jest.fn((props) => <div {...props}>LedgerTypeFilters</div>));
jest.mock("@/components/Modal/Modal", () =>
  jest.fn((props) => (
    <div {...props}>
      <h1>Modal</h1>
      <div>{props?.children}</div>
      <div>
        <button
          onClick={props?.primaryBtnClick}
          type="button"
        >
          {props?.primaryBtnText}
        </button>
        <button
          onClick={props?.tertiaryBtnClick}
          type="button"
        >
          {props?.tertiaryBtnText}
        </button>
        <button
          type="button"
          onClick={props?.onClose}
        >
          close
        </button>
      </div>
    </div>
  ))
);

describe("LedgerTypeModal Component", () => {
  const mockDispatch = jest.fn();

  const mockState = {
    ledgerTypes: {
      ledgerTypes: [],
      columnDef: [],
      status: STATUS.IDLE,
      selectedLedgerType: { ledger_type: "Type1" }
    },
    ledgerBrowse: {
      filterState: {}
    }
  };

  const mockProps = {
    isOpen: true,
    setIsOpen: jest.fn(),
    setIsDisabled: jest.fn()
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<LedgerTypeModal {...mockProps} />);
    expect(screen.getByText("Modal")).toBeInTheDocument();
    expect(screen.getByText("GridTableNew")).toBeInTheDocument();
    expect(screen.getByText("LedgerTypeFilters")).toBeInTheDocument();
  });

  it("should handle primary button click and set row", () => {
    render(<LedgerTypeModal {...mockProps} />);
    fireEvent.click(screen.getByText("common.select"));
    expect(mockDispatch).toHaveBeenCalledWith(ledgerTypeActions.selectRow(mockState.ledgerTypes.selectedLedgerType));
    expect(mockDispatch).toHaveBeenCalledWith(
      ledgersActions.setFilters(
        expect.objectContaining({
          ...mockState.ledgerBrowse.filterState,
          ledgerType: mockState.ledgerTypes.selectedLedgerType.ledger_type,
          lookingFor: "",
          pageNumber: 1,
          excludeBalanceSheetAccounts: false
        })
      )
    );
    expect(mockProps.setIsDisabled).toHaveBeenCalledWith(true);
    expect(mockProps.setIsOpen).toHaveBeenCalledWith(false);
    expect(mockDispatch).toHaveBeenCalledWith(ledgerTypeActions.resetFilters());
  });

  it("should handle tertiary button click and reset filters", () => {
    render(<LedgerTypeModal {...mockProps} />);
    fireEvent.click(screen.getByText("common.cancel"));
    expect(mockProps.setIsOpen).toHaveBeenCalledWith(false);
    expect(mockDispatch).toHaveBeenCalledWith(ledgerTypeActions.resetFilters());
  });

  it("should handle modal close and reset filters", () => {
    render(<LedgerTypeModal {...mockProps} />);
    fireEvent.click(screen.getByText("close"));
    expect(mockProps.setIsOpen).toHaveBeenCalledWith(false);
    expect(mockDispatch).toHaveBeenCalledWith(ledgerTypeActions.resetFilters());
  });

  it("should handle row selection", () => {
    render(<LedgerTypeModal {...mockProps} />);
    fireEvent.click(screen.getByText("row"));
  });
});
