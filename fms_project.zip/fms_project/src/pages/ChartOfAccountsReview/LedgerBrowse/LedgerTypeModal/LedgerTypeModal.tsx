import GridTableNew, { RowType } from "@/components/GridTableNew/GridTableNew";
import Modal from "@/components/Modal/Modal";
import { STATUS } from "@/types/UseStateType";
import { useAppSelector } from "@/store/store";
import { useAppContext } from "@/routes/Routes.utils";
import { Dispatch, SetStateAction, useEffect, useState, FC } from "react";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import LedgerTypeFilters from "./Grid/LedgerTypeFilters";
import { ledgerTypeActions } from "../../state/LedgerTypes.slice";
import { ledgersActions } from "../../state/Ledgers.slice";

type PropsType = {
  isOpen: boolean;
  setIsOpen: Dispatch<SetStateAction<boolean>>;
  setIsDisabled: Dispatch<SetStateAction<boolean>>;
};

const LedgerTypeModal: FC<PropsType> = ({ isOpen, setIsOpen, setIsDisabled }) => {
  const dispatch = useDispatch();
  const {
    ledgerTypes: { ledgerTypes, columnDef, status: typesStatus, selectedLedgerType },
    ledgerBrowse: { filterState }
  } = useAppSelector((state) => state);
  const [selectRow, setSelectRow] = useState<RowType | undefined>();
  const { t: locale }: UseTranslationResponse<"translation", {}> = useTranslation();

  useEffect(() => setSelectRow(selectedLedgerType ?? undefined), [selectedLedgerType]);

  const onSetRow = () => {
    if (selectRow) {
      dispatch(ledgerTypeActions.selectRow(selectRow));
      dispatch(
        ledgersActions.setFilters({
          ...filterState,
          ledgerType: selectRow?.ledger_type,
          lookingFor: "",
          pageNumber: 1,
          excludeBalanceSheetAccounts: false
        })
      );
      setIsDisabled(true);
      setIsOpen(false);
      dispatch(ledgerTypeActions.resetFilters());
    }
  };

  const selectedRowHandler = (row?: RowType) => setSelectRow(row);
  return (
    <Modal
      header={locale("ledgerBrowse.ledgerTypeBrowser")}
      isOpen={isOpen}
      className="set__table--hegiht"
      primaryBtnClick={onSetRow}
      tertiaryBtnText={locale("common.cancel")}
      primaryBtnText={locale("common.select")}
      tertiaryBtnClick={() => {
        setIsOpen(false);
        dispatch(ledgerTypeActions.resetFilters());
        setSelectRow(selectedLedgerType);
      }}
      fourthiaryBtnClick={() => {}}
      onClose={() => {
        setIsOpen(false);
        dispatch(ledgerTypeActions.resetFilters());
      }}
      escapeExits
    >
      <GridTableNew
        id="ledgerTypesGrid"
        dataTestId="ledgerTypesGrid"
        filters={<LedgerTypeFilters selectRow={setSelectRow} />}
        columnDef={columnDef}
        dataSource={ledgerTypes || []}
        selectedRow={selectRow}
        isScrollable
        enableScrollIntoView
        isLoading={typesStatus === STATUS.LOADING}
        selectedRowHandler={selectedRowHandler}
        onEnterKeyPress={onSetRow}
      />
    </Modal>
  );
};

export default LedgerTypeModal;
