import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

export default [
  {
    headerName: "Type",
    field: "ledger_type",
    align: "left",
    sequence: true
  },
  {
    headerName: "Description",
    field: "description",
    align: "left",
    sequence: true
  }
] as TColumnDef;
