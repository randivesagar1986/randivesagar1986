import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { STATUS } from "@/types/UseStateType";
import { ledgerTypeActions } from "../../../../state/LedgerTypes.slice";
import LedgerTypeFilters from "../LedgerTypeFilters";
import columnDef from "../LedgerTypesColumnDef";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("@essnextgen/ui-kit", () => ({
  CheckBox: jest.fn((props: any) => (
    <input
      type="checkbox"
      id="checkBox"
      {...props}
    />
  )),
  RadioButton: jest.fn((props: any) => (
    <input
      type="radio"
      id="radio"
      {...props}
    />
  )),
  TextInput: jest.fn((props: any) => (
    <input
      data-testid={props?.dataTestId}
      type="text"
      id="textInput"
      {...props}
    />
  )),
  Grid: jest.fn((props: any) => (
    <div
      {...props}
      id="grid"
    >
      {props?.children}
    </div>
  )),
  GridItem: jest.fn((props: any) => (
    <div
      {...props}
      id="gridItem"
    >
      {props?.children}
    </div>
  )),
  FormLabel: jest.fn((props: any) => (
    <div
      {...props}
      id="label"
    >
      {props?.children}
    </div>
  )),
  RadioLabelPosition: {
    Right: "right"
  },
  TextInputSize: {
    Medium: "medium"
  }
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("../../../../state/LedgerTypes.slice", () => ({
  ledgerTypeActions: {
    setFilters: jest.fn(),
    setColumnDef: jest.fn()
  }
}));

jest.mock("@/hooks/useDebounce", () => jest.fn((value) => value));
jest.mock("@/hooks/useNearestSearch", () => jest.fn());

describe("LedgerTypeFilters Component", () => {
  const mockDispatch = jest.fn();

  const mockState = {
    ledgerTypes: {
      status: STATUS.IDLE,
      ledgerTypes: [],
      filters: {
        lookingFor: "",
        sequenceValue: ""
      }
    }
  };

  const mockProps = {
    selectRow: jest.fn()
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<LedgerTypeFilters {...mockProps} />);
    expect(screen.getByText("purchaseOrder.lookingFor")).toBeInTheDocument();
    expect(screen.getByText("purchaseOrder.sequence")).toBeInTheDocument();
  });

  it("should call setFilters when the input value changes", () => {
    render(<LedgerTypeFilters {...mockProps} />);
    fireEvent.change(screen.getByRole("textbox"), { target: { value: "test" } });
    expect(mockDispatch).toHaveBeenCalledWith(ledgerTypeActions.setFilters({ lookingFor: "TEST" }));
  });

  it("should prevent non-alphanumeric characters in the input", () => {
    render(<LedgerTypeFilters {...mockProps} />);
    const input = screen.getByRole("textbox");
    fireEvent.keyDown(input, { key: "!" });
    expect(input).toHaveValue("");
  });

  it("should allow alphanumeric characters in the input", () => {
    render(<LedgerTypeFilters {...mockProps} />);
    const input = screen.getByRole("textbox");
    fireEvent.keyDown(input, { key: "a" });
    fireEvent.change(input, { target: { value: "a" } });
    expect(mockDispatch).toHaveBeenCalledWith(ledgerTypeActions.setColumnDef(expect.any(Array)));
  });

  it("should call setFilters and setColumnDef when the sequence is changed", () => {
    render(<LedgerTypeFilters {...mockProps} />);
    const seqRadios = screen.getAllByRole("radio");
    fireEvent.click(seqRadios[0]);
    expect(mockDispatch).toHaveBeenCalledWith(
      ledgerTypeActions.setFilters({
        lookingFor: "",
        sequenceValue: columnDef[0].field,
        sequenceIndex: "0"
      })
    );
    expect(mockDispatch).toHaveBeenCalledWith(ledgerTypeActions.setColumnDef(expect.any(Array)));
  });

  it("should handle arrow key navigation for sequence change", () => {
    render(<LedgerTypeFilters {...mockProps} />);
    const sequenceDiv = screen.getByTestId("sequence-outer-div");
    fireEvent.keyDown(sequenceDiv, { key: "ArrowDown" });
    expect(mockDispatch).toHaveBeenCalledWith(
      ledgerTypeActions.setFilters({
        lookingFor: "",
        sequenceValue: columnDef[1].field,
        sequenceIndex: "1"
      })
    );
  });
});
