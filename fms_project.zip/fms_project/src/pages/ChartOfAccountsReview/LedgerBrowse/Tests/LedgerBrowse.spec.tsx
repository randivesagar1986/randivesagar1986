import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider, useDispatch } from "react-redux";
import { BrowserRouter as Router, useParams, useHistory } from "react-router-dom";
import configureStore from "redux-mock-store";
import { useAppSelector } from "@/store/store";
import LedgerBrowse from "../LedgerBrowse";
import * as ledgersSlice from "../../state/Ledgers.slice";
import * as ledgerGroupsSlice from "../../state/LedgerGroups.slice";
import * as ledgerTypesSlice from "../../state/LedgerTypes.slice";

jest.mock("react-router-dom", () => {
  const actual = jest.requireActual("react-router-dom");
  return {
    ...actual,
    useParams: jest.fn(),
    useHistory: jest.fn()
  };
});

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn().mockImplementation((selector) => selector(initialState))
}));

jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn()
}));

const mockStore = configureStore([]);

const initialState = {
  ledgerBrowse: {
    ledgers: {
      ledgerCodes: ["ledger1", "ledger2"],
      currentPage: 1,
      pageSize: 10,
      totalPages: 5
    },
    selectedLedger: null,
    filterState: {
      excludeBalanceSheetAccounts: false,
      excludeNonZeroValues: false
    },
    status: "STATUS.SUCCESS"
  },
  ledgerGroups: {
    status: "STATUS.SUCCESS"
  },
  ledgerTypes: {
    ledgerTypes: [],
    filters: {},
    status: "STATUS.SUCCESS"
  },
  supplierCatalogue: {
    catalogueData: null,
    status: "idle"
  },
  glCentreLedgerLinksView: {
    availableCostCentreList: [],
    availableLedgerCodeList: []
  },
  ui: {
    alert: ""
  }
};

const mockPropsforInputNumberMask = {
  onChange: jest.fn(),
  name: "mockName",
  value: "12345.67",
  className: "mockClassName",
  validationTextLevel: undefined,
  onValueChange: jest.fn(),
  getInputRef: jest.fn(),
  onKeyDown: jest.fn(),
  beforeDecimalMaxLength: 5,
  onBlur: jest.fn(),
  beforeDecimalCursorIndex: 2,
  afterDecimalCursorIndex: 2,
  allowNegative: true
  // Add any additional props required by NumericFormatProps
};

// Mock the action creators in the LedgerGroups.slice module
jest.mock("../../state/LedgerGroups.slice", () => ({
  getLedgerGroups: jest.fn(),
  ledgerGroupActions: {
    setGroup: jest.fn()
  }
}));

jest.mock("../../state/Ledgers.slice", () => ({
  getLedgers: jest.fn(),
  ledgersActions: {
    resetFilters: jest.fn(),
    selectRow: jest.fn(),
    setFilters: jest.fn()
  }
}));

jest.mock("../../state/LedgerTypes.slice", () => ({
  getLedgerTypes: jest.fn(),
  ledgerTypeActions: {
    selectRow: jest.fn()
  }
}));

// Mock the return value of useHistory
const mockPush = jest.fn();
const mockHistory = {
  location: {
    state: {
      costCentreRecord: {
        cost_id: 123
      }
    }
  },
  block: jest.fn(),
  push: mockPush
};

const InputNumberMask = (props: any, ref: any) => (
  <input
    ref={ref}
    {...props}
  />
);

// Mock the InputNumberMask component
jest.mock("../../../../components/Input/InputNumberMask", () =>
  React.forwardRef((props, ref) => (
    <InputNumberMask
      ref={ref}
      {...props}
    />
  ))
);

describe("LedgerBrowse Component", () => {
  let store: any = mockStore({});
  let mockDispatch: jest.Mock;

  beforeEach(() => {
    store = mockStore(initialState);

    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(initialState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("renders the component", async () => {
    render(
      <Provider store={store}>
        <Router>
          <LedgerBrowse />
        </Router>
      </Provider>
    );
    await waitFor(() => {
      const element = screen.getByTestId("ledgerGridLayout");
      expect(element).toBeInTheDocument();
    });
  });

  test("fetches ledger groups on mount", async () => {
    render(
      <Provider store={store}>
        <Router>
          <LedgerBrowse />
        </Router>
      </Provider>
    );

    await waitFor(() => {
      expect(ledgerGroupsSlice.getLedgerGroups).toHaveBeenCalled();
    });
  });

  test("fetches ledger types when filters change", async () => {
    const newFilterState = { ...initialState.ledgerBrowse.filterState, sequenceIndex: 1 };
    (useAppSelector as jest.Mock).mockImplementation((selector) =>
      selector({ ...initialState, ledgerBrowse: { ...initialState.ledgerBrowse, filterState: newFilterState } })
    );

    render(
      <Provider store={store}>
        <Router>
          <LedgerBrowse />
        </Router>
      </Provider>
    );

    await waitFor(() => {
      expect(ledgerTypesSlice.getLedgerTypes).toHaveBeenCalled();
    });
  });

  test("handles keyup event for selected ledger", async () => {
    const selectedLedger = "ledger1";

    const updatedInitialState = {
      ...initialState,
      ledgerBrowse: {
        ...initialState.ledgerBrowse,
        selectedLedger,
        ledgers: {
          ...initialState.ledgerBrowse.ledgers,
          ledgerCodes: [selectedLedger]
        }
      }
    };

    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(updatedInitialState));

    render(
      <Provider store={mockStore(updatedInitialState)}>
        <Router>
          <LedgerBrowse />
        </Router>
      </Provider>
    );

    await waitFor(() => {
      expect(screen.getByTestId("ledgerGridLayout")).toBeInTheDocument();
    });

    const elementId = `rowIndex-ledgerGrid-${selectedLedger}`;
    const element = document.createElement("div");
    element.id = elementId;
    document.body.appendChild(element);

    const event = new KeyboardEvent("keyup", { key: "Enter", keyCode: 13 });
    element.dispatchEvent(event);

    await waitFor(() => {
      expect(mockDispatch).toHaveBeenCalledWith(ledgersSlice.ledgersActions.resetFilters());

      expect(mockPush).toHaveBeenCalledWith({
        pathname: "/general-ledger/chart-accounts-review",
        state: expect.objectContaining({ ledgerRecord: selectedLedger })
      });
    });
  });

  test("unblocks navigation when component unmounts", async () => {
    const unblockMock = jest.fn();
    mockHistory.block.mockImplementation((callback) => unblockMock);

    const { unmount } = render(
      <Provider store={store}>
        <Router>
          <LedgerBrowse />
        </Router>
      </Provider>
    );

    unmount();
    expect(unblockMock).toHaveBeenCalled();
  });

  test("dispatches resetFilters when ledger filter changes", async () => {
    const selectedLedger = "ledger1";
    (useAppSelector as jest.Mock).mockImplementation((selector) =>
      selector({
        ...initialState,
        ledgerBrowse: { ...initialState.ledgerBrowse, selectedLedger }
      })
    );

    render(
      <Provider store={store}>
        <Router>
          <LedgerBrowse />
        </Router>
      </Provider>
    );

    await waitFor(() => {
      const element = document.getElementById(`rowIndex-ledgerGrid-${selectedLedger}`);
      if (element) {
        const event = new KeyboardEvent("keyup", { key: "Enter", keyCode: 13 });
        element.dispatchEvent(event);
      }
    });

    await waitFor(() => {
      expect(mockDispatch).toHaveBeenCalledWith(ledgersSlice.ledgersActions.resetFilters());
    });
  });
});
