import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider, useDispatch } from "react-redux";
import { BrowserRouter as Router, useParams, MemoryRouter } from "react-router-dom";
import configureStore from "redux-mock-store";
import { useAppSelector } from "@/store/store";
import LedgerBrowserFilters from "../Grid/LedgerBrowserFilters";
import { ledgerGroupActions } from "../../state/LedgerGroups.slice";
import { ledgersActions } from "../../state/Ledgers.slice";
import { ledgerTypeActions } from "../../state/LedgerTypes.slice";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn().mockImplementation((selector) => selector(initialState))
}));

jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn()
}));

const initialState = {
  ledgerGroups: {
    ledgerGroups: [{ group_id: 1, group_des: "Group 1" }],
    selectedGroup: { text: "Assets", value: 1 },
    status: "idle"
  },
  ledgerBrowse: {
    ledgers: [],
    filterState: {
      lookingFor: "",
      excludeNonZeroValues: false,
      excludeBalanceSheetAccounts: false,
      groupId: null,
      ledgerTypeDesc: ""
    }
  },
  ledgerTypes: {
    ledgerTypes: [{ ledger_type: "Type 1", description: "Type 1 Description" }],
    selectedLedgerType: { ledger_type: "Type 1", description: "Type 1 Description" }
  }
};

// Mock the actions
jest.mock("../../state/Ledgers.slice", () => ({
  ledgersActions: {
    setFilters: jest.fn(),
    resetFilters: jest.fn()
  }
}));

jest.mock("../../state/LedgerGroups.slice", () => ({
  ledgerGroupActions: {
    setGroup: jest.fn()
  }
}));

jest.mock("../../state/LedgerTypes.slice", () => ({
  ledgerTypeActions: {
    selectRow: jest.fn()
  }
}));

const mockStore = configureStore([]);

const renderComponent = (storeState = initialState, isDisabled = false) => {
  const store = mockStore(storeState);
  const setIsDisabled = jest.fn();
  const isOpen = jest.fn();

  render(
    <Provider store={store}>
      <MemoryRouter>
        <LedgerBrowserFilters
          isOpen={isOpen}
          isDisabled={isDisabled}
          setIsDisabled={setIsDisabled}
        />
      </MemoryRouter>
    </Provider>
  );

  return { store, setIsDisabled, isOpen };
};
describe("LedgerBrowse Component", () => {
  let store: any = mockStore({});
  let mockDispatch: jest.Mock;

  beforeEach(() => {
    store = mockStore(initialState);

    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(initialState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("renders the component", async () => {
    renderComponent();

    await waitFor(() => {
      const element = screen.getByTestId("filter-input");
      expect(element).toBeInTheDocument();
    });
  });

  test("dispatches setFilters action on excludeBalanceSheetAccounts checkbox change", async () => {
    renderComponent();

    const checkbox = screen.getByLabelText(/balanceSheetExclude/i);
    fireEvent.click(checkbox);

    await waitFor(() => {
      expect(ledgersActions.setFilters).toHaveBeenCalledWith({
        ...initialState.ledgerBrowse.filterState,
        excludeBalanceSheetAccounts: true,
        pageNumber: 1
      });
    });
  });

  test("dispatches resetFilters action on reset button click", async () => {
    renderComponent();

    const resetButton = screen.getByText(/reset/i);
    fireEvent.click(resetButton);

    await waitFor(() => {
      expect(ledgersActions.resetFilters).toHaveBeenCalled();
      expect(ledgerTypeActions.selectRow).toHaveBeenCalledWith(undefined);
      expect(ledgerGroupActions.setGroup).toHaveBeenCalledWith({ text: "", value: "" });
    });
  });

  test("dispatches setFilters action on input change", async () => {
    renderComponent();

    const input = screen.getByTestId("filter-input");
    fireEvent.change(input, { target: { value: "Test" } });

    await waitFor(() => {
      expect(ledgersActions.setFilters).toHaveBeenCalledWith(
        expect.objectContaining({
          lookingFor: "TEST",
          pageNumber: 1
        })
      );
    });
  });
});
