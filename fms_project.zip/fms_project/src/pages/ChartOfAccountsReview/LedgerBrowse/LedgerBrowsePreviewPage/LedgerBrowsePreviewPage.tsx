import PreviewSection from "@/shared/components/Preview/PreviewSection";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import useLedgerBrowsePreview from "./useLedgerBrowsePreview";

const LedgerBrowsePreviewPage = () => {
  const { t } = useTranslation();
  const { convertToCsv, convertToPdf, convertToXml, fileObj, isLoading } = useLedgerBrowsePreview();
  const loaderConfig: loadingConfig = {
    isLoaderModal: true,
    loadingText: t("common.downloadingFile")
  };
  return (
    <>
      {isLoading ? <Loader loadingConfig={loaderConfig} /> : null}
      <PreviewSection
        pageTitle={t("generalLedgerSetup.preview")}
        isBreadcrumbRequired
        className="report-preview wrapper__radius--0"
        pdfSrc={fileObj?.fileData}
        onPdfClick={convertToPdf}
        onCsvClick={convertToCsv}
        onXmlClick={convertToXml}
        isLoading={isLoading}
      />
    </>
  );
};

export default LedgerBrowsePreviewPage;
