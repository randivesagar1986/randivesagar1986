import { renderHook, act } from "@testing-library/react-hooks";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import {
  getLedgerBrowseCSV,
  getLedgerBrowsePDF,
  getLedgerBrowseXML
} from "../../../state/ChartOfAccountsReviewList.slice";
import useLedgerBrowsePreview from "../useLedgerBrowsePreview";

// Mock dependencies
jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("../../../state/ChartOfAccountsReviewList.slice", () => ({
  getLedgerBrowseCSV: jest.fn((args: any) => ({
    payload: {
      data: '"Financial year","2024","Fund","All Funds","Cost Centre","All Cost Centres","Ledger Code","All Ledger Codes","Prev. Yr. Actuals","Previous year actuals up to current period","Budget","0","Committed","0.00","Invoiced","0.00","Actual","0.00","C + I + A","0","Budget Remaining","0","R6","Green Abbey School","0903"\r\n"0","O/B","0","0","0","0","0"\r\n"1","Apr","-10000","22513","0","21612.04","-31612.04"\r\n"2","May","0","-23566","0","-25675.78","25675.78"\r\n"3","Jun","0","-20825","0","-24212.6","24212.6"\r\n"4","Jul","0","-23898","0","-24065.46","24065.46"\r\n"5","Aug","0","-24710","0","-29932.11","29932.11"\r\n"6","Sep","0","-22653","0","-2367.21","2367.21"\r\n"7","Oct","-11.5","-12128","0","4840.67","-4852.17"\r\n"8","Nov","46.33","-8570","0","6948.52","-6902.19"\r\n"9","Dec","0","-17881","0","0","0"\r\n"10","Jan","0","-11436","0","0","0"\r\n"11","Feb","0","51268","0","0","0"\r\n"12","Mar","0","315886","0","0","0"\r\n"13","Y/E","0","0","0","0","0"\r\n',
      fileName: "Chart of Accounts Review.csv"
    }
  })),
  getLedgerBrowsePDF: jest.fn((args: any) => ({
    payload: {
      data: {},
      fileName: "Chart of Accounts Review.pdf"
    }
  })),
  getLedgerBrowseXML: jest.fn((args: any) => ({
    payload: {
      data: '<?xml version="1.0" encoding="utf-8"?>\r\n<Report>\r\n  <Params>\r\n    <Param>\r\n      <Name>Financial year</Name>\r\n      <Value>2024</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Fund</Name>\r\n      <Value>All Funds</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Cost Centre</Name>\r\n      <Value>All Cost Centres</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Ledger Code</Name>\r\n      <Value>All Ledger Codes</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Prev. Yr. Actuals</Name>\r\n      <Value>Previous year actuals up to current period</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Budget</Name>\r\n      <Value>0</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Committed</Name>\r\n      <Value>0.00</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Invoiced</Name>\r\n      <Value>0.00</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Actual</Name>\r\n      <Value>0.00</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>C + I + A</Name>\r\n      <Value>0.00</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Budget Remaining</Name>\r\n      <Value>0.00</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>User</Name>\r\n      <Value>R6</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Establishment</Name>\r\n      <Value>Green Abbey School</Value>\r\n    </Param>\r\n    <Param>\r\n      <Name>Establishment Code</Name>\r\n      <Value>0903</Value>\r\n    </Param>\r\n  </Params>\r\n  <Datasets>\r\n    <DataTable>\r\n      <DataRow>\r\n        <period_no>0</period_no>\r\n        <description>O/B</description>\r\n        <actual>0</actual>\r\n        <curr_bud>0</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>0</prev_act>\r\n        <Variance>0</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>1</period_no>\r\n        <description>Apr</description>\r\n        <actual>-10000</actual>\r\n        <curr_bud>22513</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>21612.04</prev_act>\r\n        <Variance>-31612.04</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>2</period_no>\r\n        <description>May</description>\r\n        <actual>0</actual>\r\n        <curr_bud>-23566</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>-25675.78</prev_act>\r\n        <Variance>25675.78</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>3</period_no>\r\n        <description>Jun</description>\r\n        <actual>0</actual>\r\n        <curr_bud>-20825</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>-24212.6</prev_act>\r\n        <Variance>24212.6</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>4</period_no>\r\n        <description>Jul</description>\r\n        <actual>0</actual>\r\n        <curr_bud>-23898</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>-24065.46</prev_act>\r\n        <Variance>24065.46</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>5</period_no>\r\n        <description>Aug</description>\r\n        <actual>0</actual>\r\n        <curr_bud>-24710</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>-29932.11</prev_act>\r\n        <Variance>29932.11</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>6</period_no>\r\n        <description>Sep</description>\r\n        <actual>0</actual>\r\n        <curr_bud>-22653</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>-2367.21</prev_act>\r\n        <Variance>2367.21</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>7</period_no>\r\n        <description>Oct</description>\r\n        <actual>-11.5</actual>\r\n        <curr_bud>-12128</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>4840.67</prev_act>\r\n        <Variance>-4852.17</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>8</period_no>\r\n        <description>Nov</description>\r\n        <actual>46.33</actual>\r\n        <curr_bud>-8570</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>6948.52</prev_act>\r\n        <Variance>-6902.19</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>9</period_no>\r\n        <description>Dec</description>\r\n        <actual>0</actual>\r\n        <curr_bud>-17881</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>0</prev_act>\r\n        <Variance>0</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>10</period_no>\r\n        <description>Jan</description>\r\n        <actual>0</actual>\r\n        <curr_bud>-11436</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>0</prev_act>\r\n        <Variance>0</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>11</period_no>\r\n        <description>Feb</description>\r\n        <actual>0</actual>\r\n        <curr_bud>51268</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>0</prev_act>\r\n        <Variance>0</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>12</period_no>\r\n        <description>Mar</description>\r\n        <actual>0</actual>\r\n        <curr_bud>315886</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>0</prev_act>\r\n        <Variance>0</Variance>\r\n      </DataRow>\r\n      <DataRow>\r\n        <period_no>13</period_no>\r\n        <description>Y/E</description>\r\n        <actual>0</actual>\r\n        <curr_bud>0</curr_bud>\r\n        <orig_bud>0</orig_bud>\r\n        <prev_act>0</prev_act>\r\n        <Variance>0</Variance>\r\n      </DataRow>\r\n    </DataTable>\r\n  </Datasets>\r\n</Report>',
      fileName: "Chart of Accounts Review.xml"
    }
  }))
}));

describe("useLedgerBrowsePreview Hook", () => {
  const mockDispatch = jest.fn((resValue: any) => resValue);
  const mockHistory = {
    location: {
      state: {
        costCentreRecord: { cost_id: 1, cost_des: "Cost Centre", cost_hold: "Holder" },
        excludeNonZeroValues: true,
        excludeBalanceSheetAccounts: false
      }
    }
  };

  const mockState = {
    ledgerGroups: {
      selectedGroup: { value: "1", text: "Group" }
    },
    ledgerTypes: {
      selectedLedgerType: { ledger_type: "Type", description: "Type Description" }
    }
  };

  beforeEach(() => {
    // Mock URL.createObjectURL
    global.URL.createObjectURL = jest.fn((args: any) => {
      // eslint-disable-control-has-associated-label
      const data = JSON.stringify({
        link: {
          href: "blob:https://localhost:3002/f87a3f07-ebc3-4de3-ab1f-e1b2033ce121"
        }
      });
      // eslint-disable-control-has-associated-label
      return data;
    });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    jest.clearAllMocks();
  });

  it("should initialize the hook correctly", () => {
    const { result } = renderHook(() => useLedgerBrowsePreview());

    expect(result.current.fileObj).toEqual({ fileData: "" });
    expect(result.current.isLoading).toBe(false);
  });

  it("should create PDF preview from base64 string on mount", async () => {
    const mockPayload = { data: "pdfdata" };
    (getLedgerBrowsePDF as unknown as jest.Mock).mockResolvedValue({ payload: mockPayload });

    const { result, waitForNextUpdate } = renderHook(() => useLedgerBrowsePreview());

    await waitForNextUpdate();

    expect(mockDispatch).toHaveBeenCalledWith(getLedgerBrowsePDF(expect.any(Object)));
    expect(result.current.fileObj.fileData).toContain("blob:");
  });

  it("should convert to CSV and download the file", async () => {
    const { result } = renderHook(() => useLedgerBrowsePreview());
    const mockPayload = {
      data: "csvdata",
      fileName: "Ledger Browse Report.csv"
    };
    (getLedgerBrowseCSV as unknown as jest.Mock).mockResolvedValue({ payload: mockPayload });

    await act(async () => {
      await result.current.convertToCsv();
    });

    expect(mockDispatch).toHaveBeenCalledWith(getLedgerBrowseCSV(expect.any(Object)));
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([mockPayload.data], { type: "text/csv" }));
    link.download = mockPayload.fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });

  it("should convert to PDF and download the file", async () => {
    const { result } = renderHook(() => useLedgerBrowsePreview());
    const mockPayload = { data: "pdfdata", fileName: "Ledger Browse Report.pdf" };
    (getLedgerBrowsePDF as unknown as jest.Mock).mockResolvedValue({ payload: mockPayload });

    await act(async () => {
      await result.current.convertToPdf();
    });

    expect(mockDispatch).toHaveBeenCalledWith(getLedgerBrowsePDF(expect.any(Object)));
    const blob = new Blob([mockPayload.data], { type: "application/pdf" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = mockPayload.fileName;
    link.click();
  });

  it("should convert to XML and download the file", async () => {
    const { result } = renderHook(() => useLedgerBrowsePreview());
    const mockPayload = {
      data: "xmldata",
      fileName: "Ledger Browse Report.xml"
    };
    (getLedgerBrowseXML as unknown as jest.Mock).mockResolvedValue({ payload: mockPayload });

    await act(async () => {
      await result.current.convertToXml();
    });

    expect(mockDispatch).toHaveBeenCalledWith(getLedgerBrowseXML(expect.any(Object)));
    const blob = new Blob([mockPayload.data], { type: "application/xml" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = mockPayload.fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });
});
