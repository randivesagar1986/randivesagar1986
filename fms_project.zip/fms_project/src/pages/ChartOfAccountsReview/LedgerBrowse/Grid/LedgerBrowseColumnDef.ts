import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

export default [
  {
    headerName: "Code",
    field: "ledger_code",
    align: "left"
  },
  {
    headerName: "Description",
    field: "ledger_des",
    align: "left"
  },
  {
    headerName: "Type",
    field: "ledger_type",
    align: "left"
  },
  {
    headerName: "Fixed Budget",
    field: "orig_bud",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Current Budget",
    field: "curr_bud",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Commitment (CM)",
    field: "commitment",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Invoiced (IV)",
    field: "unpaid",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Current Actual (CA)",
    field: "act",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "CM + IV + CA",
    field: "cia",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Remaining Budget",
    field: "remaining",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "",
    field: "actions",
    align: "left",
    cellRenderer: "GridCellLink"
  }
] as TColumnDef;
