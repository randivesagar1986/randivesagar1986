import Input from "@/components/Input/Input";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  Dropdown,
  DropdownItem,
  FormLabel,
  Grid,
  GridItem,
  ISelectedItem,
  TextInputSize
} from "@essnextgen/ui-kit";
import { useAppContext } from "@/routes/Routes.utils";
import { useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import React, { useState, FC, SyntheticEvent, useEffect, Dispatch, SetStateAction } from "react";
import useDebounce from "@/hooks/useDebounce";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import { useHistory } from "react-router-dom";
import Tooltip from "@/components/Tooltip/Tooltip";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { LedgersFiltersType, ledgersActions } from "../../state/Ledgers.slice";
import { ledgerGroupActions } from "../../state/LedgerGroups.slice";
import { ledgerTypeActions } from "../../state/LedgerTypes.slice";

type PropsType = {
  isOpen: (flag: boolean) => void;
  setIsDisabled: Dispatch<SetStateAction<boolean>>;
  isDisabled: boolean;
};

const LedgerBrowseFilters: FC<PropsType> = ({ isOpen, isDisabled, setIsDisabled }) => {
  const { t: locale }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch();
  const [value, setValue] = useState<string>("");
  const { ledgerGroups, selectedGroup, status } = useAppSelector((state) => state.ledgerGroups);
  const { ledgers } = useAppSelector((state) => state.ledgerBrowse);
  const { ledgerTypes, selectedLedgerType } = useAppSelector((state) => state.ledgerTypes);
  const [ledgerTypeRow, setLedgerTypeRow] = useState<RowType | undefined>(selectedLedgerType);
  const { filterState } = useAppSelector((state) => state.ledgerBrowse);
  const { excludeNonZeroValues, excludeBalanceSheetAccounts, groupId } = filterState as LedgersFiltersType;
  const debouncedValue = useDebounce(value, 600);
  const [search, setSearch] = useState<string | undefined>();
  const history = useHistory();
  const historyState = history.location.state as any;

  const [tooltipText, setTooltipText] = useState(selectedLedgerType?.description as string);
  const [showTooltip, setShowTooltip] = useState<boolean>(false);

  useEffect(() => {
    setSearch(selectedLedgerType?.ledger_type);
    setTooltipText(filterState?.ledgerTypeDesc as string);
    if (debouncedValue) {
      dispatch(
        ledgersActions.setFilters({
          ...filterState,
          lookingFor: debouncedValue.toUpperCase(),
          pageNumber: 1
        })
      );
    }
  }, [debouncedValue]);

  const bankAccountClick = () => {
    isOpen(true);
  };

  return (
    <Grid className="ledger-filters">
      <GridItem
        sm={4}
        md={8}
        lg={12}
        xl={4}
        xxl={5}
      >
        <Grid>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={12}
          >
            <Input
              onKeyDown={(event) => {
                // eslint-disable-next-line
                if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                  event.preventDefault();
                }
              }}
              labelText={locale("common.lookingFor")}
              value={value || filterState.lookingFor}
              dataTestId="filter-input"
              onChange={(e) => {
                if (e.target.value !== "") {
                  setValue(e.target.value.toUpperCase());
                } else {
                  dispatch(
                    ledgersActions.setFilters({
                      ...filterState,
                      lookingFor: "",
                      pageNumber: 1
                    })
                  );
                }
              }}
            />
          </GridItem>
        </Grid>
      </GridItem>
      <GridItem
        sm={4}
        md={8}
        lg={6}
        xl={4}
        xxl={3}
        className="view__type--search--input"
      >
        <Input
          id="ledger-browse-view-type"
          dataTestId="ledger-browse-view-type"
          labelText={locale("ledgerBrowse.viewType")}
          inputWidth={60}
          searchable
          value={search}
          searchItems={ledgerTypes.map((l) => ({
            text: l.ledger_type,
            value: l.description
          }))}
          onNoSelection={() => {
            isOpen(true);
          }}
          onFocus={() => {
            setSearch(undefined);
          }}
          onPending={(selectedItem, index, flag) => {
            setLedgerTypeRow(index ? ledgerTypes.at(index) : undefined);
            if (flag === false) {
              setSearch("");
            }
            if (!selectedItem?.text && flag !== false && flag !== undefined) {
              dispatch(ledgerTypeActions.selectRow(undefined));
              dispatch(
                ledgersActions.setFilters({
                  ...filterState,
                  excludeBalanceSheetAccounts: false,
                  ledgerType: "",
                  lookingFor: "",
                  pageNumber: 1
                })
              );
            }
          }}
          onSelect={(selectedItem) => {
            if (selectedItem?.text) {
              setIsDisabled(true);
              dispatch(ledgerTypeActions.selectRow(ledgerTypes.find((t) => t.ledger_type === selectedItem?.text)));
              dispatch(
                ledgersActions.setFilters({
                  ...filterState,
                  ledgerType: selectedItem?.text,
                  lookingFor: "",
                  pageNumber: 1
                })
              );
            }
          }}
          button={
            <Input
              className="read-only"
              id="ledger-type-description-input"
              searchBtnClick={bankAccountClick}
              value={ledgerTypeRow?.description ?? ""}
              disabled
            />
          }
        />
      </GridItem>

      <GridItem
        sm={4}
        md={8}
        lg={5}
        xl={3}
        xxl={3}
        className="d-flex f-direction-col gap-8 mt-24"
      >
        <CheckBox
          dataTestId="ledgerBrowse-ledgerCodeExclude"
          isSelected={excludeNonZeroValues === true}
          onChange={(e) => {
            dispatch(
              ledgersActions.setFilters({
                ...filterState,
                excludeNonZeroValues: !excludeNonZeroValues,
                pageNumber: 1
              })
            );
          }}
          label={locale("ledgerBrowse.ledgerCodeExclude")}
        />

        <CheckBox
          dataTestId="ledgerBrowse-balanceSheetExclude"
          isSelected={
            excludeBalanceSheetAccounts === true &&
            !(isDisabled || historyState?.costCentreRecord?.cost_id !== undefined)
          }
          onChange={(e) => {
            dispatch(
              ledgersActions.setFilters({
                ...filterState,
                excludeBalanceSheetAccounts:
                  !excludeBalanceSheetAccounts &&
                  !(isDisabled || historyState?.costCentreRecord?.cost_id !== undefined),
                pageNumber: 1
              })
            );
          }}
          label={locale("ledgerBrowse.balanceSheetExclude")}
          disabled={isDisabled || historyState?.costCentreRecord?.cost_id !== undefined}
        />
      </GridItem>

      <GridItem className="mt-24">
        <Button
          color={ButtonColor.Secondary}
          size={ButtonSize.Small}
          onClick={() => {
            dispatch(ledgersActions.resetFilters());
            dispatch(ledgerTypeActions.selectRow(undefined));
            dispatch(ledgerGroupActions.setGroup({ text: "", value: "" }));
            setIsDisabled(false);
          }}
        >
          {locale("ledgerBrowse.reset")}
        </Button>
      </GridItem>
      <GridItem
        sm={4}
        md={4}
        lg={6}
        xl={12}
        className="view__group--dropdown--full-width"
      >
        <FormLabel>{locale("ledgerBrowse.viewGroup")}</FormLabel>
        <div
          style={{ position: "relative" }}
          onMouseLeave={() => setShowTooltip(false)}
        >
          <Dropdown
            size={TextInputSize.Medium}
            searchable
            selectedItem={selectedGroup}
            isScrollbarVisible
            dataTestId="viewGroupDropdown"
            className="width-revert view-group-dropdown dropdown-filters set__table--hegiht"
            onSelect={(e: SyntheticEvent, item: ISelectedItem) => {
              setIsDisabled(true);
              dispatch(ledgerGroupActions.setGroup(item));
              dispatch(
                ledgersActions.setFilters({
                  ...filterState,
                  lookingFor: "",
                  excludeBalanceSheetAccounts: false,
                  pageNumber: 1,
                  groupId: Number(item.value),
                  ledgerTypeDesc: item.text
                })
              );
            }}
            onKeyDown={(e: React.KeyboardEvent) => {
              const numbersArray = Array.from({ length: 10 }, (_, index) => index.toString());
              const lengthDrop = (e.target as HTMLInputElement).value;
              if (lengthDrop.trim().length > 31 && numbersArray.includes(e.key)) {
                e.preventDefault();
              }
            }}
            scrollbarHeight={Number(ledgers?.totalCount || 0) <= 3 ? 120 : undefined}
          >
            {(ledgerGroups || []).map((view: { [key: string]: string }, i: any) => {
              const id = `dropdown-group-${i}`;
              return (
                <DropdownItem
                  key={id}
                  id={id}
                  text={view.group_des}
                  value={view.group_id}
                >
                  {view?.group_des}
                </DropdownItem>
              );
            })}
          </Dropdown>
          {showTooltip && tooltipText && <Tooltip text={tooltipText} />}
        </div>
      </GridItem>
    </Grid>
  );
};

export default LedgerBrowseFilters;
