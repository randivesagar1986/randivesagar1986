import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { specialCharacters } from "@/types/UseStateType";
import CustomCell from "../CustomCell";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("@essnextgen/ui-kit", () => ({
  Button: jest.fn((props: any) => (
    <button
      type="button"
      id="button"
      {...props}
      onClick={props?.onClick}
    >
      {props?.children}
    </button>
  )),
  ButtonColor: {
    Utility: "utility"
  }
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

describe("CustomCell Component", () => {
  const mockHistory = {
    push: jest.fn(),
    location: {
      state: {}
    }
  };

  const mockState = {
    ledgerRecord: { id: 1 }
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    (useDispatch as jest.Mock).mockReturnValue(jest.fn());
    jest.clearAllMocks();
  });

  it("should render the actions button and handle click", () => {
    const row = { id: 1 };
    render(
      <CustomCell
        field="actions"
        row={row}
      />
    );
    screen.debug();
    const button = screen.getByText("common.select");
    expect(button).toBeInTheDocument();
    fireEvent.click(button);
    expect(mockHistory.push).toHaveBeenCalledWith(
      {
        pathname: "/general-ledger/chart-accounts-review"
      },
      { ...mockHistory.location.state, ledgerRecord: row }
    );
  });

  it("should render the formatted orig_bud value", () => {
    const row = { orig_bud: 1234.56 };
    render(
      <CustomCell
        field="orig_bud"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for orig_bud when it is zero", () => {
    const row = { orig_bud: 0 };
    render(
      <CustomCell
        field="orig_bud"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted curr_bud value", () => {
    const row = { curr_bud: 1234.56 };
    render(
      <CustomCell
        field="curr_bud"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for curr_bud when it is zero", () => {
    const row = { curr_bud: 0 };
    render(
      <CustomCell
        field="curr_bud"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted commitment value", () => {
    const row = { commitment: 1234.56 };
    render(
      <CustomCell
        field="commitment"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for commitment when it is zero", () => {
    const row = { commitment: 0 };
    render(
      <CustomCell
        field="commitment"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted unpaid value", () => {
    const row = { unpaid: 1234.56 };
    render(
      <CustomCell
        field="unpaid"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for unpaid when it is zero", () => {
    const row = { unpaid: 0 };
    render(
      <CustomCell
        field="unpaid"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted act value", () => {
    const row = { act: 1234.56 };
    render(
      <CustomCell
        field="act"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for act when it is zero", () => {
    const row = { act: 0 };
    render(
      <CustomCell
        field="act"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted cia value", () => {
    const row = { cia: 1234.56 };
    render(
      <CustomCell
        field="cia"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for cia when it is zero", () => {
    const row = { cia: 0 };
    render(
      <CustomCell
        field="cia"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted remaining value", () => {
    const row = { remaining: 1234.56 };
    render(
      <CustomCell
        field="remaining"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for remaining when it is zero", () => {
    const row = { remaining: 0 };
    render(
      <CustomCell
        field="remaining"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render null when field is not matched", () => {
    const row = { narrative: "Test Narrative" };
    const { container } = render(
      <CustomCell
        field="other_field"
        row={row}
      />
    );
    expect(container).toBeEmptyDOMElement();
  });
});
