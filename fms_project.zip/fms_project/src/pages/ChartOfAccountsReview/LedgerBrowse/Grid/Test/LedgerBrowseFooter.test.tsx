import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { canDo } from "@/store/state/userAccessRights.slice";
import { usNumberFormat } from "@/utils/getDataSource";
import { ledgersActions } from "../../../state/Ledgers.slice";
import LedgerBrowseFooter from "../LedgerBrowseFooter";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("../../../state/Ledgers.slice", () => ({
  ledgersActions: {
    resetFilters: jest.fn()
  }
}));

jest.mock("@/components/Layout/Layout", () => jest.fn((props) => <div {...props}>Layout</div>));
jest.mock("@/components/OpenLinkButton/HelpButton", () =>
  jest.fn((props) => (
    <button
      type="button"
      {...props}
    >
      HelpButton
    </button>
  ))
);
jest.mock("@/utils/getDataSource", () => ({
  usNumberFormat: jest.fn((value) => value)
}));

describe("LedgerBrowseFooter Component", () => {
  const mockDispatch = jest.fn();
  const mockHistory = {
    push: jest.fn(),
    location: {
      state: {}
    }
  };

  const mockState = {
    ledgerBrowse: {
      ledgers: {
        budget: 1000,
        commitment: 2000,
        invoiced: 3000,
        actual: 4000,
        total: 5000,
        remaining: 6000,
        ledgerCodes: [1, 2, 3]
      },
      selectedLedger: { id: 1 },
      status: STATUS.SUCCESS,
      filterState: {
        excludeBalanceSheetAccounts: true,
        excludeNonZeroValues: false
      }
    },
    ledgerTypes: {
      status: STATUS.SUCCESS
    },
    ledgerGroups: {
      status: STATUS.SUCCESS
    },
    userAccessRights: {}
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<LedgerBrowseFooter />);
    expect(screen.getByText("Layout")).toBeInTheDocument();
    expect(screen.getByText("HelpButton")).toBeInTheDocument();
    expect(screen.getByText("ledgerBrowse.budget")).toBeInTheDocument();
    expect(screen.getByText("ledgerBrowse.commitment")).toBeInTheDocument();
    expect(screen.getByText("ledgerBrowse.invoiced")).toBeInTheDocument();
    expect(screen.getByText("ledgerBrowse.actual")).toBeInTheDocument();
    expect(screen.getByText("ledgerBrowse.total")).toBeInTheDocument();
    expect(screen.getByText("ledgerBrowse.remaining")).toBeInTheDocument();
  });

  it("should call onSelectLedger when the select button is clicked", () => {
    render(<LedgerBrowseFooter />);
    fireEvent.click(screen.getByText("generalLedgerSetup.select"));
    expect(mockDispatch).toHaveBeenCalledWith(ledgersActions.resetFilters());
    expect(mockHistory.push).toHaveBeenCalledWith(
      {
        pathname: "/general-ledger/chart-accounts-review"
      },
      { ...mockHistory.location.state, ledgerRecord: mockState.ledgerBrowse.selectedLedger }
    );
  });

  it("should call handlePreviewClick and navigate to preview page", () => {
    render(<LedgerBrowseFooter />);
    fireEvent.click(screen.getByText("generalLedgerSetup.preview"));
    expect(mockHistory.push).toHaveBeenCalledWith("/general-ledger/chart-accounts-review/preview", {
      ...mockHistory.location.state
    });
  });

  it("should call resetFilters and navigate to chart accounts review page when cancel button is clicked", () => {
    render(<LedgerBrowseFooter />);
    fireEvent.click(screen.getByText("common.cancel"));
    expect(mockDispatch).toHaveBeenCalledWith(ledgersActions.resetFilters());
    expect(mockHistory.push).toHaveBeenCalledWith(
      {
        pathname: "/general-ledger/chart-accounts-review"
      },
      {
        ...mockHistory.location.state,
        excludeBalanceSheetAccounts: mockState.ledgerBrowse.filterState.excludeBalanceSheetAccounts,
        excludeNonZeroValues: mockState.ledgerBrowse.filterState.excludeNonZeroValues
      }
    );
  });

  it("should disable the select button when ledgers are not loaded", () => {
    (useAppSelector as jest.Mock).mockImplementation((selector) =>
      selector({
        ...mockState,
        ledgerBrowse: {
          ...mockState.ledgerBrowse,
          status: STATUS.LOADING
        }
      })
    );

    render(<LedgerBrowseFooter />);
    expect(screen.getByText("generalLedgerSetup.select")).toBeDisabled();
  });

  it("should disable the preview button when user does not have print access", () => {
    (canDo as jest.Mock).mockReturnValue(false);
    render(<LedgerBrowseFooter />);
    expect(screen.getByText("generalLedgerSetup.preview")).toBeDisabled();
  });
});
