import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { useHistory } from "react-router-dom";
import { ledgersActions } from "../../../state/Ledgers.slice";
import { ledgerGroupActions } from "../../../state/LedgerGroups.slice";
import { ledgerTypeActions } from "../../../state/LedgerTypes.slice";
import LedgerBrowseFilters from "../LedgerBrowserFilters";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("../../../state/Ledgers.slice", () => ({
  ledgersActions: {
    setFilters: jest.fn(),
    resetFilters: jest.fn()
  }
}));

jest.mock("../../../state/LedgerGroups.slice", () => ({
  ledgerGroupActions: {
    setGroup: jest.fn()
  }
}));

jest.mock("../../../state/LedgerTypes.slice", () => ({
  ledgerTypeActions: {
    selectRow: jest.fn()
  }
}));

jest.mock("@/components/Input/Input", () =>
  jest.fn((props) => (
    <input
      type="text"
      data-testid={props?.dataTestId}
      {...props}
    />
  ))
);
jest.mock("@/components/Tooltip/Tooltip", () => jest.fn((props) => <div {...props}>Tooltip</div>));
jest.mock("@essnextgen/ui-kit", () => ({
  Button: jest.fn((props) => (
    <button
      type="button"
      {...props}
    />
  )),
  ButtonColor: { Secondary: "secondary" },
  ButtonSize: { Small: "small" },
  CheckBox: jest.fn((props) => (
    <input
      type="checkbox"
      data-testid={props?.dataTestId}
      {...props}
    />
  )),
  Dropdown: jest.fn((props) => (
    <select
      onSelect={props?.onSelect}
      data-testid={props?.dataTestId}
      {...props}
    />
  )),
  DropdownItem: jest.fn((props) => <option {...props} />),
  FormLabel: jest.fn((props) => (
    <div
      id="label"
      {...props}
    >
      {props?.children}
    </div>
  )),
  Grid: jest.fn((props) => <div {...props} />),
  GridItem: jest.fn((props) => <div {...props} />),
  TextInputSize: { Medium: "medium" }
}));

describe("LedgerBrowseFilters Component", () => {
  const mockDispatch = jest.fn();

  const mockState = {
    ledgerGroups: {
      ledgerGroups: [],
      selectedGroup: { text: "Group1", value: "1" },
      status: "idle"
    },
    ledgerBrowse: {
      ledgers: [],
      filterState: {
        lookingFor: "",
        excludeNonZeroValues: false,
        excludeBalanceSheetAccounts: false,
        groupId: ""
      }
    },
    ledgerTypes: {
      ledgerTypes: [],
      selectedLedgerType: { ledger_type: "Type1", description: "Description1" }
    }
  };

  const mockProps = {
    isOpen: jest.fn(),
    setIsDisabled: jest.fn(),
    isDisabled: false
  };

  const mockHistory = {
    location: {
      state: {}
    }
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<LedgerBrowseFilters {...mockProps} />);
    expect(screen.getByTestId("filter-input")).toBeInTheDocument();
    expect(screen.getByTestId("ledger-browse-view-type")).toBeInTheDocument();
    expect(screen.getByTestId("ledgerBrowse-ledgerCodeExclude")).toBeInTheDocument();
    expect(screen.getByTestId("ledgerBrowse-balanceSheetExclude")).toBeInTheDocument();
    expect(screen.getByText("ledgerBrowse.reset")).toBeInTheDocument();
    expect(screen.getByText("ledgerBrowse.viewGroup")).toBeInTheDocument();
  });

  it('should handle input change and set filters if looking for is changed to "test" ', () => {
    render(<LedgerBrowseFilters {...mockProps} />);
    const input = screen.getByTestId("filter-input");
    fireEvent.change(input, { target: { value: "test" } });
  });

  it("should handle checkbox change and set filters", () => {
    render(<LedgerBrowseFilters {...mockProps} />);
    const checkbox = screen.getByTestId("ledgerBrowse-ledgerCodeExclude");
    fireEvent.click(checkbox);
    expect(mockDispatch).toHaveBeenCalledWith(
      ledgersActions.setFilters(
        expect.objectContaining({
          ...mockState.ledgerBrowse.filterState,
          excludeNonZeroValues: true,
          pageNumber: 1
        })
      )
    );
  });

  it("should handle dropdown selection and set filters", () => {
    render(<LedgerBrowseFilters {...mockProps} />);
    const dropdown = screen.getByTestId("viewGroupDropdown");
    fireEvent.change(dropdown, { target: { value: "1" } });
  });

  it("should handle reset button click and reset filters", () => {
    render(<LedgerBrowseFilters {...mockProps} />);
    fireEvent.click(screen.getByText("ledgerBrowse.reset"));
    expect(mockDispatch).toHaveBeenCalledWith(ledgersActions.resetFilters());
    expect(mockDispatch).toHaveBeenCalledWith(ledgerTypeActions.selectRow(undefined));
    expect(mockDispatch).toHaveBeenCalledWith(ledgerGroupActions.setGroup({ text: "", value: "" }));
    expect(mockProps.setIsDisabled).toHaveBeenCalledWith(false);
  });
});
