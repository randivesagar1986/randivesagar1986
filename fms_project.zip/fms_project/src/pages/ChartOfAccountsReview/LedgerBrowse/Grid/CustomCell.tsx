import { cellRendererType } from "@/components/GridTable/GridTable";
import { Button, ButtonColor } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { specialCharacters } from "@/types/UseStateType";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";

const CustomCell = ({ field, row }: cellRendererType) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const historyState = history.location.state as any;
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const onSelectLedger = () => {
    history.push(
      {
        pathname: "/general-ledger/chart-accounts-review"
      },
      { ...historyState, ledgerRecord: row }
    );
  };

  const getContent = () => {
    switch (field) {
      case "actions":
        return (
          <>
            <Button
              color={ButtonColor.Utility}
              className="segments-buttons"
              onClick={onSelectLedger}
            >
              {t("common.select")}
            </Button>
          </>
        );
      case "orig_bud":
        return row?.orig_bud ? <>{numberFormatter.format(row?.orig_bud)}</> : <>{specialCharacters.zero}</>;
      case "curr_bud":
        return row?.curr_bud ? <>{numberFormatter.format(row?.curr_bud)}</> : <>{specialCharacters.zero}</>;
      case "commitment":
        return row?.commitment ? <>{numberFormatter.format(row?.commitment)}</> : <>{specialCharacters.zero}</>;
      case "unpaid":
        return row?.unpaid ? <>{numberFormatter.format(row?.unpaid)}</> : <>{specialCharacters.zero}</>;
      case "act":
        return row?.act ? <>{numberFormatter.format(row?.act)}</> : <>{specialCharacters.zero}</>;
      case "cia":
        return row?.cia ? <>{numberFormatter.format(row?.cia)}</> : <>{specialCharacters.zero}</>;
      case "remaining":
        return row?.remaining ? <>{numberFormatter.format(row?.remaining)}</> : <>{specialCharacters.zero}</>;

      default:
        return null;
    }
  };
  return getContent();
};

export default CustomCell;
