import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { useHistory, useParams } from "react-router-dom";
import { canDo } from "@/store/state/userAccessRights.slice";
import { getFinancialPeriods, getTransactions, financialPeriodActions } from "../../state/financialPeriod.slice";
import TransactionSelectPeriod from "../TransactionSelectPeriod";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("../../state/financialPeriod.slice", () => ({
  financialPeriodActions: {
    setSelectedRow: jest.fn(),
    setFilters: jest.fn(),
    resetSelectedRow: jest.fn()
  },
  getFinancialPeriods: jest.fn(),
  getTransactions: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("@essnextgen/ui-kit", () => ({
  RadioButton: jest.fn((props: any) => (
    <input
      type="radio"
      id="radio"
      {...props}
    />
  )),
  CheckBox: jest.fn((props: any) => (
    <input
      type="checkbox"
      id="checkBox"
      {...props}
    />
  )),
  Button: jest.fn((props: any) => (
    <button
      type="button"
      id="button"
      onClick={props?.onClick}
      {...props}
    >
      {props?.children}
    </button>
  )),
  TextInput: jest.fn((props: any) => (
    <input
      data-testid={props?.dataTestId}
      onKeyDown={props?.onKeyDown}
      type="text"
      id="textInput"
      {...props}
    />
  )),
  Grid: jest.fn((props: any) => (
    <div
      {...props}
      id="grid"
    >
      {props?.children}
    </div>
  )),
  GridItem: jest.fn((props: any) => (
    <div
      {...props}
      id="gridItem"
    >
      {props?.children}
    </div>
  )),
  FormLabel: jest.fn((props: any) => (
    <div
      {...props}
      id="label"
    >
      {props?.children}
    </div>
  )),
  TextInputSize: {
    Medium: "medium"
  },
  RadioLabelPosition: {
    Right: "right"
  },
  ButtonColor: {
    Secondary: "secondary"
  },
  ButtonSize: {
    Small: "small"
  },
  Divider: jest.fn(() => <br />),
  Pagination: jest.fn((props: any) => (
    <div
      {...props}
      id="pagination"
      onChange={props?.onChange}
    >
      Pagination
    </div>
  ))
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn(),
  useParams: jest.fn()
}));

jest.mock("@/components/Layout/Layout", () => ({
  __esModule: true,
  default: jest.fn((props) => (
    <div
      {...props}
      data-testid={props?.dataTestId}
    >
      {props?.children}
    </div>
  ))
}));

jest.mock("@/components/GridTableNew/GridTableNew", () =>
  jest.fn((props) => (
    <div
      {...props}
      data-testid={props?.dataTestId}
    >
      {props?.footer}
    </div>
  ))
);
jest.mock("@/components/OpenLinkButton/HelpButton", () =>
  jest.fn((props) => (
    <button
      type="button"
      {...props}
    >
      HelpButton
    </button>
  ))
);
jest.mock("@/components/Loader/Loader", () => jest.fn((props) => <div {...props}>Loader</div>));
jest.mock("../useTransactionSelectPeriod", () =>
  jest.fn(() => ({
    t: (key: string) => key,
    selectedTransactionRow: null,
    selectedRowHandler: jest.fn(),
    historyState: {},
    onCloseHandler: jest.fn(),
    onSelectHandler: jest.fn()
  }))
);

describe("TransactionSelectPeriod Component", () => {
  const mockDispatch = jest.fn();
  const mockHistoryPush = jest.fn();
  const mockHistory = {
    push: mockHistoryPush,
    location: {
      pathname: "/test-path",
      state: {}
    },
    block: jest.fn()
  };

  const mockParams = {
    fromDate: "2021-01-01",
    toDate: "2021-12-31"
  };

  const mockState = {
    financialPeriods: {
      transactionStatus: STATUS.IDLE,
      filters: {},
      transactionDetails: {
        tranDetails: [],
        pageSize: 10,
        currentPage: 1,
        totalPages: 1
      }
    },
    fundCode: {
      selectedfundCode: null
    },
    userAccessRights: {}
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    (useParams as jest.Mock).mockReturnValue(mockParams);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<TransactionSelectPeriod />);
    expect(screen.getByTestId("transactionBrowse-layout-one")).toBeInTheDocument();
    expect(screen.getByText("generalLedgerSetup.periodFrom")).toBeInTheDocument();
    expect(screen.getByText("generalLedgerSetup.to")).toBeInTheDocument();
    expect(screen.getByText("generalLedgerSetup.cost")).toBeInTheDocument();
    expect(screen.getByText("generalLedgerSetup.ledger")).toBeInTheDocument();
    expect(screen.getByText("generalLedgerSetup.fund")).toBeInTheDocument();
  });

  it("should call getFinancialPeriods and getTransactions on mount", () => {
    render(<TransactionSelectPeriod />);
    expect(mockDispatch).toHaveBeenCalledWith(getFinancialPeriods({ status: 0, callback: expect.any(Function) }));
    expect(mockDispatch).toHaveBeenCalledWith(getTransactions(expect.any(Object)));
  });

  it("should call setFilters and getTransactionsDetails on page change", () => {
    render(<TransactionSelectPeriod />);
    fireEvent.click(screen.getByText("Pagination"));
    expect(mockDispatch).toHaveBeenCalledWith(financialPeriodActions.setFilters(expect.any(Object)));
    expect(mockDispatch).toHaveBeenCalledWith(getTransactions(expect.any(Object)));
  });

  it("should call handlePreviewClick and navigate to preview page", () => {
    render(<TransactionSelectPeriod />);
    fireEvent.click(screen.getByText("generalLedgerSetup.preview"));
  });

  it("should call onCloseHandler when the close button is clicked", () => {
    render(<TransactionSelectPeriod />);
    fireEvent.click(screen.getByText("generalLedgerSetup.close"));
    expect(screen.getByText("generalLedgerSetup.close")).toBeInTheDocument();
  });

  it("should render Loader when isLoading is true", () => {
    (useAppSelector as jest.Mock).mockImplementation((selector) =>
      selector({
        ...mockState,
        financialPeriods: {
          ...mockState.financialPeriods,
          transactionStatus: STATUS.LOADING
        }
      })
    );

    render(<TransactionSelectPeriod />);
    expect(screen.getByText("Loader")).toBeInTheDocument();
  });

  it("should handle row selection", () => {
    render(<TransactionSelectPeriod />);
    fireEvent.click(screen.getByTestId("testGrid"));
  });

  it("should handle keydown event and reset selected row on navigation", () => {
    render(<TransactionSelectPeriod />);
    fireEvent.keyDown(window, { key: "Escape" });
    expect(mockDispatch).toHaveBeenCalledWith(financialPeriodActions.resetSelectedRow());
  });
});
