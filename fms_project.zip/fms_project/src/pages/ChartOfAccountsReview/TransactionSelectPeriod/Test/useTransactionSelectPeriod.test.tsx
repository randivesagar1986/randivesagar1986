import { renderHook, act } from "@testing-library/react-hooks";
import { useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import { useAppSelector } from "@/store/store";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import useTransactionSelectPeriod from "../useTransactionSelectPeriod";
import { actions } from "../../state/ChartOfAccountsReviewList.slice";

// Mock dependencies
jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn(),
  useParams: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("../../state/ChartOfAccountsReviewList.slice", () => ({
  actions: {
    setSelectedRow: jest.fn()
  }
}));

describe("useTransactionSelectPeriod Hook", () => {
  const mockDispatch = jest.fn();
  const mockHistory = {
    push: jest.fn(),
    location: {
      state: {}
    }
  };

  const mockParams = {
    fromDate: "2021-01-01",
    toDate: "2021-12-31"
  };

  const mockState = {
    financialPeriods: {
      selectedTransactionRow: { id: 1 }
    },
    chartOfAccountsReviewList: {
      selectedRow: { user_id: "123" }
    }
  };

  beforeEach(() => {
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    (useParams as jest.Mock).mockReturnValue(mockParams);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    jest.clearAllMocks();
  });

  it("should initialize the hook correctly", () => {
    const { result } = renderHook(() => useTransactionSelectPeriod());

    expect(result.current.t).toBeDefined();
    expect(result.current.selectedTransactionRow).toEqual(mockState.financialPeriods.selectedTransactionRow);
    expect(result.current.historyState).toEqual(mockHistory.location.state);
    expect(result.current.onCloseHandler).toBeDefined();
    expect(result.current.onSelectHandler).toBeDefined();
  });

  it("should handle row selection", () => {
    const { result } = renderHook(() => useTransactionSelectPeriod());

    act(() => {
      result.current.selectedRowHandler({ user_id: "456" });
    });

    expect(mockDispatch).toHaveBeenCalledWith(actions.setSelectedRow({ user_id: "456" }));
  });

  it("should handle close action and navigate to chart accounts review page", () => {
    const { result } = renderHook(() => useTransactionSelectPeriod());

    act(() => {
      result.current.onCloseHandler();
    });

    expect(mockHistory.push).toHaveBeenCalledWith("/general-ledger/chart-accounts-review", mockHistory.location.state);
  });

  it("should handle select action and navigate to transaction details page", () => {
    const { result } = renderHook(() => useTransactionSelectPeriod());

    act(() => {
      result.current.onSelectHandler();
    });

    expect(mockHistory.push).toHaveBeenCalledWith({
      pathname: `/general-ledger/chart-accounts-review/transaction-period/from/2021-01-01/to/2021-12-31/transaction-details/123`,
      state: {
        ...mockHistory.location.state,
        transactionBrowseRow: mockState.financialPeriods.selectedTransactionRow
      }
    });
  });
});
