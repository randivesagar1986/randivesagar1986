import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { useHistory, useParams } from "react-router-dom";
import { actions } from "../state/ChartOfAccountsReviewList.slice";

const useTransactionSelectPeriod = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { fromDate, toDate } = useParams<{ fromDate: string; toDate: string }>();
  const { selectedTransactionRow } = useAppSelector((state) => state.financialPeriods);
  const { selectedRow } = useAppSelector((state) => state.chartOfAccountsReviewList);
  const selectedRowHandler = (row: any) => dispatch(actions.setSelectedRow(row));

  const onCloseHandler = () => {
    history.push("/general-ledger/chart-accounts-review", { ...historyState });
  };

  const onSelectHandler = () => {
    history.push({
      pathname: `/general-ledger/chart-accounts-review/transaction-period/from/${fromDate}/to/${toDate}/transaction-details/${selectedRow?.user_id}`,
      state: {
        ...historyState,
        transactionBrowseRow: selectedTransactionRow
      }
    });
  };

  return {
    t,
    selectedTransactionRow,
    selectedRowHandler,
    historyState,
    onCloseHandler,
    onSelectHandler
  };
};

export default useTransactionSelectPeriod;
