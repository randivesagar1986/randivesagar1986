import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const transactionSelectPeriodDef: TColumnDef = [
  {
    headerName: "Journal",
    field: "det_num",
    align: "left"
  },
  {
    headerName: "Period",
    field: "period_no",
    align: "left"
  },
  {
    headerName: "Narrative",
    field: "narrative",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "From",
    field: "journal_type_mapping"
  },
  {
    headerName: "User",
    field: "user_code"
  },
  {
    headerName: "Date",
    field: "journal_date",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Debit",
    field: "debit",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Credit",
    field: "credit",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "",
    field: "actions",
    cellRenderer: "GridCellLink"
  }
];

export default transactionSelectPeriodDef;
