import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import { getDate } from "@/utils/getDataSource";
import { financialPeriodActions } from "../../../state/financialPeriod.slice";
import CustomCell from "../CustomCell";
import useTransactionSelectPeriod from "../../useTransactionSelectPeriod";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn(),
  useParams: jest.fn()
}));

jest.mock("@/utils/getDataSource", () => ({
  getDate: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("@essnextgen/ui-kit", () => ({
  Button: jest.fn((props: any) => (
    <button
      type="button"
      id="button"
      {...props}
    >
      {props?.children}
    </button>
  )),
  ButtonColor: {
    Utility: "utility"
  }
}));

jest.mock("../../useTransactionSelectPeriod", () => jest.fn());

describe("CustomCell Component", () => {
  const mockDispatch = jest.fn();
  const mockHistory = {
    push: jest.fn(),
    location: {
      state: {}
    }
  };

  const mockParams = {
    fromDate: "2021-01-01",
    toDate: "2021-12-31"
  };

  const mockSelectedTransactionRow = { id: 1 };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    (useParams as jest.Mock).mockReturnValue(mockParams);
    (useTransactionSelectPeriod as jest.Mock).mockReturnValue({
      selectedTransactionRow: mockSelectedTransactionRow
    });
    jest.clearAllMocks();
  });

  it("should render the actions button and handle click", () => {
    const row = { user_id: "123" };
    render(
      <CustomCell
        field="actions"
        row={row}
      />
    );
    const button = screen.getByText("common.view02");
    expect(button).toBeInTheDocument();
    fireEvent.click(button);
    expect(mockDispatch).toHaveBeenCalledWith(financialPeriodActions.setSelectedRow(row));
    expect(mockHistory.push).toHaveBeenCalledWith({
      pathname: `/general-ledger/chart-accounts-review/transaction-period/from/2021-01-01/to/2021-12-31/transaction-details/123`,
      state: {
        transactionBrowseRow: row,
        selectedRowState: mockSelectedTransactionRow
      }
    });
  });

  it("should render the formatted debit value", () => {
    const row = { debit: 1234.56 };
    render(
      <CustomCell
        field="debit"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for debit when it is zero", () => {
    const row = { debit: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="debit"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted credit value", () => {
    const row = { credit: 1234.56 };
    render(
      <CustomCell
        field="credit"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for credit when it is zero", () => {
    const row = { credit: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="credit"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted journal_date value", () => {
    const row = { journal_date: "2021-01-01" };
    (getDate as jest.Mock).mockReturnValue("01/01/2021");
    render(
      <CustomCell
        field="journal_date"
        row={row}
      />
    );
    expect(screen.getByText("01/01/2021")).toBeInTheDocument();
  });

  it("should render the narrative value", () => {
    const row = { narrative: "Test Narrative", pct_narrative: "Pct Narrative" };
    render(
      <CustomCell
        field="narrative"
        row={row}
      />
    );
    expect(screen.getByText("Test Narrative Pct Narrative")).toBeInTheDocument();
  });

  it("should render null when field is not matched", () => {
    const row = { narrative: "Test Narrative" };
    const { container } = render(
      <CustomCell
        field="other_field"
        row={row}
      />
    );
    expect(container).toBeEmptyDOMElement();
  });
});
