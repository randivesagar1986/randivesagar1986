import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import ReportPreview from "../ReportPreview";
import { useReportPreview } from "../useReportPreview";

// Mock dependencies
jest.mock("../useReportPreview", () => ({
  useReportPreview: jest.fn(() => ({ isLoading: false }))
}));

jest.mock("@/shared/components/Preview/PreviewSection", () =>
  jest.fn((props) => (
    <>
      <div {...props}>PreviewSection</div>
      <div>
        <button
          onClick={props?.onPdfClick}
          type="button"
        >
          pdf
        </button>
        <button
          onClick={props?.onCsvClick}
          type="button"
        >
          csv
        </button>
        <button
          onClick={props?.onXmlClick}
          type="button"
        >
          xml
        </button>
      </div>
    </>
  ))
);
jest.mock("@/components/Loader/Loader", () => ({
  __esModule: true,
  default: jest.fn((props) => <div {...props}>Loader</div>),
  loadingConfig: jest.fn()
}));

describe("ReportPreview Component", () => {
  const mockHandlePdfClick = jest.fn();
  const mockHandleCsvClick = jest.fn();
  const mockHandleXmlClick = jest.fn();

  const mockUseReportPreview = {
    handlePdfClick: mockHandlePdfClick,
    handleCsvClick: mockHandleCsvClick,
    handleXmlClick: mockHandleXmlClick,
    t: (key: string) => key,
    isLoading: false,
    fileObj: { fileData: "test-file-data" }
  };

  beforeEach(() => {
    (useReportPreview as jest.Mock).mockReturnValue(mockUseReportPreview);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<ReportPreview />);
    screen.debug();
    expect(screen.getByText("PreviewSection")).toBeInTheDocument();
  });

  it("should render the Loader component when isLoading is true", () => {
    (useReportPreview as jest.Mock).mockReturnValue({
      ...mockUseReportPreview,
      isLoading: true
    });
    render(<ReportPreview />);
    expect(screen.getByText("Loader")).toBeInTheDocument();
  });

  it("should call handlePdfClick when the PDF button is clicked", () => {
    render(<ReportPreview />);
    const btn: any = screen.getByRole("button", { name: "pdf" });
    fireEvent.click(btn);
    expect(mockHandlePdfClick).toHaveBeenCalled();
  });

  it("should call handleCsvClick when the CSV button is clicked", () => {
    render(<ReportPreview />);
    const btn: any = screen.getByRole("button", { name: "csv" });
    fireEvent.click(btn);
    expect(mockHandleCsvClick).toHaveBeenCalled();
  });

  it("should call handleXmlClick when the XML button is clicked", () => {
    render(<ReportPreview />);
    const btn: any = screen.getByRole("button", { name: "xml" });
    fireEvent.click(btn);
    expect(mockHandleXmlClick).toHaveBeenCalled();
  });

  it("should pass the correct props to PreviewSection", () => {
    render(<ReportPreview />);
    const previewSection = screen.getByText("PreviewSection");
    expect(previewSection).toHaveAttribute("pageTitle", "purchaseOrder.preview");
    expect(previewSection).toHaveAttribute("pdfSrc", "test-file-data");
  });
});
