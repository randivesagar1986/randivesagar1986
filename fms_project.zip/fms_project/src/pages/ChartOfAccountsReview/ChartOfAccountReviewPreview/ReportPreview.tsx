import PreviewSection from "@/shared/components/Preview/PreviewSection";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import { useReportPreview } from "./useReportPreview";

const ReportPreview = () => {
  const { handlePdfClick, handleCsvClick, handleXmlClick, t, isLoading, fileObj } = useReportPreview();
  const loaderConfig: loadingConfig = {
    isLoaderModal: true,
    loadingText: t("common.downloadingFile")
  };
  return (
    <>
      {isLoading ? <Loader loadingConfig={loaderConfig} /> : null}
      <PreviewSection
        pageTitle={t("purchaseOrder.preview")}
        isBreadcrumbRequired
        className="charts-accounts-review wrapper__radius--0"
        pdfSrc={fileObj?.fileData}
        onPdfClick={handlePdfClick}
        onCsvClick={handleCsvClick}
        onXmlClick={handleXmlClick}
        isLoading={isLoading}
      />
    </>
  );
};

export default ReportPreview;
