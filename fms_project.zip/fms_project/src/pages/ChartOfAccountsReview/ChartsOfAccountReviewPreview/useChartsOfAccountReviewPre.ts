import {
  getChequeNewPrintDocument,
  getChequePrintCsv,
  getChequePrintXml
} from "@/pages/ChequeProcessing/state/CheckProcessingList.slice";
import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";

interface MyResponseType {
  payload: string; // Adjust this type according to your actual response structure
  // Add other properties if necessary
}
/* eslint-disable import/prefer-default-export */
export const useChartOfAccountPreviewPre = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [historyStateData, setHistoryStateData] = useState<any>();
  const { checkNewRunPrint, chequeNewRunPrintData } = useAppSelector((state) => state.chequeProcessingList);
  const [fileObj, setFileObj] = useState<{
    filedata: string;
  }>({
    filedata: "-"
  });

  useEffect(() => {
    const historyState = history.location.state as any;
    setHistoryStateData(historyState);
  }, [history.location.state]);

  useEffect(() => {
    const createPdfFromBase64 = () => {
      try {
        const byteCharacters = atob(chequeNewRunPrintData);
        const byteNumbers = new Array(byteCharacters.length);
        let i = 0;
        while (i < byteCharacters.length) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
          i += 1; // Use compound assignment instead of increment operator
        }

        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: "application/pdf" });
        const pdfUri = URL.createObjectURL(blob);
        setFileObj({
          filedata: pdfUri
        });
      } catch (error) {
        console.error("Error decoding base64 string:", error);
        // Handle the error gracefully, e.g., set pdfUrl to null
      }
    };

    createPdfFromBase64();
  }, []);

  const convertToCsv = async () => {
    const sessionData = JSON.parse(sessionStorage.getItem("chequeProcessing")!) || [];
    const { payload } = await dispatch(
      getChequePrintCsv({
        runNumber: historyStateData?.runNumber,
        runId: historyStateData?.runId,
        param1: historyStateData?.param1,
        period: historyStateData?.period,
        uniqueId: historyStateData?.uniqueId,
        odbcHandle: historyStateData?.odbcHandle,
        bankId: sessionData?.bankId
      })
    );
    const { data, fileName = "Cheque Run Report.csv" } = payload as any;

    const blob = new Blob([data], { type: "text/csv" });
    // Create a download link for the Blob
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = historyStateData?.runNumber ? `${historyStateData?.runNumber}` : fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const convertToPdf = async () => {
    const sessionData = JSON.parse(sessionStorage.getItem("chequeProcessing")!) || [];
    const res = await dispatch(
      getChequeNewPrintDocument({
        runNumber: historyStateData?.runNumber,
        runId: historyStateData?.runId,
        param1: historyStateData?.param1,
        period: historyStateData?.period,
        uniqueId: historyStateData?.uniqueId,
        odbcHandle: historyStateData?.odbcHandle,
        bankId: sessionData?.bankId
      })
    );
    // Create a Blob from the XML string
    const pdfData = (res as unknown as MyResponseType).payload;
    const byteCharacters = atob(pdfData);
    const byteNumbers = new Array(byteCharacters.length);
    let i = 0;
    while (i < byteCharacters.length) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
      i += 1; // Use compound assignment instead of increment operator
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: "application/pdf" });
    const pdfUri = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = historyStateData?.runNumber ? `${historyStateData?.runNumber}.pdf` : "Cheque Run Report.pdf"; // Set the download attribute with file extension
    link.click();
  };
  const convertToXml = async () => {
    const sessionData = JSON.parse(sessionStorage.getItem("chequeProcessing")!) || [];
    const { payload } = await dispatch(
      getChequePrintXml({
        runNumber: historyStateData?.runNumber,
        runId: historyStateData?.runId,
        param1: historyStateData?.param1,
        period: historyStateData?.period,
        uniqueId: historyStateData?.uniqueId,
        odbcHandle: historyStateData?.odbcHandle,
        bankId: sessionData?.bankId
      })
    );
    // Create a Blob from the XML string
    const { data, fileName = "Cheque Run Report.xml" } = payload as any;
    const blob = new Blob([data], { type: "application/xml" });
    // Create a download link for the Blob
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = historyStateData?.runNumber ? `${historyStateData?.runNumber}` : fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  return {
    convertToCsv,
    convertToPdf,
    convertToXml,
    fileObj,
    t
  };
};
