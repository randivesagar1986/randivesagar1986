import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import ChartsAccountsReviewPre from "../ChartsAccountsReviewPre";
import { useChartOfAccountPreviewPre } from "../useChartsOfAccountReviewPre";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn().mockReturnValue({
    t: (key: string) => key
  })
}));

jest.mock("@essnextgen/ui-kit", () => ({
  Button: jest.fn((props) => (
    <button
      type="button"
      {...props}
    >
      {props.children}
    </button>
  )),
  ButtonColor: {
    Primary: "primary",
    Secondary: "secondary"
  },
  ButtonSize: {
    Small: "small",
    Medium: "medium",
    Large: "large"
  },
  Tooltip: jest.fn((props) => <div {...props}>{props.children}</div>)
}));

jest.mock("@/components/Layout/Layout", () => jest.fn((props) => <div {...props}>{props.children}</div>));
jest.mock("@carbon/icons-react/lib/generated/bucket-3", () => ({
  Csv: jest.fn((props) => <svg {...props} />)
}));
jest.mock("@carbon/icons-react", () => ({
  Pdf: jest.fn((props) => <svg {...props} />),
  Xml: jest.fn((props) => <svg {...props} />)
}));

jest.mock("../useChartsOfAccountReviewPre", () => ({
  useChartOfAccountPreviewPre: jest.fn()
}));

describe("ChartsAccountsReviewPre Component", () => {
  const mockConvertToCsv = jest.fn();
  const mockConvertToPdf = jest.fn();
  const mockConvertToXml = jest.fn();

  const mockUseChartOfAccountPreviewPre = {
    convertToCsv: mockConvertToCsv,
    convertToPdf: mockConvertToPdf,
    convertToXml: mockConvertToXml,
    fileObj: { filedata: "test-file-data" },
    t: (key: string) => key
  };

  beforeEach(() => {
    (useChartOfAccountPreviewPre as jest.Mock).mockReturnValue(mockUseChartOfAccountPreviewPre);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<ChartsAccountsReviewPre />);
    expect(screen.getByLabelText("pdf")).toBeInTheDocument();
    expect(screen.getByLabelText("csv")).toBeInTheDocument();
    expect(screen.getByLabelText("xml")).toBeInTheDocument();
  });

  it("should call convertToPdf when the PDF button is clicked", () => {
    render(<ChartsAccountsReviewPre />);
    fireEvent.click(screen.getByLabelText("pdf"));
    expect(mockConvertToPdf).toHaveBeenCalled();
  });

  it("should call convertToCsv when the CSV button is clicked", () => {
    render(<ChartsAccountsReviewPre />);
    fireEvent.click(screen.getByLabelText("csv"));
    expect(mockConvertToCsv).toHaveBeenCalled();
  });

  it("should call convertToXml when the XML button is clicked", () => {
    render(<ChartsAccountsReviewPre />);
    fireEvent.click(screen.getByLabelText("xml"));
    expect(mockConvertToXml).toHaveBeenCalled();
  });

  it("should focus the PDF button on mount", () => {
    render(<ChartsAccountsReviewPre />);
    expect(document.activeElement).toBe(screen.getByLabelText("pdf"));
  });

  it("should render the iframe with the correct src", () => {
    render(<ChartsAccountsReviewPre />);
    expect(screen.getByTitle("PDF Document")).toHaveAttribute("src", "test-file-data#toolbar=0");
  });
});
