import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider, useDispatch } from "react-redux";
import { BrowserRouter as Router, useParams } from "react-router-dom";
import configureStore from "redux-mock-store";
import { useAppSelector } from "@/store/store";
import ChartsAccountsReview from "../ChartOfAccountsReview";
import useChartOfAccountsReview from "../useChartOfAccountsReview";

jest.mock("../useChartOfAccountsReview");

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn().mockImplementation((selector) => selector(initialState))
}));

jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn()
}));

const mockStore = configureStore([]);

const initialState = {
  columnDef: [],
  enablePanel: false,
  isPreviousYearData: false,
  chartOfAccountsReviewList: {
    accountReviewDetails: [],
    budget: 0.0,
    commitment: 0.0,
    invoiced: 0.0,
    actual: 0.0,
    total: 0.0,
    remaining: 0.0
  },
  userAccessRights: {},
  supplierCatalogue: {
    catalogueData: null,
    status: "idle"
  },
  glCentreLedgerLinksView: {
    availableCostCentreList: [],
    availableLedgerCodeList: []
  },
  ui: {
    alert: ""
  },
  ledgerBrowse: {
    filterState: null
  },
  ccBrowse: {
    filterState: null
  },
  fundCode: {
    selectedfundCode: null
  },
  useChartOfAccountsReviewFilters: {
    costCentreBrowseClick: null,
    watch: null,
    resetAll: null
  },
  restrictedMenu: {
    restrictedUser: null
  },
  transactionDetails: {}
};

const mockProps = {
  t: (key: string) => key,
  accountReviewDetails: {
    actual: 0,
    curr_bud: 0,
    description: "O/B",
    fund_id: null,
    last_actual: 0,
    orig_bud: 0,
    period_no: 0,
    prev_act: 0,
    variance: 0,
    year_id: 0
  },
  budget: 0.0,
  commitment: 0.0,
  invoiced: 0.0,
  actual: 0.0,
  total: 0.0,
  remaining: 0.0,
  numberFormatter: new Intl.NumberFormat("en-US", {
    style: "decimal", // or 'currency', etc.
    minimumFractionDigits: 2 // specify according to your needs
  }),
  formatNumberWithCommas: jest.fn(),
  selectedRow: {
    period_no: 0,
    actual: 0,
    last_actual: 0,
    curr_bud: 0,
    orig_bud: 0,
    description: "O/B",
    prev_act: 0,
    variance: 0,
    year_id: 0,
    fund_id: null
  },
  status: "SUCCESS",
  showAllPrevYrMovement: false,
  onSelectPrevYearCheckBox: jest.fn(),
  enablePanel: false,
  selectedRowHandler: jest.fn(),
  dispatch: jest.fn(),
  formMethods: jest.fn(),
  handlePreviewClick: jest.fn()
};

const mockPropsforInputNumberMask = {
  onChange: jest.fn(),
  name: "mockName",
  value: "12345.67",
  className: "mockClassName",
  validationTextLevel: undefined, // Assuming ValidationTextLevel is an enum or similar
  onValueChange: jest.fn(),
  getInputRef: jest.fn(),
  onKeyDown: jest.fn(),
  beforeDecimalMaxLength: 5,
  onBlur: jest.fn(),
  beforeDecimalCursorIndex: 2,
  afterDecimalCursorIndex: 2,
  allowNegative: true
  // Add any additional props required by NumericFormatProps
};
const InputNumberMask = (props: any, ref: any) => (
  <input
    ref={ref}
    {...props}
  />
);

// Mock the InputNumberMask component
jest.mock("../../../../components/Input/InputNumberMask", () =>
  React.forwardRef((props, ref) => (
    <InputNumberMask
      ref={ref}
      {...props}
    />
  ))
);

describe("ChartsAccountsReview", () => {
  let store: any = mockStore({});
  let mockDispatch: jest.Mock;

  beforeEach(() => {
    store = mockStore(initialState);

    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(initialState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
    (useChartOfAccountsReview as jest.Mock).mockReturnValue(mockProps);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("renders the component", async () => {
    render(
      <Provider store={store}>
        <Router>
          <ChartsAccountsReview />
        </Router>
      </Provider>
    );
    await waitFor(() => {
      const element = screen.getByTestId("chartOfAccountsReviewList");
      expect(screen.getByText("generalLedgerSetup.chartOfAccountsReview")).toBeInTheDocument();
      expect(element).toBeInTheDocument();
    });
  });
});
