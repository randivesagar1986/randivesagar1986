import { renderHook, act } from "@testing-library/react-hooks";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useAppSelector } from "@/store/store";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import BodyUtil from "@/shared/utils/NoScroll";
import useChartOfAccountsReview from "../useChartOfAccountsReview";
import { getAcctReviewList, actions } from "../../state/ChartOfAccountsReviewList.slice";
import { ccBrowseActions } from "../../state/CostCentreBrowse.slice";

// Mock dependencies
jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("../../state/ChartOfAccountsReviewList.slice", () => ({
  getAcctReviewList: jest.fn(),
  actions: {
    setSelectedRow: jest.fn(),
    setIncludePreviousYearData: jest.fn(),
    setEnablePanel: jest.fn()
  }
}));

jest.mock("../../state/CostCentreBrowse.slice", () => ({
  ccBrowseActions: {
    resetFilters: jest.fn()
  }
}));

jest.mock("@/shared/utils/NoScroll", () => ({
  NoScroll: {
    add: jest.fn(),
    remove: jest.fn()
  }
}));

describe("useChartOfAccountsReview Hook", () => {
  const mockDispatch = jest.fn();
  const mockHistory = {
    location: {
      state: {
        costCentreRecord: { cost_id: "1", cost_des: "Cost Centre" },
        ledgerRecord: { leddef_id: "2", ledger_des: "Ledger" },
        isPreviousYearData: true
      }
    },
    push: jest.fn(),
    block: jest.fn(() => jest.fn())
  };

  const mockState = {
    fundCode: {
      selectedfundCode: { fund_id: "3", ledger_des: "Fund" }
    },
    chartOfAccountsReviewList: {
      chartOfAccountsReviewList: {
        accountReviewDetails: [],
        budget: 100,
        commitment: 200,
        invoiced: 300,
        actual: 400,
        total: 500,
        remaining: 600
      },
      status: "IDLE",
      selectedRow: null,
      isPreviousYearData: false,
      enablePanel: false
    }
  };

  beforeEach(() => {
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    jest.clearAllMocks();
  });

  it("should initialize the hook correctly", () => {
    const { result } = renderHook(() => useChartOfAccountsReview());

    expect(result.current.accountReviewDetails).toEqual([]);
    expect(result.current.budget).toBe(100);
    expect(result.current.commitment).toBe(200);
    expect(result.current.invoiced).toBe(300);
    expect(result.current.actual).toBe(400);
    expect(result.current.total).toBe(500);
    expect(result.current.remaining).toBe(600);
    expect(result.current.status).toBe("IDLE");
    expect(result.current.selectedRow).toBeNull();
    // expect(result.current.isPreviousYearData).toBe(false);
    expect(result.current.enablePanel).toBe(false);
    expect(result.current.t).toBeDefined();
  });

  it("should dispatch getAcctReviewList on mount", () => {
    renderHook(() => useChartOfAccountsReview());

    expect(mockDispatch).toHaveBeenCalledWith(getAcctReviewList(expect.any(Object)));
  });

  it("should handle preview click and navigate to preview page", () => {
    const { result } = renderHook(() => useChartOfAccountsReview());

    act(() => {
      result.current.handlePreviewClick();
    });

    expect(mockHistory.push).toHaveBeenCalledWith("/general-ledger/chart-accounts-review/preview", {
      ...mockHistory.location.state,
      isPreviousYearData: false
    });
  });

  it("should handle previous year checkbox selection", () => {
    const { result } = renderHook(() => useChartOfAccountsReview());

    act(() => {
      result.current.onSelectPrevYearCheckBox({ target: { checked: true } });
    });

    expect(mockDispatch).toHaveBeenCalledWith(actions.setIncludePreviousYearData(true));
    expect(mockDispatch).toHaveBeenCalledWith(getAcctReviewList(expect.any(Object)));
  });

  it("should add and remove no-scroll class based on enablePanel", () => {
    (useAppSelector as jest.Mock).mockImplementation((selector) =>
      selector({
        ...mockState,
        chartOfAccountsReviewList: {
          ...mockState.chartOfAccountsReviewList,
          enablePanel: true
        }
      })
    );

    renderHook(() => useChartOfAccountsReview());

    expect(BodyUtil.NoScroll.add).toHaveBeenCalled();

    (useAppSelector as jest.Mock).mockImplementation((selector) =>
      selector({
        ...mockState,
        chartOfAccountsReviewList: {
          ...mockState.chartOfAccountsReviewList,
          enablePanel: false
        }
      })
    );

    renderHook(() => useChartOfAccountsReview());

    expect(BodyUtil.NoScroll.remove).toHaveBeenCalled();
  });
});
