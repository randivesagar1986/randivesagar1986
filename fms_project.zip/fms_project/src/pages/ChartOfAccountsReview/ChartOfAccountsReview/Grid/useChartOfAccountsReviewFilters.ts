import { AppDispatch, useAppSelector } from "@/store/store";
import { useFormContext } from "react-hook-form";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { getAcctReviewList, actions } from "../../state/ChartOfAccountsReviewList.slice";
import { ccBrowseActions } from "../../state/CostCentreBrowse.slice";
import { ledgersActions } from "../../state/Ledgers.slice";
import { ledgerTypeActions } from "../../state/LedgerTypes.slice";
import { ledgerGroupActions } from "../../state/LedgerGroups.slice";

const useChartOfAccountsReviewFilters = () => {
  const history = useHistory();
  const historyState = history.location.state as any;
  const dispatch = useDispatch<AppDispatch>();
  const { watch, setValue } = useFormContext();
  const { filterState } = useAppSelector((state) => state.ccBrowse);
  const { isPreviousYearData } = useAppSelector((state) => state.chartOfAccountsReviewList);

  const costCentreBrowseClick = () => {
    dispatch(
      ccBrowseActions.setFilters({
        ...filterState,
        costId: historyState?.costCentreRecord?.cost_id,
        ledgerCode: historyState?.ledgerRecord?.ledger_code,
        lookingFor: ""
      })
    );
    history.push("/general-ledger/chart-accounts-review/cost-centre-browse", { ...historyState });
  };

  const resetAll = () => {
    history.push({ ...history.location, state: {} });
    dispatch(
      getAcctReviewList({
        includePreviousYearData: isPreviousYearData,
        callback: (data) => {
          dispatch(actions.setSelectedRow(data.accountReviewDetails.at(0)));
        }
      })
    );
    dispatch(ccBrowseActions.resetFilters());
    dispatch(
      ccBrowseActions.setFilters({
        excludeZero: filterState?.excludeZero
      })
    );
    dispatch(ledgersActions.resetFilters());
    dispatch(ledgerTypeActions.selectRow(undefined));
    dispatch(ledgerGroupActions.setGroup({ text: "", value: "" }));
  };

  return {
    costCentreBrowseClick,
    watch,
    resetAll
  };
};

export default useChartOfAccountsReviewFilters;
