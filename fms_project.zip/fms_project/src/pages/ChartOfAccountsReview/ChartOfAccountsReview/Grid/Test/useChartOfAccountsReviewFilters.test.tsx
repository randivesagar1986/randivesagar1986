import { renderHook, act } from "@testing-library/react-hooks";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useFormContext } from "react-hook-form";
import { useAppSelector } from "@/store/store";
import useChartOfAccountsReviewFilters from "../useChartOfAccountsReviewFilters";
import { getAcctReviewList, actions } from "../../../state/ChartOfAccountsReviewList.slice";
import { ccBrowseActions } from "../../../state/CostCentreBrowse.slice";
import { ledgersActions } from "../../../state/Ledgers.slice";
import { ledgerTypeActions } from "../../../state/LedgerTypes.slice";
import { ledgerGroupActions } from "../../../state/LedgerGroups.slice";

// Mock dependencies
jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-hook-form", () => ({
  useFormContext: jest.fn()
}));

jest.mock("../../../state/ChartOfAccountsReviewList.slice", () => ({
  getAcctReviewList: jest.fn(),
  actions: {
    setSelectedRow: jest.fn()
  }
}));

jest.mock("../../../state/CostCentreBrowse.slice", () => ({
  ccBrowseActions: {
    setFilters: jest.fn(),
    resetFilters: jest.fn()
  }
}));

jest.mock("../../../state/Ledgers.slice", () => ({
  ledgersActions: {
    resetFilters: jest.fn()
  }
}));

jest.mock("../../../state/LedgerTypes.slice", () => ({
  ledgerTypeActions: {
    selectRow: jest.fn()
  }
}));

jest.mock("../../../state/LedgerGroups.slice", () => ({
  ledgerGroupActions: {
    setGroup: jest.fn()
  }
}));

describe("useChartOfAccountsReviewFilters Hook", () => {
  const mockDispatch = jest.fn();
  const mockHistory = {
    location: {
      state: {
        costCentreRecord: { cost_id: "1", cost_des: "Cost Centre" },
        ledgerRecord: { ledger_code: "123", ledger_des: "Ledger" }
      }
    },
    push: jest.fn()
  };

  const mockState = {
    ccBrowse: {
      filterState: {}
    },
    chartOfAccountsReviewList: {
      isPreviousYearData: false
    }
  };

  beforeEach(() => {
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useFormContext as jest.Mock).mockReturnValue({
      watch: jest.fn(),
      setValue: jest.fn()
    });
    jest.clearAllMocks();
  });

  it("should initialize the hook correctly", () => {
    const { result } = renderHook(() => useChartOfAccountsReviewFilters());

    expect(result.current.watch).toBeDefined();
    expect(result.current.costCentreBrowseClick).toBeDefined();
    expect(result.current.resetAll).toBeDefined();
  });

  it("should handle cost centre browse click and navigate to cost centre browse page", () => {
    const { result } = renderHook(() => useChartOfAccountsReviewFilters());

    act(() => {
      result.current.costCentreBrowseClick();
    });

    expect(mockDispatch).toHaveBeenCalledWith(
      ccBrowseActions.setFilters({
        ...mockState.ccBrowse.filterState,
        costId: 1,
        ledgerCode: "123",
        lookingFor: ""
      })
    );
    expect(mockHistory.push).toHaveBeenCalledWith("/general-ledger/chart-accounts-review/cost-centre-browse", {
      ...mockHistory.location.state
    });
  });

  it("should handle reset all and dispatch actions", () => {
    const { result } = renderHook(() => useChartOfAccountsReviewFilters());

    act(() => {
      result.current.resetAll();
    });

    expect(mockDispatch).toHaveBeenCalledWith(
      getAcctReviewList({
        includePreviousYearData: false,
        callback: expect.any(Function)
      })
    );
    expect(mockDispatch).toHaveBeenCalledWith(ccBrowseActions.resetFilters());
    expect(mockDispatch).toHaveBeenCalledWith(
      ccBrowseActions.setFilters({
        excludeZero: undefined
      })
    );
    expect(mockDispatch).toHaveBeenCalledWith(ledgersActions.resetFilters());
    expect(mockDispatch).toHaveBeenCalledWith(ledgerTypeActions.selectRow(undefined));
    expect(mockDispatch).toHaveBeenCalledWith(ledgerGroupActions.setGroup({ text: "", value: "" }));
  });
});
