import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import { actions } from "../../../state/ChartOfAccountsReviewList.slice";
import CustomCell from "../CustomCell";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@essnextgen/ui-kit", () => ({
  Button: jest.fn((props: any) => (
    <button
      {...props}
      type="button"
    >
      {props?.children}
    </button>
  )),
  ButtonColor: {
    PRIMARY: "primary",
    SECONDARY: "secondary"
  }
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

describe("CustomCell Component", () => {
  const mockDispatch = jest.fn();

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    jest.clearAllMocks();
  });

  it("should render the actions button and handle click", () => {
    const row = { id: 1 };
    render(
      <CustomCell
        field="actions"
        row={row}
      />
    );
    const button = screen.getByText("common.view02");
    expect(button).toBeInTheDocument();
    fireEvent.click(button);
    expect(mockDispatch).toHaveBeenCalledWith(actions.setSelectedRow(row));
    expect(mockDispatch).toHaveBeenCalledWith(actions.setEnablePanel(true));
  });

  it("should render the formatted period_no", () => {
    const row = { period_no: "1" };
    render(
      <CustomCell
        field="period_no"
        row={row}
      />
    );
    expect(screen.getByText("1")).toBeInTheDocument();
  });

  it("should render the formatted actual value", () => {
    const row = { actual: 1234.56 };
    render(
      <CustomCell
        field="actual"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render the formatted curr_bud value", () => {
    const row = { curr_bud: 1234.56 };
    render(
      <CustomCell
        field="curr_bud"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render the formatted orig_bud value", () => {
    const row = { orig_bud: 1234.56 };
    render(
      <CustomCell
        field="orig_bud"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render the formatted variance_curr_bud value", () => {
    const row = { curr_bud: 2000, actual: 1500 };
    render(
      <CustomCell
        field="variance_curr_bud"
        row={row}
      />
    );
    expect(screen.getByText("500.00")).toBeInTheDocument();
  });

  it("should render the formatted variance_orig_bud value", () => {
    const row = { orig_bud: 2000, actual: 1500 };
    render(
      <CustomCell
        field="variance_orig_bud"
        row={row}
      />
    );
    expect(screen.getByText("500.00")).toBeInTheDocument();
  });

  it("should render the formatted prev_act value", () => {
    const row = { prev_act: 1234.56 };
    render(
      <CustomCell
        field="prev_act"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render the formatted variance value", () => {
    const row = { variance: 1234.56 };
    render(
      <CustomCell
        field="variance"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for prev_act when it is zero", () => {
    const row = { prev_act: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="prev_act"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render zero for variance when it is zero", () => {
    const row = { variance: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="variance"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });
});
