import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { actions } from "../../../FundCodeModal/FundCode.slice";
import { ledgersActions } from "../../../state/Ledgers.slice";
import ChartOfAccountsReviewFilters from "../ChartOfAccountsReviewFilters";
import useChartOfAccountsReviewFilters from "../useChartOfAccountsReviewFilters";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));
jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));
jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));
jest.mock("@essnextgen/ui-kit", () => ({
  Button: jest.fn((props: any) => (
    <button
      type="button"
      data-testid={props?.dataTestId}
      {...props}
    >
      {props?.children}
    </button>
  )),
  ButtonColor: {
    Secondary: "secondary"
  },
  ButtonSize: {
    Small: "small"
  },
  CheckBox: jest.fn((props: any) => (
    <input
      type="checkbox"
      {...props}
    />
  )),
  FormLabel: jest.fn((props: any) => <div id="label">{props?.children}</div>),
  Grid: jest.fn((props: any) => <div {...props}>{props?.children}</div>),
  GridItem: jest.fn((props: any) => <div {...props}>{props?.children}</div>),
  Icon: jest.fn((props: any) => <div {...props}>Icon</div>),
  IconColor: {
    Primary500: "primary-500"
  },
  IconSize: {
    Medium: 24
  },
  Tooltip: jest.fn((props: any) => <div {...props}>{props?.children}</div>)
}));
jest.mock("../useChartOfAccountsReviewFilters", () => jest.fn());

describe("ChartOfAccountsReviewFilters Component", () => {
  const mockDispatch = jest.fn();
  const mockHistory = {
    location: {
      state: {
        costCentreRecord: { cost_des: "Cost Centre" },
        ledgerRecord: { ledger_des: "Ledger", ledger_code: "123" },
        excludeBalanceSheetAccounts: true,
        excludeNonZeroValues: true
      }
    },
    push: jest.fn()
  };

  const mockUseChartOfAccountsReviewFilters = {
    costCentreBrowseClick: jest.fn(),
    watch: jest.fn(),
    resetAll: jest.fn()
  };

  const mockState = {
    ledgerBrowse: {
      filterState: {}
    },
    fundCode: {
      selectedfundCode: { ledger_des: "Fund" }
    },
    chartOfAccountsReviewList: {
      isPreviousYearData: false
    },
    restrictedMenu: {
      restrictedUser: { restricted_user: "F" }
    }
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    (useChartOfAccountsReviewFilters as jest.Mock).mockReturnValue(mockUseChartOfAccountsReviewFilters);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(
      <ChartOfAccountsReviewFilters
        showAllPrevYrMovement={false}
        onSelectPrevYearCheckBox={jest.fn()}
        setFundCodeModalOpen={jest.fn()}
      />
    );
    screen.debug();
    expect(screen.getByText("generalLedgerSetup.cost")).toBeInTheDocument();
    expect(screen.getByText("generalLedgerSetup.ledger")).toBeInTheDocument();
    expect(screen.getByText("generalLedgerSetup.fund")).toBeInTheDocument();
    expect(screen.getByText("generalLedgerSetup.resetAll")).toBeInTheDocument();
  });

  it("should call costCentreBrowseClick when the cost centre search button is clicked", () => {
    render(
      <ChartOfAccountsReviewFilters
        showAllPrevYrMovement={false}
        onSelectPrevYearCheckBox={jest.fn()}
        setFundCodeModalOpen={jest.fn()}
      />
    );
    fireEvent.click(screen.getByTestId("chart-accounts-review-filters-looking-for-search-cost"));
    expect(mockUseChartOfAccountsReviewFilters.costCentreBrowseClick).toHaveBeenCalled();
  });

  it("should call setFundCodeModalOpen when the fund search button is clicked", () => {
    const mockSetFundCodeModalOpen = jest.fn();
    render(
      <ChartOfAccountsReviewFilters
        showAllPrevYrMovement={false}
        onSelectPrevYearCheckBox={jest.fn()}
        setFundCodeModalOpen={mockSetFundCodeModalOpen}
      />
    );
    fireEvent.click(screen.getByTestId("chart-accounts-review-filters-looking-for-search-ledger"));
    expect(mockSetFundCodeModalOpen).toHaveBeenCalledWith(true);
  });

  it("should call resetAll and dispatch actions.reset when the reset all button is clicked", () => {
    render(
      <ChartOfAccountsReviewFilters
        showAllPrevYrMovement={false}
        onSelectPrevYearCheckBox={jest.fn()}
        setFundCodeModalOpen={jest.fn()}
      />
    );
    fireEvent.click(screen.getByRole("button", { name: "generalLedgerSetup.resetAll" }));
    expect(mockUseChartOfAccountsReviewFilters.resetAll).toHaveBeenCalled();
    expect(mockDispatch).toHaveBeenCalledWith(actions.reset());
  });

  it("should call onSelectPrevYearCheckBox when the show all previous year movement checkbox is changed", () => {
    const mockOnSelectPrevYearCheckBox = jest.fn();
    render(
      <ChartOfAccountsReviewFilters
        showAllPrevYrMovement={false}
        onSelectPrevYearCheckBox={mockOnSelectPrevYearCheckBox}
        setFundCodeModalOpen={jest.fn()}
      />
    );
    fireEvent.click(screen.getByRole("checkbox"));
    expect(mockOnSelectPrevYearCheckBox).toHaveBeenCalled();
  });
});
