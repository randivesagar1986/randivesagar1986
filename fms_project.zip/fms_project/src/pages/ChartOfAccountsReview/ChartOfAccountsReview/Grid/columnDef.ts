import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const chartOfAccountsReviewDef: TColumnDef = [
  {
    headerName: "Period",
    field: "period_no",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Period Name",
    field: "description"
  },
  {
    headerName: "Current Actual (CA)",
    field: "actual",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Current Budget (CB)",
    field: "curr_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Variance : CB - CA",
    field: "variance_curr_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Original Budget (OB)",
    field: "orig_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Variance : OB - CA",
    field: "variance_orig_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Previous Year Actual (PA)",
    field: "prev_act",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Variance : CB - PA",
    field: "variance",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "",
    field: "actions",
    cellRenderer: "GridCellLink"
  }
];

export default chartOfAccountsReviewDef;
