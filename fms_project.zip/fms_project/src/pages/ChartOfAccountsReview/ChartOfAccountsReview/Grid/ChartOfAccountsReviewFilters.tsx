import React, { useState } from "react";
import { useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  Tooltip
} from "@essnextgen/ui-kit";
import "../Style.scss";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useHistory } from "react-router-dom";
import useChartOfAccountsReviewFilters from "./useChartOfAccountsReviewFilters";
import { actions } from "../../FundCodeModal/FundCode.slice";
import { ledgersActions } from "../../state/Ledgers.slice";

const ChartOfAccountsReviewFilters = (props: any) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { filterState } = useAppSelector((state) => state.ledgerBrowse);
  const { showAllPrevYrMovement, onSelectPrevYearCheckBox, setFundCodeModalOpen } = props;
  const { costCentreBrowseClick, watch, resetAll } = useChartOfAccountsReviewFilters();
  const { selectedfundCode } = useAppSelector((state) => state.fundCode);
  const dispatch = useDispatch();
  const { isPreviousYearData } = useAppSelector((state) => state.chartOfAccountsReviewList);
  const { restrictedUser } = useAppSelector((state) => state.restrictedMenu);
  const costDescription =
    restrictedUser?.restricted_user === "T" ? t("generalLedgerSetup.myCostCentres") : t("ledgerBrowse.allCostCentres");
  return (
    <Grid className="chart-accounts-review-filters">
      <div className="essui-global-typography-default-h2 sequence-container">
        <FormLabel forId="looking-for">{t("generalLedgerSetup.costCentreCOA")}</FormLabel>
        <div className="looking-for playback">
          <Tooltip content={historyState?.costCentreRecord?.cost_des}>
            <div className="read-only essui-textinput essui-textinput--medium width-265">
              {historyState?.costCentreRecord?.cost_des || costDescription}
            </div>
          </Tooltip>
          <Button
            dataTestId="chart-accounts-review-filters-looking-for-search-cost"
            color={ButtonColor.Secondary}
            size={ButtonSize.Small}
            className="essui-button-icon-only--small"
            onClick={costCentreBrowseClick}
          >
            <Icon
              color={IconColor.Primary500}
              size={IconSize.Medium}
              name="search"
            />
          </Button>
        </div>
      </div>

      <div className="essui-global-typography-default-h2 sequence-container">
        <FormLabel>{t("generalLedgerSetup.ledger")}</FormLabel>
        <div className="looking-for playback">
          <Tooltip content={historyState?.ledgerRecord?.ledger_des}>
            <div className="read-only essui-textinput essui-textinput--medium width-265">
              {historyState?.ledgerRecord?.ledger_des || "All Ledger Codes"}
            </div>
          </Tooltip>
          <Button
            color={ButtonColor.Secondary}
            size={ButtonSize.Small}
            className="essui-button-icon-only--small"
            onClick={() => {
              if (
                historyState?.excludeBalanceSheetAccounts !== undefined &&
                historyState?.excludeNonZeroValues !== undefined
              ) {
                dispatch(
                  ledgersActions.setFilters({
                    ...filterState,
                    excludeBalanceSheetAccounts: historyState.excludeBalanceSheetAccounts,
                    excludeNonZeroValues: historyState.excludeNonZeroValues,
                    highLightedRecord: historyState?.ledgerRecord?.ledger_code
                  })
                );
              }
              history.push("/general-ledger/chart-accounts-review/ledger-browse", { ...historyState });
            }}
            disabled={historyState?.costCentreRecord?.cost_des === undefined && restrictedUser?.restricted_user === "T"}
          >
            <Icon
              color={IconColor.Primary500}
              size={IconSize.Medium}
              name="search"
            />
          </Button>
        </div>
      </div>

      <div className="essui-global-typography-default-h2 sequence-container">
        <FormLabel>{t("generalLedgerSetup.fund")}</FormLabel>
        <div className="looking-for playback ">
          <Tooltip content={selectedfundCode?.ledger_des}>
            <div className="read-only essui-textinput essui-textinput--medium width-265">
              {selectedfundCode?.ledger_des ?? "All Funds"}
            </div>
          </Tooltip>

          <Button
            color={ButtonColor.Secondary}
            size={ButtonSize.Small}
            dataTestId="chart-accounts-review-filters-looking-for-search-ledger"
            className="essui-button-icon-only--small"
            onClick={() => setFundCodeModalOpen(true)}
            disabled={restrictedUser?.restricted_user === "T"}
          >
            <Icon
              color={IconColor.Primary500}
              size={IconSize.Medium}
              name="search"
            />
          </Button>
        </div>
      </div>

      <div className="essui-global-typography-default-h2 mt-16">
        <Button
          size={ButtonSize.Small}
          color={ButtonColor.Secondary}
          onClick={() => {
            resetAll();
            dispatch(actions.reset());
          }}
        >
          {t("generalLedgerSetup.resetAll")}
        </Button>
      </div>

      <div className="essui-global-typography-default-h2 mr-t20">
        <CheckBox
          label={t("generalLedgerSetup.showAllPrevYrMovement")}
          isSelected={isPreviousYearData}
          onChange={onSelectPrevYearCheckBox}
        />
      </div>
    </Grid>
  );
};

export default ChartOfAccountsReviewFilters;
