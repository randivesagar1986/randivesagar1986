import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import configureStore from "redux-mock-store";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { AsyncThunkAction } from "@reduxjs/toolkit";
import { Dispatch } from "redux";
import TransactionDetailsPreviewPage from "../TransactionDetailsPreviewPage/TransactionDetailsPreviewPage";
import useTransactionDetailsPreview from "../TransactionDetailsPreviewPage/useTransactionDetailsPreview";
import {
  getTransactionDetailsCSV,
  getTransactionDetailsPDF,
  getTransactionDetailsXML
} from "../../state/ChartOfAccountsReviewList.slice";

jest.mock("../TransactionDetailsPreviewPage/useTransactionDetailsPreview");
const mockUseTransactionDetailsPreview = useTransactionDetailsPreview as jest.Mock;

jest.mock("@essnextgen/ui-intl-kit");
const mockUseTranslation = useTranslation as jest.Mock;

const mockStore = configureStore([]);
const store = mockStore({
  supplierCatalogue: {
    catalogueData: {}
  },
  userAccessRights: {
    isSupplierHavingAccess: true
  }
});

describe("TransactionDetailsPreviewPage", () => {
  beforeEach(() => {
    mockUseTranslation.mockReturnValue({ t: (key: string) => key });
  });

  it("should render the loader when isLoading is true", () => {
    mockUseTransactionDetailsPreview.mockReturnValue({
      convertToCsv: jest.fn(),
      convertToPdf: jest.fn(),
      convertToXml: jest.fn(),
      fileObj: null,
      isLoading: true
    });

    render(
      <Provider store={store}>
        <Router>
          <TransactionDetailsPreviewPage />
        </Router>
      </Provider>
    );

    expect(screen.getByText("common.downloadingFile")).toBeInTheDocument();
  });

  it("should render the PreviewSection with correct props when isLoading is false", () => {
    mockUseTransactionDetailsPreview.mockReturnValue({
      convertToCsv: async () => {
        setLoading(true);
        const res: any = await dispatch(getTransactionDetailsCSV({ payload: generatePayload() }));
        const csvData = res.payload.data;
        const blob = new Blob([csvData], { type: "text/csv" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = res?.payload?.fileName ?? "file";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setLoading(false);
      },
      convertToPdf: async () => {
        setLoading(true);
        const { payload } = await dispatch(getTransactionDetailsPDF({ payload: generatePayload() }));
        const { data, fileName } = payload as any;
        const blob = new Blob([data], { type: "application/pdf" });
        const link = document.createElement("a");
        link.href = window.URL.createObjectURL(blob);
        link.download = fileName || "transactionNominalJournalDetailsFile";
        link.click();
        setLoading(false);
      },
      convertToXml: async () => {
        setLoading(true);
        const res: any = await dispatch(getTransactionDetailsXML({ payload: generatePayload() }));
        const xmlData = res.payload.data;
        const blob = new Blob([xmlData], { type: "application/xml" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = res?.payload?.fileName ?? "file";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setLoading(false);
      },
      fileObj: { fileData: "mockPdfSrc" },
      isLoading: false
    });
    const mockConvertToCsv = jest.fn();
    const mockConvertToPdf = jest.fn();
    const mockConvertToXml = jest.fn();
    const mockFileObj = { fileData: "mockPdfSrc" };

    mockUseTransactionDetailsPreview.mockReturnValue({
      convertToCsv: mockConvertToCsv,
      convertToPdf: mockConvertToPdf,
      convertToXml: mockConvertToXml,
      fileObj: mockFileObj,
      isLoading: false
    });

    render(
      <Provider store={store}>
        <Router>
          <TransactionDetailsPreviewPage />
        </Router>
      </Provider>
    );

    expect(screen.getByText("generalLedgerSetup.preview")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /pdf/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /csv/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /xml/i })).toBeInTheDocument();
  });

  it("should call convertToPdf when PDF button is clicked", () => {
    const mockConvertToPdf = jest.fn();

    mockUseTransactionDetailsPreview.mockReturnValue({
      convertToCsv: jest.fn(),
      convertToPdf: mockConvertToPdf,
      convertToXml: jest.fn(),
      fileObj: { fileData: "mockPdfSrc" },
      isLoading: false
    });

    render(
      <Provider store={store}>
        <Router>
          <TransactionDetailsPreviewPage />
        </Router>
      </Provider>
    );

    fireEvent.click(screen.getByRole("button", { name: /pdf/i }));
    expect(mockConvertToPdf).toHaveBeenCalled();
  });

  it("should call convertToCsv when CSV button is clicked", () => {
    const mockConvertToCsv = jest.fn();

    mockUseTransactionDetailsPreview.mockReturnValue({
      convertToCsv: mockConvertToCsv,
      convertToPdf: jest.fn(),
      convertToXml: jest.fn(),
      fileObj: { fileData: "mockPdfSrc" },
      isLoading: false
    });

    render(
      <Provider store={store}>
        <Router>
          <TransactionDetailsPreviewPage />
        </Router>
      </Provider>
    );

    fireEvent.click(screen.getByRole("button", { name: /csv/i }));
    expect(mockConvertToCsv).toHaveBeenCalled();
  });

  it("should call convertToXml when XML button is clicked", () => {
    const mockConvertToXml = jest.fn();

    mockUseTransactionDetailsPreview.mockReturnValue({
      convertToCsv: jest.fn(),
      convertToPdf: jest.fn(),
      convertToXml: mockConvertToXml,
      fileObj: { fileData: "mockPdfSrc" },
      isLoading: false
    });

    render(
      <Provider store={store}>
        <Router>
          <TransactionDetailsPreviewPage />
        </Router>
      </Provider>
    );

    fireEvent.click(screen.getByRole("button", { name: /xml/i }));
    expect(mockConvertToXml).toHaveBeenCalled();
  });

  it("should render the correct file preview when fileObj is not null", () => {
    const mockFileObj = { fileData: "mockPdfSrc" };

    mockUseTransactionDetailsPreview.mockReturnValue({
      convertToCsv: jest.fn(),
      convertToPdf: jest.fn(),
      convertToXml: jest.fn(),
      fileObj: mockFileObj,
      isLoading: false
    });

    render(
      <Provider store={store}>
        <Router>
          <TransactionDetailsPreviewPage />
        </Router>
      </Provider>
    );

    const iframe = screen.getByTitle("PDF Document");
    expect(iframe).toHaveAttribute("src", "mockPdfSrc");
  });
});

function generatePayload(): {
  journalId: string;
  period: string;
  date: string;
  credit: string;
  debit: string;
  type: string;
  user: string;
  journalNo: string;
  narrative: string;
} {
  throw new Error("Function not implemented.");
}
function dispatch(
  arg0: AsyncThunkAction<
    { data: unknown; fileName: any },
    {
      payload: {
        journalId: string;
        period: string;
        date: string;
        credit: string;
        debit: string;
        type: string;
        user: string;
        journalNo: string;
        narrative: string;
      };
    },
    {
      state?: unknown;
      dispatch?: Dispatch;
      extra?: unknown;
      rejectValue?: unknown;
      serializedErrorType?: unknown;
      pendingMeta?: unknown;
      fulfilledMeta?: unknown;
      rejectedMeta?: unknown;
    }
  >
): any {
  throw new Error("Function not implemented.");
}

function setLoading(arg0: boolean) {
  throw new Error("Function not implemented.");
}
