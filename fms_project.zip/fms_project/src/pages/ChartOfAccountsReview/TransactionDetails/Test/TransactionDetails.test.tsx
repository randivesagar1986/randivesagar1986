import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import configureStore from "redux-mock-store";
import thunk from "redux-thunk";
import { STATUS } from "@/types/UseStateType";
import TransactionDetails from "../TransactionDetails";

const mockStore = configureStore([thunk]);

describe("TransactionDetails", () => {
  let store: any;

  beforeEach(() => {
    store = mockStore({
      chartOfAccountsReviewList: {
        transactionDetails: {
          journalHeaderDetails: {
            period_no: "2023-01",
            description: "January 2023",
            journal_date: "2023-01-01",
            debit: 1000,
            credit: 1000,
            journal_type_mapping: "Type A",
            user_code: "User123",
            det_num: "12345",
            narrative: "Test Narrative",
            pct_narrative: "Additional Narrative"
          },
          journalDetails: []
        },
        tranStatus: STATUS.SUCCESS,
        transactionDetailsPagination: {
          currentPage: 1,
          totalPages: 10,
          pageSize: 5,
          data: []
        }
      },
      financialPeriods: {
        journalId: "someJournalId"
      },
      userAccessRights: {
        rights: []
      }
    });
  });

  it("should render the transaction details correctly", () => {
    render(
      <Provider store={store}>
        <Router>
          <TransactionDetails />
        </Router>
      </Provider>
    );

    expect(screen.getByText((content) => content.includes("January 2023"))).toBeInTheDocument();
    expect(screen.getByText("01 Jan 2023")).toBeInTheDocument();
    expect(screen.getByText("Type A")).toBeInTheDocument();
    expect(screen.getByText("User123")).toBeInTheDocument();
    expect(screen.getByText("12345")).toBeInTheDocument();
    expect(screen.getByText("Test Narrative Additional Narrative")).toBeInTheDocument();
  });

  it("should disable preview button if user does not have print rights", () => {
    store = mockStore({
      chartOfAccountsReviewList: {
        transactionDetails: {
          journalHeaderDetails: {
            period_no: "2023-01",
            description: "January 2023",
            journal_date: "2023-01-01",
            debit: 1000,
            credit: 1000,
            journal_type_mapping: "Type A",
            user_code: "User123",
            det_num: "12345",
            narrative: "Test Narrative",
            pct_narrative: "Additional Narrative"
          },
          journalDetails: []
        },
        tranStatus: STATUS.SUCCESS
      },
      financialPeriods: {
        journalId: "someJournalId"
      },
      userAccessRights: {
        rights: []
      },
      transactionDetailsPagination: {
        currentPage: 1,
        totalPages: 10,
        pageSize: 5,
        data: []
      }
    });

    render(
      <Provider store={store}>
        <Router>
          <TransactionDetails />
        </Router>
      </Provider>
    );

    const previewButton = screen.getByText("generalLedgerSetup.preview");
    expect(previewButton).toBeDisabled();
  });

  it("should render help button", () => {
    render(
      <Provider store={store}>
        <Router>
          <TransactionDetails />
        </Router>
      </Provider>
    );

    expect(screen.getByText("common.help")).toBeInTheDocument();
  });

  it("should render the journal date correctly", () => {
    render(
      <Provider store={store}>
        <Router>
          <TransactionDetails />
        </Router>
      </Provider>
    );

    expect(screen.getByText("01 Jan 2023")).toBeInTheDocument();
  });

  it("should render the journal type correctly", () => {
    render(
      <Provider store={store}>
        <Router>
          <TransactionDetails />
        </Router>
      </Provider>
    );

    expect(screen.getByText("Type A")).toBeInTheDocument();
  });

  it("should render the user code correctly", () => {
    render(
      <Provider store={store}>
        <Router>
          <TransactionDetails />
        </Router>
      </Provider>
    );

    expect(screen.getByText("User123")).toBeInTheDocument();
  });

  it("should render the journal number correctly", () => {
    render(
      <Provider store={store}>
        <Router>
          <TransactionDetails />
        </Router>
      </Provider>
    );

    expect(screen.getByText("12345")).toBeInTheDocument();
  });

  it("should render the narrative correctly", () => {
    render(
      <Provider store={store}>
        <Router>
          <TransactionDetails />
        </Router>
      </Provider>
    );

    expect(screen.getByText("Test Narrative Additional Narrative")).toBeInTheDocument();
  });
});
