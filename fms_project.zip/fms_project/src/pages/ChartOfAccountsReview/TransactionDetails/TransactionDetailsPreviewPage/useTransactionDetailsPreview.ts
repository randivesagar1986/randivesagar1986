import { AppDispatch, useAppSelector } from "@/store/store";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import {
  getTransactionDetails,
  getTransactionDetailsCSV,
  getTransactionDetailsPDF,
  getTransactionDetailsXML
} from "../../state/ChartOfAccountsReviewList.slice";

interface MyResponseType {
  payload: string;
}
const useTransactionDetailsPreview = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const dispatch = useDispatch<AppDispatch>();

  const [isLoading, setLoading] = useState<boolean>(false);
  const [fileObj, setFileObj] = useState<{
    fileData: string;
  }>({
    fileData: ""
  });

  const historyState = history.location.state as any;
  const { transactionDetails } = useAppSelector((state) => state.chartOfAccountsReviewList);

  useEffect(() => {
    if (historyState?.transactionBrowseRow?.journal_id) {
      dispatch(
        getTransactionDetails({
          journalId: historyState?.transactionBrowseRow?.journal_id
        })
      );
    }
  }, []);

  const getDate = (date?: any) => {
    const newDate = date
      ? new Date(date)
          .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric"
          })
          .replace("Sept", "Sep")
      : new Date()
          .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric"
          })
          .replace("Sept", "Sep");

    return newDate;
  };

  const formatNumberWithTwoDecimals = (number: number) => {
    const formattedNumber = number.toFixed(2);
    return formattedNumber || "0.00";
  };

  const generatePayload = () => ({
    journalId: transactionDetails?.journalHeaderDetails?.journal_id,
    period: `${transactionDetails?.journalHeaderDetails?.period_no} ${transactionDetails?.journalHeaderDetails?.description}`,
    date: getDate(transactionDetails?.journalHeaderDetails?.journal_date),
    credit: formatNumberWithTwoDecimals(transactionDetails?.journalHeaderDetails?.credit),
    debit: formatNumberWithTwoDecimals(transactionDetails?.journalHeaderDetails?.debit),
    type: transactionDetails?.journalHeaderDetails?.journal_type_mapping,
    user: transactionDetails?.journalHeaderDetails?.user_code,
    journalNo: transactionDetails?.journalHeaderDetails?.det_num,
    narrative: `${transactionDetails?.journalHeaderDetails?.narrative} ${
      transactionDetails?.journalHeaderDetails?.pct_narrative || ""
    }`
  });

  const createPdfPreviewFromBase64 = async () => {
    try {
      const { payload } = await dispatch(getTransactionDetailsPDF({ payload: generatePayload() }));
      const { data } = payload as any;

      const blob = new Blob([data], { type: "application/pdf" });
      const pdfUri = URL.createObjectURL(blob);
      setFileObj({
        fileData: pdfUri
      });
    } catch (error) {
      setLoading(false);
      // console.error("Error decoding base64 string:", error);  // TODO: Error Handling
    }
  };

  useEffect(() => {
    if (transactionDetails?.journalHeaderDetails?.journal_id) {
      createPdfPreviewFromBase64();
    }
  }, [transactionDetails?.journalHeaderDetails?.journal_id]);

  const convertToPdf = async () => {
    setLoading(true);
    const { payload } = await dispatch(getTransactionDetailsPDF({ payload: generatePayload() }));
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/pdf" });
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName || t("generalLedgerSetup.transactionBrowse.transactionNominalJournalDetailsFile");
    link.click();
    setLoading(false);
  };

  const convertToXml = async () => {
    setLoading(true);
    const res: any = await dispatch(getTransactionDetailsXML({ payload: generatePayload() }));
    const xmlData = res.payload.data;
    const blob = new Blob([xmlData], { type: "application/xml" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = res?.payload?.fileName ?? "file";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  const convertToCsv = async () => {
    setLoading(true);
    const res: any = await dispatch(getTransactionDetailsCSV({ payload: generatePayload() }));
    const csvData = res.payload.data;
    const blob = new Blob([csvData], { type: "text/csv" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = res?.payload?.fileName ?? "file";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  return {
    convertToCsv,
    convertToPdf,
    convertToXml,
    fileObj,
    isLoading
  };
};

export default useTransactionDetailsPreview;
