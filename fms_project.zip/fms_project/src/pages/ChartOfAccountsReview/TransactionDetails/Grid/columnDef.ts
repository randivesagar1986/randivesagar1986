import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const transactionSelectPeriodDef: TColumnDef = [
  {
    headerName: "Ledger Code",
    field: "ledger_code"
  },
  {
    headerName: "Fund",
    field: "fund_code_display",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Ledger Description",
    field: "ledger_des"
  },
  {
    headerName: "Cost Code",
    field: "cost_code"
  },
  {
    headerName: "Cost Centre",
    field: "cost_des"
  },
  {
    headerName: "Debit",
    field: "debit",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Credit",
    field: "credit",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "VAT Amount",
    field: "vat_amount",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "VAT Code",
    field: "vat_code"
  },
  {
    headerName: "",
    field: "actions",
    cellRenderer: "GridCellLink"
  }
];

export default transactionSelectPeriodDef;
