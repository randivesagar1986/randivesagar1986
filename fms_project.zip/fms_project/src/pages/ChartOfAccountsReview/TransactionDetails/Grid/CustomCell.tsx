import { cellRendererType } from "@/components/GridTable/GridTable";
import { Button, ButtonColor } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import { getDate, getSessionItem } from "@/utils/getDataSource";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useHistory, useParams } from "react-router-dom";
import { RootContext, useAppContext } from "@/routes/Routes.utils";

const CustomCell = ({ field, row }: cellRendererType) => {
  const { fromDate, toDate } = useParams<{ fromDate: string; toDate: string }>();
  const { redirectToBankReconciledDetails } = useAppContext();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { id } = useParams<{ id: string }>();
  const { selectedRow } = useAppSelector((state) => state.chartOfAccountsReviewList);
  const { transactionDetails } = useAppSelector((state) => state.chartOfAccountsReviewList);
  const invoiceDetails = transactionDetails?.invoiceDetails;
  const isDisabled = invoiceDetails === null;

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const redirectToViewPage = (row: any) => {
    let navUrl = "";
    if (invoiceDetails?.invoice_type === "PI" && invoiceDetails?.order_id !== 0) {
      navUrl = `/general-ledger/chart-accounts-review/transaction-period/from/${fromDate}/to/${toDate}/transaction-details/${id}/invoice-credit-note/order-invoice/orderno/${invoiceDetails?.order_id}/invoiceId/${invoiceDetails?.invoice_id}`;
    } else if (invoiceDetails?.invoice_type === "PI" && invoiceDetails?.order_id === 0) {
      navUrl = `/general-ledger/chart-accounts-review/transaction-period/from/${fromDate}/to/${toDate}/transaction-details/${id}/invoice-credit-note/nonorder-invoice/invoiceId/${invoiceDetails?.invoice_id}`;
    } else if (invoiceDetails?.invoice_type === "PC") {
      navUrl = `/general-ledger/chart-accounts-review/transaction-period/from/${fromDate}/to/${toDate}/transaction-details/${id}/invoice-credit-note/credite-note/invoiceId/${invoiceDetails?.invoice_id}`;
    }

    history.push({
      pathname: navUrl,
      state: {
        ...historyState,
        selectedRow
      }
    });
  };

  const getContent = () => {
    if (field === "actions") {
      return (
        <>
          <Button
            color={ButtonColor.Utility}
            className="segments-buttons"
            onClick={() => redirectToViewPage(row)}
            disabled={isDisabled}
          >
            {t("common.view02")}
          </Button>
        </>
      );
    }
    if (field === "debit") {
      const formattedDebit =
        row?.debit !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.debit) : specialCharacters.zero;
      return <>{formattedDebit}</>;
    }
    if (field === "credit") {
      return <>{row?.credit !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.credit) : specialCharacters.zero}</>;
    }
    if (field === "vat_amount") {
      return (
        <>
          {row?.vat_amount !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.vat_amount) : specialCharacters.zero}
        </>
      );
    }
    if (field === "fund_code_display") {
      return <>{row?.fund_code_display !== " " ? row?.fund_code_display : "-"}</>;
    }
    if (field === "journal_date") {
      return <>{getDate(row?.journal_date)}</>;
    }
    return null;
  };
  return getContent();
};

export default CustomCell;
