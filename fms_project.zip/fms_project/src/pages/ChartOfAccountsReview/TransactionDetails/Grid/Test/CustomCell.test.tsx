import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useHistory, useParams } from "react-router-dom";
import { useAppSelector } from "@/store/store";
import { getDate } from "@/utils/getDataSource";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import { useAppContext } from "@/routes/Routes.utils";
import CustomCell from "../CustomCell";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("@essnextgen/ui-kit", () => ({
  Button: jest.fn((props: any) => (
    <button
      type="button"
      id="button"
      {...props}
    >
      {props?.children}
    </button>
  )),
  ButtonColor: {
    Utility: "utility"
  }
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn(),
  useParams: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("@/utils/getDataSource", () => ({
  getDate: jest.fn()
}));

jest.mock("@/routes/Routes.utils", () => ({
  useAppContext: jest.fn()
}));

describe("CustomCell Component", () => {
  const mockHistory = {
    push: jest.fn(),
    location: {
      state: {}
    }
  };

  const mockParams = {
    fromDate: "2021-01-01",
    toDate: "2021-12-31",
    id: "123"
  };

  const mockState = {
    chartOfAccountsReviewList: {
      selectedRow: { user_id: "123" },
      transactionDetails: {
        invoiceDetails: {
          invoice_type: "PI",
          order_id: 1,
          invoice_id: "456"
        }
      }
    }
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    (useParams as jest.Mock).mockReturnValue(mockParams);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    (useAppContext as jest.Mock).mockReturnValue({
      redirectToBankReconciledDetails: jest.fn()
    });
    jest.clearAllMocks();
  });

  it("should render the actions button and handle click", () => {
    const row = { user_id: "123" };
    render(
      <CustomCell
        field="actions"
        row={row}
      />
    );
    const button = screen.getByText("common.view02");
    expect(button).toBeInTheDocument();
    fireEvent.click(button);
    expect(mockHistory.push).toHaveBeenCalledWith({
      pathname: `/general-ledger/chart-accounts-review/transaction-period/from/2021-01-01/to/2021-12-31/transaction-details/123/invoice-credit-note/order-invoice/orderno/1/invoiceId/456`,
      state: {
        selectedRow: mockState.chartOfAccountsReviewList.selectedRow
      }
    });
  });

  it("should render the formatted debit value", () => {
    const row = { debit: 1234.56 };
    render(
      <CustomCell
        field="debit"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for debit when it is zero", () => {
    const row = { debit: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="debit"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted credit value", () => {
    const row = { credit: 1234.56 };
    render(
      <CustomCell
        field="credit"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for credit when it is zero", () => {
    const row = { credit: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="credit"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted vat_amount value", () => {
    const row = { vat_amount: 1234.56 };
    render(
      <CustomCell
        field="vat_amount"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for vat_amount when it is zero", () => {
    const row = { vat_amount: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="vat_amount"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the fund_code_display value", () => {
    const row = { fund_code_display: "FUND123" };
    render(
      <CustomCell
        field="fund_code_display"
        row={row}
      />
    );
    expect(screen.getByText("FUND123")).toBeInTheDocument();
  });

  it('should render "-" for fund_code_display when it is empty', () => {
    const row = { fund_code_display: " " };
    render(
      <CustomCell
        field="fund_code_display"
        row={row}
      />
    );
    expect(screen.getByText("-")).toBeInTheDocument();
  });

  it("should render the formatted journal_date value", () => {
    const row = { journal_date: "2021-01-01" };
    (getDate as jest.Mock).mockReturnValue("01/01/2021");
    render(
      <CustomCell
        field="journal_date"
        row={row}
      />
    );
    expect(screen.getByText("01/01/2021")).toBeInTheDocument();
  });

  it("should render null when field is not matched", () => {
    const row = { narrative: "Test Narrative" };
    const { container } = render(
      <CustomCell
        field="other_field"
        row={row}
      />
    );
    expect(container).toBeEmptyDOMElement();
  });
});
