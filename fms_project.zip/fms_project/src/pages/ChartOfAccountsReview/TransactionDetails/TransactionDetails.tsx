import Layout from "@/components/Layout/Layout";
import { Button, ButtonColor, ButtonSize, Grid, GridItem, Pagination, IPaginationProps } from "@essnextgen/ui-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { getDate, getSessionItem } from "@/utils/getDataSource";
import { useParams, useHistory } from "react-router-dom";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS } from "@/types/UseStateType";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { canDo } from "@/store/state/userAccessRights.slice";
import Loader, { loadingConfig } from "@/components/Loader/Loader";
import CustomCell from "./Grid/CustomCell";
import transactionSelectPeriodDef from "./Grid/columnDef";
import useTransactionSelectPeriod from "../TransactionSelectPeriod/useTransactionSelectPeriod";
import {
  getTransactionDetails,
  getTransactionPaginationDetails,
  actions as brsAction
} from "../state/ChartOfAccountsReviewList.slice";

type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];

const TransactionDetails = () => {
  const {
    transactionDetails,
    tranStatus,
    transactionDetailsPagination,
    transactionDetailsPaginationStatus,
    selectedRow
  } = useAppSelector((state) => state.chartOfAccountsReviewList);
  const { journalId } = useAppSelector((state) => state.financialPeriods);
  const dispatch = useDispatch<AppDispatch>();
  const { t, selectedRowHandler } = useTransactionSelectPeriod();
  const { fromDate, toDate } = useParams<{ fromDate: string; toDate: string }>();
  const journalHeaderDetails = transactionDetails?.journalHeaderDetails;
  const history = useHistory();
  const historyState = history.location.state as any;
  const userAccessRights = useAppSelector((state) => state.userAccessRights);
  const canPrint = canDo(userAccessRights, { module: "General Ledger Review", action: "Print" });
  const { currentPage, totalPages, pageSize, data } = transactionDetailsPagination;

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const onCloseHandler = () => {
    history.push({
      pathname: `/general-ledger/chart-accounts-review/transaction-period/from/${fromDate}/to/${toDate}`,
      state: {
        ...historyState,
        from: "transactionDetails"
      }
    });
  };

  useEffect(() => {
    const fetchTransactionDetails = async () => {
      await dispatch(
        getTransactionDetails({
          journalId: historyState?.journalId
        })
      );
      await dispatch(
        getTransactionPaginationDetails({
          journalId: historyState?.journalId,
          pageNumber: 1,
          pageSize,
          callback: (data) => {
            dispatch(brsAction.setSelectedRow(data?.data[0]));
          }
        })
      );
    };

    fetchTransactionDetails();
  }, []);

  useEffect(() => {
    const timerID = setTimeout(() => {
      const element = document.getElementById(`rowIndex-transactionDetailsTable-0`)?.focus();
    }, 10);

    return () => {
      clearTimeout(timerID);
    };
  }, [transactionDetailsPagination]);

  const handlePreviewClick = () => {
    history.push(`${history.location.pathname}/preview`, { ...historyState });
  };

  const onPageChangeHandler: onChangeType = (e: any, page) => {
    dispatch(
      getTransactionPaginationDetails({
        journalId,
        pageNumber: page,
        pageSize,
        callback: (data) => {
          dispatch(brsAction.setSelectedRow(data?.data[0]));
        }
      })
    );
  };

  const loaderConfig: loadingConfig = {};

  return (
    <>
      {tranStatus === STATUS.LOADING ? (
        <Loader loadingConfig={loaderConfig} />
      ) : (
        <>
          <Layout
            pageTitle={t("generalLedgerSetup.transactionDetails")}
            isBreadcrumbRequired
          >
            <Grid className="mt-8">
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("generalLedgerSetup.period")}</div>
                  <div className="mt-8">
                    {journalHeaderDetails?.period_no} {journalHeaderDetails?.description}
                  </div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("generalLedgerSetup.date")}</div>
                  <div className="mt-8">{getDate(journalHeaderDetails?.journal_date)}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("generalLedgerSetup.debit")}</div>
                  <div className="mt-8">{numberFormatter.format(journalHeaderDetails?.debit)}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("generalLedgerSetup.credit")}</div>
                  <div className="mt-8">{numberFormatter.format(journalHeaderDetails?.credit)}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("generalLedgerSetup.type")}</div>
                  <div className="mt-8">{journalHeaderDetails?.journal_type_mapping}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("generalLedgerSetup.user")}</div>
                  <div className="mt-8">{journalHeaderDetails?.user_code}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("generalLedgerSetup.journalNo")}</div>
                  <div className="mt-8">{journalHeaderDetails?.det_num}</div>
                </div>
              </GridItem>
              <GridItem
                lg={12}
                xl={12}
                sm={4}
              >
                <div className="">
                  <div className="essui-form-label">{t("generalLedgerSetup.narrative")}</div>
                  <div className="mt-8">{`${journalHeaderDetails?.narrative} ${
                    journalHeaderDetails?.pct_narrative || ""
                  }`}</div>
                </div>
              </GridItem>
            </Grid>
          </Layout>

          <Layout
            isBreadcrumbRequired={false}
            type="transparent"
          >
            <GridTableNew
              columnDef={transactionSelectPeriodDef}
              dataSource={transactionDetailsPagination?.data || []}
              isLoading={transactionDetailsPaginationStatus === STATUS.LOADING}
              customCell={CustomCell}
              dataTestId="transactionDetailsTable"
              id="transactionDetailsTable"
              selectedRow={selectedRow}
              selectedRowHandler={selectedRowHandler as any}
              className=""
              footer={
                <Pagination
                  count={totalPages}
                  page={currentPage}
                  onChange={onPageChangeHandler}
                  className="fl-rt"
                />
              }
            />
          </Layout>

          <Layout isBreadcrumbRequired={false}>
            <Grid className="flex-rev">
              <GridItem
                sm={4}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="rightbtn">
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Primary}
                    onClick={handlePreviewClick}
                    disabled={!canPrint}
                  >
                    {t("generalLedgerSetup.preview")}
                  </Button>
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    onClick={onCloseHandler}
                  >
                    {t("generalLedgerSetup.close")}
                  </Button>
                </div>
              </GridItem>
              <GridItem
                sm={8}
                lg={6}
                md={4}
              >
                <div>
                  <HelpButton
                    identifier="testIdentifier"
                    labelName={t("common.help")}
                  />
                </div>
              </GridItem>
            </Grid>
          </Layout>
        </>
      )}
    </>
  );
};

export default TransactionDetails;
