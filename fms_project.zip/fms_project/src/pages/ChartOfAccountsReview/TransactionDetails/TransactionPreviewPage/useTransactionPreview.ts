import { AppDispatch, useAppSelector } from "@/store/store";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import { getFinancialPeriods } from "../../state/financialPeriod.slice";
import { getTransactionCSV, getTransactionPDF, getTransactionXML } from "../../state/ChartOfAccountsReviewList.slice";

interface MyResponseType {
  payload: string;
}
const useTransactionPreview = () => {
  const { t } = useTranslation();
  const [isLoading, setLoading] = useState<boolean>(false);
  const history = useHistory();
  const historyState = history.location.state as any;

  const selectedfundCode = useAppSelector((state) => state.fundCode.selectedfundCode);

  const dispatch = useDispatch<AppDispatch>();
  const [fromDescription, setFromDescription] = useState("");
  const [toDescription, setToDescription] = useState("");
  const { fromDate, toDate } = useParams<{
    fromDate: string;
    toDate: string;
  }>();

  useEffect(() => {
    dispatch(
      getFinancialPeriods({
        status: 0,
        callback: (data) => {
          const fromDescriptionRes = data.find((p: any) => String(p.period_no) === fromDate);
          setFromDescription(fromDescriptionRes?.description);

          const toDescriptionRes = data.find((p: any) => String(p.period_no) === toDate);
          setToDescription(toDescriptionRes?.description);
        }
      })
    );
  }, []);

  const generatePayload = () => ({
    costId: historyState?.costCentreRecord?.cost_id,
    leddefId: historyState?.ledgerRecord?.leddef_id,
    fundId: selectedfundCode?.fund_id,
    costDescription: historyState?.costCentreRecord
      ? `${historyState?.costCentreRecord?.cost_code} ${historyState?.costCentreRecord?.cost_des}`
      : "All Cost Centres",
    ledgerDescription: historyState?.ledgerRecord
      ? `${historyState?.ledgerRecord?.ledger_code} ${historyState?.ledgerRecord?.ledger_des}`
      : "All Ledger Codes",
    fundDescription: selectedfundCode?.ledger_des
      ? `${selectedfundCode?.fund_code} ${selectedfundCode.ledger_des}`
      : t("purchaseOrder.allFunds"),
    fromPeriod: fromDate,
    toPeriod: toDate,
    fromPeriodDescription: fromDescription,
    toPeriodDescription: toDescription
  });

  const [fileObj, setFileObj] = useState<{
    fileData: string;
  }>({
    fileData: ""
  });

  useEffect(() => {
    if (fromDescription && toDescription) createPdfPreviewFromBase64();
  }, [fromDescription, toDescription]);

  const convertToCsv = async () => {
    setLoading(true);
    const { payload } = await dispatch(getTransactionCSV({ payload: generatePayload() }));
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "text/csv" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName || t("generalLedgerSetup.transactionBrowse.transactionBrowseFile");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  const createPdfPreviewFromBase64 = async () => {
    try {
      const { payload } = await dispatch(getTransactionPDF({ payload: generatePayload() }));
      const { data } = payload as any;

      const blob = new Blob([data], { type: "application/pdf" });
      const pdfUri = URL.createObjectURL(blob);
      setFileObj({
        fileData: pdfUri
      });
    } catch (error) {
      setLoading(false);
      console.error("Error decoding base64 string:", error);
    }
  };

  const convertToPdf = async () => {
    setLoading(true);
    const { payload } = await dispatch(getTransactionPDF({ payload: generatePayload() }));
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/pdf" });

    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName || `${t("generalLedgerSetup.transactionBrowse.transactionBrowseFile")}.pdf`; // Set the download attribute with file extension
    link.click();
    setLoading(false);
  };

  const convertToXml = async () => {
    setLoading(true);
    const { payload } = await dispatch(getTransactionXML({ payload: generatePayload() }));
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/xml" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName || t("generalLedgerSetup.transactionBrowse.transactionBrowseFile");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  return {
    convertToCsv,
    convertToPdf,
    convertToXml,
    fileObj,
    isLoading
  };
};

export default useTransactionPreview;
