import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { IPaginationProps } from "@essnextgen/ui-kit";
import { useHistory } from "react-router-dom";
import useDebounce from "@/hooks/useDebounce";
import { costCentreBrowseFilter, ccBrowseActions } from "../state/CostCentreBrowse.slice";

type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];
const useCostCentreBrowse = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const [lookingFor, setLookingFor] = useState<string>("");
  const historyState = history.location.state as any;

  const { costCentreBrowseStatus, selectedRow, filterState } = useAppSelector((state) => state.ccBrowse);

  const { tranDetails, pageSize, currentPage, totalPages } = useAppSelector(
    ({ ccBrowse }) => ccBrowse?.costCentresBrowseList
  );
  const selectedRowHandler = (row: { [key: string]: any }) => dispatch(ccBrowseActions.setSelectedRow(row));

  const debouncedValue = useDebounce(lookingFor, 700);

  useEffect(() => {
    if (lookingFor !== filterState?.lookingFor && lookingFor !== undefined && debouncedValue) {
      dispatch(ccBrowseActions.setFilters({ lookingFor }));
    }
  }, [debouncedValue]);

  useEffect(() => {
    dispatch(
      costCentreBrowseFilter({
        ...filterState
      })
    );
  }, [filterState]);

  const onChangeHandler: onChangeType = (e, page) => {
    setLookingFor("");
    dispatch(
      ccBrowseActions.setFilters({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize,
        costId: undefined
      })
    );
  };

  const lookingForChangehandler = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setLookingFor(value);
  };

  const onSelectCostCentreRecord = () => {
    history.push(
      {
        pathname: "/general-ledger/chart-accounts-review"
      },
      { ...historyState, costCentreRecord: selectedRow, from: "cost centre browse" }
    );
  };

  const onCancel = () => {
    dispatch(
      ccBrowseActions.setFilters({
        ...filterState,
        pageNumber: 1
      })
    );
    history.push("/general-ledger/chart-accounts-review", { ...historyState });
  };

  const onSelectCostCentresCheckBox = (e: any) => {
    setLookingFor("");
    dispatch(
      ccBrowseActions.setFilters({
        ...filterState,
        lookingFor: "",
        pageNumber: 1,
        excludeZero: e.target.checked,
        costId: undefined
      })
    );
  };

  return {
    t,
    tranDetails,
    currentPage,
    totalPages,
    selectedRow,
    costCentreBrowseStatus,
    onSelectCostCentresCheckBox,
    onChangeHandler,
    selectedRowHandler,
    onSelectCostCentreRecord,
    onCancel,
    lookingFor,
    lookingForChangehandler,
    history,
    historyState,
    filterState
  };
};

export default useCostCentreBrowse;
