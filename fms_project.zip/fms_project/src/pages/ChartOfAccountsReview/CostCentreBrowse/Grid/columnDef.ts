import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const costCentreBrowseDef: TColumnDef = [
  {
    headerName: "Code",
    field: "cost_code"
  },
  {
    headerName: "Description",
    field: "cost_des",
    enableTooltip: true
  },
  {
    headerName: "Fixed Budget",
    field: "orig_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Current Budget",
    field: "curr_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Commitment (CM)",
    field: "commitment",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Invoiced (IV)",
    field: "unpaid",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Current Actual (CA)",
    field: "act",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "CM + IV + CA",
    field: "cia",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Remaining Budget",
    field: "remaining",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "",
    field: "actions",
    cellRenderer: "GridCellLink"
  }
];

export default costCentreBrowseDef;
