import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import CustomCell from "../CustomCell";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    getAuthTokens: jest.fn()
  }
}));

jest.mock("@essnextgen/ui-kit", () => ({
  Button: jest.fn((props: any) => (
    <button
      {...props}
      type="button"
    >
      {props?.children}
    </button>
  )),
  ButtonColor: {
    PRIMARY: "primary",
    SECONDARY: "secondary"
  }
}));

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

describe("CustomCell Component", () => {
  const mockDispatch = jest.fn();
  const mockHistory = {
    push: jest.fn(),
    location: {
      state: {}
    }
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue(mockHistory);
    jest.clearAllMocks();
  });

  it("should render the actions button and handle click", () => {
    const row = { id: 1 };
    render(
      <CustomCell
        field="actions"
        row={row}
      />
    );
    const button = screen.getByText("generalLedgerSetup.select");
    expect(button).toBeInTheDocument();
    fireEvent.click(button);
    expect(mockHistory.push).toHaveBeenCalledWith(
      {
        pathname: "/general-ledger/chart-accounts-review"
      },
      { ...mockHistory.location.state, costCentreRecord: row, from: "cost centre browse" }
    );
  });

  it("should render the formatted orig_bud value", () => {
    const row = { orig_bud: 1234.56 };
    render(
      <CustomCell
        field="orig_bud"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render the formatted curr_bud value", () => {
    const row = { curr_bud: 1234.56 };
    render(
      <CustomCell
        field="curr_bud"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render the formatted commitment value", () => {
    const row = { commitment: 1234.56 };
    render(
      <CustomCell
        field="commitment"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for commitment when it is zero", () => {
    const row = { commitment: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="commitment"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted unpaid value", () => {
    const row = { unpaid: 1234.56 };
    render(
      <CustomCell
        field="unpaid"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for unpaid when it is zero", () => {
    const row = { unpaid: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="unpaid"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted act value", () => {
    const row = { act: 1234.56 };
    render(
      <CustomCell
        field="act"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for act when it is zero", () => {
    const row = { act: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="act"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted cia value", () => {
    const row = { cia: 1234.56 };
    render(
      <CustomCell
        field="cia"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for cia when it is zero", () => {
    const row = { cia: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="cia"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });

  it("should render the formatted remaining value", () => {
    const row = { remaining: 1234.56 };
    render(
      <CustomCell
        field="remaining"
        row={row}
      />
    );
    expect(screen.getByText("1,234.56")).toBeInTheDocument();
  });

  it("should render zero for remaining when it is zero", () => {
    const row = { remaining: KEYBOARD_STRING.Zero };
    render(
      <CustomCell
        field="remaining"
        row={row}
      />
    );
    expect(screen.getByText(specialCharacters.zero)).toBeInTheDocument();
  });
});
