import { renderHook } from "@testing-library/react-hooks";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import useCostCentreBrowseFilters from "../useCostCentreBrowseFilters";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

describe("useCostCentreBrowseFilters Hook", () => {
  const mockState = {
    ccBrowse: {
      filterState: {
        excludeZero: false
      }
    }
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(mockState));
    jest.clearAllMocks();
  });

  it("should initialize the hook correctly", () => {
    const { result } = renderHook(() => useCostCentreBrowseFilters());

    expect(result.current.t).toBeDefined();
    expect(result.current.filterState).toEqual(mockState.ccBrowse.filterState);
  });
});
