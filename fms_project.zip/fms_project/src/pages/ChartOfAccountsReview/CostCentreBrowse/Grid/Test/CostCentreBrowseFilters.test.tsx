import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import CostCentreBrowseFilters from "../CostCentreBrowseFilters";
import useCostCentreBrowseFilters from "../useCostCentreBrowseFilters";

// Mock dependencies
jest.mock("@essnextgen/ui-kit", () => ({
  CheckBox: jest.fn((props: any) => (
    <input
      type="checkbox"
      id="checkBox"
      {...props}
    />
  )),
  TextInput: jest.fn((props: any) => (
    <input
      data-testid={props?.dataTestId}
      type="text"
      id="textInput"
      {...props}
    />
  )),
  Grid: jest.fn((props: any) => (
    <div
      {...props}
      id="grid"
    >
      {props?.children}
    </div>
  )),
  GridItem: jest.fn((props: any) => (
    <div
      {...props}
      id="gridItem"
    >
      {props?.children}
    </div>
  )),
  FormLabel: jest.fn((props: any) => (
    <div
      {...props}
      id="label"
    >
      {props?.children}
    </div>
  ))
}));

jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("../useCostCentreBrowseFilters", () => jest.fn());

describe("CostCentreBrowseFilters Component", () => {
  const mockUseCostCentreBrowseFilters = {
    t: (key: string) => key,
    filterState: {
      excludeZero: false
    }
  };

  const mockProps = {
    onSelectCostCentresCheckBox: jest.fn(),
    lookingFor: "",
    lookingForChangehandler: jest.fn()
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useCostCentreBrowseFilters as jest.Mock).mockReturnValue(mockUseCostCentreBrowseFilters);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<CostCentreBrowseFilters {...mockProps} />);
    expect(screen.getByText("common.lookingFor")).toBeInTheDocument();
    expect(screen.getAllByRole("checkbox")).toHaveLength(1);
  });

  it("should call lookingForChangehandler when the input value changes", () => {
    render(<CostCentreBrowseFilters {...mockProps} />);
    fireEvent.change(screen.getByTestId("chart-accounts-review-filters-looking-for"), { target: { value: "test" } });
    expect(mockProps.lookingForChangehandler).toHaveBeenCalledWith(expect.any(Object));
  });

  it("should call onSelectCostCentresCheckBox when the checkbox is changed", () => {
    render(<CostCentreBrowseFilters {...mockProps} />);
    fireEvent.click(screen.getByRole("checkbox"));
    expect(mockProps.onSelectCostCentresCheckBox).toHaveBeenCalledWith(expect.any(Object));
  });

  it("should prevent non-alphanumeric characters in the input", () => {
    render(<CostCentreBrowseFilters {...mockProps} />);
    const input = screen.getByRole("textbox");
    fireEvent.keyDown(input, { key: "!" });
    expect(input).toHaveValue("");
  });
});
