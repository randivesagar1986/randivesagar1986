import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import CostCentrePreviewPage from "../CostCentrePreviewPage";
import useCostCentrePreview from "../useCostCentrePreview";

// Mock dependencies
jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@/shared/components/Preview/PreviewSection", () =>
  jest.fn((props) => (
    <>
      <div {...props}>PreviewSection</div>
      <div>
        <button
          onClick={props?.onPdfClick}
          type="button"
        >
          pdf
        </button>
        <button
          onClick={props?.onCsvClick}
          type="button"
        >
          csv
        </button>
        <button
          onClick={props?.onXmlClick}
          type="button"
        >
          xml
        </button>
      </div>
    </>
  ))
);
jest.mock("@/components/Loader/Loader", () => ({
  __esModule: true,
  default: jest.fn((props) => <div {...props}>Loader</div>),
  loadingConfig: jest.fn()
}));

jest.mock("../useCostCentrePreview", () => jest.fn());

describe("CostCentrePreviewPage Component", () => {
  const mockConvertToCsv = jest.fn();
  const mockConvertToPdf = jest.fn();
  const mockConvertToXml = jest.fn();

  const mockUseCostCentrePreview = {
    convertToCsv: mockConvertToCsv,
    convertToPdf: mockConvertToPdf,
    convertToXml: mockConvertToXml,
    fileObj: { fileData: "test-file-data" },
    isLoading: false
  };

  beforeEach(() => {
    (useTranslation as jest.Mock).mockReturnValue({
      t: (key: string) => key
    });
    (useCostCentrePreview as jest.Mock).mockReturnValue(mockUseCostCentrePreview);
    jest.clearAllMocks();
  });

  it("should render the component", () => {
    render(<CostCentrePreviewPage />);
    expect(screen.getByText("PreviewSection")).toBeInTheDocument();
  });

  it("should render the Loader component when isLoading is true", () => {
    (useCostCentrePreview as jest.Mock).mockReturnValue({
      ...mockUseCostCentrePreview,
      isLoading: true
    });
    render(<CostCentrePreviewPage />);
    expect(screen.getByText("Loader")).toBeInTheDocument();
  });

  it("should call convertToPdf when the PDF button is clicked", () => {
    render(<CostCentrePreviewPage />);
    const btn = screen.getByRole("button", { name: "pdf" });
    fireEvent.click(btn);
    expect(mockConvertToPdf).toHaveBeenCalled();
  });

  it("should call convertToCsv when the CSV button is clicked", () => {
    render(<CostCentrePreviewPage />);
    const btn = screen.getByRole("button", { name: "csv" });
    fireEvent.click(btn);
    expect(mockConvertToCsv).toHaveBeenCalled();
  });

  it("should call convertToXml when the XML button is clicked", () => {
    render(<CostCentrePreviewPage />);
    const btn = screen.getByRole("button", { name: "xml" });
    fireEvent.click(btn);
    expect(mockConvertToXml).toHaveBeenCalled();
  });

  it("should pass the correct props to PreviewSection", () => {
    render(<CostCentrePreviewPage />);
    const previewSection = screen.getByText("PreviewSection");
    expect(previewSection).toHaveAttribute("pageTitle", "generalLedgerSetup.preview");
    expect(previewSection).toHaveAttribute("pdfSrc", "test-file-data");
  });
});
