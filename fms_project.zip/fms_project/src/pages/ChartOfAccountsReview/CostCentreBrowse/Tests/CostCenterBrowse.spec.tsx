import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider, useDispatch } from "react-redux";
import { BrowserRouter as Router, useParams } from "react-router-dom";
import { FormProvider } from "react-hook-form";
import configureStore from "redux-mock-store";
import { useAppSelector } from "@/store/store";
import CostCentreBrowse from "../CostCentreBrowse";
import useCostCentreBrowse from "../useCostCentreBrowse";

jest.mock("../useCostCentreBrowse");

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn().mockImplementation((selector) => selector(initialState))
}));

jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn()
}));

const mockStore = configureStore([]);

const initialState = {
  t: (key: any) => key,
  tranDetails: [],
  currentPage: 1,
  totalPages: 5,
  selectedRow: null,
  costCentreBrowseStatus: "STATUS.LOADING",
  onSelectCostCentresCheckBox: jest.fn(),
  onChangeHandler: jest.fn(),
  selectedRowHandler: jest.fn(),
  onSelectCostCentreRecord: jest.fn(),
  onCancel: jest.fn(),
  lookingFor: "",
  lookingForChangehandler: jest.fn(),
  history: { push: jest.fn() },
  historyState: {},
  filterState: {},
  supplierCatalogue: {
    catalogueData: null,
    status: "idle"
  },
  glCentreLedgerLinksView: {
    availableCostCentreList: [],
    availableLedgerCodeList: []
  },
  ui: {
    alert: ""
  },
  ledgerBrowse: {
    filterState: null
  },
  ccBrowse: {
    filterState: null
  },
  fundCode: {
    selectedfundCode: null
  }
};

const mockProps = {
  t: (key: string) => key,
  tranDetails: [],
  currentPage: 1,
  totalPages: 5,
  selectedRow: null,
  costCentreBrowseStatus: "STATUS.LOADING",
  onSelectCostCentresCheckBox: jest.fn(),
  onChangeHandler: jest.fn(),
  selectedRowHandler: jest.fn(),
  onSelectCostCentreRecord: jest.fn(),
  onCancel: jest.fn(),
  lookingFor: "",
  lookingForChangehandler: jest.fn(),
  history: { push: jest.fn() },
  historyState: {},
  filterState: {}
};

const mockPropsforInputNumberMask = {
  onChange: jest.fn(),
  name: "mockName",
  value: "12345.67",
  className: "mockClassName",
  validationTextLevel: undefined, // Assuming ValidationTextLevel is an enum or similar
  onValueChange: jest.fn(),
  getInputRef: jest.fn(),
  onKeyDown: jest.fn(),
  beforeDecimalMaxLength: 5,
  onBlur: jest.fn(),
  beforeDecimalCursorIndex: 2,
  afterDecimalCursorIndex: 2,
  allowNegative: true
  // Add any additional props required by NumericFormatProps
};
const InputNumberMask = (props: any, ref: any) => (
  <input
    ref={ref}
    {...props}
  />
);

// Mock the InputNumberMask component
jest.mock("../../../../components/Input/InputNumberMask", () =>
  React.forwardRef((props, ref) => (
    <InputNumberMask
      ref={ref}
      {...props}
    />
  ))
);

describe("ChartsAccountsReview", () => {
  let store: any = mockStore({});
  let mockDispatch: jest.Mock;

  beforeEach(() => {
    store = mockStore(initialState);

    mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(initialState));
    (useParams as jest.Mock).mockReturnValue({ index: "1" });
    (useCostCentreBrowse as jest.Mock).mockReturnValue(mockProps);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("renders the component", async () => {
    render(
      <Provider store={store}>
        <Router>
          <CostCentreBrowse />
        </Router>
      </Provider>
    );
    await waitFor(() => {
      const element = screen.getByTestId("costCentreBrowseLayout");
      expect(element).toBeInTheDocument();
    });
  });
});
