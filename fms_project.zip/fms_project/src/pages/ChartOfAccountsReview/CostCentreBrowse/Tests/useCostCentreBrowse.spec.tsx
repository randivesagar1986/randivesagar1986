import { renderHook, act } from "@testing-library/react-hooks";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import React from "react";
import { costCentreBrowseFilter, ccBrowseActions } from "../../state/CostCentreBrowse.slice";
import useCostCentreBrowse from "../useCostCentreBrowse";

jest.mock("react-redux", () => ({
  useDispatch: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("react-router-dom", () => ({
  useHistory: jest.fn()
}));

jest.mock("@essnextgen/ui-intl-kit", () => ({
  useTranslation: jest.fn()
}));

jest.mock("@/store/state/ui.slice", () => jest.requireActual("@/store/state/ui.slice"));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    init: jest.fn()
  }
}));

// Mocking the actions and functions from CostCentreBrowse.slice
jest.mock("../../state/CostCentreBrowse.slice", () => ({
  ccBrowseActions: {
    setFilters: jest.fn(),
    setSelectedRow: jest.fn()
  },
  costCentreBrowseFilter: jest.fn()
}));

describe("useCostCentreBrowse", () => {
  const mockDispatch = jest.fn();
  const mockHistoryPush = jest.fn();

  beforeEach(() => {
    jest.useFakeTimers();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useHistory as jest.Mock).mockReturnValue({ push: mockHistoryPush, location: { state: {} } });
    (useTranslation as jest.Mock).mockReturnValue({ t: (key: string) => key });

    (useAppSelector as jest.Mock).mockImplementation((selector) => {
      if (selector.name === "ccBrowse") {
        return {
          costCentreBrowseStatus: "idle",
          selectedRow: null,
          filterState: {
            pageNumber: 1,
            pageSize: undefined,
            excludeZero: false,
            lookingFor: "",
            yearId: "",
            costId: 0,
            ledgerCode: ""
          },
          costCentresBrowseList: {
            tranDetails: [{}],
            currentPage: 1,
            totalCount: 0,
            pageSize: 10,
            totalPages: 1,
            highlightedCostId: 0
          }
        };
      }
      return {};
    });
  });

  afterEach(() => {
    jest.useRealTimers();
    jest.clearAllMocks();
  });

  it("should initialize correctly", () => {
    const { result } = renderHook(() => useCostCentreBrowse());

    expect(result.current.t).toBeDefined();
  });

  it("should select a cost centre record and navigate", () => {
    const { result } = renderHook(() => useCostCentreBrowse());

    act(() => {
      result.current.selectedRowHandler({ id: 1, name: "Test Centre" });
    });

    expect(mockDispatch).toHaveBeenCalledWith(ccBrowseActions.setSelectedRow({ id: 1, name: "Test Centre" }));
  });

  it("should handle pagination change", () => {
    const { result } = renderHook(() => useCostCentreBrowse());

    const mockEvent = {} as React.ChangeEvent<unknown>; // Use an empty object for the event.

    act(() => {
      result.current.onChangeHandler(mockEvent, 2);
    });

    expect(mockDispatch).toHaveBeenCalledWith(
      ccBrowseActions.setFilters({
        ...result.current.filterState,
        lookingFor: "",
        pageNumber: 2,
        pageSize: 10,
        costId: undefined
      })
    );
  });

  it("should reset filters and navigate on cancel", () => {
    const { result } = renderHook(() => useCostCentreBrowse());

    act(() => {
      result.current.onCancel();
    });

    expect(mockDispatch).toHaveBeenCalledWith(
      ccBrowseActions.setFilters({
        ...result.current.filterState,
        pageNumber: 1
      })
    );

    expect(mockHistoryPush).toHaveBeenCalledWith("/general-ledger/chart-accounts-review", {
      ...result.current.historyState
    });
  });

  it("should handle checkbox selection and update filters", () => {
    const { result } = renderHook(() => useCostCentreBrowse());

    act(() => {
      result.current.onSelectCostCentresCheckBox({ target: { checked: true } });
    });

    expect(mockDispatch).toHaveBeenCalledWith(
      ccBrowseActions.setFilters({
        ...result.current.filterState,
        lookingFor: "",
        pageNumber: 1,
        excludeZero: true,
        costId: undefined
      })
    );
  });

  it("should update lookingFor state and dispatch setFilters on input change", () => {
    const { result } = renderHook(() => useCostCentreBrowse());

    const mockEvent = {
      target: { value: "New Centre" }
    } as React.ChangeEvent<HTMLInputElement>;

    act(() => {
      result.current.lookingForChangehandler(mockEvent);
    });

    // The lookingFor state should be updated
    expect(result.current.lookingFor).toBe("New Centre");

    // Simulate a change in the debounced value
    jest.runAllTimers();

    expect(mockDispatch).toHaveBeenCalledWith(
      ccBrowseActions.setFilters({
        ...result.current.filterState,
        lookingFor: "New Centre"
      })
    );
  });
});
