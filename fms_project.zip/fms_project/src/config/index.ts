import { getBearerToken, getCurrentFinancialYear, getTempDefaultUserEmail } from "@/types/UseStateType";
import { authService } from "@essnextgen/auth-ui";
import axios, { AxiosError } from "axios";

// Logging utility
let enableLogging = true;
const isProtectedGlobal = process.env.IS_ALL_ROUTE_PROTECTED || "false";

export const setLogging = (value: boolean) => {
  enableLogging = value;
};

export const log = (message: string) => {
  if (enableLogging) {
    // console.log(message);
  }
};

const convertString = (input: any) => {
  // Replace all instances of '/' with '|'
  const output = input.replace(/\//g, "|");

  // Remove the leading and trailing '|' if present
  return output.startsWith("|") ? output.slice(1) : output;
};

// Getter and Setter for request log metadata
let requestLogData = {
  description: ""
};

export const getLogdata = () => requestLogData;
export const setLogdata = (logdata = {}) => {
  requestLogData = { ...requestLogData, ...logdata };
};

let clickeventName: any;
const handleClick = (event: any) => {
  clickeventName = event.target.textContent;
};

// Add event listener for clicks
document.addEventListener("click", handleClick);

axios.interceptors.request.use(
  (config) => {
    const isAuthenticated = isProtectedGlobal === "true" ? authService.isAuthenticated() : true;

    if (isAuthenticated) {
      if (config.headers) {
        // Add any additional headers if needed
        const localOrgId = localStorage.getItem("organisationId"); // Get the organisation ID from local storage
        const orgId = localOrgId !== null ? localOrgId : authService.getOrgId(); // If organisation ID is not present in local storage, get it from the auth service

        config.headers.FinancialYear = getCurrentFinancialYear();
        config.headers.Email = getTempDefaultUserEmail();
        config.headers.Authorization = `Bearer ${getBearerToken()}`;
        config.headers.OrganisationId = orgId?.toLocaleLowerCase() as string;

        config.headers.Breadcrumb = convertString(window.location.pathname);
        config.headers.URL = `${config.url}`;
        config.headers.userid = "Test User";

        const { description } = getLogdata();
        config.headers.description = description;

        // Log the request details including headers
        log(`Request made to ${config.url} with headers: ${JSON.stringify(config.headers)}`);
      }
    } else {
      // If not authenticated, reject the request
      return Promise.reject(new Error("User is not authenticated"));
    }

    return config;
  },
  (error) =>
    // Do something with request error
    Promise.reject(error)
);

axios.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    if (error.response?.status === 401 && isProtectedGlobal === "true") {
      setTimeout(async () => {
        if (!authService.isAuthenticated()) {
          authService.authenticateUser({});
        }
      }, 1000);
    }
    return Promise.reject(error);
  }
);

export const apiRoot = process.env.CUSTOM_ENV === "local" ? process.env.API_PATH : process.env.API_URL;
export const client = axios;
