import React, { useEffect, useRef, useState } from "react";
import { useOutsideClick } from "@essnextgen/ui-kit";
import { useLocation } from "react-router-dom";
import { useAppSelector } from "@/store/store";
import { actions as sidebarMenuActions } from "@/components/SidebarMenu/state/SidebarMenu.slice";
import { useDispatch } from "react-redux";
import { getSessionItem } from "@/utils/getDataSource";
import HeaderView from "./Header.view";
import UseStateType from "../../types/UseStateType";
import { IHeaderProps } from "./HeaderProps";

const Header: React.FC<IHeaderProps> = () => {
  const [showMenu, setShowMenu]: UseStateType<boolean> = useState(false);
  const { isSidebarOpen, showProfileMenu } = useAppSelector((state) => state.sidebarMenu);
  const { setIsSidebarOpen, setShowProfileMenu } = sidebarMenuActions;
  const dispatch = useDispatch();

  const toggleMenu: (e: React.SyntheticEvent) => void = (e: React.SyntheticEvent) => {
    e.preventDefault();
    dispatch(setIsSidebarOpen(!isSidebarOpen));
  };

  const toggleProfileMenu: () => void = () => {
    dispatch(setShowProfileMenu(!showProfileMenu));
  };

  const applicationMenuRef: React.Ref<HTMLDivElement> = useRef(null);
  const { isOutsideClicked } = useOutsideClick(applicationMenuRef);

  useEffect(() => {
    if (isOutsideClicked) {
      setTimeout(() => {
        if (getSessionItem("clickAwayMenu") !== true) {
          dispatch(setShowProfileMenu(false));
        }
      }, 100);
    }
  }, [isOutsideClicked]);

  const location = useLocation();

  useEffect(() => {
    dispatch(setIsSidebarOpen(false));
  }, [location]);

  return (
    <div
      className="header main__header"
      ref={applicationMenuRef}
    >
      <HeaderView
        toggleMenu={toggleMenu}
        toggleProfileMenu={toggleProfileMenu}
        showMenu={isSidebarOpen}
        showProfileMenu={showProfileMenu}
      />
    </div>
  );
};

export default Header;
