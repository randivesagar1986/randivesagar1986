import React from "react";

export interface IHeaderProps {}

export interface IHeaderViewProps {
  toggleMenu: (e: React.SyntheticEvent) => void;
  toggleProfileMenu: () => void;
  showMenu: boolean;
  showProfileMenu: boolean;
}
