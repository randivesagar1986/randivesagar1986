import { fireEvent, render, screen } from "@testing-library/react";
import { be } from "date-fns/locale";
import { BrowserRouter as Router } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import Header from "../Index";

const initialState = {
  userAccessRights: {
    userMappedData: {}
  },
  sidebarMenu: {
    mainMenu: [{ id: 1 }, { id: 2 }]
  },
  restrictedMenu: {
    menus: [],
    accessMenus: []
  }
};

jest.mock("@/hooks/useUserAccess", () => ({
  __esModule: true,
  default: jest.fn(() => ({
    userAccessRights: initialState.userAccessRights
  })),
  userDontHaveAccess: false
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

jest.mock("@/hooks/useOrganisationData", () => ({
  __esModule: true,
  default: jest.fn(() => ({
    organisationData: {}
  })),
  organisationList: [],
  selectedOrgData: {
    value: "sample",
    text: "sample"
  }
}));

jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn()
}));

jest.mock("@essnextgen/auth-ui", () => ({
  authService: {
    login: jest.fn(),
    logout: jest.fn(),
    isAuthenticated: jest.fn(),
    init: jest.fn(),
    isTokenValid: jest.fn(() => true),
    getEmailId: jest.fn(),
    getUserInitial: jest.fn(),
    getUsername: jest.fn()
  }
}));

describe("Header", () => {
  beforeEach(() => {
    (useDispatch as jest.Mock).mockReturnValue(jest.fn());
    (useAppSelector as jest.Mock).mockImplementation((selector) => selector(initialState));
  });
  it("should render the header", () => {
    render(
      <Router>
        <Header />
      </Router>
    );
    expect(screen.getByTestId("header")).toBeInTheDocument();
  });
});
