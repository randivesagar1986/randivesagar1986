import { Dropdown, DropdownItem, Header, ProfileMenu, ProfileMenuItem } from "@essnextgen/ui-kit";
import { authService } from "@essnextgen/auth-ui";
import { URL_HELP } from "@/types/UseStateType";
import { useHistory } from "react-router-dom";
import { Industry } from "@carbon/icons-react";
import useUserAccess from "@/hooks/useUserAccess";
import { clearCookies } from "@/utils/getDataSource";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import useOrganisationData from "@/hooks/useOrganisationData";
import { IHeaderViewProps } from "./HeaderProps";
import "./Style.scss";
import { SidebarMenu } from "../SidebarMenu/SidebarMenu";

const HeaderView: ({}: IHeaderViewProps) => JSX.Element = ({
  toggleMenu,
  toggleProfileMenu,
  showMenu,
  showProfileMenu
}: IHeaderViewProps) => {
  const isTokenValid = authService?.isTokenValid();
  const emaidId = isTokenValid ? authService?.getEmailId() : "";
  const userInitial = isTokenValid ? authService?.getUserInitial() : "";
  const username = isTokenValid ? authService?.getUsername() : "";
  const history = useHistory();
  const { userDontHaveAccess } = useUserAccess();
  const isProtectedGlobal = process.env.IS_ALL_ROUTE_PROTECTED || false;
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { organisationList, selectedOrgData } = useOrganisationData();

  const onSwitchSchoolHandler = () => {
    history?.push("/switch-site");
    toggleProfileMenu();
  };

  const logoutHandler = () => {
    clearCookies();
    localStorage.removeItem("organisationId"); // Remove the organisation ID from local storage
    localStorage.setItem("LOGOUT", "true");
    authService.logOut();
  };

  const bankReconciliationViews = [
    { ledger_code: "001", ledger_des: "Cash Account" },
    { ledger_code: "002", ledger_des: "Accounts Receivable" },
    { ledger_code: "003", ledger_des: "Inventory" }
    // Add more items as needed
  ];

  return (
    <>
      <Header
        className={!userInitial || userDontHaveAccess ? "hide-profile" : ""}
        applicationName={
          (
            <div className="header-heading header-dropdown">
              <div className="d-flex">
                <span>FMS</span>
                <p className="header-school" />
              </div>
              <div className="dropdown__content d-flex">
                <div className="d-flex align-center mr-16 dropdown__content--label">
                  <span className="essui-form-label mr-4">{selectedOrgData?.text} </span>
                </div>
                {/* <Dropdown
                    searchable
                    isScrollbarVisible
                    scrollbarHeight={bankReconciliationViews.length <= 3 ? 120 : undefined}
                    inputWidth={300}
                  >
                    {bankReconciliationViews.map((view, i) => {
                      const id = `dropdown-${i}`;
                      return (
                        <DropdownItem
                          key={id}
                          id={id}
                          text={view.ledger_des}
                          value={view.ledger_code}
                        >
                          {view.ledger_des}
                        </DropdownItem>
                      );
                    })}
                  </Dropdown> */}
              </div>
            </div>
          ) as any
        }
        dataTestId="header"
        userInitials={userInitial}
        showNotificationIcon={false}
        onClickMenu={toggleMenu}
        onClickAvatar={toggleProfileMenu}
        onClickHelp={() => window.open(URL_HELP.URLHELP)}
        showHelpIcon={!userDontHaveAccess}
        showMenuIcon={!(isProtectedGlobal === "true" && (!isTokenValid || userDontHaveAccess))}
      />
      <SidebarMenu
        isOpen={showMenu}
        onClose={toggleMenu}
      />
      {showProfileMenu && !userDontHaveAccess && isTokenValid && (
        <ProfileMenu
          dataTestId="header-profile-menu"
          emailId={emaidId}
          id="element-id"
          onClickSignout={logoutHandler}
          userFullname={username}
          userInitials={userInitial}
          className="elr-header__profile-menu"
        >
          {organisationList?.length > 1 && (
            <ProfileMenuItem
              className="switch-menu"
              onClick={onSwitchSchoolHandler}
            >
              <Industry
                size={24}
                className="school-icon"
              />
              <span>{t("common.switchSite")}</span>
            </ProfileMenuItem>
          )}
        </ProfileMenu>
      )}
    </>
  );
};

export default HeaderView;
