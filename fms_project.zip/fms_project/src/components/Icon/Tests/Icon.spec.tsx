import React from "react";
import { render } from "@testing-library/react";
import { IconSize, IIconProps } from "@essnextgen/ui-kit";
import IconWithText from "../Icon";

describe("IconWithText", () => {
  const defaultProps: IIconProps & { text: string } = {
    size: IconSize.Medium,
    name: "test-icon",
    text: "Test Text"
  };
  it("should render the text correctly", () => {
    const { getByText } = render(<IconWithText {...defaultProps} />);
    expect(getByText("Test Text")).toBeInTheDocument();
  });

  it("should apply the correct class to the wrapper span", () => {
    const { container } = render(<IconWithText {...defaultProps} />);
    expect(container.firstChild).toHaveClass("icon");
  });
});
