import { FormLabel, ITextInputProps, TextInputIconPosition, TextInputSize } from "@essnextgen/ui-kit";
import React, { useEffect, useRef, useState } from "react";
import classnames from "classnames";
import { INVOICE_TYPE, KEYBOARD_STRING } from "@/types/UseStateType";

export type NumberInputPropsType = ITextInputProps & {
  labelText?: string;
  defaultValue?: string;
  maxLength: number;
  decimals: number;
  name: string;
  id?: string;
  zeroNotAllowed?: boolean;
};

const NumberInput: React.FC<NumberInputPropsType> = ({
  defaultValue,
  maxLength,
  decimals,
  labelText,
  disabled = false,
  size = TextInputSize.Medium,
  iconPosition = TextInputIconPosition.Left,
  id,
  zeroNotAllowed,
  ...rest
}) => {
  const [inputValue, setValue] = useState(defaultValue);
  const inputRef = useRef(rest.inputRef ? rest.inputRef : null);

  useEffect(() => {
    if (zeroNotAllowed && Number(defaultValue) === 0) {
      setValue("");
    } else if (!Number.isNaN(Number(defaultValue))) {
      setValue(Number(defaultValue).toFixed(decimals));
    }
  }, [defaultValue, zeroNotAllowed]);

  function padDigits(number: any, digits: any) {
    return number + Array(Math.max(digits - String(number).length + 1, 0)).join("0");
  }

  const processInput = (input: any) => {
    let { value } = input;
    const { selectionStart } = input;
    const { selectionEnd } = input;
    const resetCursor = () => input.setSelectionRange(selectionStart, selectionEnd);
    if (selectionStart === 1 && selectionEnd === 1) {
      const num = String(value).split(".");
      let truncatedValue;
      if (num.at(0)?.at(1) === "0" || !num.at(0)?.at(1)) {
        truncatedValue = num.at(0) ? Math.floor(parseFloat(num.at(0)!)) / 10 : 0;
      } else {
        truncatedValue = Number(num.at(0));
      }
      const float = num?.at(1) ? `.${num?.at(1)}` : ".0";
      if (num.at(0) === "0" || num.at(0)?.length === 1) {
        truncatedValue *= 10;
      }
      value = decimals
        ? parseFloat(`${String(truncatedValue).split(".").at(0)}${float}`).toFixed(decimals)
        : String(Math.floor(truncatedValue));
      resetCursor();
    }

    // Limiting to 8 digits before decimal
    const digitsBeforeDecimal = value.split(".");
    if (digitsBeforeDecimal.at(0).length > maxLength) {
      value = `${value.slice(0, maxLength)}${value.slice(maxLength).replace(/[0-9]/g, "")}${
        decimals && digitsBeforeDecimal.at(1) ? digitsBeforeDecimal.at(1) : ""
      }`;
    }
    // eslint-disable-next-line
    if (/^[0-9.]+$/.test(value)) {
      const p = value.indexOf("..");

      if (p >= 0) {
        input.value = value.replace("..", ".");
        resetCursor();
        processInput(input);
      } else if ([...value].filter((c) => c === ".").length > 1) {
        const j = value.indexOf(".");
        input.value = [...value].filter((c, k) => k <= j || c !== ".").join("");
        resetCursor();
        processInput(input);
      } else {
        let num = String(value).split(".")[1];
        if ((num || [])?.length > decimals && decimals > 0) {
          num = num
            .split("")
            ?.map((decimalN, index) => {
              if (index < decimals) {
                return decimalN;
              }
              return null;
            })
            .join("");
        }
        input.value = decimals
          ? `${String(value).split(".")[0] ? String(value).split(".")[0] : "0"}.${padDigits(num || 0, decimals)}`
          : Number(value.replace(".", ""));
        resetCursor();
      }
    } else {
      // eslint-disable-next-line
      if (input.value === "") {
        if (zeroNotAllowed) {
          input.value = "";
        } else {
          input.value = "0";
          if (decimals !== 0) {
            input.value = `0.${padDigits(0, decimals)}`;
          }
        }
      } else {
        value = value.replace(/[^0-9.]/g, "");
        input.value = value;
      }
      resetCursor();
    }
    input.defaultValue = input.value;
  };

  const handleInputChange = (event: any) => {
    processInput(event.target);

    setValue(event.target.value);
    if (rest.onChange) rest.onChange(event);
  };

  const handleKeyDown = (event: any) => {
    if (event.key === "Backspace") {
      const { selectionStart, selectionEnd } = event.target;
      const { value } = event.target;
      if (value[selectionStart - 1] === ".") {
        event.preventDefault();
        event.target.setSelectionRange(selectionStart - 1, selectionEnd - 1);
      }
    }
    if (rest.onKeyDown) rest.onKeyDown(event);
  };

  const handleBlur: (e: any) => void = (e: any) => {
    if (rest.onBlur) rest.onBlur(e);
  };

  const classNames: string = classnames(
    rest.className,
    rest.useAutoWidth ? "essui-textinput essui-textinput1" : "essui-textinput",
    `essui-textinput--${size}`,
    rest.validationTextLevel && `essui-textinput--${rest.validationTextLevel}`,
    disabled && "essui-textinput--disabled",
    rest.isFixedMultiSelect && "essui-textinput--fixed",
    rest.iconName && iconPosition === TextInputIconPosition.Left && `essui-textinput--${size}-with-icon`
  );

  return (
    <div className="essui-textinput-container">
      {labelText ? <FormLabel forId={id}>{labelText}</FormLabel> : null}
      <input
        defaultValue={inputValue}
        className={classNames}
        id={id}
        value={inputValue}
        onChange={(e) => handleInputChange(e)}
        onBlur={(e) => handleBlur(e)}
        onKeyDown={(e) => handleKeyDown(e)}
        ref={inputRef as any}
        tabIndex={disabled ? -1 : 0} // This is for disable focus on tab key
        // placeholder="0.00"
      />
    </div>
  );
};

NumberInput.defaultProps = {
  labelText: undefined,
  defaultValue: undefined,
  id: undefined,
  zeroNotAllowed: undefined
};

export default NumberInput;
