import React from "react";
import { render, fireEvent } from "@testing-library/react";
import NumberInput, { NumberInputPropsType } from "../NumberInput";

describe("NumberInput Component", () => {
  const defaultProps: NumberInputPropsType = {
    maxLength: 8,
    decimals: 2,
    name: "test-input"
  };

  it("should handle default value", () => {
    const { getByDisplayValue } = render(
      <NumberInput
        {...defaultProps}
        defaultValue="123.45"
      />
    );
    expect(getByDisplayValue("123.45")).toBeInTheDocument();
  });

  it("should not allow zero if zeroNotAllowed is true", () => {
    const { getByDisplayValue } = render(
      <NumberInput
        {...defaultProps}
        defaultValue="0"
        zeroNotAllowed
      />
    );
    expect(getByDisplayValue("")).toBeInTheDocument();
  });

  it("should limit input to maxLength before decimal", () => {
    const { getByRole } = render(<NumberInput {...defaultProps} />);
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "123456789" } });
    expect(input).toHaveValue("12345678.00");
  });

  it("should format input to specified decimals", () => {
    const { getByRole } = render(<NumberInput {...defaultProps} />);
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "123.456" } });
    expect(input).toHaveValue("123.45");
  });

  it("should call onChange prop when input changes", () => {
    const handleChange = jest.fn();
    const { getByRole } = render(
      <NumberInput
        {...defaultProps}
        onChange={handleChange}
      />
    );
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "123.45" } });
    expect(handleChange).toHaveBeenCalled();
  });

  it("should call onBlur prop when input loses focus", () => {
    const handleBlur = jest.fn();
    const { getByRole } = render(
      <NumberInput
        {...defaultProps}
        onBlur={handleBlur}
      />
    );
    const input = getByRole("textbox");

    fireEvent.blur(input);
    expect(handleBlur).toHaveBeenCalled();
  });

  it("should call onKeyDown prop when a key is pressed", () => {
    const handleKeyDown = jest.fn();
    const { getByRole } = render(
      <NumberInput
        {...defaultProps}
        onKeyDown={handleKeyDown}
      />
    );
    const input = getByRole("textbox");

    fireEvent.keyDown(input, { key: "Enter" });
    expect(handleKeyDown).toHaveBeenCalled();
  });

  it("should handle input when selectionStart and selectionEnd are 1", () => {
    const { getByRole } = render(<NumberInput {...defaultProps} />);
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "01", selectionStart: 1, selectionEnd: 1 } });
  });
  it("should replace double dots with a single dot", () => {
    const { getByRole } = render(<NumberInput {...defaultProps} />);
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "12..34" } });
    expect(input).toHaveValue("12.34");
  });

  it("should remove extra dots if more than one is present", () => {
    const { getByRole } = render(<NumberInput {...defaultProps} />);
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "12.3.4" } });
    expect(input).toHaveValue("12.34");
  });
  it("should set input value to 0 if input is empty and zeroNotAllowed is false", () => {
    const { getByRole } = render(
      <NumberInput
        {...defaultProps}
        zeroNotAllowed={false}
      />
    );
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "" } });
  });

  it("should set input value to empty string if input is empty and zeroNotAllowed is true", () => {
    const { getByRole } = render(
      <NumberInput
        {...defaultProps}
        zeroNotAllowed
      />
    );
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "" } });
    expect(input).toHaveValue("");
  });

  it("should set input value to 0.00 if input is empty, zeroNotAllowed is false, and decimals is not 0", () => {
    const { getByRole } = render(
      <NumberInput
        {...defaultProps}
        zeroNotAllowed={false}
        decimals={2}
      />
    );
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "" } });
  });

  it("should remove non-numeric characters from input value", () => {
    const { getByRole } = render(<NumberInput {...defaultProps} />);
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "123abc" } });
  });
  it("should prevent backspace from deleting a decimal point", () => {
    const { getByRole } = render(
      <NumberInput
        {...defaultProps}
        defaultValue="123.45"
      />
    );
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "123.45", selectionStart: 4, selectionEnd: 4 } });
    fireEvent.keyDown(input, { key: "Backspace" });

    expect(input).toHaveValue("123.45");
  });

  it("should allow backspace to delete a number", () => {
    const { getByRole } = render(
      <NumberInput
        {...defaultProps}
        defaultValue="123.45"
      />
    );
    const input = getByRole("textbox");

    fireEvent.change(input, { target: { value: "123.45", selectionStart: 5, selectionEnd: 5 } });
    fireEvent.keyDown(input, { key: "Backspace" });
  });

  it("should call onKeyDown prop when Backspace is pressed", () => {
    const handleKeyDown = jest.fn();
    const { getByRole } = render(
      <NumberInput
        {...defaultProps}
        onKeyDown={handleKeyDown}
      />
    );
    const input = getByRole("textbox");

    fireEvent.keyDown(input, { key: "Backspace" });
    expect(handleKeyDown).toHaveBeenCalled();
  });
});
