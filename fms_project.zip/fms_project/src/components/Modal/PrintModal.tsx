import React, { ReactNode } from "react";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";
import "./Style.scss";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import HelpButton from "../OpenLinkButton/HelpButton";

type modal = {
  children: ReactNode;
  primaryBtnText?: string;
  secondaryBtnText?: string;
  tertiaryBtnText?: string;
  fourthiaryBtnText?: string;
  primaryBtnClick?: (e: React.SyntheticEvent) => void;
  secondaryBtnClick?: (e: React.SyntheticEvent) => void;
  tertiaryBtnClick?: (e: React.SyntheticEvent) => void;
  fourthiaryBtnClick?: (e: React.SyntheticEvent) => void;
  header?: string;
  isOpen: boolean;
  className?: string;
};

const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

const PrintModal = ({
  children,
  primaryBtnText,
  secondaryBtnText,
  tertiaryBtnText,
  fourthiaryBtnText,
  primaryBtnClick,
  secondaryBtnClick,
  tertiaryBtnClick,
  fourthiaryBtnClick,
  header,
  isOpen,
  className
}: modal) => (
  <Grid
    container
    className="print-modal"
  >
    <Dialog
      isOpen={isOpen}
      dataTestId="print-modal"
      escapeExits
      id="element-id"
      onClose={primaryBtnClick}
      returnFocusOnDeactivate
      title={header}
      className="pd-20"
    >
      <DialogContent className="">{children}</DialogContent>
      <DialogFooter>
        <Grid>
          <GridItem
            className="flex-rt"
            sm={12}
            md={6}
            lg={6}
          >
            {primaryBtnClick && primaryBtnText && (
              <Button
                size={ButtonSize.Medium}
                color={ButtonColor.Tertiary}
                onClick={primaryBtnClick}
                className="mt-20"
              >
                {primaryBtnText}
              </Button>
            )}
            {secondaryBtnClick && secondaryBtnText && (
              <Button
                size={ButtonSize.Medium}
                color={ButtonColor.Tertiary}
                onClick={secondaryBtnClick}
                className="mt-20"
              >
                {secondaryBtnText}
              </Button>
            )}
          </GridItem>
          <GridItem
            className="flex-lt"
            sm={12}
            md={6}
            lg={6}
          >
            {tertiaryBtnClick && tertiaryBtnText && (
              <Button
                size={ButtonSize.Medium}
                color={ButtonColor.Secondary}
                onClick={tertiaryBtnClick}
                className="mt-20"
              >
                {tertiaryBtnText}
              </Button>
            )}

            {fourthiaryBtnClick && fourthiaryBtnText && (
              // <Button
              //   size={ButtonSize.Medium}
              //   onClick={fourthiaryBtnClick}
              //   className="mt-20"
              // >
              //   {fourthiaryBtnText}
              // </Button>
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            )}
          </GridItem>
        </Grid>
      </DialogFooter>
    </Dialog>
  </Grid>
);

PrintModal.defaultProps = {
  primaryBtnText: undefined,
  secondaryBtnText: undefined,
  tertiaryBtnText: undefined,
  fourthiaryBtnText: undefined,
  primaryBtnClick: undefined,
  secondaryBtnClick: undefined,
  tertiaryBtnClick: undefined,
  fourthiaryBtnClick: undefined,
  header: undefined,
  className: undefined
};
export default PrintModal;
