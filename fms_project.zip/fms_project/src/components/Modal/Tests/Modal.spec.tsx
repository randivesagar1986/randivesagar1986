import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import Modal from "../Modal";

describe("Modal Component", () => {
  it("should set tabindex to -1 for the close button and find the modal element when isOpen is true", () => {
    // Mock the document.querySelector and document.getElementById
    document.querySelector = jest.fn().mockImplementation((selector) => {
      if (selector === ".delete-alert .essui-button--tertiary") {
        return { setAttribute: jest.fn() };
      }
      return null;
    });

    document.getElementById = jest.fn().mockImplementation((id) => {
      if (id === "essui-modal") {
        return {};
      }
      return null;
    });

    // Render the Modal component with isOpen set to true
    render(<Modal isOpen>{undefined}</Modal>);

    // Wait for the useEffect to run
    setTimeout(() => {
      // Check if the close button's tabindex was set to -1
      const closeButton = document.querySelector(".delete-alert .essui-button--tertiary");
      if (closeButton) {
        expect(closeButton.setAttribute).toHaveBeenCalledWith("tabindex", "-1");
      } else {
        throw new Error("Close button not found");
      }

      // Check if the modal element was found
      const modalElement = document.getElementById("essui-modal");
      expect(modalElement).not.toBeNull();
    }, 0);
  });
});
