import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { I18nextProvider, IntlProvider, useTranslation } from "@essnextgen/ui-intl-kit";
import { uiKitTranslation } from "@essnextgen/ui-kit";
import { uiAppKitTranslation } from "@essnextgen/ui-application-kit";
import translationEn from "@/locales/en/translation.json";
import translationCy from "@/locales/cy/translation.json";
import PrintModal from "../PrintModal";

describe("PrintModal", () => {
  const i18n = IntlProvider.init({
    translation: {
      en: {
        ...uiKitTranslation.en,
        ...uiAppKitTranslation.en,
        ...translationEn,
        Test: "Test english",
        message: "click <homelink>here</homelink> to go to home pages",
        message1: "test"
      },
      cy: {
        ...uiKitTranslation.cy,
        ...uiAppKitTranslation.cy,
        ...translationCy,
        Test: "Test welsh",
        message: "click <1>here</1> to go towerewrw home page2."
      }
    }
  });
  const defaultProps = {
    isOpen: true,
    children: <div>Modal Content</div>
  };

  it("renders correctly with required props", () => {
    render(<PrintModal {...defaultProps} />);
    expect(screen.getByText("Modal Content")).toBeInTheDocument();
  });

  it("calls primary button click handler when clicked", () => {
    const primaryBtnClick = jest.fn();
    const props = {
      ...defaultProps,
      primaryBtnText: "Primary",
      primaryBtnClick
    };
    render(<PrintModal {...props} />);
    fireEvent.click(screen.getByText("Primary"));
    expect(primaryBtnClick).toHaveBeenCalled();
  });

  it("calls secondary button click handler when clicked", () => {
    const secondaryBtnClick = jest.fn();
    const props = {
      ...defaultProps,
      secondaryBtnText: "Secondary",
      secondaryBtnClick
    };
    render(<PrintModal {...props} />);
    fireEvent.click(screen.getByText("Secondary"));
    expect(secondaryBtnClick).toHaveBeenCalled();
  });

  it("calls tertiary button click handler when clicked", () => {
    const tertiaryBtnClick = jest.fn();
    const props = {
      ...defaultProps,
      tertiaryBtnText: "Tertiary",
      tertiaryBtnClick
    };
    render(<PrintModal {...props} />);
    fireEvent.click(screen.getByText("Tertiary"));
    expect(tertiaryBtnClick).toHaveBeenCalled();
  });
});
