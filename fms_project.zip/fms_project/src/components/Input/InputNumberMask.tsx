import { ValidationTextLevel } from "@essnextgen/ui-kit";
import React, { useEffect, useState } from "react";
import { NumberFormatValues, NumericFormat, NumericFormatProps } from "react-number-format";

type InputMaskPropsType = {
  validationTextLevel?: ValidationTextLevel | undefined;
  beforeDecimalMaxLength: number;
  beforeDecimalCursorIndex: number;
  afterDecimalCursorIndex: number;
  allowNegative?: boolean;
  resrictDecimalInput?: boolean;
};
const InputNumberMask = React.forwardRef(
  ({
    onChange,
    name,
    value,
    className,
    validationTextLevel,
    onValueChange,
    getInputRef,
    onKeyDown,
    beforeDecimalMaxLength,
    onBlur,
    beforeDecimalCursorIndex,
    afterDecimalCursorIndex,
    allowNegative,
    resrictDecimalInput,
    ...rest
  }: NumericFormatProps & InputMaskPropsType) => {
    const [inputValue, setInputValue] = useState(value);
    let lastKeyPressed = "";
    useEffect(() => {
      if (value?.toString().trim().length === 0) {
        setInputValue("0.00");
      } else {
        setInputValue(value);
      }
    }, [value]);

    const onValueChangeHandler = (values: NumberFormatValues) => {
      const { formattedValue, value } = values;
      let newValue = "0.00";
      if (lastKeyPressed) {
        newValue = `${lastKeyPressed}${value.slice(2)}`;
      }
      if (typeof onValueChange === "function" && lastKeyPressed) {
        setInputValue(newValue);
        onChange?.({ target: { name, value: newValue } } as any);
        onValueChange({ ...values, value: newValue }, { source: "event" } as any);
      } else if (value?.startsWith(".")) {
        setInputValue(`0${value}`);
        onChange?.({ target: { name, value: `0${value}` } } as any);
        onValueChange?.({ ...values, value: `0${value}` }, { source: "event" } as any);
      } else {
        setInputValue(formattedValue);
        onChange?.({ target: { name, value } } as any);
        onValueChange?.(values, { source: "event" } as any);
      }
    };
    return (
      <NumericFormat
        {...rest}
        getInputRef={getInputRef}
        value={value}
        className={` ${validationTextLevel ? "input-mask-error" : ""} ${
          className ?? "essui-textinput essui-textinput--medium"
        }`} // Added the custom-placeholder class
        onBlur={(e) => {
          if (typeof onBlur === "function") {
            onBlur(e);
          }
        }}
        onValueChange={onValueChangeHandler}
        isAllowed={(values) => {
          const { floatValue, value } = values;
          if (floatValue === undefined) return true; // Allow empty input
          const [integerPart] = value.toString().split(".");
          if (resrictDecimalInput) {
            return (
              (floatValue === undefined || Number.isInteger(floatValue)) && integerPart.length <= beforeDecimalMaxLength
            );
          }
          return integerPart.length <= beforeDecimalMaxLength;
        }}
        onKeyDown={(e) => {
          const numbers = Array.from({ length: 10 }, (_, index) => index.toString());
          const target = e.target as HTMLInputElement;
          const element = (getInputRef as React.RefObject<HTMLInputElement>)?.current;
          lastKeyPressed = "";

          if (numbers.includes(e.key)) {
            if (target.value.startsWith("0.") && target.selectionStart === 0) {
              lastKeyPressed = e.key;
              element?.setSelectionRange(1, 1);
            } else if (target.selectionStart === 1 && target.value[0] === "0") {
              lastKeyPressed = e.key;
              element?.setSelectionRange(1, 1);
            } else if (target.selectionStart === beforeDecimalCursorIndex) {
              element?.setSelectionRange(afterDecimalCursorIndex, afterDecimalCursorIndex);
            }
          }
        }}
        allowNegative={allowNegative ?? false}
      />
    );
  }
);
InputNumberMask.defaultProps = {
  validationTextLevel: undefined,
  allowNegative: undefined,
  resrictDecimalInput: false
};
export default InputNumberMask;
