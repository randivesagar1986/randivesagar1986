import { useEffect } from "react";

type HotKeysProps = {
  keyName: string;
  handleOnKeyPress: () => void;
};

const useHotKeys = ({ keyName, handleOnKeyPress }: HotKeysProps) => {
  const keyboardKeyDown = (event: KeyboardEvent) => {
    if (event.key === keyName) {
      handleOnKeyPress();
    }
  };

  useEffect(() => {
    document.addEventListener("keydown", keyboardKeyDown);

    return () => {
      document.removeEventListener("keydown", keyboardKeyDown);
    };
  }, [keyName, handleOnKeyPress]);
};

export default useHotKeys;
