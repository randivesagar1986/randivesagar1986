import React from "react";
import { Grid, GridItem, Button, ButtonSize, ButtonColor } from "@essnextgen/ui-kit";
import "./Style.scss";

export type PageToolbarType = {
  title: string;
  element: React.ReactNode;
  onClick?: () => void;
  size?: ButtonSize;
  disableCheck?: boolean;
};

const PageToolbar = ({ buttons }: { buttons: PageToolbarType[] }) => (
  <Grid
    justify="flex-end"
    className="tools"
  >
    {buttons.map((button, i) => {
      const id = `button-${i}`;

      return (
        <GridItem>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            title={button.title}
            onClick={button.onClick}
            disabled={button.disableCheck}
          >
            {button.element}
          </Button>
        </GridItem>
      );
    })}
  </Grid>
);

export default PageToolbar;
