import React from "react";
import { ButtonSize, Segmented, SegmentedButton, Tooltip } from "@essnextgen/ui-kit";

export type ToolbarType = {
  title: string;
  element: React.ReactNode;
  onClick?: (e: React.SyntheticEvent) => void;
  size: ButtonSize;
  disabled?: boolean;
  id?: string;
};

const Toolbar = ({ buttons }: { buttons: ToolbarType[] }) => (
  <div className="tools">
    <Segmented>
      {buttons.map((button, i) => {
        const id = `button-${i}`;

        return (
          <SegmentedButton
            dataTestId={id}
            key={id}
            id={id}
            size={button.size}
            title={button.title}
            onClick={button.onClick ? button.onClick : undefined}
            disabled={button.disabled}
            active
          >
            <Tooltip content={button.title}>
              <span className="button-content">{button.element}</span>
            </Tooltip>
          </SegmentedButton>
        );
      })}
    </Segmented>
  </div>
);

export default Toolbar;
