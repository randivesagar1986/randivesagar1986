import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { ButtonSize } from "@essnextgen/ui-kit";
import Toolbar, { ToolbarType } from "../Toolbar"; // Adjust the path as needed

describe("Toolbar Component", () => {
  const mockOnClick = jest.fn();

  const buttons: ToolbarType[] = [
    {
      title: "Focus Mode",
      element: <span>Focus Icon</span>,
      size: ButtonSize.Small,
      onClick: mockOnClick,
      disabled: false
    },
    {
      title: "Previous Record",
      element: <span>Arrow Up Icon</span>,
      size: ButtonSize.Small,
      onClick: mockOnClick,
      disabled: false
    },
    {
      title: "Next Record",
      element: <span>Arrow Down Icon</span>,
      size: ButtonSize.Small,
      onClick: mockOnClick,
      disabled: false
    }
  ];

  it("calls the correct onClick handler when a button is clicked", () => {
    render(<Toolbar buttons={buttons} />);

    // Simulate clicking the first button
    const focusButton = screen.getByText("Focus Icon");
    fireEvent.click(focusButton);

    // Check if the onClick handler was called
    expect(mockOnClick).toHaveBeenCalledTimes(1);
  });

  it("disables buttons when the disabled property is true", () => {
    const disabledButton = {
      title: "Disabled Button",
      element: <span>Disabled Icon</span>,
      size: ButtonSize.Small,
      onClick: mockOnClick,
      disabled: true
    };

    render(<Toolbar buttons={[disabledButton]} />);

    // Check if the button is disabled
    const buttonElement = screen.getByText("Disabled Icon").closest("button");
    expect(buttonElement).toBeDisabled();
  });

  it("renders the correct number of buttons", () => {
    render(<Toolbar buttons={buttons} />);

    // Check if the correct number of buttons are rendered
    expect(screen.getAllByRole("button")).toHaveLength(buttons.length);
  });
});
