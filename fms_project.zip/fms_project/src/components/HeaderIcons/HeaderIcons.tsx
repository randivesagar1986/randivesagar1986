import { Button, ButtonSize, ButtonColor, GridItem, Grid } from "@essnextgen/ui-kit";
import { Calculator, CalendarHeatMap, CalendarSettings, DocumentExport } from "@carbon/icons-react";
import "./Style.scss";

const HeaderIcons = () => (
  <GridItem>
    <Grid
      justify="flex-end"
      className="tools page-icons"
    >
      <Button
        size={ButtonSize.Small}
        color={ButtonColor.Utility}
        title="Change financial year"
        onClick={() => {}}
      >
        <CalendarHeatMap size={22} />
      </Button>
      <Button
        size={ButtonSize.Small}
        color={ButtonColor.Utility}
        title="Close current period"
        onClick={() => {}}
      >
        <CalendarSettings size={22} />
      </Button>
      {/* <Button
        size={ButtonSize.Small}
        color={ButtonColor.Utility}
        title="Calculator"
        onClick={() => {}}
      >
        <Calculator size={22} />
      </Button> */}
    </Grid>
  </GridItem>
);

export default HeaderIcons;
