import { CenterSquare, LicenseThirdParty, Notebook, ToolKit } from "@carbon/icons-react";
import { TMenu } from "./types/menu";

/* eslint-disable import/prefer-default-export */
export const NavigationMenu: Array<TMenu> = [
  {
    id: "focus",
    label: "Focus",
    icon: "",
    href: "",
    children: ["accounts-payable", "general-ledger", "change-financial-year"],
    index: 1,
    tags: "PI1", // Being parent menu, this will be either PI1 or PI2 or PI3
    apikey: "",
    visible: true,
    accessMenuKey: "",
    enable: true
  },
  {
    id: "accounts-payable",
    label: "Accounts Payable",
    icon: "",
    href: "",
    children: [
      "supplier",
      "purchase-order",
      "invoice-credit-note",
      "cheque-processing",
      "bacs-processing",
      "deliveries",
      "importOrdersInviocesCreditNotes"
    ],
    index: 1,
    tags: "PI1", // Being parent menu, this will be either PI1 or PI2 or PI3
    apikey: "",
    visible: true,
    accessMenuKey: "",
    enable: true
  },
  {
    id: "supplier",
    label: "Supplier",
    icon: "",
    href: "/accounts-payable/supplier",
    children: [],
    index: 2,
    tags: "33050", // This is the EPIC ID for Supplier menu, used to show/hide the menu items. ID should be available in the environment files also to make it visible in the UI.
    apikey: "",
    visible: true,
    accessMenuKey: "Suppliers",
    enable: true
  },
  {
    id: "purchase-order",
    label: "Purchase Order",
    icon: "",
    href: "/accounts-payable/purchase-orders",
    children: [],
    index: 3,
    tags: "35162", // This is the EPIC ID for Purchase Order menu, used to show/hide the menu items. ID should be available in the environment files also to make it visible in the UI.
    apikey: "",
    visible: true,
    accessMenuKey: "PurchaseOrders",
    enable: true
  },
  {
    id: "invoice-credit-note",
    label: "Invoice/Credit Note",
    icon: "",
    href: "/accounts-payable/invoice-credit-note",
    children: [],
    index: 4,
    tags: "35170", // This is the EPIC ID for Invoice/Credit Note menu, used to show/hide the menu items. ID should be available in the environment files also to make it visible in the UI.
    apikey: "",
    visible: true,
    accessMenuKey: "APInvoices",
    enable: true
  },
  {
    id: "cheque-processing",
    label: "Cheque Processing",
    icon: "",
    href: "/accounts-payable/cheque-processing",
    children: [],
    index: 5,
    tags: "33065", // This is the EPIC ID for Cheque Processing menu, used to show/hide the menu items. ID should be available in the environment files also to make it visible in the UI.
    apikey: "",
    visible: true,
    accessMenuKey: "ChequeProcessing",
    enable: true
  },
  {
    id: "bacs-processing",
    label: "BACS Processing",
    icon: "",
    href: "/accounts-payable/bacs-processing",
    children: [],
    index: 6,
    tags: "PI3",
    apikey: "",
    visible: true,
    accessMenuKey: "BACSprocessing",
    enable: true
  },
  {
    id: "deliveries",
    label: "Deliveries",
    icon: "",
    href: "/accounts-payable/deliveries",
    children: [],
    index: 7,
    tags: "PI3",
    apikey: "",
    visible: true,
    accessMenuKey: "Delivery",
    enable: true
  },
  {
    id: "importOrdersInviocesCreditNotes",
    label: "Import Orders/Invoices/Credit Notes",
    icon: "",
    href: "/accounts-payable/import-orders-invoices-credit-notes",
    children: [],
    index: 8,
    tags: "PI3",
    apikey: "",
    visible: true,
    accessMenuKey: "ImportOrdersInviocesCreditNotes",
    enable: true
  },
  {
    id: "general-ledger",
    label: "General Ledger",
    icon: "",
    href: "",
    children: ["bank-recon", "petty-cash", "charts-of-accounts-review", "manual-journal-processing", "journal-review"],
    index: 2,
    tags: "PI2", // Being parent menu, this will be either PI1 or PI2 or PI3
    apikey: "",
    visible: true,
    accessMenuKey: "",
    enable: true
  },
  {
    id: "bank-recon",
    label: "Bank Reconciliation",
    icon: "",
    href: "/general-ledger/bank-reconciliation",
    children: [],
    index: 1,
    tags: "33138", // This is the EPIC ID for Bank Reconciliation menu, used to show/hide the menu items. ID should be available in the environment files also to make it visible in the UI.
    apikey: "",
    visible: true,
    accessMenuKey: "BankRec",
    enable: true
  },
  {
    id: "petty-cash",
    label: "Petty Cash",
    icon: "",
    href: "/general-ledger/petty-cash",
    children: [],
    index: 4,
    tags: "36044",
    apikey: "",
    visible: true,
    accessMenuKey: "PettyCash",
    enable: true
  },
  {
    id: "charts-of-accounts-review",
    label: "Charts of Accounts Review",
    icon: "",
    href: "/general-ledger/chart-accounts-review",
    children: [],
    index: 2,
    tags: "36042",
    apikey: "",
    visible: true,
    accessMenuKey: "ChartReview",
    enable: true
  },

  {
    id: "manual-journal-processing",
    label: "Manual Journal Processing",
    icon: "",
    href: "/general-ledger/manual-journal-list",
    children: [],
    index: 3,
    tags: "36043",
    apikey: "",
    visible: true,
    accessMenuKey: "Journals",
    enable: true
  },
  {
    id: "change-financial-year",
    label: "Change Financial Year",
    icon: "",
    href: "/change-financial-year",
    children: [],
    index: 3,
    tags: "32786",
    apikey: "",
    visible: true,
    accessMenuKey: "ChangeFinancialYear",
    enable: true
  },
  {
    id: "tools",
    label: "Tools",
    icon: "",
    href: "",
    children: [
      "general-ledger-setup",
      "manage-users",
      "define-vat-periods",
      "ap-furtle",
      "search-part",
      "fms-satisfaction-survey"
    ],
    index: 2,
    tags: "PI2",
    apikey: "",
    visible: true,
    accessMenuKey: "",
    enable: true
  },
  {
    id: "general-ledger-setup",
    label: "General Ledger Setup",
    icon: "",
    href: "/tools/general-ledger-setup/fund-codes",
    children: [],
    index: 1,
    tags: "32896",
    apikey: "Tools - Genenral Ledger Setup",
    visible: true,
    accessMenuKey: "GeneralLedgerSetup",
    enable: true
  },
  {
    id: "manage-users",
    label: "Manage Users",
    icon: "",
    href: "/tools/manage-users",
    children: [],
    index: 3,
    tags: "32786",
    apikey: "Tools - Manage Users",
    visible: true,
    accessMenuKey: "ManageUsers",
    enable: true
  },
  {
    id: "journal-review",
    label: "Journal Review",
    icon: "",
    href: "/general-ledger/journal-review",
    children: [],
    index: 5,
    tags: "36045",
    apikey: "",
    visible: true,
    accessMenuKey: "JournalReview",
    enable: true
  },
  {
    id: "define-vat-periods",
    label: "Define VAT Periods",
    icon: "",
    href: "/tools/define-vat-periods",
    children: [],
    index: 4,
    tags: "32891",
    apikey: "Tools - Define VAT Periods",
    visible: true,
    accessMenuKey: "DefineVATPeriods",
    enable: true
  },

  {
    id: "ap-furtle",
    label: "Find A/P Transactions",
    icon: "",
    href: "/tools/ap-furtle",
    children: [],
    index: 5,
    tags: "32786",
    apikey: "",
    visible: true,
    accessMenuKey: "APFurtle",
    enable: true
  },
  {
    id: "search-part",
    label: "Search Parts Catalogue",
    icon: "",
    href: "/tools/search-part",
    children: [],
    index: 6,
    tags: "32786",
    apikey: "",
    visible: true,
    accessMenuKey: "SearchPart",
    enable: true
  },
  {
    id: "fms-satisfaction-survey",
    label: "FMS Satisfaction Survey",
    icon: "",
    href: "/tools/fms-satisfaction-survey",
    children: [],
    index: 7,
    tags: "32786",
    apikey: "",
    visible: true,
    accessMenuKey: "FMSSatisfactionSurvey",
    enable: true
  }
];
