import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { TMenuAccess, TMenuVisibility } from "@/store/state/restrictedMenu.slice";
import { NavigationMenu } from "../NavigationMenu";
import { TMenu } from "../types";

type TMenuState = {
  mainMenu: Array<TMenu>;
  isSidebarOpen: boolean;
  showProfileMenu: boolean;
};

const initialState: TMenuState = {
  mainMenu: [],
  isSidebarOpen: false,
  showProfileMenu: false
};

const sidebarMenuSlice = createSlice({
  initialState,
  name: "getMenuList",
  reducers: {
    setMenuVisibility: (state: any, action: PayloadAction<any>) => {
      const { restrictedMenus, accessMenus } = action.payload;

      const menuList = NavigationMenu.map((menu: TMenu) => {
        const newMenu: TMenu = { ...menu };
        const found = restrictedMenus?.find(
          (restrictedMenu: TMenuVisibility) => restrictedMenu.menu_item === menu.apikey
        );
        if (found as TMenu) {
          newMenu.visible = found.visible;
        }
        newMenu.enable =
          accessMenus?.find((accessMenu: TMenuAccess) => accessMenu.menu === newMenu?.accessMenuKey)?.enable ??
          menu.enable;

        return newMenu;
      });

      state.mainMenu = [...menuList];
    },
    setIsSidebarOpen: (state: any, action: PayloadAction<boolean>) => {
      state.isSidebarOpen = action.payload;
    },
    setShowProfileMenu: (state: any, action: PayloadAction<boolean>) => {
      state.showProfileMenu = action.payload;
    }
  }
});

export const { actions, reducer } = sidebarMenuSlice;
export default sidebarMenuSlice.reducer;
