import { renderHook, act } from "@testing-library/react-hooks";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { useSidebarMenu } from "../useSidebarMenu";
import sidebarMenuActions from "../state/SidebarMenu.slice";

jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useDispatch: jest.fn()
}));

jest.mock("@/store/store", () => ({
  useAppSelector: jest.fn()
}));

describe("useSidebarMenu Hook", () => {
  let dispatchMock: jest.Mock;
  let onCloseMock: jest.Mock;

  beforeEach(() => {
    dispatchMock = jest.fn();
    onCloseMock = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(dispatchMock);
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.useRealTimers();
  });

  test("should initialize with default values", () => {
    (useAppSelector as jest.Mock).mockReturnValueOnce({ mainMenu: [] }).mockReturnValueOnce({
      menus: [],
      accessMenus: []
    });

    const { result } = renderHook(() => useSidebarMenu(onCloseMock));
  });

  test("should call onClose when an outside click is detected", () => {
    (useAppSelector as jest.Mock).mockReturnValue({ mainMenu: [] });
    renderHook(() => useSidebarMenu(onCloseMock));

    act(() => {
      jest.advanceTimersByTime(100);
    });
  });

  test("should dispatch setMenuVisibility when restrictedMenus and accessMenus are present", () => {
    const restrictedMenus = [{ menu_item: "item1", visible: true }];
    const accessMenus = [{ menu: "menu1", enable: true }];

    (useAppSelector as jest.Mock)
      .mockReturnValueOnce({ mainMenu: [] })
      .mockReturnValueOnce({ menus: restrictedMenus, accessMenus });

    renderHook(() => useSidebarMenu(onCloseMock));
  });

  test("should update menuList when mainMenu changes", () => {
    const mainMenu = [{ id: 1 }, { id: 2 }];
    (useAppSelector as jest.Mock).mockReturnValueOnce({ mainMenu }).mockReturnValueOnce({ menus: [], accessMenus: [] });

    const { result } = renderHook(() => useSidebarMenu(onCloseMock));

    expect(result.current.menuList).toHaveLength(0);
  });

  test("should toggle activeId when changeHandler is called", () => {
    (useAppSelector as jest.Mock).mockReturnValue({ mainMenu: [] });
    const { result } = renderHook(() => useSidebarMenu(onCloseMock));

    act(() => {
      result.current.changeHandler(true);
    });
  });
  test("should filter mainMenu based on tags and create menu", () => {
    process.env.TAGS = "tag1,tag2";

    const mainMenu = [
      { id: 1, tags: "tag1", index: 1 },
      { id: 2, tags: "tag2", index: 2 },
      { id: 3, tags: "tag3", index: 3 }
    ];

    (useAppSelector as jest.Mock).mockReturnValueOnce({ mainMenu }).mockReturnValueOnce({ menus: [], accessMenus: [] });

    const { result } = renderHook(() => useSidebarMenu(onCloseMock));

    expect(result.current.menuList).toHaveLength(2);
    expect(result.current.menuList).toEqual(
      expect.arrayContaining([expect.objectContaining({ id: 1 }), expect.objectContaining({ id: 2 })])
    );
  });
  test("should call makeSubMenus when menu item has children", () => {
    const mainMenu = [
      {
        id: 1,
        tags: "tag1",
        index: 1,
        children: [2] // This will trigger the makeSubMenus call
      },
      {
        id: 2,
        tags: "tag1",
        index: 2,
        children: []
      }
    ];

    process.env.TAGS = "tag1";

    (useAppSelector as jest.Mock).mockReturnValueOnce({ mainMenu }).mockReturnValueOnce({ menus: [], accessMenus: [] });

    const { result } = renderHook(() => useSidebarMenu(onCloseMock));

    // Assert that makeSubMenus was called, by checking that the menuList has a nested structure
    expect(result.current.menuList).toHaveLength(1);
    expect(result.current.menuList[0]).toHaveProperty("submenus");
    expect(result.current.menuList[0].submenus).toHaveLength(1);
    expect(result.current.menuList[0].submenus[0].id).toBe(2);
  });
  test("should call makeSubMenus recursively when childMenu has its own children", () => {
    const mainMenu = [
      {
        id: 1,
        tags: "tag1",
        index: 1,
        children: [2] // Top-level item with a child
      },
      {
        id: 2,
        tags: "tag1",
        index: 2,
        children: [3] // Child item with its own child
      },
      {
        id: 3,
        tags: "tag1",
        index: 3,
        children: [] // Final nested child with no further children
      }
    ];

    process.env.TAGS = "tag1";

    (useAppSelector as jest.Mock).mockReturnValueOnce({ mainMenu }).mockReturnValueOnce({ menus: [], accessMenus: [] });

    const { result } = renderHook(() => useSidebarMenu(onCloseMock));

    // Assertions to check the nested structure due to recursive makeSubMenus calls
    expect(result.current.menuList).toHaveLength(1); // Top-level menu item
    expect(result.current.menuList[0]).toHaveProperty("submenus");
    expect(result.current.menuList[0].submenus).toHaveLength(1); // First child level
    expect(result.current.menuList[0].submenus[0]).toHaveProperty("submenus");
    expect(result.current.menuList[0].submenus[0].submenus).toHaveLength(1); // Second child level
    expect(result.current.menuList[0].submenus[0].submenus[0].id).toBe(3); // Deepest nested child
  });
});
