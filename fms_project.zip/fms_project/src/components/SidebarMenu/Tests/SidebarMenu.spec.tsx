import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { BrowserRouter as Router } from "react-router-dom";
import { SidebarMenu } from "../SidebarMenu";
import { useSidebarMenu } from "../useSidebarMenu";
import { NavigationMenu } from "../NavigationMenu";

jest.mock("../useSidebarMenu");

describe("SidebarMenu", () => {
  beforeEach(() => {
    (useSidebarMenu as jest.Mock).mockReturnValue({
      menuList: NavigationMenu,
      applicationMenuRef: React.createRef()
    });
  });

  it("renders SidebarMenu component", () => {
    render(
      <Router>
        <SidebarMenu
          isOpen
          onClose={jest.fn()}
        />
      </Router>
    );

    expect(screen.getByTestId("breadcrumb-menu")).toBeInTheDocument();
  });

  it("renders menu items", () => {
    render(
      <Router>
        <SidebarMenu
          isOpen
          onClose={jest.fn()}
        />
      </Router>
    );

    NavigationMenu.forEach((menuItem) => {
      expect(screen.getByText(menuItem.label)).toBeInTheDocument();
    });
  });

  it("does not render when menuList is empty", () => {
    (useSidebarMenu as jest.Mock).mockReturnValue({
      menuList: [],
      applicationMenuRef: React.createRef()
    });

    const { container } = render(
      <Router>
        <SidebarMenu
          isOpen
          onClose={jest.fn()}
        />
      </Router>
    );

    expect(container.firstChild).toBeNull();
  });
});
