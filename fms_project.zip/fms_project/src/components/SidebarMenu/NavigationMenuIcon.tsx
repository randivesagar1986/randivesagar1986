import { CenterSquare, LicenseThirdParty, Notebook, ToolKit } from "@carbon/icons-react";
import { TMenu, TMenuIcon } from "./types";

/* eslint-disable import/prefer-default-export */
export const NavigationMenuIcon: Array<TMenuIcon> = [
  {
    id: "focus",
    icon: <CenterSquare className="menuicon" />
  },
  {
    id: "accounts-payable",
    icon: <LicenseThirdParty className="menuicon" />
  },
  {
    id: "supplier",
    icon: null
  },
  {
    id: "purchase-order",
    icon: null
  },
  {
    id: "invoice-credit-note",
    icon: null
  },
  {
    id: "cheque-processing",
    icon: null
  },
  {
    id: "general-ledger",
    icon: <Notebook className="menuicon" />
  },
  {
    id: "bank-recon",
    icon: null
  },
  {
    id: "petty-cash",
    icon: null
  },
  {
    id: "charts-of-accounts-review",
    icon: null
  },

  {
    id: "manual-journal-processing",
    icon: null
  },
  {
    id: "tools",
    icon: <ToolKit className="menuicon" />
  },
  {
    id: "general-ledger-setup",
    icon: null
  },
  {
    id: "journal-review",
    icon: null
  }
];
