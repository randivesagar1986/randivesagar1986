export type TMenuIcon = {
  id: string;
  icon: any;
};
