export type TMenu = {
  id: string;
  label: string;
  icon: string;
  href: string;
  children: string[];
  index: number;
  tags: string;
  apikey: string;
  visible: boolean;
  accessMenuKey: string;
  enable: boolean;
};
