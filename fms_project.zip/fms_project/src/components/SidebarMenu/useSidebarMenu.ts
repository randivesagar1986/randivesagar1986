import React, { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { useOutsideClick } from "@essnextgen/ui-kit";

import { useAppSelector } from "@/store/store";

import { actions as sidebarMenuActions } from "./state/SidebarMenu.slice";
import { TMenu } from "./types/menu";

/**
 * Custom hook for managing the sidebar menu state and behavior.
 * @param onClose - Callback function to be called when the sidebar menu is closed.
 * @returns An object containing the menuList, activeId, setActiveId, applicationMenuRef, and changeHandler.
 */
/* eslint-disable import/prefer-default-export */
export const useSidebarMenu = (onClose: Function) => {
  const dispatch = useDispatch();
  const { mainMenu } = useAppSelector((state) => state.sidebarMenu);
  const { menus: restrictedMenus, accessMenus } = useAppSelector((state) => state.restrictedMenu);

  /**
   * Array of tags obtained from the environment variable TAGS.
   */
  const tags: string[] = process.env.TAGS ? process.env.TAGS.split(",") : [];

  /**
   * State variable for storing the menu list.
   */
  const [menuList, setMenuList]: any[] = useState([]);

  /**
   * State variable for storing the active menu item ID.
   */
  const [activeId, setActiveId] = useState<number>(0);

  /**
   * Reference to the application menu element.
   */
  const applicationMenuRef: React.Ref<HTMLDivElement> = useRef(null);

  /**
   * Custom hook for detecting clicks outside the application menu.
   */
  const { isOutsideClicked } = useOutsideClick(applicationMenuRef);

  // const setMenuVisibility = () => {

  //   const menuList = Menu.forEach((menu) => {

  //     const found = restrictedMenus?.find((restrictedMenu: TMenuVisibility) => restrictedMenu.menu_item === menu.apikey);
  //     if (found) {
  //       menu.visible = found.visible;
  //     }
  //     return menu;
  //   });
  //   return menuList;
  // }

  /**
   * Creates the menu based on the filtered menu items.
   * @param filteredMenu - The filtered menu items.
   */
  const makeMenu = (filteredMenu: any) => {
    let menu: any[] = [];
    const childMenuList: any[] = [];
    filteredMenu.forEach((menuItem: any) => {
      let menuListItem: any = { ...menuItem };
      if (menuListItem.children && menuListItem.children.length) {
        menuListItem = makeSubMenus(filteredMenu, menuListItem, childMenuList);
      }
      menu.push(menuListItem);
    });
    menu = eliminateDuplicates(menu, childMenuList);
    setMenuList(menu);
  };

  /**
   * Creates the submenus for a menu item.
   * @param filteredMenu - The filtered menu items.
   * @param menuListItem - The menu item to create submenus for.
   * @param childMenuList - The list of child menu items.
   * @returns The updated menu item with submenus.
   */
  const makeSubMenus = (filteredMenu: any, menuListItem: any, childMenuList: any[]) => {
    menuListItem.submenus = [];
    menuListItem.children.forEach((childElement: any) => {
      const found = filteredMenu.find((eachMenu: any) => eachMenu.id === childElement);
      if (found) {
        populateDuplicates(found, childMenuList);
        let childMenu: any = { ...found };
        if (childMenu.children && childMenu.children.length) {
          childMenu = makeSubMenus(filteredMenu, childMenu, childMenuList);
        }
        menuListItem.submenus.push(childMenu);
      }
    });
    // sorting the child menus
    menuListItem.submenus.sort((a: any, b: any) => a.index - b.index);
    return menuListItem;
  };

  /**
   * Populates the list of child menu items with duplicates.
   * @param menuListItem - The menu item to check for duplicates.
   * @param childMenuList - The list of child menu items.
   */
  const populateDuplicates = (menuListItem: any, childMenuList: any[]) => {
    const found = childMenuList.find((childMenuItem) => childMenuItem.id === menuListItem.id);
    if (!found) {
      childMenuList.push(menuListItem);
    }
  };

  /**
   * Eliminates duplicates from the menu list.
   * @param menuList - The menu list.
   * @param childMenuList - The list of child menu items.
   * @returns The menu list without duplicates.
   */
  const eliminateDuplicates = (menuList: any[], childMenuList: any[]) =>
    menuList.filter((menu: any) => !childMenuList.some((childMenu: any) => childMenu.id === menu.id));

  /**
   * Event handler for menu item expansion/collapse.
   * @param isExpanded - Indicates whether the menu item is expanded or collapsed.
   */
  const changeHandler = (isExpanded: boolean) => setActiveId(isExpanded ? 0 : 1);

  /**
   * Executes when the isOutsideClicked state changes.
   * If isOutsideClicked is true, calls the onClose callback after a delay of 100ms.
   */
  useEffect(() => {
    if (isOutsideClicked) {
      setTimeout(() => onClose, 100);
    }
  }, [isOutsideClicked]);

  useEffect(() => {
    if (restrictedMenus?.length && accessMenus?.length) {
      dispatch(sidebarMenuActions.setMenuVisibility({ restrictedMenus, accessMenus }));
    }
  }, [restrictedMenus, accessMenus]);

  useEffect(() => {
    if (mainMenu.length) {
      const mainMenuJSON = [...mainMenu];

      mainMenuJSON.sort((a, b) => a.index - b.index);
      const filteredMenu = mainMenuJSON.filter((m: TMenu) => tags.includes(m.tags));

      makeMenu(filteredMenu);
    }
  }, [mainMenu]);

  return {
    menuList,
    activeId,
    setActiveId,
    applicationMenuRef,
    changeHandler
  };
};
