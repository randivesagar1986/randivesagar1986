import React, { useState } from "react";
import "./Style.scss";

const Tooltip = ({ text }: { text: string | undefined }) => <div className="tooltiptext">{text}</div>;

export default Tooltip;
