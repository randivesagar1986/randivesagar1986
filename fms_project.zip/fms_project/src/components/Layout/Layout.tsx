import React from "react";
import "./style.scss";
import { Grid, GridItem, SizeLevel, Tag, TagColor, TagSize } from "@essnextgen/ui-kit";
import Breadcrumbs from "../Breadcrumbs/Breadcrumbs";

type LayoutType = {
  pageTitle?: string;
  children: React.ReactNode;
  className?: string;
  toolbar?: React.ReactNode;
  rightContent?: React.ReactNode;
  isSubTitle?: React.ReactNode;
  type?: "white" | "transparent";
  isBreadcrumbRequired?: boolean;
  isTagRequired?: boolean;
  tagText?: string;
  dataTestId?: string;
};

const Layout = ({
  pageTitle,
  children,
  className,
  rightContent,
  isSubTitle,
  type = "white",
  toolbar,
  dataTestId,
  isTagRequired = false,
  tagText = "",
  isBreadcrumbRequired = true
}: LayoutType) => (
  <div data-testid={dataTestId}>
    {isBreadcrumbRequired ? (
      <section className="layout mt-8 pb-8">
        <div className="wrapper layout--transparent">
          <Grid
            className="breadcrums"
            justify="space-between"
            align="center"
          >
            {toolbar ? (
              <>
                <GridItem lg={9}>
                  <Breadcrumbs />
                </GridItem>

                <GridItem lg={3}>{toolbar}</GridItem>
              </>
            ) : (
              <GridItem>
                <Breadcrumbs />
              </GridItem>
            )}
          </Grid>
        </div>
      </section>
    ) : null}
    <section className={`layout ${className || ""}`}>
      {pageTitle ? (
        <div className="wrapper layout--transparent">
          <div className="toolbar-section">
            <div className="d-flex gap-8">
              <h1 className="essui-global-typography-default-h3">{pageTitle}</h1>

              {isTagRequired && (
                <Tag
                  className="ml-4"
                  id="component-layout-tag"
                  color={TagColor.Highlight}
                  size={TagSize.Large}
                  text={tagText}
                />
              )}
            </div>
            {isSubTitle}
            {rightContent}
          </div>
        </div>
      ) : null}
      <div className={`wrapper${type === "transparent" ? " layout--transparent" : ""}`}>{children}</div>
    </section>
  </div>
);

Layout.defaultProps = {
  pageTitle: undefined,
  rightContent: undefined,
  className: undefined,
  type: undefined,
  toolbar: undefined,
  isBreadcrumbRequired: undefined,
  isSubTitle: undefined,
  dataTestId: undefined,
  isTagRequired: undefined,
  tagText: undefined
};

export default Layout;
