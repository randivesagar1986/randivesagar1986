import React from "react";
import { act, render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Button } from "@essnextgen/ui-kit";
import { Modalv2 } from "../Modalv2";

describe("Modalv2 Component", () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });
  it("should set tabindex to -1 for the close button and order type modal, and focus the primary button when isOpen is true", () => {
    // Mock the document.getElementById and querySelector
    const setAttributeMock = jest.fn();
    const focusMock = jest.fn();
    document.getElementById = jest.fn().mockImplementation((id) => {
      if (id === "essui-modal-v2") {
        return {
          querySelector: jest.fn().mockImplementation((selector) => {
            if (selector === ".delete-alert .essui-button--tertiary") {
              return { setAttribute: setAttributeMock };
            }
            if (selector === ".select-order-type .essui-button--tertiary") {
              return { setAttribute: setAttributeMock };
            }
            if (selector === ".essui-button--primary") {
              return { focus: focusMock };
            }
            return null;
          })
        };
      }
      return null;
    });

    // Render the Modalv2 component with isOpen set to true
    render(
      <Modalv2
        isOpen
        primaryButton={undefined}
      >
        {undefined}
      </Modalv2>
    );

    // Wait for the useEffect to run
    setTimeout(() => {
      // Check if the close button's tabindex was set to -1
      const modalElement = document.getElementById("essui-modal-v2");
      if (modalElement) {
        const closeButton = modalElement.querySelector(".delete-alert .essui-button--tertiary");
        const orderTypeModal = modalElement.querySelector(".select-order-type .essui-button--tertiary");
        const primaryButton = modalElement.querySelector(".essui-button--primary");

        if (closeButton) {
          expect(closeButton.setAttribute).toHaveBeenCalledWith("tabindex", "-1");
        }
        if (orderTypeModal) {
          expect(orderTypeModal.setAttribute).toHaveBeenCalledWith("tabindex", "-1");
        }

        // Check if the primary button was focused
        if (primaryButton) {
          expect((primaryButton as HTMLElement).focus).toHaveBeenCalled();
        }
      }
    }, 20); // Ensure the timeout is longer than the one in useEffect
  });

  it("should set tabindex and focus correctly when isOpen is true", async () => {
    // Mock the DOM elements
    document.body.innerHTML = `
      <div id="essui-modal-v2">
        <button class="delete-alert essui-button--tertiary"></button>
        <button class="select-order-type essui-button--tertiary"></button>
        <button class="essui-button--primary"></button>
      </div>
    `;

    // Render the component
    await act(async () => {
      render(
        <Modalv2
          isOpen
          primaryButton={<Button>Primary</Button>}
          tertiaryButton={<Button>tertiary</Button>}
        >
          {undefined}
        </Modalv2>
      );
      jest.advanceTimersByTime(2000);
    });

    // Use act to simulate the state change and timeout
    act(() => {
      jest.advanceTimersByTime(10);
    });

    // Get the elements
    const closeButton = document.querySelector(".delete-alert.essui-button--tertiary");
    const orderTypeModal = document.querySelector(".select-order-type.essui-button--tertiary");
    const primaryButton = document.querySelector(".essui-button--primary");

    // Assert the attributes and focus
    expect(closeButton).not.toBeNull();
    expect(orderTypeModal).not.toBeNull();
    expect(primaryButton).not.toBeNull();

    // if (closeButton && orderTypeModal && primaryButton) {
    //   expect(closeButton).toHaveAttribute('tabindex', '-1');
    //   expect(orderTypeModal).toHaveAttribute('tabindex', '-1');
    //   expect(primaryButton).toHaveFocus();
    // }
  });
});
