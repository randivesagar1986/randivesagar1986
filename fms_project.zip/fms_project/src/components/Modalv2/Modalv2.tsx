import React, { ReactNode, useEffect } from "react";
import { Dialog, DialogContent, DialogFooter } from "@essnextgen/ui-kit";
import "./Style.scss";
import { boolean } from "yup";

type TModal = {
  focusSelectBtnDef?: boolean;
  dataTestId?: string;
  isOpen: boolean;
  className?: string;
  children: ReactNode;
  onClose?: (e: React.SyntheticEvent) => void;
  header?: string;
  footer?: React.ReactNode;
  primaryButton: React.ReactNode;
  secondaryButton?: React.ReactNode;
  tertiaryButton?: React.ReactNode;
  fourthiaryButton?: React.ReactNode;
  escapeExits?: boolean;
};

// eslint-disable-next-line import/prefer-default-export
export const Modalv2: React.FC<TModal> = ({
  focusSelectBtnDef = true,
  dataTestId,
  children,
  onClose,
  header,
  isOpen,
  className,
  footer,
  primaryButton,
  secondaryButton,
  tertiaryButton,
  fourthiaryButton,
  escapeExits = true
}) => {
  useEffect(() => {
    setTimeout(() => {
      if (isOpen) {
        const modalElement = document.getElementById("essui-modal-v2") as HTMLElement;
        if (!modalElement) return;

        const closeButton = modalElement.querySelector(".delete-alert .essui-button--tertiary") as HTMLElement;
        const orderTypeModal = modalElement.querySelector(".select-order-type .essui-button--tertiary") as HTMLElement;
        const primaryButton = modalElement.querySelector(".essui-button--primary") as HTMLElement;

        if (focusSelectBtnDef) {
          closeButton?.setAttribute("tabindex", "-1");
          orderTypeModal?.setAttribute("tabindex", "-1");

          primaryButton?.focus();
        }
      }
    }, 10);
  }, [isOpen]);

  return (
    <div
      className="modalv2"
      data-testId={dataTestId}
    >
      <Dialog
        isOpen={isOpen}
        dataTestId="modal"
        escapeExits={escapeExits}
        id="essui-modal-v2"
        onClose={onClose}
        returnFocusOnDeactivate
        title={header}
        className={className}
      >
        <DialogContent>{children}</DialogContent>
        {footer ? (
          <DialogFooter>{footer}</DialogFooter>
        ) : (
          <DialogFooter>
            <div className="buttons">
              {secondaryButton || primaryButton || fourthiaryButton ? (
                <div className="buttons-right">
                  {primaryButton}
                  {fourthiaryButton}
                  {secondaryButton}
                </div>
              ) : (
                <></>
              )}
              {tertiaryButton ? <div className="buttons-left">{tertiaryButton}</div> : <></>}
            </div>
          </DialogFooter>
        )}
      </Dialog>
    </div>
  );
};

Modalv2.defaultProps = {
  focusSelectBtnDef: undefined,
  onClose: undefined,
  header: undefined,
  className: undefined,
  footer: undefined,
  secondaryButton: undefined,
  tertiaryButton: undefined,
  fourthiaryButton: undefined,
  escapeExits: undefined,
  dataTestId: undefined
};
