import {
  CheckBox,
  CheckBoxSelectedState,
  IGridItemProps,
  RowBasedTable,
  RowBasedTableBody,
  RowBasedTableCell,
  RowBasedTableFoot,
  RowBasedTableHead,
  RowBasedTableRow,
  RowBasedTableUtility,
  RowBasedTableWrapper,
  TableRowType,
  Tooltip
} from "@essnextgen/ui-kit";
import React, { useEffect, useRef, useState } from "react";
import "./Style.scss";
import { deepEqual } from "@/utils/constants";
import "../../pages/JournalReview/JournalReviewList/Style.scss";
import "./GridStyle.scss";
import { useLocation } from "react-router-dom";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { KEYBOARD_STRING } from "@/types/UseStateType";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { centreLinksActionView } from "@/pages/GeneralLedgerSetup/State/glCentreLedgerLinksView.slice";
import { centreLinksAction } from "../../pages/GeneralLedgerSetup/State/glCentreLedgerLinks.slice";

export type RowType = { [key: string]: any };
export type KeyValueType = { [key: string]: any };

export enum ResponseCode {
  Default = "Default",
  Error = "Error",
  Info = "Info"
}

export type TColumnDef = {
  field: string;
  key?: string;
  headerName?: string;
  primary?: boolean;
  sequenceName?: string;
  sequence?: boolean;
  sequenceIndex?: number;
  checkboxSelection?: boolean;
  headerCheckboxSelection?: boolean;
  align?: "left" | "right" | "center";
  cellRenderer?: "GridCellLink";
  className?: string;
  val?: number;
  enableTooltip?: boolean;
  columnWidth?: 5 | 10 | 15 | 20 | 25 | 30 | 40 | 50 | 70 | 75 | 80 | 90 | 100 | 145 | 150 | 200 | 300;
}[];

export type TColumnHeadDef = {
  headerName?: string;
  primary?: boolean;
  sequenceName?: string;
  sequence?: boolean;
  sequenceIndex?: number;
  checkboxSelection?: boolean;
  headerCheckboxSelection?: boolean;
  align?: "left" | "right" | "center";
  cellRenderer?: "GridCellLink";
  className?: string;
  val?: number;
  colSpan?: number;
}[];

export type cellRendererType = {
  field?: string;
  row?: RowType;
  onSubmit?: (isRedirect?: boolean, isDelete?: boolean, isOpenEditPage?: boolean) => Promise<boolean>;
};

type GridTableType = {
  dataSource: RowType[];
  columnDef: TColumnDef;
  columnDefHeader?: TColumnHeadDef;
  isLoading: boolean;
  isRowSelectionEnabled?: boolean;
  isRowSelectOnArrowkey?: boolean;
  isDefaultAutoFocus?: boolean;
  loadingMsg?: string;
  emptyDataMsg?: string;
  displayErrorMsg?: string;
  selectedRow?: RowType;
  id?: string;
  selectedRowHandler?: (row?: RowType, rowIndex?: number) => void;
  checkedRowHandler?: (row: RowType) => void;
  headerClickHandler?: () => void;
  filters?: React.ReactNode;
  footer?: React.ReactNode;
  actions?: React.ReactNode;
  customCell?: any;
  onSubmit?: (isRedirect?: boolean) => void;
  checkedRows?: RowType[];
  toolTipAllow?: boolean;
  isScrollable?: boolean;
  enableScrollIntoView?: boolean;
  stickyHeader?: boolean;
  useDeepSearch?: boolean;
  dataTestId?: string;
  onEnterKeyPress?: (event?: any) => void;
  hideHeader?: boolean;
  isAutoFocusInitially?: boolean;
  onFocus?: React.FocusEventHandler<HTMLDivElement> | undefined;
  isSelectedAll?: boolean;
  handleTableHeadChange?: () => void;
} & Omit<IGridItemProps, "children">;

const GridTableNew = ({
  id,
  dataSource,
  isLoading,
  loadingMsg = "Please wait...",
  emptyDataMsg = "Register taken",
  columnDef,
  columnDefHeader,
  selectedRow,
  displayErrorMsg,
  selectedRowHandler,
  checkedRowHandler,
  headerClickHandler,
  filters,
  footer,
  checkedRows = [],
  toolTipAllow,
  isRowSelectionEnabled = true,
  isRowSelectOnArrowkey = true,
  isDefaultAutoFocus = true,
  isScrollable = false,
  enableScrollIntoView,
  stickyHeader,
  useDeepSearch,
  onEnterKeyPress,
  actions,
  dataTestId = "gridTable",
  hideHeader = false,
  isAutoFocusInitially = true,
  onFocus,
  isSelectedAll,
  handleTableHeadChange,
  onSubmit,
  ...rest
}: GridTableType) => {
  const { availableCostCentreList, availableLedgerCodeList } = useAppSelector(
    (state) => state.glCentreLedgerLinksView || {}
  );
  const dispatch = useDispatch<AppDispatch>();

  const [isKeyDownEnable, setIsKeyDownEnable] = useState(true);
  const [newSelectRow, setNewSelectRow] = useState<RowType | undefined>(selectedRow);
  const [gridRowIndex, setGridRowIndex] = useState<number>(0);
  const [rows, setRows] = useState<RowType[]>([]);
  const gridRef: React.Ref<HTMLDivElement> = useRef(null);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const translationLoadingText = t("common.loading");
  const location = useLocation();
  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;

  const rowHandler = () => {
    const row = dataSource.filter((row) => deepEqual(newSelectRow, row))[0];
    const index = dataSource.indexOf(row || dataSource[0]);
    setGridRowIndex(index);
    const element = document.getElementById(getIndex(dataTestId, index));
    element?.scrollIntoView({ block: "center", behavior: "smooth" });
    gridRef.current?.querySelectorAll("input")[0].focus();
  };

  const toggleTabIndex = () => {
    gridRef.current?.querySelectorAll("thead .essui-rowbasedtable__row").forEach((itemEl) => {
      itemEl.setAttribute("tabindex", "-1");
    });
    gridRef.current?.querySelectorAll("tfoot .essui-rowbasedtable__row").forEach((itemEl) => {
      itemEl.setAttribute("tabindex", "-1");
    });
    // gridRef.current?.querySelector("thead")?.setAttribute("tabindex", "0");
    // gridRef.current?.querySelector("tfoot")?.setAttribute("tabindex", "0");
    gridRef.current?.querySelectorAll("tbody .essui-rowbasedtable__row").forEach((itemEl) => {
      itemEl.setAttribute("tabindex", "-1");

      itemEl.querySelectorAll("button").forEach((buttonEl) => {
        buttonEl.setAttribute("tabindex", "-1");
      });
      itemEl.querySelectorAll("[type='checkbox']").forEach((buttonEl) => {
        buttonEl.setAttribute("tabindex", "-1");
      });
    });
    const selectedRowEl = gridRef.current?.querySelector("tbody .essui-rowbasedtable__row.selected-row");
    selectedRowEl?.setAttribute("tabindex", "0");
    selectedRowEl?.querySelectorAll("button").forEach((buttonEl) => {
      buttonEl.setAttribute("tabindex", "0");
    });
    selectedRowEl?.querySelectorAll("[type='checkbox']").forEach((buttonEl) => {
      buttonEl.setAttribute("tabindex", "0");
    });
    const selectedRowFl = gridRef.current?.querySelector("tfoot .essui-rowbasedtable__row");
    selectedRowFl?.setAttribute("tabindex", "-1");
  };

  useEffect(() => {
    if (!isLoading && dataSource && dataSource.length && newSelectRow) {
      toggleTabIndex();
    }
  }, [isLoading, newSelectRow, gridRef.current?.querySelectorAll("tbody .essui-rowbasedtable__row")]);

  useEffect(() => {
    if (enableScrollIntoView && !isScrollable && dataSource.length) {
      setTimeout(rowHandler, 0);
    }
  }, [enableScrollIntoView, isScrollable, dataSource]);

  useEffect(() => {
    if (isLoading === false) {
      const found = document.querySelectorAll("input")[0];
      if (!found && isAutoFocusInitially) {
        gridRef.current?.getElementsByTagName("tr")[0]?.focus();
        (gridRef?.current?.querySelector("tbody tr:first-child") as HTMLInputElement)?.focus();
      } else if (isDefaultAutoFocus) {
        found?.focus({ preventScroll: true });
      }
    }
  }, [isLoading, gridRef]);

  useEffect(() => {
    if (selectedRowHandler && newSelectRow !== undefined) {
      selectedRowHandler(newSelectRow, gridRowIndex);
    }
  }, [newSelectRow]);

  useEffect(() => {
    if (selectedRow !== undefined && dataSource?.length) {
      setNewSelectRow(selectedRow);
      if (useDeepSearch) {
        setGridRowIndex(dataSource.findIndex((obj) => deepEqual(obj, selectedRow)));
      } else {
        setGridRowIndex(dataSource.indexOf(selectedRow));
      }
    }
  }, [selectedRow, dataSource]);

  useEffect(() => {
    if (dataSource?.length > 0) {
      setRows(dataSource);
      const index = newSelectRow ? selectedRow : dataSource?.at(0);
      const rowIndexOf = dataSource.indexOf(index || dataSource[0]);
      if (rowIndexOf !== -1) {
        setNewSelectRow(index);
        setGridRowIndex(dataSource.indexOf(index || dataSource[0]));
      }
    } else {
      setRows([]);
    }
  }, [dataSource]);

  useEffect(() => {
    let timer: any;
    if (
      gridRef.current &&
      isLoading === false &&
      dataSource?.length &&
      isScrollable &&
      enableScrollIntoView !== undefined
    ) {
      timer = setTimeout(() => {
        rowHandler();
      }, 0);
    }

    return () => clearTimeout(timer);
  }, [enableScrollIntoView, isLoading, dataSource, isScrollable]);

  const handleCheckboxChange = (e: any, row: RowType) => {
    const exactPath = location.pathname;
    if (exactPath.includes("c-centre-ledger-links/add")) {
      const id = row.cost_id || row.ledger_id;
      if (row.cost_id) {
        const temp = availableCostCentreList;
        temp.forEach((obj) => {
          if (obj.cost_id === id) {
            dispatch(
              centreLinksActionView.setAvailableCostCentreList({ cost_id: obj.cost_id, isSelected: !obj.isSelected })
            );
          }
          return obj;
        });
      } else if (row.ledger_id) {
        const temp = availableLedgerCodeList;
        temp.forEach((obj) => {
          if (obj.ledger_id === id) {
            dispatch(
              centreLinksActionView.setAvailableLedgerCodeList({
                ledger_id: obj.ledger_id,
                isSelected: !obj.isSelected
              })
            );
          }
          return obj;
        });
      }
    }

    if (checkedRowHandler) {
      const updatedRows = [...checkedRows];
      const rowIndex = updatedRows.findIndex((r) => deepEqual(r, row));
      if (e.target.checked) {
        if (rowIndex === -1) {
          updatedRows.push(row);
        }
      } else if (rowIndex !== -1) {
        updatedRows.splice(rowIndex, 1);
      }
      checkedRowHandler(updatedRows);
    }
  };

  const getClassName = (index: number) => (index === gridRowIndex ? "essui-rowbasedtable__row-focus selected-row" : "");

  const handleSelectedRow = (row: RowType) => {
    const exactPath = location.pathname;
    const checkboxDef = columnDef.filter((column) => column.checkboxSelection)[0];
    const key = checkboxDef.key || 0;
    if (
      exactPath.includes("c-centre-ledger-links/add") &&
      ((row.cost_id !== undefined && row.cost_id) || (row.ledger_id !== undefined && row.ledger_id))
    ) {
      return row.isSelected;
    }
    if (row[key]) {
      return (checkedRows || []).some((checkedRow) => checkedRow[key] === row[key]);
    }
    if (row.line_number) {
      return (checkedRows || []).some((checkedRow) => checkedRow?.line_number === row?.line_number);
    }
    if (row.order_line_id) {
      /** this condition is for line item order data into purchase order */
      return (checkedRows || []).some((checkedRow) => checkedRow?.order_line_id === row?.order_line_id);
    }
    /** This condition is for invoice listing checkbox selection */
    if (exactPath.includes("/invoice-credit-note")) {
      return (checkedRows || []).some((checkedRow) => checkedRow?.invoice_id === row?.invoice_id);
    }
    /** This is for returning the checked value in purchase order */
    return (checkedRows || []).some((checkedRow) => checkedRow?.order_id === row?.order_id);
  };

  const getRow = (row: RowType, column: RowType) => {
    if (column?.cellRenderer === "GridCellLink") {
      return (
        rest.customCell && (
          <rest.customCell
            field={column?.field}
            row={row}
            onSubmit={onSubmit}
          />
        )
      );
    }
    if (row[column?.field]) {
      const { length } = row[column?.field];
      const formatText = (text: string, maxLength: number) => {
        const words = String(text)?.trim().split(/\s+/);

        let formattedText = "";
        let lineLength = 0;

        words.forEach((word) => {
          if (lineLength + word.length > maxLength) {
            formattedText += `\n${word} `;
            lineLength = word.length + 1;
          } else {
            formattedText += `${word} `;
            lineLength += word.length + 1;
          }
        });

        return formattedText.trim();
      };
      const formattedContent = formatText(row[column?.field], 40);

      return column.enableTooltip && length >= 30 ? (
        <>
          <Tooltip
            content={formattedContent}
            className="custom-tooltip"
          >
            <div className={`tooltip ${column.columnWidth === 10 && "tooltip-new-width"}`}>{row[column?.field]}</div>
          </Tooltip>
        </>
      ) : (
        row[column?.field]
      );
    }
    return "-";
  };

  const getCustomHeader = () => (
    <>
      <RowBasedTableRow
        rowType={TableRowType.Head}
        className="is-height-zero"
      >
        {columnDefHeader?.map((column, index: number) => {
          const rowKey = `row-${index}`;
          return (
            <RowBasedTableCell
              key={rowKey}
              header
              colSpan={column.colSpan}
              align={column.align}
            >
              {column?.headerName}
            </RowBasedTableCell>
          );
        })}
      </RowBasedTableRow>
    </>
  );

  useEffect(() => {
    if (gridRowIndex !== 0 && gridRowIndex !== -1) {
      setNewSelectRow(dataSource.at(gridRowIndex));
    }
  }, [gridRef, gridRowIndex]);

  const handleKeyDown: React.KeyboardEventHandler<HTMLDivElement> = (event) => {
    if (isKeyDownEnable) {
      if (event.key === "ArrowUp" || event.key === "ArrowLeft") {
        event.preventDefault();
        const index = gridRowIndex !== 0 ? gridRowIndex - 1 : 0;
        document.getElementById(getIndex(dataTestId, index))?.focus();
        document.getElementById("gridTable")?.scrollTo({ top: 0, behavior: "smooth" });
        document.getElementById(getIndex(dataTestId, index))?.scrollIntoView({ block: "center", behavior: "smooth" });
        setGridRowIndex(index);
        if (index === 0) {
          setNewSelectRow(dataSource.at(0));
        }
      } else if (event.key === "ArrowDown" || event.key === "ArrowRight") {
        event.preventDefault();
        const index = dataSource.length - 1 > gridRowIndex ? gridRowIndex + 1 : dataSource.length - 1;
        document.getElementById(getIndex(dataTestId, index))?.focus();
        setGridRowIndex(index);
      } else if (event.key === "Enter" && onEnterKeyPress) {
        onEnterKeyPress(event);
      }
    }
  };

  useEffect(() => {
    const handleFocus = (event: Event) => {
      const focusedElement = event.target as HTMLDivElement;
      // Perform any necessary actions with the focused item
      if (
        focusedElement.classList.contains("essui-overflow-menu__item") ||
        focusedElement.closest(".essui-dropdown-container")
      ) {
        setIsKeyDownEnable(false);
      } else {
        setIsKeyDownEnable(true);
      }
    };
    document.addEventListener("focus", handleFocus, true); // Use capture phase to catch focus events on child elements

    return () => {
      document.removeEventListener("focus", handleFocus, true);
    };
  }, []);

  const utitlyElementHeight = gridRef.current?.querySelector(".essui-rowbasedtable-utility")?.clientHeight;
  if (utitlyElementHeight && stickyHeader) {
    gridRef.current?.querySelector(".scroll-zindex")?.setAttribute("style", `top: ${utitlyElementHeight ?? 0 + 22}px;`);
  }

  return (
    <div
      className={`generic-table ${rest.className || ""}`}
      ref={gridRef}
      onFocus={onFocus}
      onKeyDown={isRowSelectOnArrowkey ? handleKeyDown : () => {}}
    >
      <RowBasedTableWrapper
        dataTestId={`grid-table-${id}`}
        id={id}
        isLoading={isLoading}
        loadingMsg={translationLoadingText || loadingMsg}
        isEmptyData={false}
        emptyDataMsg={emptyDataMsg}
        buttonText="Finish"
        className={`${isLoading && id === "journal-periods-modal" ? "loader-alignment" : ""} ${
          !isLoading && "grid-table-height"
        }`}
      >
        {filters && !stickyHeader ? <RowBasedTableUtility>{filters}</RowBasedTableUtility> : null}
        <div
          id={`gridTable${id ?? ""}`}
          className={`${isScrollable ? "fixed-header-table " : ""}`}
        >
          {filters && stickyHeader ? <RowBasedTableUtility>{filters}</RowBasedTableUtility> : null}
          <RowBasedTable>
            {!hideHeader && (
              <RowBasedTableHead
                id="gridTableHead"
                className="scroll-zindex"
              >
                {columnDefHeader ? getCustomHeader() : null}
                <RowBasedTableRow
                  rowType={TableRowType.Head}
                  onClick={() => (headerClickHandler ? headerClickHandler() : undefined)}
                >
                  {columnDef?.map((column, index: number) => {
                    const rowKey = `row-${index}`;
                    return column?.headerCheckboxSelection ? (
                      <RowBasedTableCell
                        key={rowKey}
                        className="w-5"
                        header
                      >
                        <CheckBox
                          onChange={handleTableHeadChange}
                          // eslint-disable-next-line
                          isSelected={
                            isSelectedAll || (checkedRows.length > 0 && ("indeterminate" as CheckBoxSelectedState))
                          } // eslint-disable-line
                          id="table-head-checkbox"
                        />
                      </RowBasedTableCell>
                    ) : (
                      <RowBasedTableCell
                        key={rowKey}
                        header
                        align="left"
                        className={column?.className ?? ""}
                      >
                        {t(`${column?.headerName ? column?.headerName : ""}`)
                          ? t(`${column?.headerName}`)
                          : column?.headerName}
                      </RowBasedTableCell>
                    );
                  })}
                </RowBasedTableRow>
              </RowBasedTableHead>
            )}
            <RowBasedTableBody>
              {(rows || []).map((row: any, rowIndex: number) => {
                const index = getIndex(dataTestId, rowIndex);
                return (
                  <RowBasedTableRow
                    rowType={TableRowType.Default}
                    key={index}
                    onClick={() => {
                      if (isRowSelectionEnabled) {
                        setGridRowIndex(rowIndex);
                        setNewSelectRow(row);
                      }
                    }}
                    className={getClassName(rowIndex)}
                    id={index}
                    dataTestId={String(rowIndex)}
                  >
                    {columnDef?.map((column, colIndex: any) => {
                      const colKey = `colIndex-${colIndex}`;
                      return column?.checkboxSelection ? (
                        <RowBasedTableCell
                          key={colKey}
                          className="w-5"
                        >
                          <CheckBox
                            isSelected={handleSelectedRow(row)}
                            value={String(rowIndex)}
                            onChange={(e) => handleCheckboxChange(e, row)}
                          />
                        </RowBasedTableCell>
                      ) : (
                        <RowBasedTableCell
                          key={colKey}
                          align={column?.align}
                          className={`${toolTipAllow ? "tool-tip-ellipse" : ""} ${
                            column?.columnWidth ? `w-${column.columnWidth}` : null
                          }`}
                        >
                          {toolTipAllow ? (
                            <>
                              <span title={row[column?.field]}>
                                {column?.cellRenderer === "GridCellLink"
                                  ? rest.customCell && (
                                      <rest.customCell
                                        field={column?.field}
                                        row={row}
                                        onSubmit={onSubmit}
                                      />
                                    )
                                  : row[column?.field]}
                              </span>
                            </>
                          ) : (
                            <>{getRow(row, column)}</>
                          )}
                        </RowBasedTableCell>
                      );
                    })}
                  </RowBasedTableRow>
                );
              })}
              {rows?.length === 0 ? (
                <RowBasedTableRow rowType={TableRowType.Info}>
                  <RowBasedTableCell
                    responseCode={ResponseCode.Info}
                    responseMessage={displayErrorMsg || t("common.noDataDisplay")}
                  />
                </RowBasedTableRow>
              ) : null}
            </RowBasedTableBody>
            {footer ? (
              <RowBasedTableFoot>
                <RowBasedTableRow rowType={TableRowType.Foot}>
                  <RowBasedTableCell
                    colSpan={columnDef?.length || 1}
                    align="right"
                  >
                    {footer}
                  </RowBasedTableCell>
                </RowBasedTableRow>
              </RowBasedTableFoot>
            ) : null}
          </RowBasedTable>
        </div>
        {actions ? <div className="grid-footer-actions">{actions}</div> : undefined}
      </RowBasedTableWrapper>
    </div>
  );
};

GridTableNew.defaultProps = {
  loadingMsg: undefined,
  emptyDataMsg: undefined,
  id: undefined,
  selectedRowHandler: undefined,
  checkedRowHandler: undefined,
  filters: undefined,
  footer: undefined,
  customCell: undefined,
  checkedRows: undefined,
  selectedRow: undefined,
  toolTipAllow: undefined,
  columnDefHeader: undefined,
  isRowSelectionEnabled: undefined,
  isAutoFocusInitially: undefined,
  headerClickHandler: undefined,
  isScrollable: undefined,
  displayErrorMsg: undefined,
  enableScrollIntoView: undefined,
  stickyHeader: undefined,
  dataTestId: undefined,
  onEnterKeyPress: undefined,
  useDeepSearch: undefined,
  actions: undefined,
  hideHeader: undefined,
  onFocus: undefined,
  isRowSelectOnArrowkey: undefined,
  isSelectedAll: undefined,
  handleTableHeadChange: undefined,
  onSubmit: undefined,
  isDefaultAutoFocus: undefined
};

export default GridTableNew;
