import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import GridTable, { TColumnDef } from "../GridTable";

const mockDataSource = [
  { id: 1, name: "John Doe", age: 28 },
  { id: 2, name: "Jane Smith", age: 34 }
];

const mockColumnDef: TColumnDef = [
  { field: "id", headerName: "ID", primary: true },
  { field: "name", headerName: "Name" },
  { field: "age", headerName: "Age" }
];

describe("GridTable Component", () => {
  test("renders loading message when isLoading is true", () => {
    render(
      <GridTable
        dataSource={[]}
        columnDef={mockColumnDef}
        isLoading
      />
    );
    expect(screen.getByText("Please wait")).toBeInTheDocument();
  });

  test("renders empty data message when dataSource is empty", () => {
    render(
      <GridTable
        dataSource={[]}
        columnDef={mockColumnDef}
        isLoading={false}
      />
    );
    expect(screen.getByText("No data to display")).toBeInTheDocument();
  });

  test("renders table with data", () => {
    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={mockColumnDef}
        isLoading={false}
      />
    );
    expect(screen.getByText("John Doe")).toBeInTheDocument();
    expect(screen.getByText("Jane Smith")).toBeInTheDocument();
  });

  test("calls selectedRowHandler when a row is clicked", () => {
    const mockSelectedRowHandler = jest.fn();
    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={mockColumnDef}
        isLoading={false}
        selectedRowHandler={mockSelectedRowHandler}
      />
    );
    fireEvent.click(screen.getByText("John Doe"));
    expect(mockSelectedRowHandler).toHaveBeenCalledWith(mockDataSource[0]);
  });

  test("renders custom cell component", () => {
    const CustomCell = ({ field, row }: { field?: string; row?: { [key: string]: any } }) => (
      <a href={`#${row?.[field!]}`}>{row?.[field!]}</a>
    );

    CustomCell.defaultProps = {
      field: "",
      row: {}
    };

    const customColumnDef: TColumnDef = [
      { field: "id", headerName: "ID", primary: true },
      { field: "name", headerName: "Name", cellRenderer: "GridCellLink" },
      { field: "age", headerName: "Age" }
    ];

    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={customColumnDef}
        isLoading={false}
        customCell={CustomCell}
      />
    );

    expect(screen.getByText("John Doe").closest("a")).toHaveAttribute("href", "#John Doe");
  });

  test("calls checkedRowHandler when a checkbox is clicked", () => {
    const mockCheckedRowHandler = jest.fn();
    const checkboxColumnDef: TColumnDef = [
      { field: "id", headerName: "ID", primary: true, checkboxSelection: true },
      { field: "name", headerName: "Name" },
      { field: "age", headerName: "Age" }
    ];

    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={checkboxColumnDef}
        isLoading={false}
        checkedRowHandler={mockCheckedRowHandler}
      />
    );

    fireEvent.click(screen.getAllByRole("checkbox")[0]);
    expect(mockCheckedRowHandler).toHaveBeenCalledWith(mockDataSource[0]);
  });

  test("renders footer when provided", () => {
    const footer = <div>Footer Content</div>;
    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={mockColumnDef}
        isLoading={false}
        footer={footer}
      />
    );
    expect(screen.getByText("Footer Content")).toBeInTheDocument();
  });

  test("renders filters when provided", () => {
    const filters = <div>Filter Content</div>;
    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={mockColumnDef}
        isLoading={false}
        filters={filters}
      />
    );
    expect(screen.getByText("Filter Content")).toBeInTheDocument();
  });

  test("renders slaveView when provided", () => {
    const slaveView = <div>Slave View Content</div>;
    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={mockColumnDef}
        isLoading={false}
        slaveView={slaveView}
      />
    );
    expect(screen.getByText("Slave View Content")).toBeInTheDocument();
  });

  test("handles checkbox uncheck correctly", () => {
    const mockCheckedRowHandler = jest.fn();
    const checkboxColumnDef: TColumnDef = [
      { field: "id", headerName: "ID", primary: true, checkboxSelection: true },
      { field: "name", headerName: "Name" },
      { field: "age", headerName: "Age" }
    ];

    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={checkboxColumnDef}
        isLoading={false}
        checkedRowHandler={mockCheckedRowHandler}
        checkedRows={[mockDataSource[0]]}
      />
    );

    fireEvent.click(screen.getAllByRole("checkbox")[0]);
    expect(mockCheckedRowHandler).toHaveBeenCalledWith({ ...mockDataSource[0], unchecked: true });
  });
});
