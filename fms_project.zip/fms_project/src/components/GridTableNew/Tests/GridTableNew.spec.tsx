import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import configureStore from "redux-mock-store";
import { useLocation } from "react-router-dom";
import GridTableNew, { cellRendererType, RowType, TColumnDef } from "../GridTableNew";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn(),
  useLocation: jest.fn(),
  useRouteMatch: jest.fn()
}));

const mockUseLocation = useLocation as jest.Mock;
mockUseLocation.mockReturnValue({ pathname: "/c-centre-ledger-links/add" });
const mockStore = configureStore([]);
const store = mockStore({
  glCentreLedgerLinksView: {
    availableCostCentreList: [],
    availableLedgerCodeList: []
  }
});

const mockDataSource: RowType[] = [
  { id: 1, name: "Row 1", cost_id: 1, ledger_id: 1 },
  { id: 2, name: "Row 2", cost_id: 2, ledger_id: 2 }
];

const mockColumnDef: TColumnDef = [
  { field: "name", headerName: "Name", primary: true },
  { field: "cost_id", headerName: "Cost ID", checkboxSelection: true }
];

const defaultProps = {
  dataSource: mockDataSource,
  columnDef: mockColumnDef,
  isLoading: false,
  selectedRowHandler: jest.fn(),
  checkedRowHandler: jest.fn(),
  headerClickHandler: jest.fn(),
  onEnterKeyPress: jest.fn(),
  onSubmit: jest.fn(),
  id: "test"
};

const renderComponent = (props = {}) =>
  render(
    <Provider store={store}>
      <GridTableNew
        {...defaultProps}
        {...props}
      />
    </Provider>
  );

describe("GridTableNew Component", () => {
  test("renders without crashing", () => {
    renderComponent();
    expect(screen.getByTestId("grid-table-test")).toBeInTheDocument();
  });

  test("displays loading message when isLoading is true", () => {
    renderComponent({ isLoading: true });
    expect(screen.getByTestId("wrapper-loader")).toBeInTheDocument();
  });

  test("displays empty data message when dataSource is empty", () => {
    renderComponent({ dataSource: [] });
    expect(screen.getByText((content, element) => content.startsWith("common.noDataDisplay"))).toBeInTheDocument();
  });

  test("calls selectedRowHandler when a row is selected", () => {
    renderComponent();
    const firstRow = screen.getByText("Row 1");
    fireEvent.click(firstRow);
    expect(defaultProps.selectedRowHandler).toHaveBeenCalledWith(mockDataSource[0], 0);
  });

  test("calls checkedRowHandler when a checkbox is clicked", () => {
    renderComponent();
    const checkbox = screen.getAllByRole("checkbox")[0];
    fireEvent.click(checkbox);
    expect(defaultProps.checkedRowHandler).toHaveBeenCalled();
  });

  test("calls onEnterKeyPress when Enter key is pressed", () => {
    renderComponent();
    fireEvent.keyDown(screen.getByTestId("grid-table-test"), { key: "Enter", code: "Enter" });
    expect(defaultProps.onEnterKeyPress).toHaveBeenCalled();
  });

  test("renders filters when provided", () => {
    const filters = <div>Filters</div>;
    renderComponent({ filters });
    expect(screen.getByText("Filters")).toBeInTheDocument();
  });

  test("renders footer when provided", () => {
    const footer = <div>Footer</div>;
    renderComponent({ footer });
    expect(screen.getByText("Footer")).toBeInTheDocument();
  });

  test("renders actions when provided", () => {
    const actions = <div>Actions</div>;
    renderComponent({ actions });
    expect(screen.getByText("Actions")).toBeInTheDocument();
  });

  test("renders sticky header when stickyHeader is true", () => {
    renderComponent({ stickyHeader: true });
  });

  test("renders scrollable table when isScrollable is true", () => {
    renderComponent({ isScrollable: true });
    expect(screen.getByTestId("grid-table-test").querySelector(".fixed-header-table")).toBeInTheDocument();
  });

  test("calls headerClickHandler when header is clicked", () => {
    renderComponent();
    const header = screen.getByText("Name");
    fireEvent.click(header);
    expect(defaultProps.headerClickHandler).toHaveBeenCalled();
  });

  test("calls onFocus when the table is focused", () => {
    const onFocus = jest.fn();
    renderComponent({ onFocus });
    fireEvent.focus(screen.getByTestId("grid-table-test"));
    expect(onFocus).toHaveBeenCalled();
  });

  test("handles key down events for arrow keys", () => {
    renderComponent();
    fireEvent.keyDown(screen.getByTestId("grid-table-test"), { key: "ArrowDown", code: "ArrowDown" });
    expect(defaultProps.selectedRowHandler).toHaveBeenCalledWith(mockDataSource[1], 1);
  });

  test("handles key down events for Enter key", () => {
    renderComponent();
    fireEvent.keyDown(screen.getByTestId("grid-table-test"), { key: "Enter", code: "Enter" });
    expect(defaultProps.onEnterKeyPress).toHaveBeenCalled();
  });

  test("handles checkbox selection correctly", () => {
    renderComponent();
    const checkbox = screen.getAllByRole("checkbox")[0];
    fireEvent.click(checkbox);
    expect(defaultProps.checkedRowHandler).toHaveBeenCalledWith([mockDataSource[0]]);
  });

  test("handles deep search correctly", () => {
    renderComponent({ useDeepSearch: true, selectedRow: mockDataSource[1] });
    expect(defaultProps.selectedRowHandler).toHaveBeenCalledWith(mockDataSource[1], 1);
  });

  test("handles scroll into view correctly", () => {
    renderComponent({ enableScrollIntoView: true });
    expect(screen.getByTestId("grid-table-test").querySelector(".essui-rowbasedtable__row-focus")).toBeInTheDocument();
  });

  test("handles row selection with arrow keys", () => {
    renderComponent();
    fireEvent.keyDown(screen.getByTestId("grid-table-test"), { key: "ArrowDown", code: "ArrowDown" });
    expect(defaultProps.selectedRowHandler).toHaveBeenCalledWith(mockDataSource[1], 1);
  });

  test("handles row selection with mouse click", () => {
    renderComponent();
    const firstRow = screen.getByText("Row 1");
    fireEvent.click(firstRow);
    expect(defaultProps.selectedRowHandler).toHaveBeenCalledWith(mockDataSource[0], 0);
  });

  test("handles row selection with Enter key", () => {
    renderComponent();
    fireEvent.keyDown(screen.getByTestId("grid-table-test"), { key: "Enter", code: "Enter" });
    expect(defaultProps.onEnterKeyPress).toHaveBeenCalled();
  });

  test("handles focus events correctly", () => {
    const onFocus = jest.fn();
    renderComponent({ onFocus });
    fireEvent.focus(screen.getByTestId("grid-table-test"));
    expect(onFocus).toHaveBeenCalled();
  });

  test("handles header click events correctly", () => {
    renderComponent();
    const header = screen.getByText("Name");
    fireEvent.click(header);
    expect(defaultProps.headerClickHandler).toHaveBeenCalled();
  });
});
