import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import Sequence from "../Sequence";
import { TColumnDef } from "../../GridTable/GridTable";

const mockColumnDef: TColumnDef = [
  { field: "name", headerName: "Name", sequence: true, checkboxSelection: true },
  { field: "age", headerName: "Age", sequence: true, checkboxSelection: false },
  { field: "address", headerName: "Address", sequence: true, checkboxSelection: false }
];

describe("Sequence Component", () => {
  it("should render all sequence radio buttons", () => {
    const { getByLabelText } = render(<Sequence columnDef={mockColumnDef} />);
    expect(getByLabelText("Name")).toBeInTheDocument();
    expect(getByLabelText("Age")).toBeInTheDocument();
    expect(getByLabelText("Address")).toBeInTheDocument();
  });

  it("should handle radio button change", () => {
    const setColumnsMock = jest.fn();
    const { getByLabelText } = render(
      <Sequence
        columnDef={mockColumnDef}
        setColumns={setColumnsMock}
      />
    );

    fireEvent.click(getByLabelText("Age"));
    expect(setColumnsMock).toHaveBeenCalled();
  });

  it("should update selected option on radio button change", () => {
    const { getByLabelText } = render(<Sequence columnDef={mockColumnDef} />);

    const ageRadioButton = getByLabelText("Age");
    fireEvent.click(ageRadioButton);
    expect(ageRadioButton).toBeChecked();
  });

  it("should swap columns correctly when checkboxSelection is true", () => {
    const setColumnsMock = jest.fn();
    render(
      <Sequence
        columnDef={mockColumnDef}
        setColumns={setColumnsMock}
      />
    );
    const nameRadioButton = screen.getAllByTestId("sequence-radio")[1];
    fireEvent.click(nameRadioButton);
    expect(setColumnsMock).toHaveBeenCalledWith([
      { field: "name", headerName: "Name", sequence: true, checkboxSelection: true },
      { field: "age", headerName: "Age", sequence: true, checkboxSelection: false },
      { field: "address", headerName: "Address", sequence: true, checkboxSelection: false }
    ]);
  });

  it("should swap columns correctly when checkboxSelection is false", () => {
    const setColumnsMock = jest.fn();
    render(
      <Sequence
        columnDef={mockColumnDef}
        setColumns={setColumnsMock}
      />
    );
    const ageRadioButton = screen.getAllByTestId("sequence-radio")[0];
    fireEvent.click(ageRadioButton);
    expect(setColumnsMock).toHaveBeenCalledWith([
      { field: "age", headerName: "Age", sequence: true, checkboxSelection: false },
      { field: "name", headerName: "Name", sequence: true, checkboxSelection: true },
      { field: "address", headerName: "Address", sequence: true, checkboxSelection: false }
    ]);
  });

  it("should swap columns correctly when no checkboxSelection is true", () => {
    const setColumnsMock = jest.fn();
    const columnDefWithoutCheckboxSelection: TColumnDef = [
      { field: "name", headerName: "Name", sequence: true, checkboxSelection: false },
      { field: "age", headerName: "Age", sequence: true, checkboxSelection: false },
      { field: "address", headerName: "Address", sequence: true, checkboxSelection: false }
    ];
    render(
      <Sequence
        columnDef={columnDefWithoutCheckboxSelection}
        setColumns={setColumnsMock}
      />
    );
    const ageRadioButton = screen.getAllByTestId("sequence-radio")[1];
    fireEvent.click(ageRadioButton);
    expect(setColumnsMock).toHaveBeenCalledWith([
      { field: "age", headerName: "Age", sequence: true, checkboxSelection: false },
      { field: "name", headerName: "Name", sequence: true, checkboxSelection: false },
      { field: "address", headerName: "Address", sequence: true, checkboxSelection: false }
    ]);
  });
});
