import { Loader, LoaderType } from "@essnextgen/ui-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";

export type loadingConfig = {
  loadingText?: string;
  isLoaderModal?: boolean;
  className?: string;
};

const AppLoader = ({ loadingConfig }: { loadingConfig: loadingConfig }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const defaultLoadingText =
    loadingConfig && loadingConfig.loadingText ? loadingConfig.loadingText : t("common.loading");

  return (
    <>
      <div className="apploader">
        <Loader
          loaderType={LoaderType.Circular}
          loaderText={defaultLoadingText}
          isLoaderModal={loadingConfig?.isLoaderModal}
          className={loadingConfig?.className}
        />
      </div>
    </>
  );
};

export default AppLoader;
