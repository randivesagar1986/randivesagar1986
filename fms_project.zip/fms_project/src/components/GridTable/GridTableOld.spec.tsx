import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import GridTable, { TColumnDef } from "./GridTable";

const mockDataSource = [
  { id: 1, name: "John Doe", age: 28 },
  { id: 2, name: "Jane Smith", age: 34 }
];

const mockColumnDef: TColumnDef = [
  { field: "id", headerName: "ID", primary: true },
  { field: "name", headerName: "Name" },
  { field: "age", headerName: "Age" }
];

describe("GridTable", () => {
  it("renders loading message when isLoading is true", () => {
    render(
      <GridTable
        dataSource={[]}
        columnDef={mockColumnDef}
        isLoading
      />
    );
    expect(screen.getByTestId("wrapper-loader")).toBeInTheDocument();
  });

  it("renders table with data", () => {
    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={mockColumnDef}
        isLoading={false}
      />
    );
    expect(screen.getByText("John Doe")).toBeInTheDocument();
    expect(screen.getByText("Jane Smith")).toBeInTheDocument();
  });

  it("calls selectedRowHandler when a row is clicked", () => {
    const mockSelectedRowHandler = jest.fn();
    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={mockColumnDef}
        isLoading={false}
        selectedRowHandler={mockSelectedRowHandler}
      />
    );
    fireEvent.click(screen.getByText("John Doe"));
    expect(mockSelectedRowHandler).toHaveBeenCalledWith(mockDataSource[0]);
  });

  it("calls checkedRowHandler when a checkbox is clicked", () => {
    const mockCheckedRowHandler = jest.fn();
    const columnDefWithCheckbox: TColumnDef = [
      ...mockColumnDef,
      { field: "select", headerCheckboxSelection: true, checkboxSelection: true }
    ];
    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={columnDefWithCheckbox}
        isLoading={false}
        checkedRowHandler={mockCheckedRowHandler}
      />
    );
    fireEvent.click(screen.getAllByTestId("checkbox")[1]);
  });

  it("renders custom cell when cellRenderer is provided", () => {
    const CustomCell = ({ field, row }: { field?: string; row?: { [key: string]: any } }) => (
      <a href={`/${row?.id}`}>{row?.[field ?? ""]}</a>
    );

    CustomCell.defaultProps = {
      field: "",
      row: {}
    };
    const columnDefWithCustomCell: TColumnDef = [{ field: "name", headerName: "Name", cellRenderer: "GridCellLink" }];
    render(
      <GridTable
        dataSource={mockDataSource}
        columnDef={columnDefWithCustomCell}
        isLoading={false}
        customCell={CustomCell}
      />
    );
    expect(screen.getByText("John Doe").closest("a")).toHaveAttribute("href", "/1");
  });
});
