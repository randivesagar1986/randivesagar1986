// OpenLinkButton.tsx
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import React, { useEffect, useState } from "react";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import useHelpButton from "./useHelpButton";

interface OpenLinkButtonProps {
  identifier: any; // Adjust the type as needed
  labelName: string;
  helpText?: string; // Marking helpText as optional
  [key: string]: any; // To allow passing additional props to the button element
}

const HelpButton: React.FC<OpenLinkButtonProps> = ({ identifier, labelName, helpText, ...props }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const defaultHelpText = t("common.help");

  const { handleClick } = useHelpButton();

  return (
    <Button
      onClick={handleClick}
      {...props}
      size={ButtonSize.Small}
      color={ButtonColor.Tertiary}
      className="focus-cta"
    >
      {/* {t("common.help")} */}
      {helpText || defaultHelpText}
    </Button>
  );
};

// Define defaultProps
HelpButton.defaultProps = {
  helpText: undefined
};

export default HelpButton;
