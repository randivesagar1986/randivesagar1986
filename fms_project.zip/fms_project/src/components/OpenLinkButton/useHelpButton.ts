import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";

const useHelpButton = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const urlHelp = "https://customer.support-ess.com/csm";

  const handleClick = () => {
    window.open(urlHelp, "_blank");
  };

  return {
    handleClick
  };
};
export default useHelpButton;
