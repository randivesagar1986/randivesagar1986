module.exports = {
  rootDir: "../../",
  setupFilesAfterEnv: ["<rootDir>/config/jest/setupTests.ts"],
  testMatch: [
    "**/__tests__/**/*.+(ts|tsx|js|jsx)",
    "**/?(*.)+(spec|test).+(ts|tsx|js|jsx)"
  ],
  moduleNameMapper: {
    "\\.(css|less|sass|scss)$":
      "<rootDir>/config/jest/__mocks__/styleMock.js",
    "\\.(gif|ttf|eot|svg|jpg|jpeg|png|ico|webp)$":
      "<rootDir>/config/jest/__mocks__/fileMock.js",
      "@/(.*)": "<rootDir>/src/$1"
  },
  transformIgnorePatterns: ["node_modules", "dist"],
  preset: "ts-jest",
  testEnvironment: "jsdom",
  transform: {
    "^.+\\.(ts|tsx)?$": "ts-jest",
    "^.+\\.(js|jsx)$": "babel-jest"
  },
  reporters: [
    "default",
    [
      "jest-html-reporters",
      {
        publicPath: "./coverage/html-report",
        filename: "report.html"
      }
    ]
  ],
  collectCoverageFrom: [
    "src/**/*.{js,ts,jsx,tsx}",
    "!src/types/*.{js,jsx,ts,tsx}",
    "!src/index.tsx",
    "!src/redux/rootReducer.ts",
    "!src/redux/store.ts",
    "!src/talismanfailure.js",
    "!src/api/index.ts",
    "!src/**/*.stories.{js,jsx,ts,tsx}",
    "!src/reportWebVitals.ts",
    "!src/api/api.ts",
    "!src/**/**/index*.{js,ts,jsx,tsx}",
    "!src/features/Sample/*.{js,jsx,ts,tsx}"
  ],
  coverageReporters: ["json", "lcov", "text", "clover", "cobertura"],

  coverageThreshold: {
    global: {
      branches: 50,
      functions: 50,
      lines: 50,
      statements: 50
    }
  }
};
