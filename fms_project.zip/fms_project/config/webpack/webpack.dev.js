const { merge } = require("webpack-merge");
const { baseConfig } = require("./webpack.base");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const path = require("path");
const fs = require("fs");

const webpackDevServerSettings = {
  compress: true,
  hot: true,
  port: process.env.PORT || 3002,
  server: {
    type: 'https',
  },
  open: ['/'],
  proxy: {
    '/api': {
      // target: 'https://fms7-dev.parentpaygroup.com',
      target: 'http://localhost:7147/',
      secure: false
    },
  },
  client: {
    overlay: false
  }
};

module.exports = merge(baseConfig, {
  devtool: "eval-source-map",
  devServer: webpackDevServerSettings
});
