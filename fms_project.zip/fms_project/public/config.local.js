window.AUTH_API_URL = window.SIMS_CONFIG.authApiUrl;
window.REACT_API_URL = window.SIMS_CONFIG.reactApiUrl;
window.REACT_CLIENT_ID = window.SIMS_CONFIG.reactClientId;
window.REACT_AUTH_ENDPOINT = window.SIMS_CONFIG.reactAuthEndpoint;
window.REACT_REDIRECT_URI = "https://localhost:3002/UI/oauth/authorise/auth";
window.SIMS_HOME_URL = window.SIMS_CONFIG.simsHomeUrl;
window.APPLICATION = window.SIMS_CONFIG.application;
window.REACT_ENVIRONMENT = window.SIMS_CONFIG.reactEnvironment;

//window.AppInsightsConnectionString = "";
//window.REACT_GA_TRACKING_ID = "";
//window.HOME_URL = "https://dev.home.sims.co.uk/";
//window.REACT_ONETRUST_DOMAIN_ID = "e025a41c-b4c9-4895-a6af-b28f3ca27ba0-test";
//window.USE_SCHOOL_PERMISSION = "false";
//window.REDIRECT_URI = "https://fms7-dev.parentpaygroup.com/ui/oauth/authorise/auth";
//window.LANDING_PAGE_URL = "https://localhost:3002/ui/oauth/authorise";