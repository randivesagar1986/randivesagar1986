export interface RoleDataType {
    roleId: number,
    role: string,
    id: string
}

export interface DesigantionDataType {
    designation: string,
    id: string,
    description: string,
    skills: string
}

export interface ClientDataType {
    id: string;
    clientName: string;
    clientEmail: string;
    companyName: string;
    address: string;
    clientContact: string;
    country: string;
    employeeStrength: number;
    terms: boolean;
}

export interface EmployeeDataType {
    empName: string,
    id: string,
    empCode: string,
    emailId: string,
    empDesignation: string,
    role: string
}
  

export interface ProjectDataType {
    id: string
    projectName: string
    startDate: string
    leadEmpId: string
    empName: string
    clientId: string
    projectDetails: string
    employeesWorking: number
    emailId: string
    clientName: string
    clientEmail: string
  }

export interface signUpData {
    firstName: string
    lastName: string
    id: string
    email: string
    password: string
}