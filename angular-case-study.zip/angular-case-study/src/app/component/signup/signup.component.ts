import { Component, signal } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { SignUpService } from '../../services/signup.service';
import { Router, RouterLink } from '@angular/router';
import { API_ERROR, FILL_ALL_REQUIRED_FIELD } from '../../constant/app.constant';

const equalValue = (controlName1:string, controlName2:string) => {
  return (control: AbstractControl) => {
    const val1 = control.get(controlName1)?.value;
    const val2 = control.get(controlName2)?.value;
    if(val1 === val2){
      return null
    }

    return {valueNotEqual: true}
  }
}
@Component({
  selector: 'app-signup',
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent {

    errorMsg = signal("");
    constructor(private signUpService: SignUpService, private router: Router){

    }

    form = new FormGroup({
       firstName : new FormControl("", {
          validators: [Validators.required]
       }),
       lastName : new FormControl("", {
        validators: [Validators.required]
       }),
       email : new FormControl("", {
        validators: [Validators.required, Validators.email]
       }),
       id : new FormControl("", {
        validators: [Validators.required, Validators.maxLength(10)]
       }),
       passwords : new FormGroup({
          password: new FormControl("", {
            validators: [Validators.required, Validators.minLength(8), Validators.maxLength(15)]
          }),
          confirmPass: new FormControl("", {
            validators: [Validators.required, Validators.minLength(8), Validators.maxLength(15)]
          }),   
       },{
        validators: [equalValue("password", "confirmPass")]
       }),
    })

    get errorDisplayOrNot(){
      return this.errorMsg() === "" ? {display:"none"} : {display:"block"}
    }

    errorDisplayNoneTimeout(msg:string){
      this.errorMsg.set(msg);
      setTimeout(() => {
        this.errorMsg.set("");
      }, 5000); // Shows error for 3 seconds
    }

    onSignUp(){
      if(this.form.invalid){
        this.errorDisplayNoneTimeout(FILL_ALL_REQUIRED_FIELD);
        return
      }else{
        const data = {
          firstName: this.form.value.firstName,
          lastName: this.form.value.lastName,
          email: this.form.value.email,
          password: this.form.value.passwords?.password,
          id: this.form.value.id
        }

        const loginData = {
          id: this.form.value.id,
          email: this.form.value.email,
          token: `@@${this.form.value.id}%%${this.form.value.email}$$`
        }

        this.signUpService.createNewAccount(data).subscribe({
          next : (res: any) => {
            console.log("UserData", res);
            this.signUpService.createLogin(loginData).subscribe((res1: any)=>{
                console.log(res1);
                this.router.navigateByUrl("/login");
            })
          },
          error : (error: Error) => {
            console.log("error", error?.message);
            this.errorDisplayNoneTimeout(API_ERROR);
          },
          complete: () => {
            this.onResetForm();
          }
        })

      }
    }

    onResetForm(){
      this.errorMsg.set("");
      this.form.reset();
    }
}
