import { Component, input } from "@angular/core";
import { MasterService } from "../../services/master.service";

@Component({
    selector: "app-alert",
    templateUrl: "./alert.component.html",
    styleUrl: "./alert.component.css",
    imports: []
})

export class AlertComponent{
    alertMessage = input.required();

    constructor(public masterService: MasterService){

    }
}