import { Component, EventEmitter, inject, input, Input, Output } from '@angular/core';
import { ClientDataType } from '../../../model/app.model';
import { MasterService } from '../../../services/master.service';

@Component({
  selector: 'app-client-view',
  imports: [],
  templateUrl: './client-view.component.html',
  styleUrl: './client-view.component.css'
})
export class ClientViewComponent {
    @Input() clientData?:ClientDataType;
    isViewModalOpen = input.required<boolean>();
    @Output() modalClose = new EventEmitter();
    masterService = inject(MasterService);
    
    constructor(){
      console.log("Render client view")
    }

    closeModal(){
      this.modalClose.emit(false);
    }

}
