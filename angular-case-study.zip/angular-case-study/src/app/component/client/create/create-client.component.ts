import { Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ClientService } from '../../../services/client.service';
import { ClientDataType } from '../../../model/app.model';
import { Router } from '@angular/router';
import { AlertComponent } from "../../modal/alert.component";
import { MasterService } from '../../../services/master.service';
import { API_ERROR } from '../../../constant/app.constant';

@Component({
  selector: 'app-create-client',
  templateUrl: './create-client.component.html',
  styleUrl: './create-client.component.css',
  imports: [ReactiveFormsModule, AlertComponent]
})
export class CreateClientComponent {
    clientService = inject(ClientService);
    clientList:ClientDataType[] = [];
    //isError = signal(false);
    alertMessage = signal("");

    constructor(private router: Router, public masterService: MasterService) {

    }

    form = new FormGroup({
        clientName : new FormControl("", {
            validators:[Validators.required, Validators.minLength(3), Validators.maxLength(20)]
        }),
        companyName: new FormControl("", {
            validators:[Validators.required, Validators.minLength(3), Validators.maxLength(20)]
        }),
        clientEmail: new FormControl("", {
            validators:[Validators.email, Validators.required]
        }),
        clientContact: new FormControl("", {
            validators:[Validators.required, Validators.minLength(10), Validators.maxLength(10)]
        }),
        address: new FormControl("", {
            validators:[Validators.required, Validators.minLength(5)]
        }),
        country:  new FormControl("", {
            validators:[Validators.required]
        }),
        employeeStrength: new FormControl("", {
            validators:[Validators.required]
        }),
        terms: new FormControl(false, {
            validators:[Validators.required, Validators.requiredTrue]
        })
    })

    ngOnInit(): void {
        this.clientService.getAllClients().subscribe({
          next : (resClients: ClientDataType[]) => {
            this.clientList = resClients;
          },
          error : (error:Error) => {
            console.log("error", error?.message);
          }
         })
    }

    clientCreateSubmit(){
        console.log("enter");
        console.log("form", this.form)
        if(this.form.invalid){
            //this.isError.set(true);
            this.masterService.closeOpenAlertModal(true);
            this.alertMessage.set("Please fill all mandatory fields");
        }else if(this.form.value.companyName && this.form.value.clientEmail && this.form.value.clientContact && this.form.value.    employeeStrength && this.form.value.terms && this.form.value.clientName && this.form.value.country && this.form.value.address){
            let data = {
                companyName: this.form.value.companyName,
                clientEmail: this.form.value.clientEmail,
                clientContact: this.form.value.clientContact,
                employeeStrength: Number(this.form.value.employeeStrength),
                terms: this.form.value.terms,
                clientName: this.form.value.clientName,
                country: this.form.value.country,
                address: this.form.value.address,
                id: (this.clientList.length + 1).toString()
            }
            this.clientService.createNewClient(data).subscribe({
                next : (resClients: any) => {
                    console.log("resClients", resClients);
                    this.router.navigateByUrl("/client");
                  },
                  error : (error:Error) => {
                    console.log("error", error?.message);
                    this.alertMessage.set(API_ERROR);
                    this.masterService.closeOpenAlertModal(true);
                    //this.isError.set(true);
                  },
                  complete: () => {
                    this.form.reset();
                  }
            })
        }
    }

    onReset() {
        this.form.reset();
    }

    /* isFieldInvalid(fieldName:string) {
        return this.form && this.form.controls.clientName.dirty
    } */
}
