import { Component, inject, OnInit, signal } from '@angular/core';
import { ClientService } from '../../services/client.service';
import { ClientDataType } from '../../model/app.model';
import { ClientViewComponent } from './client-view/client-view.component';
import { MasterService } from '../../services/master.service';
import { AlertComponent } from "../modal/alert.component";
import { catchError, tap } from 'rxjs';
import { UpperCasePipe } from '@angular/common';
import { API_ERROR, CLIENT_SUCCESS_DELETE_ALERT, NO_DATA } from '../../constant/app.constant';
import { ErrorComponent } from "../error/error.component";

@Component({
  selector: 'app-client',
  imports: [ClientViewComponent, AlertComponent, UpperCasePipe, ErrorComponent],
  templateUrl: './client.component.html',
  styleUrl: './client.component.css'
})
export class ClientComponent implements OnInit{
    clientService = inject(ClientService);
    clientList: ClientDataType[] = [];
    errorMessage = signal("");
    modalMessage = signal("");
    isDataFetching = signal(false);
    isViewModalOpen = signal(false);
    viewClientData:ClientDataType|undefined

    constructor(public masterService: MasterService){

    }

    fetchData(){
        this.isDataFetching.set(true);
        this.clientService.getAllClients().subscribe({
          next : (resClients: ClientDataType[]) => {
            this.clientList = resClients;
            if(resClients.length <= 0){
              this.errorMessage.set(NO_DATA);
            }
          },
          error : (error:Error) => {
            this.isDataFetching.set(false);
            this.errorMessage.set(API_ERROR);
          },
          complete: () => {
            this.isDataFetching.set(false);
          }
      })
    }

    ngOnInit(): void {
        this.fetchData();
    }

    viewMoreDetails(clientId: string){
      this.isViewModalOpen.set(true);
      this.viewClientData = this.clientList.find((client)=>{
        return client.id == clientId
      })
    }

    viewModalClose(isOpen:boolean){
      this.isViewModalOpen.set(isOpen);
      this.viewClientData = undefined
    }

   /*  showAlert() {
      document.getElementById("successAlert").slideDown('slow');
      setTimeout(function() {
          $('#successAlert').slideUp('slow');
      }, 3000);
    }

  showAlert(); */

    onClientDelete(id:string){
      this.isDataFetching.set(true);
      this.clientService.deleteClient(id).pipe(
        tap((res) => {
          console.log(`Deleted item with id=${id}`);
          console.log("deleteRes", res)
          // After successful deletion, fetch the updated data
          this.fetchData();
          this.modalMessage.set(CLIENT_SUCCESS_DELETE_ALERT);
          this.masterService.closeOpenAlertModal(true);
        }),
        catchError((error) => {
          this.isDataFetching.set(false);
          this.modalMessage.set(API_ERROR);
          this.masterService.closeOpenAlertModal(true);
          console.log("errorDelete", error)
          return [];
        })
      ).subscribe({
        complete: () => {
          this.isDataFetching.set(false);
        }
      })
    }
}
