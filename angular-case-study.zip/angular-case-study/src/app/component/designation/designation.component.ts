import { Component, inject, input, OnInit, signal } from '@angular/core';
import { MasterService } from '../../services/master.service';
import { DesigantionDataType } from '../../model/app.model';
import { ErrorComponent } from '../error/error.component';
import { API_ERROR, NO_DATA } from '../../constant/app.constant';
import { RouterEvent, RouterLink } from '@angular/router';

@Component({
  selector: 'app-designation',
  imports: [ErrorComponent, RouterLink],
  templateUrl: './designation.component.html',
  styleUrl: './designation.component.css'
})
export class DesignationComponent implements OnInit{
    masterService = inject(MasterService);
    designationList: DesigantionDataType[] = [];
    errorMessage = signal<string>("");
    isDataFetching = signal(false);
    showLess = input<number>(0);
    
    //any function which are returning observable type of data we can subscribe it using subscribe method.
    ngOnInit(): void {
        this.isDataFetching.set(true);
        this.masterService.getDesignation().subscribe({
          next : (resDesigantion: DesigantionDataType[]) => {
            if(this.showLess()){
              const lessData = resDesigantion?.slice(0, this.showLess());
              this.designationList = lessData;
            }else{
              this.designationList = resDesigantion;
            }
            if(resDesigantion.length <=0){
              this.errorMessage.set(NO_DATA);
            }
          },
          error : (error: Error) => {
            this.errorMessage.set(API_ERROR);
            this.isDataFetching.set(false);
          },
          complete : () => {
            this.isDataFetching.set(false);
          }
        })
    }
}
