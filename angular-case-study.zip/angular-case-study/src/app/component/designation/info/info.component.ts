import { Component, inject, input, Input, OnChanges, OnInit, signal, SimpleChanges } from '@angular/core';
import { MasterService } from '../../../services/master.service';
import { DesigantionDataType } from '../../../model/app.model';
import { API_ERROR } from '../../../constant/app.constant';
import { ErrorComponent } from "../../error/error.component";
import { ActivatedRoute, Route, Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-info',
  imports: [ErrorComponent, RouterLink],
  templateUrl: './info.component.html',
  styleUrl: './info.component.css'
})
export class InfoComponent implements OnInit, OnChanges{
  //@Input() designationId : string | undefined;
  //designationId = input.required<string>();
  designationId: string = "";
  isDataFetching = signal(false);
  errorMessage = signal("");
  designationData : null | DesigantionDataType = null;
  router = inject(Router);


  constructor(private masterService: MasterService, private route: ActivatedRoute){

  }

  get getDesignationId(){
      return this.designationId
  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.designationId = params['designationId'];
      console.log(this.designationId);
    });
    console.log("designationId", this.designationId)
    this.isDataFetching.set(true);
    this.masterService.getDesignationInfo(this.designationId).subscribe({
      next : (resDesigantion: DesigantionDataType) => {
        this.designationData = resDesigantion
      },
      error : (error: Error) => {
        this.errorMessage.set(API_ERROR);
        this.isDataFetching.set(false);
      },
      complete : () => {
        this.isDataFetching.set(false);
      }
    })
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['designationId']) {
      console.log(this.designationId);
      // Now you can use the dynamicId
    }
  }
  

}


/* This is a common issue in Angular, especially when dealing with asynchronous data fetching or URL parameters. When you try to access the input value in `ngOnInit`, it's possible that the value hasn't been set yet, resulting in `undefined`.

Here are some possible reasons and solutions for this issue:

### 1. URL Parameters are Asynchronous

When you navigate to a route, Angular's router takes some time to resolve the route and pass the URL parameters to the component. This means that when `ngOnInit` is called, the URL parameters might not be available yet.

**Solution:** Use the `ActivatedRoute` service to subscribe to the `params` observable, which will emit the URL parameters when they become available.

```typescript
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-example',
  template: '<p>Example works!</p>'
})
export class ExampleComponent implements OnInit {
  dynamicId: string;

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.dynamicId = params['id'];
      // Now you can use the dynamicId
      console.log(this.dynamicId);
    });
  }
}
```

### 2. Input Value is Not Set Yet

When you pass an input value from a parent component, it might take some time for the value to be propagated to the child component. If you try to access the input value in `ngOnInit`, it might be `undefined`.

**Solution:** Use the `ngOnChanges` lifecycle hook to detect changes in the input value. When the input value changes, the `ngOnChanges` method will be called, allowing you to access the new value.

```typescript
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-example',
  template: '<p>Example works!</p>'
})
export class ExampleComponent implements OnChanges {
  @Input() dynamicId: string;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.dynamicId) {
      console.log(this.dynamicId);
      // Now you can use the dynamicId
    }
  }
}
```

### 3. Using a Resolver

Another approach is to use a route resolver to fetch the data before the component is initialized. This way, you can be sure that the data is available when the component is created.

**Solution:** Create a resolver service that fetches the data from the URL parameters, and then use the resolver in your route configuration.

```typescript
import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ExampleResolver implements Resolve<string> {
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): string {
    return route.params['id'];
  }
}
```

```typescript
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ExampleComponent } from './example/example.component';
import { ExampleResolver } from './example/example.resolver';

const routes: Routes = [
  {
    path: '',
    component: ExampleComponent,
    resolve: {
      dynamicId: ExampleResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
```

```typescript
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-example',
  template: '<p>Example works!</p>'
})
export class ExampleComponent implements OnInit {
  dynamicId: string;

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.dynamicId = this.route.snapshot.data.dynamicId;
    console.log(this.dynamicId);
  }
}
```

These solutions should help you access the required input value without getting `undefined` in `ngOnInit`. */
