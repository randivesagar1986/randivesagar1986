import { Component, inject, signal } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { Router, RouterLink } from '@angular/router';
import { SignUpService } from '../../services/signup.service';
import { AppService } from '../../services/app.service';
import { API_ERROR, FILL_ALL_REQUIRED_FIELD, INVLID_LOGIN_PASSWORD } from '../../constant/app.constant';

@Component({
  selector: 'app-login',
  imports: [FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})

export class LoginComponent {
    loginId:string = "";
    password:string = "";
    signUpService = inject(SignUpService);
    router = inject(Router);
    isErrorDisplay = signal(false);
    errorMessage = signal("");
    loggedUserData = signal(null);
    appService = inject(AppService);

    get isLoginUnable(){
      return this.loginId && this.password ? false : true
    }

    get errorDisplayOrNot(){
      return this.isErrorDisplay() ? {display:"block"} : {display:"none"}
    }

    errorDisplayNoneTimeout(msg:string){
      this.errorMessage.set(msg);
      setTimeout(() => {
        this.errorMessage.set("");
      }, 5000); // Shows error for 3 seconds
    }

    tokenCreation(){
      return `@@${this.loginId}$$`
    }

    onLogin(){
        if(this.loginId=="" || this.password==""){
          //alert("Please fill all required fields");
          this.errorDisplayNoneTimeout(FILL_ALL_REQUIRED_FIELD);
          return
        }else{
          this.signUpService.getLoginUser(this.loginId).subscribe({
            next : (res: any) => {
              console.log("loginUser", res);
              if(res?.id === this.loginId && res?.password === this.password){
                  this.signUpService.getLoginUserToken(this.loginId).subscribe((tokenData: any)=>{
                      console.log("tokenData", tokenData);
                      localStorage.setItem("loginUser", JSON.stringify(tokenData));
                      this.appService.setIsUserLoggedIn(true);
                      this.loggedUserData.set(tokenData);
                      this.router.navigateByUrl("/master");
                  })
              }else{
                this.errorDisplayNoneTimeout(INVLID_LOGIN_PASSWORD);
                this.isErrorDisplay.set(true);
                this.loginId = "";
                this.password = "";
              }
            },
            error : (error: Error) => {
              console.log("error", error?.message);
              this.isErrorDisplay.set(true);
              this.errorDisplayNoneTimeout(API_ERROR);
            },
            complete: () => {
              this.loginId = "";
              this.password = "";
            }
          })
        }
    }
}
