import { NgIf } from '@angular/common';
import { Component, inject } from '@angular/core';
import { RolesComponent } from '../roles/roles.component';
import { DesignationComponent } from '../designation/designation.component';
import { MasterService } from '../../services/master.service';
import { SHOW_LESS_COUNT } from '../../constant/app.constant';

@Component({
  selector: 'app-master',
  imports: [RolesComponent, DesignationComponent],
  templateUrl: './master.component.html',
  styleUrl: './master.component.css'
})
export class MasterComponent {
  masterService = inject(MasterService);
  /* constructor(private masterService:MasterService){

  } */
 showLessCount = SHOW_LESS_COUNT;
}
