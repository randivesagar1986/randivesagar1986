import { HttpClient } from '@angular/common/http';
import { Component, inject, input, OnInit, signal } from '@angular/core';
import { RoleDataType } from '../../model/app.model';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { catchError } from 'rxjs';
import { MasterService } from '../../services/master.service';
import { ErrorComponent } from '../error/error.component';
import { API_ERROR, NO_DATA } from '../../constant/app.constant';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrl: './roles.component.css',
  imports: [CommonModule, ErrorComponent, RouterLink],
})
export class RolesComponent implements OnInit{
    http = inject(HttpClient);
    roleList: RoleDataType[] = [];
    isDataFetching = signal(false);
    masterService = inject(MasterService)
    errorMessage = signal("");
    showLess = input<number>(0);

    ngOnInit() {
        this.getAllRoles();
    }

    getAllRoles() {
      this.isDataFetching.set(true);
        this.http.get<RoleDataType[]>("http://localhost:3000/roles").subscribe({
          next : (res: RoleDataType[]) => {
            console.log("response", res);
            if(this.showLess()){
              const lessData = res?.slice(0, this.showLess());
              this.roleList = lessData;
            }else{
              this.roleList = res;
            }
            this.isDataFetching.set(false);
            if(res?.length <=0){
              this.errorMessage.set(NO_DATA);
            }
          },
          error : (error: Error) => {
            console.log("error", error?.message);
            this.errorMessage.set(API_ERROR)
            this.isDataFetching.set(false);
          },
      })  
    }
}
