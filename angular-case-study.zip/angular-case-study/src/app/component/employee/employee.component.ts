import { NgFor, NgIf } from '@angular/common';
import { Component, inject, OnInit, signal } from '@angular/core';
import { EmployeeDataType } from '../../model/app.model';
import { EmployeeService } from '../../services/employee.service';
import { ErrorComponent } from "../error/error.component";
import { API_ERROR, NO_DATA } from '../../constant/app.constant';

@Component({
  selector: 'app-employee',
  imports: [NgFor, ErrorComponent],
  templateUrl: './employee.component.html',
  styleUrl: './employee.component.css'
})
export class EmployeeComponent implements OnInit {
      employeeService = inject(EmployeeService)
      EmployeeList: EmployeeDataType[] = [];
      errorMessage = signal<string>("");
      isDataFetching = signal(false);
      //any function which are returning observable type of data we can subscribe it using subscribe method.
      ngOnInit(): void {
        this.isDataFetching.set(true);
        this.employeeService.getAllEmployeeData().subscribe({
          next : (resEmployees: EmployeeDataType[]) => {
            this.EmployeeList = resEmployees;
            if(resEmployees.length <= 0){
              this.errorMessage.set(NO_DATA);
            }
          },
          error : (error: Error) => {
            this.errorMessage.set(API_ERROR);
            this.isDataFetching.set(false);
          },
          complete : () => {
            this.isDataFetching.set(false);
          }
        })
      }
}
