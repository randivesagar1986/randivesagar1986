import { Component, Input } from "@angular/core";


@Component({
    selector:"app-error",
    template:'<div class="ml-20"><span class="error">{{errorMsg}}</span></div>',
    styleUrl: "./error.component.css"
})

export class ErrorComponent{
    @Input() errorMsg!: string;
}