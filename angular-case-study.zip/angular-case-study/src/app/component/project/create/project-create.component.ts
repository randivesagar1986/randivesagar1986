import { Component, inject, OnInit, signal, viewChild } from "@angular/core";
import { FormsModule, NgForm } from "@angular/forms";
import { EmployeeService } from "../../../services/employee.service";
import { ClientService } from "../../../services/client.service";
import { ClientDataType, EmployeeDataType } from "../../../model/app.model";
import { ProjectService } from "../../../services/project.service";
import { Router } from "@angular/router";
import { MasterService } from "../../../services/master.service";
import { AlertComponent } from "../../modal/alert.component";

@Component({
    selector:"app-create-project",
    imports:[FormsModule, AlertComponent],
    templateUrl: "./project-create.component.html",
    styleUrl: "./project-create.component.css"
})

export class CreateProjectComponent implements OnInit{
    private form = viewChild.required<NgForm>('form');
    EmployeeList: EmployeeDataType[] = [];
    ClientList: ClientDataType[] = [];
    router = inject(Router);
    alertMessage = signal("");
    constructor(private employeeService: EmployeeService, private clientService: ClientService, private projectService: ProjectService, public masterService: MasterService){

    }
    createNewProject(formData: NgForm) {
        console.log("NgForm", formData);
        console.log("form", formData.form.value);
        console.log("employeeEmail", formData.form.controls?.["employeeEmail"]?.value)
        if(formData.invalid){
            console.log("Please enter valid data in all required fields.")
            return
        }
        let data = {
            ...formData.form.value,
            employeeId: formData.form.controls?.["employeeId"]?.value,
            employeeEmail: formData.form.controls?.["employeeEmail"]?.value,
            clientId: formData.form.controls?.["clientId"]?.value,
            clientEmail: formData.form.controls?.["clientEmail"]?.value,
        }
        this.projectService.createNewProject(data).subscribe({
            next : (resClients: any) => {
                console.log("resClients", resClients);
                this.router.navigateByUrl("/project")
              },
              error : (error:Error) => {
                console.log("error", error?.message);
                this.alertMessage.set(error?.message);
                this.masterService.closeOpenAlertModal(true);
                //this.isError.set(true);
              },
              complete: () => {
                this.form().reset();
              }
        })
        //formData.form.reset();
    }

    ngOnInit(): void {
        this.fetchEmployeeData();
        this.fetchClientData();
    }

    fetchEmployeeData(){
        this.employeeService.getAllEmployeeData().subscribe({
            next : (resEmployees: EmployeeDataType[]) => {
                this.EmployeeList = resEmployees;
            },
            error : (error: Error) => {
            
            },
            complete : () => {
            
            }
        })
    }

    fetchClientData(){
        this.clientService.getAllClients().subscribe({
            next : (resEmployees: ClientDataType[]) => {
                this.ClientList = resEmployees;
            },
            error : (error: Error) => {
            
            },
            complete : () => {
            
            }
        })
    }

    changeEmployeeNameField(employeeName: string){
        const selectedEmp = this.EmployeeList?.find((employee)=>{
            return employee.empName.toLowerCase() === employeeName.toLowerCase();
        })

        this.form()?.controls?.["employeeId"]?.setValue(selectedEmp?.id);
        this.form()?.controls?.["employeeEmail"]?.setValue(selectedEmp?.emailId);
    }
       
    changeClientNameField(clientName: string){
        const selectedClient = this.ClientList?.find((client)=>{
            return client.clientName.toLowerCase() === clientName.toLowerCase();
        })

        this.form()?.controls?.["clientId"]?.setValue(selectedClient?.id);
        this.form()?.controls?.["clientEmail"]?.setValue(selectedClient?.clientEmail);
    }

}
    