import { Component, inject, OnInit, signal } from '@angular/core';
import { ProjectService } from '../../services/project.service';
import { ProjectDataType } from '../../model/app.model';
import { NgFor } from '@angular/common';
import { API_ERROR, NO_DATA } from '../../constant/app.constant';
import { ErrorComponent } from "../error/error.component";

@Component({
  selector: 'app-project',
  imports: [NgFor, ErrorComponent],
  templateUrl: './project.component.html',
  styleUrl: './project.component.css'
})
export class ProjectComponent implements OnInit{
    projectService = inject(ProjectService)
    projectList: ProjectDataType[] = [];
    errorMessage = signal<string>("");
    isDataFetching = signal(false);
    //any function which are returning observable type of data we can subscribe it using subscribe method.
    ngOnInit(): void {
      this.isDataFetching.set(true);
      this.projectService.getAllProjects().subscribe({
        next : (resProjects: ProjectDataType[]) => {
          this.projectList = resProjects;
          if(resProjects.length <= 0){
            this.errorMessage.set(NO_DATA)
          }
        },
        error : (error: Error) => {
          this.errorMessage.set(API_ERROR);
          this.isDataFetching.set(false);
        },
        complete : () => {
          this.isDataFetching.set(false);
        }
      })
    }
}
