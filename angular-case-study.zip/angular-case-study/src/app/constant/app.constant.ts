export const API_ERROR = "Some error occured, try after some time.";
export const NO_DATA = "No data found!";
export const CLIENT_SUCCESS_DELETE_ALERT = "Client data successfully delete.";
export const SHOW_LESS_COUNT = 3;
export const FILL_ALL_REQUIRED_FIELD = "Please fill all required fields.";
export const INVLID_LOGIN_PASSWORD = "Invalid login id and password";