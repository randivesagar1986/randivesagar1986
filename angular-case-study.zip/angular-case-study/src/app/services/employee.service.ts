import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDataType } from '../model/app.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  constructor(private http: HttpClient) {};

  getAllEmployeeData():Observable<EmployeeDataType[]>{
    return this.http.get<EmployeeDataType[]>("http://localhost:3000/employees")
  }
}
