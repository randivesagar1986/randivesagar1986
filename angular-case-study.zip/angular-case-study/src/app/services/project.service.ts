import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDataType, ProjectDataType } from '../model/app.model';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  constructor(private http: HttpClient) {};

  getAllProjects():Observable<ProjectDataType[]>{
    return this.http.get<ProjectDataType[]>("http://localhost:3000/projects")
  }

  createNewProject(projectDetails:ProjectDataType){
        return this.http.post("http://localhost:3000/projects", projectDetails)
  }
}
