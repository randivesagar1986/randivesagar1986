// url-service.ts
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class UrlService {
  private _id: number;

  constructor(private route: ActivatedRoute) {
    this._id = this.route.snapshot.params['_id'];
  }

  get id(): number {
    return this._id;
  }
}