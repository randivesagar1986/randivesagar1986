import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ClientDataType } from '../model/app.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  constructor(private http: HttpClient) {};

  getAllClients():Observable<ClientDataType[]>{
      return this.http.get<ClientDataType[]>("http://localhost:3000/clients")
  }

  createNewClient(clientDetails:ClientDataType){
      return this.http.post("http://localhost:3000/clients", clientDetails)
  }

  deleteClient(clientId:string){
      return this.http.delete(`http://localhost:3000/clients/${clientId}`)
  }
}
