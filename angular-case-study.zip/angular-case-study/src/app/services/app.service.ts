import { inject, Injectable, signal } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";

@Injectable({providedIn: "root"})
export class AppService {
    isUserLoggedIn = signal(!!localStorage.getItem("loginUser"));
    router = inject(Router);
    activateRoute = inject(ActivatedRoute);
    currentPathSegment = signal(this.activateRoute.snapshot.url.map(segment => segment.path))

    get getCurrentPath(){
        return this.router.url;
    }
    setIsUserLoggedIn(isLogged:boolean){
        this.isUserLoggedIn.set(isLogged);
    }
}