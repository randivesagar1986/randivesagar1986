import { HttpClient } from '@angular/common/http';
import { Injectable, signal } from '@angular/core';
import { Observable } from 'rxjs';
import { DesigantionDataType } from '../model/app.model';

@Injectable({
  providedIn: 'root'
})
export class MasterService {
  activeTab = signal("role");
  isAlertModelOpen = signal(false);
  constructor(private http: HttpClient) { }

  selectTabClick(tabName:string) {
    this.activeTab.set(tabName);
  }

  getDesignation():Observable<DesigantionDataType[]> {
    return this.http.get<DesigantionDataType[]>("http://localhost:3000/designation")
  }

  getDesignationInfo(designationId: string):Observable<DesigantionDataType> {
    return this.http.get<DesigantionDataType>(`http://localhost:3000/designation/${designationId}`)
  }

  displayStyle(isModelOpen: boolean){
    //this.isAlertModelOpen.set(isModelOpen)
    return isModelOpen ? {display: "block"} : {display: "none"}
  }

  modalOpenCloseStyle(){
    //this.isAlertModelOpen.set(isModelOpen)
    return this.isAlertModelOpen() ? {display: "block"} : {display: "none"}
  }

  closeOpenAlertModal(isOpen:boolean){
    this.isAlertModelOpen.set(isOpen);
  }
}
