import { inject, Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { signUpData } from "../model/app.model";
import { HttpClient } from "@angular/common/http";

@Injectable({providedIn: "root"})
export class SignUpService {
    http = inject(HttpClient)
    createNewAccount(data:any):Observable<any>{
        return this.http.post<any>("http://localhost:3000/users", data);
    }

    getAllUser(){
        return this.http.get("http://localhost:3000/users");
    }

    getLoginUser(loginId:string){
        return this.http.get(`http://localhost:3000/users/${loginId}`);
    }

    getLoginUserToken(loginId:string){
        return this.http.get(`http://localhost:3000/login/${loginId}`);
    }

    createLogin(data:any){
        return this.http.post("http://localhost:3000/login", data);
    }

    onUserLogin(data:any){
        return this.http.post<any>("http://localhost:3000/login", data);
    }
}