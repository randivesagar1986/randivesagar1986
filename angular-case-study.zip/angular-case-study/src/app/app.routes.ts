import { Routes } from '@angular/router';
import { RolesComponent } from './component/roles/roles.component';
import { DesignationComponent } from './component/designation/designation.component';
import { MasterComponent } from './component/master/master.component';
import { EmployeeComponent } from './component/employee/employee.component';
import { ClientComponent } from './component/client/client.component';
import { CreateClientComponent } from './component/client/create/create-client.component';
import { ProjectComponent } from './component/project/project.component';
import { CreateProjectComponent } from './component/project/create/project-create.component';
import { SignupComponent } from './component/signup/signup.component';
import { LoginComponent } from './component/login/login.component';
import { AppGuard } from './app.guard';
import { InfoComponent } from './component/designation/info/info.component';

export const routes: Routes = [
    {
        path: "",
        redirectTo: ()=>{
            const loginUser = localStorage.getItem("loginUser");
            if(loginUser){
                return "/master"
            }
            return "/login"
        },
        pathMatch: "full",

    },
    {
        path: "signup",
        component: SignupComponent,
        pathMatch: "full",
    },
    {
        path: "login",
        component: LoginComponent,
        pathMatch: "full"
    },
    {
        path: "master",
        component: MasterComponent,
        pathMatch: "full",
    },
    {
        path: "roles",
        component: RolesComponent,
        pathMatch: "full",
        canActivate:[AppGuard]
    },
    {
        path: "designation",
        component: DesignationComponent,
        pathMatch: "full",
        canActivate:[AppGuard]
    },
    {
        path: "designation/:designationId",
        component: InfoComponent,
        pathMatch: "full",
        canActivate:[AppGuard]
    },
    {
        path: "employee",
        component: EmployeeComponent,
         pathMatch: "full",
         canActivate:[AppGuard]
    },
    {
        path: "client",
        component: ClientComponent,
        pathMatch: "full",
        canActivate:[AppGuard]
    },
    {
        path: "client/create",
        component: CreateClientComponent,
        pathMatch: "full",
        canActivate:[AppGuard]
    },
    {
        path: "project",
        component: ProjectComponent,
        pathMatch: "full",
        canActivate:[AppGuard]
    },
    {
        path: "project/create",
        component: CreateProjectComponent,
        pathMatch: "full",
        canActivate:[AppGuard]
    }
];
