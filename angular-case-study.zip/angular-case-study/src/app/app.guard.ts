import { inject, Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from "@angular/router";

@Injectable({providedIn: 'root'})
export class AppGuard {
    router = inject(Router);
    canActivate(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ) {
        if(!localStorage.getItem("loginUser")){
            this.router.navigateByUrl("/login");
            return false;
        }

        return true;
    }
}