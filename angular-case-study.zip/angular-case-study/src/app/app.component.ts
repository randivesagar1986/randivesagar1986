import { Component, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import {MatSidenavModule} from '@angular/material/sidenav';
import {  MatListModule } from "@angular/material/list";
import {MatIconModule} from '@angular/material/icon';
import { MatToolbarModule } from "@angular/material/toolbar";
import {MatMenuModule} from '@angular/material/menu';
import { MasterService } from './services/master.service';
import { AppService } from './services/app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  imports: [MatSidenavModule, MatListModule, MatIconModule, MatToolbarModule, RouterOutlet, RouterLink, RouterLinkActive, MatMenuModule]
})

export class AppComponent {
  //sidenav: any;
  /* public masterService:MasterService
  constructor(masterService: MasterService){
    this.masterService = masterService
  } */

  activeLink = signal("");
  
  constructor(public masterService: MasterService, private router: Router, public appService: AppService){};

  selectedLink(link:string) {
    this.activeLink.set(link);
  }

  onLogout(){
    console.log("currentPath", this.router.url)
    localStorage.setItem("loginUser", "");
    console.log("router", this.router);
    this.appService.setIsUserLoggedIn(false);
    this.router.navigateByUrl("/login");
  }
}
